# Inspec — Gestão inteligente de inspeções

PWA para inspeção de equipamentos de emergência (extintores, hidrantes, macas, chuveiros/lava-olhos e categorias personalizadas): QR Code em cada ponto, checklist no celular mesmo sem internet, comunicados de desvio com One Page, painel de gestão, relatórios em PDF/Excel e auditoria completa.

**Versão:** app 1.5.2 · banco 1.5.1 · produção em https://inspec.rwnitsolutions.com.br
**Autor:** Robert William V. Nascimento · [rwnitsolutions.com.br](https://rwnitsolutions.com.br) — todos os direitos reservados.

> ⚠️ **Mantenha este repositório PRIVADO.** `app/data/carga_inicial.json` contém dados reais da operação (pontos, locais e nomes de bombeiros responsáveis), e o workflow de backup gera cópias do banco.

## Estrutura

```text
├── app/                     site publicado na Cloudflare Pages (envie o CONTEÚDO desta pasta)
│   ├── config.js            ÚNICO arquivo editável: URL do Supabase + Publishable key (pública por design)
│   ├── index.html · sw.js · manifest.webmanifest · _headers (CSP) · _redirects (/Q/<ID>)
│   ├── js/                  módulos ES (core, db, dados, ui, qr, pwa, versoes) + views/
│   ├── css/ · img/ · icons/ · data/carga_inicial.json
│   └── vendor/              supabase-js, jsQR, qrcode-generator, jsPDF 4.2.1, SheetJS 0.20.3 + LICENCAS.txt
├── supabase/
│   ├── inspec-completo.sql  banco completo e idempotente (instalação nova)
│   ├── atualizar-1.5.1.sql  atualização de um banco 1.5 → 1.5.1
│   ├── testes_rls.sql       13 blocos de testes de segurança (rodar com "Run without RLS")
│   ├── functions/           Edge Functions (CLI): criar-usuario, excluir-usuario, enviar-onepage
│   └── functions_painel/    as mesmas funções em arquivo único, para colar no painel
├── workers/heartbeat/       Cloudflare Worker (cron diário) que mantém o Supabase Free ativo
├── .github/workflows/       backup semanal do banco (pg_dump)
├── docs/                    Documento Técnico, Guia de Uso, Parecer Legal e de Segurança, Flyer
├── testes/                  ambiente Supabase simulado + testes ponta a ponta (Playwright)
└── DEPLOY.md                passo a passo de produção e de atualização
```

## Publicar / atualizar
Siga o **[DEPLOY.md](DEPLOY.md)**. Resumo de uma atualização de site: acrescente a versão no topo de `app/js/versoes.js`, use o mesmo número em `app/sw.js` (`VERSAO`) e envie o conteúdo de `app/` para a Cloudflare Pages.

## Segurança
- **Nunca** coloque a Secret key do Supabase (`sb_secret_…`), a chave da Resend ou a URL do banco em arquivos deste repositório. Elas ficam só nos *secrets* das Edge Functions, do Worker e do GitHub Actions (`SUPABASE_DB_URL`).
- A Publishable key em `app/config.js` é pública por design; a proteção dos dados está na RLS do banco.
- Detalhes, riscos e plano de ação: `docs/Inspec_Parecer_Legal_e_Seguranca_v1.1.pdf`.

## Licenças de terceiros
Ver `app/vendor/LICENCAS.txt` (MIT, Apache-2.0 e SIL OFL 1.1 — todas permitem uso comercial).
