# Inspec v1.0 — Passo a passo para subir em PRODUÇÃO

Domínio: **https://inspec.rwnitsolutions.com.br**
Tempo estimado: cerca de 1h30. Siga a ordem abaixo. O Supabase vem primeiro porque o site precisa da URL e da chave dele.

| Parte | O que faz | Tempo |
|---|---|---|
| A | Banco no Supabase (SQL único, autenticação, bucket de fotos) | 20 min |
| B | Edge Functions (criar e excluir usuários, e-mail do One Page) | 15 min |
| C | Configurar o `config.js` do site | 2 min |
| D | Publicar o site na Cloudflare Pages + domínio | 15 min |
| E | Primeiro acesso: criar a organização e fazer a carga dos 814 pontos | 10 min |
| F | Equipe, responsáveis, reserva, destinatários e etiquetas QR | 20 min |
| G | Heartbeat diário (evita a pausa do plano gratuito) | 10 min |
| H | Backup semanal (GitHub Actions) | 10 min |
| I | Testes de aceite antes de liberar para a equipe | 15 min |

**Você vai precisar de:**
- conta Cloudflare com a zona `rwnitsolutions.com.br`;
- conta Supabase;
- conta Resend (e-mail do One Page; plano gratuito);
- Node.js 20 ou superior no computador (usado só nas Partes B e G-terminal);
- a pasta `inspec/` deste pacote.

> **Regra de ouro das chaves**
> - A **Publishable key** (`sb_publishable_…`) é pública por design e vai no `config.js`.
> - A **Secret key** (`sb_secret_…`, a antiga service_role) só entra como *secret* das Edge Functions (Parte B).
> - A Secret key nunca vai em arquivo do site, zip, Git, e-mail, chat ou Worker.

---

## Parte A — Supabase: banco, autenticação e fotos

1. Crie o projeto: **supabase.com/dashboard → New project**.
   - Name: `inspec`.
   - Region: **South America (São Paulo)**.
   - Gere uma senha forte do banco e guarde num cofre de senhas.
2. Abra `inspec/supabase/inspec-completo.sql` num editor de texto. Na **seção 13 (BOOTSTRAP)**, no fim do arquivo, troque `SEU-EMAIL@exemplo.com.br` pelo **seu e-mail**, que será o owner (primeiro administrador).
3. Rode o SQL: **SQL Editor → New query** → cole o arquivo inteiro → **Run**. Deve terminar em *Success*.
4. Clique **Run** de novo. Deve terminar sem erro de novo: o script é idempotente.
5. Rode os testes: **New query** → cole `inspec/supabase/testes_rls.sql` → **Run**.
   - O resultado precisa mostrar **TODOS OS TESTES PASSARAM**.
   - O teste roda dentro de uma transação desfeita no fim (ROLLBACK) e não deixa nada gravado.
6. **Authentication → Sign In / Providers → Email**:
   - deixe o Email habilitado;
   - **desligue "Allow new users to sign up"**, porque só o administrador cria usuários;
   - em "Confirm email", tanto faz: os usuários são criados já confirmados.
   - Senha mínima: 8 caracteres.
7. **Authentication → URL Configuration**:
   - Site URL: `https://inspec.rwnitsolutions.com.br`
   - Redirect URLs: `https://inspec.rwnitsolutions.com.br/**`
   - Esses endereços são usados pelo link de "Esqueci minha senha".
8. **Authentication → Users → Add user → Create new user**:
   - e-mail: o mesmo do passo 2;
   - senha forte;
   - marque **Auto Confirm User**.
9. **Project Settings → API Keys**: anote a **Project URL** (`https://xxxx.supabase.co`) e a **Publishable key**.
10. **Storage**: confira que o bucket **`fotos`** existe e está **Private**.

## Parte B — Edge Functions (obrigatório: sem elas não é possível criar usuários)

Feito todo pelo painel do Supabase, sem terminal. Use os arquivos da pasta `supabase/functions_painel/`: cada função está num arquivo único, pronto para colar.

**B1. Secrets** — Supabase → **Edge Functions → Secrets** → adicione:

| Nome | Valor |
|---|---|
| `SERVICE_KEY` | a **Secret key** (`sb_secret_…`) de Project Settings → API Keys. Cole só aqui. |
| `APP_DOMINIO` | `https://inspec.rwnitsolutions.com.br` |
| `EMAIL_KEY` | API key do Resend (pode ficar para depois) |
| `EMAIL_FROM` | `Inspec <inspec@rwnitsolutions.com.br>` |

**B2. Criar as 3 funções** — **Edge Functions → Deploy a new function → Via Editor**, uma de cada vez:

1. Nome **exatamente** `criar-usuario` → apague o código de exemplo → cole `functions_painel/criar-usuario/index.ts` → **Deploy**.
2. Repita para `excluir-usuario` e `enviar-onepage`.

**B3. Verificação de JWT** — em cada função → **Details/Settings** → desligue **"Enforce JWT verification" / "Verify JWT"** → Save.
As funções verificam o usuário por conta própria (consultam o Auth e exigem administrador ativo). A verificação automática do gateway é incompatível com as novas chaves do Supabase e bloquearia o app.

**B4. E-mail (Resend)** — em resend.com → Domains → adicione `rwnitsolutions.com.br`, crie na Cloudflare os registros SPF/DKIM indicados e aguarde *Verified*. Até lá o One Page pode ser baixado em PDF; o envio por e-mail fica recusado com mensagem clara.

> Alternativa por terminal (opcional): `npx supabase functions deploy <nome> --use-api --no-verify-jwt` a partir da pasta `inspec/`, usando `supabase/functions/`.

## Parte C — `config.js` (o único arquivo do site que você edita)

Abra `inspec/app/config.js` e preencha:

```js
SUPABASE_URL: 'https://xxxx.supabase.co',
SUPABASE_KEY: 'sb_publishable_...',
```

- Não mexa nas outras linhas.
- `DOMINIO_QR` é o endereço gravado nas etiquetas: mantenha `HTTPS://INSPEC.RWNITSOLUTIONS.COM.BR/Q/`.

## Parte D — Cloudflare Pages + domínio

1. **dash.cloudflare.com → Workers & Pages → Create → Pages → Upload assets**.
   - Project name: `inspec`.
   - Se o projeto `inspec` já existir (do protótipo), abra-o e use **Create deployment**: a versão de produção substitui o protótipo no mesmo endereço.
2. Arraste **o conteúdo da pasta `app/`** (já com o `config.js` preenchido) → **Deploy**.
   - `index.html`, `_headers`, `_redirects`, `sw.js` e `config.js` precisam ficar **na raiz** do upload, e não dentro de uma subpasta `app/`.
3. **Custom domains → Set up a custom domain** → `inspec.rwnitsolutions.com.br` → **Activate domain**.
   - A Cloudflare cria o CNAME sozinha.
   - Aguarde o status *Active*.
4. Abra `https://inspec.rwnitsolutions.com.br`. Deve aparecer a tela de login.
   - Se aparecer o aviso "Configuração pendente", o `config.js` não foi preenchido.

> O `_headers` aplica a política de segurança (CSP): o site só conversa com o próprio domínio e com `*.supabase.co`, e não aceita scripts de terceiros.

## Parte E — Primeiro acesso (owner)

1. Entre com o e-mail e a senha do passo A8.
2. A tela **"Primeiro acesso do administrador"** aparece porque o seu e-mail está no convite do SQL. Preencha:
   - Organização (ex.: *Bombeiros Civis SESI — ArcelorMittal*);
   - Unidade (ex.: *Juiz de Fora*);
   - seu nome.
3. O app abre em **Administração → Importação**. Clique em **Ver prévia da carga inicial** e depois em **Importar 814 pontos novos**.
   - Cada ponto recebe um **QR único** gerado pelo banco.
   - A importação pode ser repetida sem duplicar nada.
   - Os 20 avisos da conversão da planilha aparecem na prévia: agentes fora da lista do Forms foram importados como "Outra" e ficam marcados para conferência.

## Parte F — Deixar pronto para a equipe

1. **Administração → Equipe → Criar usuário**, para cada bombeiro (perfil *Inspetor*) e para os gestores (perfil *Consulta*).
   - O sistema mostra uma **senha provisória** uma única vez: repasse por canal seguro.
   - No 1º acesso, a pessoa é obrigada a trocar a senha.
   - Somente o owner cria usuários com perfil *Administrador*.
2. **Equipe → Vincular responsáveis**: associe cada nome da planilha (Glauco, Franciele, Rosana, Flávio, Samuel, Cláudio) ao usuário dele. Isso ativa o filtro "Meus pontos".
3. **Reserva técnica → Entrada / inventário**: lance o estoque atual de cada agente e o mínimo.
4. **Destinatários**: cadastre quem recebe o One Page (Gerência da área, SST etc.). Pode ser por gerência ou para todas.
5. **Configurações → Evidência fotográfica**: o padrão é foto obrigatória só em NC (economiza armazenamento).
6. **Pontos e etiquetas → Etiquetas QR**:
   - escolha "Ainda não impressas" e o modelo de folha (Pimaco A4263 por padrão);
   - abra e imprima **em 100%**, sem "ajustar à página";
   - ao clicar em Imprimir, o app marca as etiquetas como impressas.
   - Comece por uma gerência e teste a leitura antes de imprimir tudo.

## Parte G — Heartbeat (impede a pausa de 7 dias do Supabase Free)

1. Cloudflare → **Workers & Pages → Create → Worker** → nome `inspec-heartbeat` → **Deploy** → **Edit code**.
2. Cole `inspec/workers/heartbeat/index.js` → **Deploy**.
3. **Settings → Variables and Secrets**:
   - `SUPABASE_URL` (Text) = Project URL;
   - `SUPABASE_KEY` (Secret) = **Publishable key**;
   - `HEARTBEAT_TESTE` (Secret) = uma palavra qualquer.
4. **Settings → Triggers → Cron Triggers → Add**: `0 11 * * *` (08:00 em Brasília).
5. Teste: abra `https://inspec-heartbeat.<sua-conta>.workers.dev/?chave=<HEARTBEAT_TESTE>`. A resposta deve ser `{"ok":true,…}`.
6. No app, **Administração → Backup e uso → Consultar uso** passa a mostrar o tamanho do banco e das fotos.

## Parte H — Backup semanal do banco

1. Crie um repositório **privado** no GitHub e suba a pasta `inspec/`. O `.gitignore` já bloqueia segredos; o `config.js` só tem a chave pública.
2. No Supabase, abra **Connect → Session pooler** e copie a connection string, trocando `[YOUR-PASSWORD]` pela senha do banco.
3. No GitHub: **Settings → Secrets and variables → Actions → New repository secret** → `SUPABASE_DB_URL`.
4. **Actions → backup-semanal → Run workflow**. O artefato `inspec-backup` deve aparecer.
5. Complemento mensal: **Administração → Backup e uso → Backup em Excel / JSON**.

## Parte I — Testes de aceite (faça antes de liberar)

| # | Teste | Esperado |
|---|---|---|
| 1 | Login de um inspetor com a senha provisória | Pede troca de senha e depois abre o Início com as pendências |
| 2 | Câmera comum do celular lendo uma etiqueta | Abre o app no ponto certo |
| 3 | Inspeção conforme pelo leitor de QR do app | Aparece no Histórico e o ponto sai das pendências |
| 4 | Inspeção com NC + foto | Aparece em **NCs** e a foto abre na ficha do ponto |
| 5 | Modo avião → inspeção → desligar o modo avião | O selo mostra "1 na fila" e depois "Online"; o registro chega ao servidor |
| 6 | Ficha do ponto → Registrar troca (origem Reserva) | Troca no histórico; reserva −1 |
| 7 | Comunicado de desvio com substituição | Número CD-AAAA-NNNN; One Page em PDF; e-mail enviado (após o Resend estar verificado) |
| 8 | Instalar no celular ("Adicionar à tela inicial") e abrir em modo avião | O app abre com os dados salvos |
| 9 | Login com perfil Consulta | Vê painel, NCs e relatórios; não consegue inspecionar nem administrar |
| 10 | Relatórios → consolidado e planilhas Excel | Abrem e baixam corretamente |

---

## Atualizações futuras

- **Nova versão do site:**
  1. Edite os arquivos.
  2. Acrescente uma linha no topo de `app/js/versoes.js` (número, data e o que mudou). É o que aparece em **Menu → Sobre o sistema**.
  3. Use **o mesmo número** em `app/sw.js` (`VERSAO = 'inspec-v1.1.1'`, por exemplo).
  4. No projeto Pages → **Create deployment** → envie o conteúdo de `app/`.
  - Os aparelhos baixam a versão nova sozinhos e mostram "Nova versão instalada — Recarregar agora". Em **Sobre o sistema → Procurar atualização** dá para forçar a verificação.
- **Rollback:** Pages → **Deployments** → versão anterior → **Rollback to this deployment**.
- **Banco:** o `inspec-completo.sql` pode ser rodado de novo para aplicar correções (é idempotente e não apaga dados).
- Publique fora do horário de inspeção e evite os dois últimos dias do ciclo mensal.

### Atualizar para a v1.5.2 (quem já está na v1.5)

A v1.5.2 só muda o site (nomes e ordem do menu). Quem já rodou o `atualizar-1.5.1.sql` só precisa publicar o `Inspec_site_CloudflarePages_v1.5.2.zip`. Quem ainda está na v1.5 segue os passos abaixo e publica o zip da v1.5.2 no passo 3.

#### Passos da v1.5.1

1. **Banco:** Supabase → SQL Editor → New query → cole o `supabase/atualizar-1.5.1.sql` inteiro → **Run** (não precisa de e-mail; pode rodar mais de uma vez). Cria a tabela `acessos` (registros de acesso com IP) e atualiza as funções de evento. Confira em **Sobre o sistema** → Versão do banco = **v1.5.1**. (Instalação nova continua sendo pelo `inspec-completo.sql`.)
2. **Testes (opcional):** rode `supabase/testes_rls.sql` com **Run without RLS** — deve terminar em "TODOS OS TESTES PASSARAM" (agora com os testes dos registros de acesso).
3. **Site:** Pages → **Create deployment** → envie o `Inspec_site_CloudflarePages_v1.5.2.zip` (o `config.js` já vai preenchido).
4. Edge Functions e secrets **não mudam**.

> **Origem das bibliotecas atualizadas** (`app/vendor`): jsPDF 4.2.1 veio do pacote oficial `jspdf` do npm. O SheetJS 0.20.3 oficial é distribuído só pelo CDN da SheetJS (cdn.sheetjs.com), que não estava acessível no ambiente de build; o arquivo veio do espelho npm `@e965/xlsx@0.20.3`, que republica o build oficial sem alterações. Para conferir, baixe `https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.mini.min.js` e compare o SHA-256 com o do pacote: `0cb353f830d7288385492c83d277b058ddeac664ca51cf1393aa1fd3e2b70939`. Se for diferente, use o arquivo do CDN oficial.

## Problemas comuns

| Sintoma | Causa provável |
|---|---|
| Aviso "Configuração pendente" no login | O `config.js` não foi preenchido ou não foi enviado na raiz |
| "Sem convite de bootstrap" no primeiro acesso | O e-mail do passo A2 é diferente do usuário criado no passo A8; corrija na tabela `convites` |
| "Criar usuário" falha com "Secret SERVICE_KEY não configurado" | A Parte B ficou incompleta |
| Link "Esqueci minha senha" cai em página errada | As URL Configuration do passo A7 não foram ajustadas |
| E-mail do One Page recusado | O domínio no Resend ainda não está verificado, ou `EMAIL_KEY` / `EMAIL_FROM` estão errados |
| Celular continua na versão antiga | `VERSAO` do `sw.js` não foi alterada; feche e reabra o app |
