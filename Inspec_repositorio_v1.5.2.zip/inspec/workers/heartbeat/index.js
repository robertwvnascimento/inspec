// Inspec — heartbeat diário: mantém o projeto Supabase Free ativo e grava o consumo (uso_diario)
export default {
  async scheduled(event, env, ctx) {
    ctx.waitUntil(bater(env));
  },
  // permite testar no navegador: https://inspec-heartbeat.<sua-conta>.workers.dev/?chave=<HEARTBEAT_TESTE>
  async fetch(req, env) {
    const u = new URL(req.url);
    if (!env.HEARTBEAT_TESTE || u.searchParams.get('chave') !== env.HEARTBEAT_TESTE) return new Response('ok');
    return new Response(JSON.stringify(await bater(env)), { headers: { 'Content-Type': 'application/json' } });
  }
};

async function bater(env) {
  const r = await fetch(`${env.SUPABASE_URL}/rest/v1/rpc/heartbeat`, {
    method: 'POST',
    headers: { apikey: env.SUPABASE_KEY, 'Content-Type': 'application/json' },
    body: '{}'
  });
  const corpo = await r.text();
  if (!r.ok) throw new Error(`heartbeat falhou: ${r.status} ${corpo}`);   // aparece nos logs do Worker
  return JSON.parse(corpo);
}
