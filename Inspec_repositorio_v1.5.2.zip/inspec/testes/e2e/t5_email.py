from base import *
import subprocess
def sql(q): return subprocess.run(['psql','-h','/tmp','-p','54329','-U','postgres','-d','inspecprod','-At','-c',q],capture_output=True,text=True).stdout.strip()
with sync_playwright() as p:
    b, ctx, pg = novo(p, mobile=True)
    login(pg, 'glauco@inspec.local', 'Glauco2026x'); esperar_app(pg)
    pg.goto(URL + '/#/desvio/' + sql("select id from desvios where numero='CD-2026-0001'")); pg.wait_for_selector('[data-action="dv-email"]'); pg.wait_for_timeout(800)
    pg.click('[data-action="dv-email"]'); pg.wait_for_timeout(6000); print('toast:', pg.inner_text('#toast')); print('db:', sql("select status, erro from envios_email"))
    pg.screenshot(path='m11_email.png', full_page=True)
    b.close()
