from base import *
FAKE = """() => { const ev = new Event('beforeinstallprompt'); ev.prompt = () => { window.__promptou = true; }; ev.userChoice = Promise.resolve({ outcome: 'accepted' }); window.dispatchEvent(ev); }"""
with sync_playwright() as p:
    b, ctx, pg = novo(p, mobile=True)
    pg.goto(URL + '/'); pg.wait_for_selector('#lg-email'); pg.wait_for_timeout(1500)
    pg.evaluate(FAKE); pg.wait_for_timeout(400); print('login install btn:', pg.locator('[data-action="pwa-instalar"]').count())
    pg.screenshot(path='p1_login.png')
    login(pg, 'owner@inspec.local', 'Senha123!'); esperar_app(pg); pg.wait_for_timeout(2500)
    pg.evaluate(FAKE); pg.wait_for_timeout(500); print('painel card:', pg.locator('.install-card').count())
    pg.screenshot(path='p2_painel.png')
    pg.goto(URL + '/#/menu'); pg.wait_for_timeout(600); print('menu install:', pg.locator('#view [data-action="pwa-instalar"]').count())
    pg.click('a[href="#/sobre"]'); pg.wait_for_timeout(2500)
    pg.screenshot(path='p3_sobre.png', full_page=True)
    print('off:', pg.inner_text('#sb-off'), '| db:', pg.inner_text('#sb-db'), '| esp:', pg.inner_text('#sb-esp'))
    pg.click('[data-action="sb-atualizar"]'); pg.wait_for_timeout(3000); print('upd:', pg.inner_text('#sb-upd'))
    pg.click('#view [data-action="pwa-instalar"]'); pg.wait_for_timeout(500); print('prompt chamado:', pg.evaluate('window.__promptou'), '| toast:', pg.inner_text('#toast'))
    print('ERROS', [e for e in erros() if 'TUNNEL' not in e])
    b.close()
