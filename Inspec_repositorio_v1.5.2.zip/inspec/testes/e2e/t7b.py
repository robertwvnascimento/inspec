from base import *
with sync_playwright() as p:
    b, ctx, pg = novo(p, mobile=True)
    login(pg, 'owner@inspec.local', 'Senha123!'); esperar_app(pg); pg.wait_for_timeout(2500)
    pg.goto(URL + '/#/sobre'); pg.wait_for_timeout(1500)
    pg.click('[data-action="sb-atualizar"]')
    for i in range(8):
        pg.wait_for_timeout(700); print(i, pg.inner_text('#sb-upd')[:80], '|', pg.inner_text('#toast')[:80])
    print(erros())
    b.close()
