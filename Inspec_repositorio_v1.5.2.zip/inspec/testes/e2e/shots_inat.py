exec(open('shots.py').read().split("sql(\"update membros")[0])
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 390, 'height': 844}, device_scale_factor=2); pg = ctx.new_page()
    pg.clock.install(); pg.goto(URL + '/'); pg.wait_for_selector('#lg-email')
    pg.fill('#lg-email', 'glauco@inspec.local'); pg.fill('#lg-senha', 'Glauco2026x'); pg.click('#lg-btn'); pg.wait_for_selector('#view', timeout=30000); pg.wait_for_timeout(2000)
    pg.clock.fast_forward('04:38'); pg.clock.run_for(5000); pg.wait_for_timeout(400); shot(pg, 'i_aviso_inatividade')
    pg.clock.fast_forward('00:30'); pg.clock.run_for(6000); pg.wait_for_timeout(2000); shot(pg, 'i_sessao_encerrada')
    b.close()
