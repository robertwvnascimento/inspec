from base import *
with sync_playwright() as p:
    for email, senha, mobile, nome in [('owner@inspec.local','Senha123!',False,'owner'),('glauco@inspec.local','Glauco2026x',False,'insp_desk'),('glauco@inspec.local','Glauco2026x',True,'insp_mob'),('consulta@inspec.local','Consulta2026',True,'leit_mob')]:
        b, ctx, pg = novo(p, mobile=mobile); login(pg, email, senha); esperar_app(pg); pg.wait_for_timeout(1500)
        sel = '#bottom-nav' if mobile else '#side-nav'
        print(nome, '|', pg.inner_text(sel).replace('\n', ' · '))
        if nome == 'owner':
            pg.goto(URL + '/#/historico'); pg.wait_for_timeout(800); print('  título historico:', pg.inner_text('header h1, .topbar h1, #titulo').split('\n')[0] if pg.locator('header h1, .topbar h1, #titulo').count() else '?')
            pg.screenshot(path='saida/v152_side.png', clip={'x':0,'y':0,'width':320,'height':620})
        b.close()
    print(erros())
