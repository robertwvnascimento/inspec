import asyncio, json, sys, time, re
from playwright.sync_api import sync_playwright
URL = 'http://127.0.0.1:9000'
ERROS = []
def novo(p, mobile=False, offline_ctx=False):
    b = p.chromium.launch(args=['--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream'])
    ctx = b.new_context(viewport={'width': 390, 'height': 844} if mobile else {'width': 1366, 'height': 900}, device_scale_factor=1, permissions=['camera'], accept_downloads=True)
    pg = ctx.new_page()
    pg.on('console', lambda m: ERROS.append(f'[{m.type}] {m.text}') if m.type in ('error','warning') else None)
    pg.on('pageerror', lambda e: ERROS.append(f'[pageerror] {e}'))
    return b, ctx, pg
def login(pg, email, senha):
    pg.goto(URL + '/'); pg.wait_for_selector('#lg-email', timeout=15000)
    pg.fill('#lg-email', email); pg.fill('#lg-senha', senha); pg.click('#lg-btn')
def esperar_app(pg, t=30000):
    pg.wait_for_selector('#view', timeout=t)
def erros():
    e = [x for x in ERROS if 'favicon' not in x and 'fonts.g' not in x]
    ERROS.clear(); return e
