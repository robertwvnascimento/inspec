from base import *
import subprocess
with sync_playwright() as p:
    b, ctx, pg = novo(p, mobile=True)
    login(pg, 'owner@inspec.local', 'Senha123!'); esperar_app(pg); pg.wait_for_timeout(3000)
    pg.goto(URL + '/#/sobre'); pg.wait_for_timeout(1500)
    subprocess.run(['sed','-i',"s/inspec-v1.1.0/inspec-v1.1.9/",'../../app/sw.js'])
    pg.click('[data-action="sb-atualizar"]'); pg.wait_for_timeout(6000)
    print('upd:', pg.inner_text('#sb-upd'), '| botão recarregar:', pg.locator('[data-action="pwa-recarregar"]').count(), '| toast:', pg.inner_text('#toast')[:90])
    pg.click('#view [data-action="pwa-recarregar"]'); esperar_app(pg); pg.wait_for_timeout(2000)
    pg.goto(URL + '/#/sobre'); pg.wait_for_timeout(1500); print('off agora:', pg.inner_text('#sb-off'))
    subprocess.run(['sed','-i',"s/inspec-v1.1.9/inspec-v1.1.0/",'../../app/sw.js'])
    b.close()
