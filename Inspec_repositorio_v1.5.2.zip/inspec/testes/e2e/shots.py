from base import *
import subprocess, json
from PIL import Image
OUT = 'saida/img/'
def sql(q): return subprocess.run(['psql','-h','/tmp','-p','54329','-U','postgres','-d','inspecprod','-At','-c',q],capture_output=True,text=True).stdout.strip()
pid = lambda c: sql(f"select id from pontos where codigo='{c}'")
S = json.load(open('senhas.json'))
CSS = "#toast{display:none!important} .install-card{display:none!important}"
def prep(pg): pg.add_style_tag(content=CSS)
def shot(pg, nome, full=False, maxh=None, sel=None):
    prep(pg); pg.wait_for_timeout(500)
    if sel: pg.locator(sel).screenshot(path=OUT + nome + '.png')
    elif full:
        vs = pg.viewport_size; h = pg.evaluate("Math.max(document.documentElement.scrollHeight, document.querySelector('#view')?.scrollHeight||0)")
        pg.set_viewport_size({'width': vs['width'], 'height': min(h + 80, maxh or 2000)}); pg.wait_for_timeout(700)
        pg.screenshot(path=OUT + nome + '.png'); pg.set_viewport_size(vs); pg.wait_for_timeout(300)
    else: pg.screenshot(path=OUT + nome + '.png')
    if maxh:
        im = Image.open(OUT + nome + '.png'); dpr = im.width / (pg.viewport_size['width'])
        if im.height > maxh * dpr: im.crop((0, 0, im.width, int(maxh * dpr))).save(OUT + nome + '.png')
    print('ok', nome)
def ir(pg, h, t=1500): pg.goto(URL + h); pg.wait_for_timeout(t)
def entrar(p, email, senha, mobile, nova=None):
    b = p.chromium.launch(args=['--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream'])
    ctx = b.new_context(viewport={'width': 390, 'height': 844} if mobile else {'width': 1366, 'height': 860}, device_scale_factor=2 if mobile else 1.4, permissions=['camera'], accept_downloads=True)
    pg = ctx.new_page(); pg.goto(URL + '/'); pg.wait_for_selector('#lg-email')
    pg.fill('#lg-email', email); pg.fill('#lg-senha', senha); pg.click('#lg-btn')
    if nova:
        pg.wait_for_selector('#form-senha'); pg.fill('#ts-1', nova); pg.fill('#ts-2', nova); pg.click('#ts-btn')
    pg.wait_for_selector('#view', timeout=30000); pg.wait_for_timeout(2000)
    return b, ctx, pg

sql("update membros set papel='inspetor_leitura' where nome='Franciele Moura'")
import sys
RUN=[int(x) for x in sys.argv[1:]] or [1,2,3,4,5]
with sync_playwright() as p:
    # ---------- login / 1º acesso
    if 1 in RUN:
        b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 390, 'height': 844}, device_scale_factor=2); pg = ctx.new_page()
        pg.goto(URL + '/'); pg.wait_for_selector('#lg-email'); shot(pg, 'm_login')
        pg.fill('#lg-email', 'franciele@inspec.local'); pg.fill('#lg-senha', S['franciele@inspec.local']); pg.click('#lg-btn'); pg.wait_for_selector('#form-senha'); shot(pg, 'm_primeiro_acesso'); b.close()

    # ---------- INSPETOR (mobile)
    if 2 in RUN:
        b, ctx, pg = entrar(p, 'glauco@inspec.local', 'Glauco2026x', True)
        ir(pg, '/#/inicio'); shot(pg, 'i_inicio', True, 1500)
        ir(pg, '/#/buscar'); pg.fill('#busca', 'tarugos'); pg.dispatch_event('#busca', 'input'); pg.wait_for_timeout(600); shot(pg, 'i_buscar')
        pg.click('.scan-cta'); pg.wait_for_timeout(2500); shot(pg, 'i_leitor'); pg.click('[data-action="scan-fechar"]')
        ir(pg, '/#/nova'); shot(pg, 'i_nova')
        g = sql("select id from gerencias where nome='ACIARIA'"); ir(pg, f'/#/nova?ger={g}&cat=extintor'); shot(pg, 'i_nova_lista')
        ir(pg, f"/#/inspecao/{pid('ACI-050')}?de=qr"); shot(pg, 'i_insp_topo')
        pg.click('[data-action="ck-tudo"]'); pg.click('[data-action="ck"][data-k="mangueira"][data-v="NC"]'); pg.wait_for_timeout(300)
        pg.locator('.fsec', has_text='Checklist').scroll_into_view_if_needed(); shot(pg, 'i_insp_checklist')
        pg.locator('.fsec', has_text='Cor do anel').scroll_into_view_if_needed(); shot(pg, 'i_insp_anel')
        ir(pg, f"/#/inspecao/{pid('HID-005')}"); pg.locator('h3', has_text='Materiais do abrigo').scroll_into_view_if_needed(); shot(pg, 'i_insp_mangueiras')
        ir(pg, f"/#/inspecao/{pid('ACI-051')}"); pg.click('[data-action="ck-tudo"]'); pg.click('[data-action="ck-op"][data-k="anel"][data-v="Verde"]'); pg.click('[data-action="ck-op"][data-k="base"][data-v="Coluna"]'); pg.click('#btn-salvar'); pg.wait_for_selector('.success'); pg.wait_for_timeout(500)
        prep(pg); pg.screenshot(path=OUT + 'i_salvo.png'); print('ok i_salvo'); pg.keyboard.press('Escape')
        ir(pg, f"/#/ponto/{pid('ACI-002')}"); shot(pg, 'i_ficha', True, 2200)
        pg.click('[data-action="troca-abrir"]'); pg.wait_for_timeout(500); shot(pg, 'i_troca'); pg.keyboard.press('Escape')
        ir(pg, f"/#/desvio/novo?eq={pid('ACI-060')}"); pg.click('[data-action="dv-gat"][data-v="extrativo"]'); pg.click('[data-action="dv-papel"][data-v="lider"]'); pg.click('[data-action="dv-meio"][data-v="radio"]'); pg.wait_for_timeout(300); shot(pg, 'i_desvio_novo', True, 1700)
        dv = sql("select id from desvios where numero='CD-2026-0001'"); ir(pg, f'/#/desvio/{dv}'); shot(pg, 'i_desvio_det', True, 1600)
        ir(pg, '/#/ncs'); shot(pg, 'i_ncs')
        ir(pg, '/#/historico'); shot(pg, 'i_historico')
        ir(pg, '/#/menu'); shot(pg, 'i_menu', True, 1500)
        ir(pg, '/#/sobre', 2500); shot(pg, 'i_sobre', True, 1400)
        pg.locator('h2', has_text='Autoria e licenças').scroll_into_view_if_needed(); pg.wait_for_timeout(300); shot(pg, 'i_sobre_licencas')
        b.close()

    # ---------- INSPETOR (LEITURA)
    if 3 in RUN:
        b, ctx, pg = entrar(p, 'franciele@inspec.local', S['franciele@inspec.local'], True, nova='Franciele2026')
        ir(pg, '/#/inicio'); shot(pg, 'il_inicio')
        ir(pg, f"/#/ponto/{pid('ACI-002')}"); shot(pg, 'il_ficha')
        b.close()

    # ---------- OWNER / ADMIN (desktop)
    if 4 in RUN:
        b, ctx, pg = entrar(p, 'owner@inspec.local', 'Senha123!', False)
        ir(pg, '/#/inicio', 2500); shot(pg, 'a_painel', True, 1900)
        pg.locator('h2', has_text='Relatórios').scroll_into_view_if_needed(); pg.wait_for_timeout(300); shot(pg, 'a_painel_relatorios')
        ir(pg, '/#/relatorios'); shot(pg, 'a_relatorios', True, 1300)
        with ctx.expect_page() as np: pg.click('[data-action="rep-doc"][data-t="consolidado"]')
        w = np.value; w.wait_for_load_state(); w.wait_for_timeout(800); w.set_viewport_size({'width': 1100, 'height': 1300}); w.screenshot(path=OUT + 'a_rel_consolidado.png'); w.close(); print('ok consolidado')
        ir(pg, '/#/admin/pontos'); shot(pg, 'a_pontos')
        pg.click('[data-action="etq-abrir"]'); pg.select_option('[data-k="filtro"]', 'todas'); pg.wait_for_timeout(500); shot(pg, 'a_etiquetas'); pg.keyboard.press('Escape')
        ir(pg, '/#/admin/equipe'); shot(pg, 'a_equipe')
        pg.click('[data-action="user-novo"]'); pg.wait_for_timeout(400); shot(pg, 'a_criar_usuario'); pg.keyboard.press('Escape'); pg.keyboard.press('Escape')
        ir(pg, '/#/admin/categorias'); shot(pg, 'a_categorias')
        pg.click('[data-action="cat-nova"]'); pg.fill('#ct-nome', 'Alarme de incêndio'); pg.fill('#ct-plural', 'Alarmes de incêndio'); pg.wait_for_timeout(300); shot(pg, 'a_categoria_nova'); pg.keyboard.press('Escape')
        ir(pg, '/#/admin/agentes'); shot(pg, 'a_agentes')
        ir(pg, '/#/admin/reserva'); shot(pg, 'a_reserva')
        ir(pg, '/#/admin/destinatarios'); shot(pg, 'a_destinatarios')
        ir(pg, '/#/admin/importacao'); pg.click('[data-action="imp-carga"]'); pg.wait_for_timeout(1500); shot(pg, 'a_importacao', True, 1500)
        ir(pg, '/#/admin/config'); shot(pg, 'a_config', True, 1500)
        pg.click('[data-action="zerar-abrir"]'); pg.wait_for_timeout(400); shot(pg, 'a_zerar'); pg.keyboard.press('Escape')
        ir(pg, '/#/admin/backup'); shot(pg, 'a_backup')
        ir(pg, '/#/admin/auditoria', 4000); shot(pg, 'a_auditoria', True, 1500)
        ir(pg, '/#/admin/alteracoes'); shot(pg, 'a_alteracoes', True, 1300)
        ir(pg, '/#/admin/acessos', 3000); shot(pg, 'a_acessos', True, 1200)
        ir(pg, '/#/galeria', 4000); shot(pg, 'a_galeria', True, 1300)
        ir(pg, '/#/desvios'); shot(pg, 'a_desvios')
        dv = sql("select id from desvios where numero='CD-2026-0003'"); ir(pg, f'/#/desvio/{dv}')
        with ctx.expect_page() as np: pg.click('[data-action="dv-ver"]')
        w = np.value; w.wait_for_load_state(); w.wait_for_timeout(1500); w.set_viewport_size({'width': 1000, 'height': 1250}); w.screenshot(path=OUT + 'a_onepage.png'); w.close(); print('ok onepage')
        b.close()

    # ---------- ADMIN (LEITURA)
    if 5 in RUN:
        b, ctx, pg = entrar(p, 'consulta@inspec.local', 'Consulta2026', False)
        ir(pg, '/#/admin/pontos'); shot(pg, 'al_pontos')
        ir(pg, '/#/admin/equipe'); shot(pg, 'al_equipe')
        b.close()
