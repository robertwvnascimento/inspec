from base import *
import subprocess
def sql(q): return subprocess.run(['psql','-h','/tmp','-p','54329','-U','postgres','-d','inspecprod','-At','-c',q],capture_output=True,text=True).stdout.strip()
pid = lambda c: sql(f"select id from pontos where codigo='{c}'")
with sync_playwright() as p:
    b, ctx, pg = novo(p)
    login(pg, 'owner@inspec.local', 'Senha123!'); esperar_app(pg); pg.wait_for_timeout(1500)
    pg.goto(URL + f"/#/desvio/novo?eq={pid('ACI-030')}"); pg.wait_for_selector('#form-desvio')
    pg.click('[data-action="dv-gat"][data-v="violacao"]'); pg.click('[data-action="dv-papel"][data-v="lider"]'); pg.click('[data-action="dv-meio"][data-v="pessoalmente"]')
    pg.check('input[data-k="localOk"]'); pg.fill('textarea[data-k="descricao"]', 'Lacre violado.'); pg.click('[data-action="dv-subs"][data-v="Não"]'); pg.fill('textarea[data-k="acao"]', 'Relacrado no local.')
    pg.set_input_files('input[data-change="foto"] >> nth=1', 'foto0.jpg'); pg.wait_for_selector('#thumbs img'); pg.set_input_files('input[data-change="foto"] >> nth=1', 'foto2.jpg'); pg.wait_for_timeout(500)
    pg.click('#dv-btn'); pg.wait_for_url('**/desvio/*'); pg.wait_for_timeout(5000); pg.reload(); esperar_app(pg); pg.wait_for_timeout(1500)
    with ctx.expect_page() as np: pg.click('[data-action="dv-ver"]')
    w = np.value; w.wait_for_load_state(); w.wait_for_timeout(2000); print('onepage fotos:', w.locator('.fotos img').count(), 'carregadas:', w.evaluate("[...document.querySelectorAll('.fotos img')].filter(i=>i.naturalWidth>0).length"))
    w.screenshot(path='r2_onepage.png', full_page=True)
    with pg.expect_download() as d: w.click('#b-x0')
    d.value.save_as('op2.pdf'); print('pdf baixado')
    b.close()
