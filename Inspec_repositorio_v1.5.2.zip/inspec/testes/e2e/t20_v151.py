from base import *
import subprocess, io
from pypdf import PdfReader
def sql(q): return subprocess.run(['psql','-h','/tmp','-p','54329','-U','postgres','-d','inspecprod','-At','-c',q],capture_output=True,text=True).stdout.strip()
OUT = 'saida/v151_'
with sync_playwright() as p:
    # ---------------- OWNER desktop
    b, ctx, pg = novo(p); login(pg, 'owner@inspec.local', 'Senha123!'); esperar_app(pg); pg.wait_for_timeout(2000)
    pg.goto(URL + '/#/admin/alteracoes'); pg.wait_for_timeout(1200)
    tabs = pg.eval_on_selector_all('.tabs[aria-label="Seções da administração"] a', "els => els.map(e => { const r = e.getBoundingClientRect(); const p = e.parentElement.getBoundingClientRect(); return [e.textContent, r.right <= p.right + 1 && r.left >= p.left - 1] })")
    print('abas:', len(tabs), 'todas visíveis:', all(v for _, v in tabs), [t for t, v in tabs if not v])
    print('aba acessos para owner:', any('Registros de acesso' in t for t, _ in tabs))
    pg.screenshot(path=OUT + 'abas.png', clip={'x': 0, 'y': 0, 'width': 1366, 'height': 260})
    # registros de acesso
    pg.goto(URL + '/#/admin/acessos'); pg.wait_for_selector('text=Endereço IP', timeout=15000); pg.wait_for_timeout(800)
    print('acessos linhas:', pg.locator('#view table.tbl tbody tr').count(), '| ip mostrado:', '203.0.113.7' in pg.inner_text('#view'))
    pg.screenshot(path=OUT + 'acessos.png', full_page=True)
    with pg.expect_download() as d: pg.click('[data-action="acs-xlsx"]')
    print('excel acessos:', d.value.suggested_filename)
    # filtros compartilhados painel -> relatórios
    pg.goto(URL + '/#/painel'); pg.wait_for_timeout(1500)
    g = sql("select id from gerencias where nome='ACIARIA'")
    pg.select_option('.fbar [data-k="ger"]', g); pg.wait_for_timeout(600)
    bomb = pg.eval_on_selector('.fbar [data-k="bomb"]', "s => [...s.options].map(o => o.value).filter(Boolean)[0] || ''")
    if bomb: pg.select_option('.fbar [data-k="bomb"]', bomb); pg.wait_for_timeout(600)
    pg.goto(URL + '/#/relatorios'); pg.wait_for_timeout(1200)
    print('relatórios tem filtro bombeiro:', pg.locator('.fbar [data-k="bomb"]').count() == 1, '| ger herdada:', pg.eval_on_selector('.fbar [data-k="ger"]', 'e => e.value') == g, '| bomb herdado:', pg.eval_on_selector('.fbar [data-k="bomb"]', 'e => e.value') == bomb)
    pg.screenshot(path=OUT + 'relatorios.png', clip={'x': 0, 'y': 0, 'width': 1366, 'height': 420})
    pg.select_option('.fbar [data-k="ger"]', ''); pg.select_option('.fbar [data-k="bomb"]', ''); pg.wait_for_timeout(500)
    # relatório de pontos em paisagem
    with ctx.expect_page() as np: pg.click('[data-action="rep-doc"][data-t="pontos"]')
    w = np.value; w.wait_for_load_state(); w.wait_for_timeout(800)
    dims = w.evaluate("() => { const pg = document.querySelector('.pg'), t = document.querySelector('table.t'); return [pg.clientWidth, t.scrollWidth, t.clientWidth] }")
    print('pontos .pg largura px:', dims[0], '(paisagem≈1122) | tabela cabe:', dims[1] <= dims[0])
    w.emulate_media(media='print'); pdf = w.pdf(prefer_css_page_size=True, print_background=True)
    r = PdfReader(io.BytesIO(pdf)); bx = r.pages[0].mediabox
    print('PDF pontos páginas:', len(r.pages), '| paisagem:', float(bx.width) > float(bx.height))
    open(OUT + 'pontos.pdf', 'wb').write(pdf); w.close()
    with ctx.expect_page() as np: pg.click('[data-action="rep-doc"][data-t="ncs"]')
    w = np.value; w.wait_for_load_state(); w.emulate_media(media='print'); r = PdfReader(io.BytesIO(w.pdf(prefer_css_page_size=True))); bx = r.pages[0].mediabox
    print('PDF ncs retrato:', float(bx.width) < float(bx.height)); w.close()
    # Excel com SheetJS novo
    with pg.expect_download() as d: pg.click('[data-action="rep-xlsx"][data-t="pontos"]')
    pth = d.value.path(); print('excel pontos:', d.value.suggested_filename, open(pth, 'rb').read(2) == b'PK')
    print('versão XLSX:', pg.evaluate('window.XLSX && XLSX.version'), '| jsPDF:', pg.evaluate('window.jspdf && window.jspdf.jsPDF.version'))
    # importação lê planilha com SheetJS novo
    pg.goto(URL + '/#/admin/importacao'); pg.wait_for_timeout(800)
    pg.set_input_files('[data-change="imp-file"]', pth); pg.wait_for_timeout(2500)
    print('importação leu planilha:', len(pg.inner_text('#imp-prev')) > 20)
    # One Page PDF com jsPDF 4
    dv = sql("select id from desvios order by criado_em limit 1")
    if dv:
        pg.goto(URL + f'/#/desvio/{dv}'); pg.wait_for_timeout(1200)
        with pg.expect_download(timeout=30000) as d: pg.click('[data-action="dv-onepage"]')
        print('One Page PDF jsPDF4:', d.value.suggested_filename, len(open(d.value.path(), 'rb').read()) > 5000)
    # Sobre: licenças
    pg.goto(URL + '/#/sobre'); pg.wait_for_timeout(1500)
    print('sobre tem licenças:', pg.locator('a[href="/vendor/LICENCAS.txt"]').count() == 1)
    rr = pg.request.get(URL + '/vendor/LICENCAS.txt'); print('LICENCAS.txt:', rr.status, 'jsQR' in rr.text(), 'Kazuhiko' in rr.text())
    # owner não sai por inatividade
    print('ERROS owner:', erros())
    b.close()

    # ---------------- ADMIN (LEITURA): sem acesso aos registros de IP
    b, ctx, pg = novo(p); login(pg, 'consulta@inspec.local', 'Consulta2026'); esperar_app(pg); pg.wait_for_timeout(1500)
    pg.goto(URL + '/#/admin/pontos'); pg.wait_for_timeout(800)
    print('admin leitura vê aba acessos:', pg.locator('a[href="#/admin/acessos"]').count())
    pg.goto(URL + '/#/admin/acessos'); pg.wait_for_timeout(800); print('admin leitura rota acessos:', 'Acesso restrito' in pg.inner_text('#view'))
    print('admin leitura API acessos:', pg.evaluate("async () => { const r = await fetch('/rest/v1/acessos?select=id', { headers: { apikey: JSON.parse(localStorage.getItem('inspec-auth')).access_token ? '' : '', Authorization: 'Bearer ' + JSON.parse(localStorage.getItem('inspec-auth')).access_token } }); return r.status + ' ' + (await r.text()).slice(0, 40) }"))
    b.close()

    # ---------------- INSPETOR: inatividade
    b, ctx, pg = novo(p, mobile=True)
    pg.clock.install()
    login(pg, 'glauco@inspec.local', 'Glauco2026x'); esperar_app(pg); pg.wait_for_timeout(1500)
    pg.clock.fast_forward('04:00'); pg.wait_for_timeout(300); pg.clock.run_for(5000)
    print('aviso aos 4 min?', pg.locator('#aviso-inativo').count())
    pg.mouse.click(200, 300); pg.wait_for_timeout(300)
    pg.clock.fast_forward('04:20'); pg.clock.run_for(5000)
    print('atividade reinicia contagem (sem logout aos 8:20 total):', pg.locator('#lg-email').count() == 0, '| aviso visível:', pg.locator('#aviso-inativo').count())
    pg.screenshot(path=OUT + 'aviso.png')
    # inspeção offline e depois inatividade
    pt = sql("select id from pontos where codigo='ACI-070'")
    pg.goto(URL + f'/#/inspecao/{pt}'); pg.wait_for_timeout(1200)
    ctx.set_offline(True)
    pg.click('[data-action="ck-tudo"]'); pg.click('[data-action="ck-op"][data-k="anel"][data-v="Verde"]'); pg.click('[data-action="ck-op"][data-k="base"][data-v="Coluna"]')
    pg.click('#btn-salvar'); pg.wait_for_selector('.success', timeout=10000); pg.keyboard.press('Escape'); pg.wait_for_timeout(500)
    pg.clock.fast_forward('05:10'); pg.clock.run_for(6000); pg.wait_for_timeout(1500)
    txt = pg.inner_text('body')
    print('logout por inatividade:', pg.locator('#lg-email').count() == 1, '| mensagem:', 'inatividade' in txt, '| guardou fila:', 'não enviado' in txt)
    pg.screenshot(path=OUT + 'logout.png')
    n_antes = sql(f"select count(*) from inspecoes where ponto_id='{pt}'")
    ctx.set_offline(False)
    pg.fill('#lg-email', 'glauco@inspec.local'); pg.fill('#lg-senha', 'Glauco2026x'); pg.click('#lg-btn'); esperar_app(pg); pg.wait_for_timeout(4000); pg.clock.run_for(3000); pg.wait_for_timeout(2000)
    print('inspeção offline enviada após novo login:', n_antes, '->', sql(f"select count(*) from inspecoes where ponto_id='{pt}'"))
    print('evento inatividade registrado:', sql("select count(*) from acessos where evento='acesso.inatividade'"))
    print('ERROS inspetor:', [e for e in erros() if 'ERR_INTERNET_DISCONNECTED' not in e and 'Failed to fetch' not in e])
    b.close()

    # ---------------- OWNER não é desconectado
    b, ctx, pg = novo(p); pg.clock.install(); login(pg, 'owner@inspec.local', 'Senha123!'); esperar_app(pg); pg.wait_for_timeout(1500)
    pg.clock.fast_forward('07:00'); pg.clock.run_for(6000)
    print('owner continua após 7 min:', pg.locator('#lg-email').count() == 0)
    b.close()
