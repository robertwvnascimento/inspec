from base import *
import subprocess
def sql(q): return subprocess.run(['psql','-h','/tmp','-p','54329','-U','postgres','-d','inspecprod','-At','-c',q],capture_output=True,text=True).stdout.strip()
with sync_playwright() as p:
    b, ctx, pg = novo(p, mobile=True); pg.clock.install()
    login(pg, 'consulta@inspec.local', 'Consulta2026'); esperar_app(pg); pg.wait_for_timeout(1500)
    pg.clock.fast_forward('04:36'); pg.clock.run_for(5000); pg.wait_for_timeout(300)
    print('aviso aos 4:41:', pg.locator('#aviso-inativo').count(), pg.inner_text('#aviso-inativo') if pg.locator('#aviso-inativo').count() else '')
    pg.screenshot(path='saida/v151_aviso.png')
    pg.clock.fast_forward('00:30'); pg.clock.run_for(6000); pg.wait_for_timeout(2000)
    print('admin leitura desconectado:', pg.locator('#lg-email').count() == 1)
    print('evento:', sql("select evento, ip from acessos where evento='acesso.inatividade'"))
    # reabrir o app depois de 10 min com sessão salva
    login(pg, 'consulta@inspec.local', 'Consulta2026'); esperar_app(pg); pg.wait_for_timeout(1500)
    pg.evaluate("localStorage.setItem('inspec-ativo', String(Date.now() - 10*60e3))")
    pg2 = ctx.new_page(); pg2.goto(URL + '/'); pg2.wait_for_timeout(5000)
    print('reabrir após 10 min pede login:', pg2.locator('#lg-email').count() == 1)
    b.close()
