from base import *
import io
from pypdf import PdfReader
with sync_playwright() as p:
    b, ctx, pg = novo(p); login(pg, 'owner@inspec.local', 'Senha123!'); esperar_app(pg); pg.wait_for_timeout(1500)
    pg.goto(URL + '/#/relatorios'); pg.wait_for_timeout(1000)
    for t in ['pontos', 'desvios', 'rastreio', 'inspecoes', 'n2', 'ncs', 'consolidado']:
        with ctx.expect_page() as np: pg.click(f'[data-action="rep-doc"][data-t="{t}"]')
        w = np.value; w.wait_for_load_state(); w.wait_for_timeout(600)
        d = w.evaluate("() => { const pg = document.querySelector('.pg'); return [pg.clientWidth, Math.max(...[...document.querySelectorAll('table.t')].map(t => t.scrollWidth))] }")
        w.emulate_media(media='print'); r = PdfReader(io.BytesIO(w.pdf(prefer_css_page_size=True, print_background=True))); bx = r.pages[0].mediabox
        print(t, 'paisagem' if float(bx.width) > float(bx.height) else 'retrato', 'cabe' if d[1] <= d[0] else f'ESTOURA {d}', len(r.pages), 'pág')
        if t == 'pontos': open('saida/v151_pontos.pdf', 'wb').write(w.pdf(prefer_css_page_size=True, print_background=True))
        w.close()
    b, ctx2, pg2 = novo(p, mobile=True); pg2.clock.install(); login(pg2, 'glauco@inspec.local', 'Glauco2026x'); esperar_app(pg2); pg2.wait_for_timeout(1200)
    pg2.clock.fast_forward('04:40'); pg2.clock.run_for(5000); pg2.wait_for_timeout(300); pg2.screenshot(path='saida/v151_aviso.png')
