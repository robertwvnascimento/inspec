from base import *
with sync_playwright() as p:
    b, ctx, pg = novo(p, mobile=True)
    login(pg, 'owner@inspec.local', 'Senha123!'); esperar_app(pg); pg.wait_for_timeout(1500)
    pg.goto(URL + '/#/buscar'); pg.wait_for_selector('#busca'); pg.click('#busca'); pg.keyboard.type('aci', delay=80)
    pg.set_viewport_size({'width': 390, 'height': 500}); pg.wait_for_timeout(600)   # teclado abriu
    pg.evaluate("window.dispatchEvent(new Event('online'))"); pg.wait_for_timeout(2500)
    pg.keyboard.type('-0', delay=80)
    print('foco no campo:', pg.evaluate("document.activeElement.id"), '| valor:', pg.input_value('#busca'))
    b.close()
