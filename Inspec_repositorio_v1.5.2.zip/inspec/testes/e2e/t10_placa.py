from base import *
with sync_playwright() as p:
    b, ctx, pg = novo(p)
    login(pg, 'owner@inspec.local', 'Senha123!'); esperar_app(pg); pg.wait_for_timeout(1500)
    pg.goto(URL + '/#/admin/pontos'); pg.wait_for_timeout(600); pg.click('[data-action="etq-abrir"]'); pg.wait_for_timeout(300)
    pg.select_option('[data-k="filtro"]', 'todas'); pg.wait_for_timeout(200); pg.select_option('[data-k="ger"]', label='MEIO AMBIENTE'); pg.wait_for_timeout(500)
    pg.screenshot(path='q1_dlg.png')
    with ctx.expect_page() as np: pg.click('[data-action="etq-imprimir"]')
    w = np.value; w.wait_for_load_state(); w.wait_for_timeout(800)
    print(w.title(), '| placas:', w.locator('.pl').count(), '| folhas:', w.locator('.fl').count())
    w.screenshot(path='q2_placas.png', full_page=True)
    w.pdf(path='placas.pdf', prefer_css_page_size=True, print_background=True)
    b.close()
