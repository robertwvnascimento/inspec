from base import *
import subprocess
def sql(q): return subprocess.run(['psql','-h','/tmp','-p','54329','-U','postgres','-d','inspecprod','-At','-c',q],capture_output=True,text=True).stdout.strip()
S = json.load(open('senhas.json'))
with sync_playwright() as p:
    b, ctx, pg = novo(p)
    login(pg, 'owner@inspec.local', 'Senha123!'); esperar_app(pg); pg.wait_for_timeout(1500)
    pg.screenshot(path='d1_painel.png', full_page=True)
    # etiquetas
    pg.goto(URL + '/#/admin/pontos'); pg.wait_for_timeout(500); pg.click('[data-action="etq-abrir"]'); pg.select_option('[data-k="filtro"]', 'todas'); pg.wait_for_timeout(200); pg.select_option('[data-k="ger"]', label='MEIO AMBIENTE'); pg.wait_for_timeout(300)
    print('etq:', pg.inner_text('#etq-n'))
    with ctx.expect_page() as np: pg.click('[data-action="etq-imprimir"]')
    w = np.value; w.wait_for_load_state(); print('janela:', w.title(), '| etiquetas:', w.locator('.etq').count()); w.screenshot(path='d2_etq.png')
    w.evaluate("window.print = () => {}"); w.click('#b-imp'); pg.wait_for_timeout(1500); print('impressas db:', sql("select count(*) from pontos where qr_impresso_em is not null")); w.close()
    # relatórios
    pg.goto(URL + '/#/relatorios'); pg.wait_for_timeout(500)
    for t in ['inspecoes','rastreio','pontos','desvios']:
        with pg.expect_download() as d: pg.click(f'[data-action="rep-xlsx"][data-t="{t}"]')
        d.value.save_as('r_'+d.value.suggested_filename); print('xlsx:', d.value.suggested_filename)
    with ctx.expect_page() as np: pg.click('[data-action="rep-doc"][data-t="consolidado"]')
    w = np.value; w.wait_for_load_state(); w.wait_for_timeout(800); w.screenshot(path='d3_consolidado.png', full_page=True); print('consolidado h2:', w.locator('h2').count()); w.close()
    # anular
    i = sql("select id from inspecoes where origem='lista' limit 1"); pt = sql(f"select ponto_id from inspecoes where id='{i}'")
    pg.goto(URL + f'/#/ponto/{pt}'); pg.wait_for_timeout(800); pg.click(f'[data-action="anular"][data-id="{i}"]'); pg.fill('#dlg-campo', 'Registro duplicado em teste'); pg.click('#dlg-ok'); pg.wait_for_timeout(1500)
    print('anulada:', sql(f"select anulada, motivo_anulacao from inspecoes where id='{i}'"))
    # histórico alterações + backup
    pg.goto(URL + '/#/admin/alteracoes'); pg.wait_for_timeout(800); pg.screenshot(path='d4_alt.png', full_page=True)
    pg.goto(URL + '/#/admin/backup'); pg.wait_for_timeout(500)
    with pg.expect_download() as d: pg.click('[data-action="backup-json"]')
    d.value.save_as('backup.json'); bj = json.load(open('backup.json')); print('backup:', {k: len(v) for k, v in bj.items() if isinstance(v, list)})
    pg.goto(URL + '/#/historico'); pg.wait_for_timeout(800); print('hist:', pg.inner_text('#h-count'))
    print('ERROS', [e for e in erros() if 'TUNNEL' not in e])
    b.close()
    # consulta
    b, ctx, pg = novo(p, mobile=True)
    login(pg, 'consulta@inspec.local', S['consulta@inspec.local']); pg.wait_for_selector('#form-senha'); pg.fill('#ts-1','Consulta2026'); pg.fill('#ts-2','Consulta2026'); pg.click('#ts-btn'); esperar_app(pg); pg.wait_for_timeout(1500)
    print('consulta nav:', pg.inner_text('#bottom-nav').replace('\n',' '))
    pg.goto(URL + '/#/inspecao/' + pt); pg.wait_for_timeout(800); print('consulta inspecao ->', pg.evaluate('location.hash')[:12])
    pg.goto(URL + '/#/admin/pontos'); pg.wait_for_timeout(500); print('consulta admin:', pg.inner_text('#view')[:40])
    r = pg.evaluate("""async () => { const k = JSON.parse(localStorage.getItem('inspec-auth')).access_token; const r = await fetch('/rest/v1/pontos?id=eq.%s', {method:'PATCH', headers:{apikey:'x', Authorization:'Bearer '+k, 'Content-Type':'application/json', Prefer:'return=representation'}, body: JSON.stringify({local:'hack'})}); return r.status + ' ' + await r.text(); }""" % pt)
    print('consulta PATCH direto:', r)
    print('ERROS', [e for e in erros() if 'TUNNEL' not in e])
    b.close()
