#!/bin/bash
cd "$(dirname "$0")/../ambiente-local" && ./reset_db.sh >/dev/null 2>&1
psql -h /tmp -p 54329 -U postgres -d inspecprod -q -c "insert into auth.users(id,email) values ('11111111-1111-4111-8111-111111111111','owner@inspec.local'); insert into auth.local_pw values ('11111111-1111-4111-8111-111111111111', encode(sha256('Senha123!'::bytea),'hex'));"
rm -rf /var/tmp/inspec_storage/* 2>/dev/null
pkill -f server.py; sleep 0.3; cd "$(dirname "$0")/../ambiente-local" && APP_DIR=$PWD/../../app FUNCS='{"criar-usuario":3101,"excluir-usuario":3102,"enviar-onepage":3103}' nohup python3 server.py 9000 > /var/tmp/proxy.log 2>&1 &
sleep 1; echo reset ok
