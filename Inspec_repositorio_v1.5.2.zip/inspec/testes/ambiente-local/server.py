"""Supabase local mínimo para testar o Inspec (NÃO é para produção).
Rotas (mesma origem do app):
  /rest/v1/*       -> PostgREST (porta 3001)
  /auth/v1/*       -> GoTrue simulado (senha, refresh, user, logout, admin)
  /storage/v1/*    -> Storage simulado (upload, sign, download) com RLS do banco
  /functions/v1/x  -> Edge Functions rodando em Deno (portas 3101..)
  demais           -> arquivos estáticos do app
"""
import json, os, re, sys, time, uuid, hashlib, threading, urllib.request, urllib.error, mimetypes
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import jwt, psycopg2

SECRET = 'super-secret-jwt-token-with-at-least-32-characters-long'
APP_DIR = os.environ.get('APP_DIR', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'app'))
STORE = '/var/tmp/inspec_storage'
os.makedirs(STORE, exist_ok=True)
FUNCS = json.loads(os.environ.get('FUNCS', '{}'))  # {"criar-usuario": 3101, ...}
DSN = 'host=127.0.0.1 port=54329 dbname=inspecprod user=postgres'

def token(role, sub=None, email=None, exp=3600):
    now = int(time.time())
    c = {'role': role, 'iat': now, 'exp': now + exp, 'aud': 'authenticated' if role == 'authenticated' else role}
    if sub: c['sub'] = sub
    if email: c['email'] = email
    return jwt.encode(c, SECRET, algorithm='HS256')

ANON = token('anon', exp=10**8)
SERVICE = token('service_role', exp=10**8)

def db():
    c = psycopg2.connect(DSN); c.autocommit = True; return c

def user_obj(uid, email, meta=None):
    return {'id': uid, 'aud': 'authenticated', 'role': 'authenticated', 'email': email, 'email_confirmed_at': '2026-01-01T00:00:00Z',
            'app_metadata': {'provider': 'email'}, 'user_metadata': meta or {}, 'created_at': '2026-01-01T00:00:00Z'}

def session(uid, email):
    at = token('authenticated', uid, email)
    rt = uuid.uuid4().hex
    REFRESH[rt] = (uid, email)
    return {'access_token': at, 'token_type': 'bearer', 'expires_in': 3600, 'expires_at': int(time.time()) + 3600,
            'refresh_token': rt, 'user': user_obj(uid, email)}

REFRESH = {}

def h(s): return hashlib.sha256(s.encode()).hexdigest()

class H(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def log_message(self, *a): pass

    def _cors(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Headers', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS,HEAD')
        self.send_header('Access-Control-Expose-Headers', 'Content-Range, Content-Profile')

    def send(self, code, body=b'', ctype='application/json', extra=None):
        if isinstance(body, (dict, list)): body = json.dumps(body).encode()
        elif isinstance(body, str): body = body.encode()
        self.send_response(code); self._cors()
        self.send_header('Content-Type', ctype); self.send_header('Content-Length', str(len(body)))
        for k, v in (extra or {}).items(): self.send_header(k, v)
        self.end_headers()
        if self.command != 'HEAD': self.wfile.write(body)

    def body(self):
        n = int(self.headers.get('Content-Length') or 0)
        return self.rfile.read(n) if n else b''

    def claims(self):
        a = self.headers.get('Authorization', '')
        if not a.startswith('Bearer '): return None
        try: return jwt.decode(a[7:], SECRET, algorithms=['HS256'], options={'verify_aud': False})
        except Exception: return None

    def do_OPTIONS(self): self.send(204, b'')
    def do_GET(self): self.route()
    def do_POST(self): self.route()
    def do_PUT(self): self.route()
    def do_PATCH(self): self.route()
    def do_DELETE(self): self.route()
    def do_HEAD(self): self.route()

    def route(self):
        p = urlparse(self.path)
        try:
            if p.path.startswith('/rest/v1'): return self.proxy('http://127.0.0.1:3001' + self.path[len('/rest/v1'):])
            if p.path.startswith('/auth/v1'): return self.auth(p)
            if p.path.startswith('/storage/v1'): return self.storage(p)
            if p.path.startswith('/functions/v1/'):
                nome = p.path.split('/')[3]
                if nome not in FUNCS: return self.send(404, {'error': 'function not found'})
                return self.proxy(f'http://127.0.0.1:{FUNCS[nome]}/' + nome + (('?' + p.query) if p.query else ''))
            return self.static(p.path)
        except Exception as e:
            import traceback; traceback.print_exc()
            return self.send(500, {'error': str(e)})

    def proxy(self, url):
        data = self.body() if self.command in ('POST', 'PUT', 'PATCH', 'DELETE') else None
        req = urllib.request.Request(url, data=data, method=self.command)
        for k, v in self.headers.items():
            if k.lower() in ('host', 'content-length', 'connection', 'accept-encoding'): continue
            req.add_header(k, v)
        if 'apikey' in self.headers and 'Authorization' not in self.headers:
            req.add_header('Authorization', 'Bearer ' + self.headers['apikey'])
        req.add_header('X-Forwarded-For', '203.0.113.7, ' + self.client_address[0])   # simula o gateway do Supabase
        try:
            r = urllib.request.urlopen(req, timeout=60); code = r.status; b = r.read(); hd = r.headers
        except urllib.error.HTTPError as e:
            code = e.code; b = e.read(); hd = e.headers
        extra = {k: v for k, v in hd.items() if k.lower() in ('content-range', 'preference-applied', 'location')}
        self.send(code, b, hd.get('Content-Type', 'application/json'), extra)

    # ---------------- auth ----------------
    def auth(self, p):
        rota = p.path[len('/auth/v1'):]
        q = parse_qs(p.query)
        b = json.loads(self.body() or b'{}') if self.command in ('POST', 'PUT') else {}
        c = db(); cur = c.cursor()
        if rota == '/token' and q.get('grant_type') == ['password']:
            cur.execute("select u.id, u.email from auth.users u join auth.local_pw p on p.id = u.id where lower(u.email)=lower(%s) and p.senha=%s", (b.get('email', ''), h(b.get('password', ''))))
            r = cur.fetchone()
            if r: cur.execute("update auth.users set last_sign_in_at = now() where id = %s", (r[0],))
            if not r: return self.send(400, {'error': 'invalid_grant', 'error_description': 'Invalid login credentials', 'msg': 'Invalid login credentials', 'code': 'invalid_credentials'})
            return self.send(200, session(str(r[0]), r[1]))
        if rota == '/token' and q.get('grant_type') == ['refresh_token']:
            rt = b.get('refresh_token')
            if rt not in REFRESH: return self.send(400, {'error': 'invalid_grant', 'error_description': 'Invalid Refresh Token'})
            uid, email = REFRESH.pop(rt); return self.send(200, session(uid, email))
        if rota == '/user':
            cl = self.claims()
            if not cl or cl.get('role') != 'authenticated': return self.send(401, {'msg': 'invalid JWT', 'code': 401})
            if self.command == 'PUT' and b.get('password'):
                if len(b['password']) < 8: return self.send(422, {'msg': 'Password should be at least 8 characters.', 'code': 'weak_password'})
                cur.execute("update auth.local_pw set senha=%s where id=%s", (h(b['password']), cl['sub']))
            return self.send(200, user_obj(cl['sub'], cl.get('email')))
        if rota == '/logout': return self.send(204, b'')
        if rota == '/recover': return self.send(200, {})
        if rota.startswith('/admin/users'):
            cl = self.claims()
            if not cl or cl.get('role') != 'service_role': return self.send(403, {'msg': 'not admin'})
            if self.command == 'POST':
                cur.execute("select 1 from auth.users where lower(email)=lower(%s)", (b['email'],))
                if cur.fetchone(): return self.send(422, {'msg': 'A user with this email address has already been registered', 'code': 'email_exists'})
                uid = str(uuid.uuid4())
                cur.execute("insert into auth.users (id, email) values (%s, %s)", (uid, b['email']))
                cur.execute("insert into auth.local_pw (id, senha, meta) values (%s, %s, %s)", (uid, h(b.get('password', '')), json.dumps(b.get('user_metadata', {}))))
                return self.send(200, user_obj(uid, b['email'], b.get('user_metadata')))
            if self.command == 'DELETE':
                uid = rota.split('/')[-1]
                cur.execute("delete from auth.users where id=%s", (uid,)); return self.send(200, {})
        return self.send(404, {'msg': 'rota auth não simulada: ' + rota})

    # ---------------- storage ----------------
    def as_user(self, cur, cl):
        cur.execute("select set_config('request.jwt.claims', %s, true)", (json.dumps(cl),))
        cur.execute("set local role " + ('service_role' if cl.get('role') == 'service_role' else 'authenticated'))

    def storage(self, p):
        rota = p.path[len('/storage/v1'):]
        cl = self.claims()
        m = re.match(r'^/object/sign/([^/]+)/(.+)$', rota)
        if m and self.command == 'GET':
            tk = parse_qs(p.query).get('token', [''])[0]
            try: d = jwt.decode(tk, SECRET, algorithms=['HS256'])
            except Exception: return self.send(400, {'error': 'InvalidJWT', 'message': 'invalid signature or expired'})
            if d.get('url') != m.group(1) + '/' + m.group(2): return self.send(400, {'error': 'bad token'})
            f = os.path.join(STORE, m.group(1), m.group(2))
            if not os.path.exists(f): return self.send(404, {'error': 'not found'})
            return self.send(200, open(f, 'rb').read(), 'image/jpeg')
        if not cl: return self.send(401, {'error': 'Unauthorized', 'message': 'jwt required'})
        md = re.match(r'^/object/([^/]+)/?$', rota)
        if md and self.command == 'DELETE':
            b = json.loads(self.body() or b'{}'); out = []
            c = db(); cur = c.cursor(); cur.execute('begin'); self.as_user(cur, cl)
            for path in b.get('prefixes', []):
                cur.execute("delete from storage.objects where bucket_id=%s and name=%s returning name", (md.group(1), path))
                if cur.fetchone(): out.append({'name': path})
            cur.execute('commit')
            return self.send(200, out)
        mb = re.match(r'^/object/sign/([^/]+)/?$', rota)
        if mb and self.command == 'POST':
            b = json.loads(self.body() or b'{}'); bucket = mb.group(1); out = []
            c = db(); cur = c.cursor(); cur.execute('begin'); self.as_user(cur, cl)
            for path in b.get('paths', []):
                cur.execute("select 1 from storage.objects where bucket_id=%s and name=%s", (bucket, path))
                if cur.fetchone():
                    tk = jwt.encode({'url': bucket + '/' + path, 'exp': int(time.time()) + int(b.get('expiresIn', 60))}, SECRET, algorithm='HS256')
                    out.append({'path': path, 'signedURL': f'/object/sign/{bucket}/{path}?token={tk}', 'error': None})
                else: out.append({'path': path, 'signedURL': None, 'error': 'Either the object does not exist or you do not have access to it'})
            cur.execute('rollback')
            return self.send(200, out)
        if m and self.command == 'POST':
            b = json.loads(self.body() or b'{}')
            c = db(); cur = c.cursor(); cur.execute('begin'); self.as_user(cur, cl)
            cur.execute("select 1 from storage.objects where bucket_id=%s and name=%s", (m.group(1), m.group(2)))
            ok = cur.fetchone(); cur.execute('rollback')
            if not ok: return self.send(400, {'error': 'not_found', 'message': 'Object not found', 'statusCode': '404'})
            tk = jwt.encode({'url': m.group(1) + '/' + m.group(2), 'exp': int(time.time()) + int(b.get('expiresIn', 60))}, SECRET, algorithm='HS256')
            return self.send(200, {'signedURL': f'/object/sign/{m.group(1)}/{m.group(2)}?token={tk}'})
        m = re.match(r'^/object/([^/]+)/(.+)$', rota)
        if m and self.command in ('POST', 'PUT'):
            data = self.body(); bucket, name = m.group(1), m.group(2)
            ct = self.headers.get('Content-Type', '')
            if ct.startswith('multipart/form-data'):
                bnd = ct.split('boundary=')[1].strip('"').encode()
                for parte in data.split(b'--' + bnd):
                    if b'\r\n\r\n' not in parte: continue
                    cab, corpo = parte.split(b'\r\n\r\n', 1)
                    mm = re.search(rb'Content-Type: ([^\r\n]+)', cab)
                    if mm and b'filename' in cab:
                        ct = mm.group(1).decode(); data = corpo[:-2] if corpo.endswith(b'\r\n') else corpo; break
            c = db(); cur = c.cursor(); cur.execute('begin')
            cur.execute("select file_size_limit, allowed_mime_types from storage.buckets where id=%s", (bucket,))
            bk = cur.fetchone()
            if not bk: cur.execute('rollback'); return self.send(400, {'error': 'Bucket not found', 'statusCode': '404', 'message': 'Bucket not found'})
            if bk[0] and len(data) > bk[0]: cur.execute('rollback'); return self.send(413, {'statusCode': '413', 'error': 'Payload too large', 'message': 'The object exceeded the maximum allowed size'})
            if bk[1] and ct.split(';')[0] not in bk[1]: cur.execute('rollback'); return self.send(415, {'statusCode': '415', 'error': 'invalid_mime_type', 'message': f'mime type {ct} is not supported'})
            cur.execute("select 1 from storage.objects where bucket_id=%s and name=%s", (bucket, name))
            if cur.fetchone(): cur.execute('rollback'); return self.send(400, {'statusCode': '409', 'error': 'Duplicate', 'message': 'The resource already exists'})
            self.as_user(cur, cl)
            try:
                cur.execute("insert into storage.objects (bucket_id, name, owner, metadata) values (%s,%s,%s,%s)", (bucket, name, cl.get('sub'), json.dumps({'size': len(data), 'mimetype': ct})))
                cur.execute('commit')
            except psycopg2.Error as e:
                cur.execute('rollback')
                return self.send(403, {'statusCode': '403', 'error': 'Unauthorized', 'message': 'new row violates row-level security policy'})
            f = os.path.join(STORE, bucket, name); os.makedirs(os.path.dirname(f), exist_ok=True); open(f, 'wb').write(data)
            return self.send(200, {'Key': f'{bucket}/{name}', 'Id': str(uuid.uuid4())})
        return self.send(404, {'error': 'rota storage não simulada: ' + rota})

    # ---------------- estáticos ----------------
    def static(self, path):
        if path in ('', '/'): path = '/index.html'
        f = os.path.normpath(os.path.join(APP_DIR, path.lstrip('/')))
        if not f.startswith(APP_DIR) or not os.path.isfile(f):
            f = os.path.join(APP_DIR, 'index.html')    # SPA (como a Cloudflare Pages sem 404.html)
        ct = mimetypes.guess_type(f)[0] or 'application/octet-stream'
        if f.endswith('.webmanifest'): ct = 'application/manifest+json'
        if f.endswith('.js') or f.endswith('.mjs'): ct = 'text/javascript'
        extra = {'Cache-Control': 'no-cache'}
        try:
            hd = open(os.path.join(APP_DIR, '_headers')).read()
            m = re.search(r'Content-Security-Policy: (.*)', hd)
            if m and f.endswith('.html'): extra['Content-Security-Policy'] = m.group(1).replace('https://*.supabase.co', "'self'").replace('wss://*.supabase.co', '')
        except Exception: pass
        self.send(200, open(f, 'rb').read(), ct, extra)

if __name__ == '__main__':
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 9000
    print('anon', ANON); print('service', SERVICE); sys.stdout.flush()
    ThreadingHTTPServer(('127.0.0.1', port), H).serve_forever()
