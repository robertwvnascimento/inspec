// local: faz o Deno.serve() das funções ouvir na porta definida
const port = Number(Deno.env.get('PORT'));
const orig = Deno.serve.bind(Deno);
// deno-lint-ignore no-explicit-any
(Deno as any).serve = (h: any) => orig({ port, hostname: '127.0.0.1', onListen() {} }, h);
await import('file://' + Deno.env.get('FN'));
