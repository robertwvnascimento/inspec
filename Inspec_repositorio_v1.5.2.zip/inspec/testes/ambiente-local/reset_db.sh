#!/bin/bash
# recria o banco local de testes do Inspec
P="psql -h /tmp -p 54329 -U postgres -v ON_ERROR_STOP=1 -q"
$P -c "select pg_terminate_backend(pid) from pg_stat_activity where datname='inspecprod' and pid<>pg_backend_pid()" >/dev/null
$P -c "drop database if exists inspecprod" && $P -c "create database inspecprod" && \
$P -d inspecprod -f stub_local.sql && \
sed "s/SEU-EMAIL@exemplo.com.br/owner@inspec.local/" ${1:-../../supabase/inspec-completo.sql} > /tmp/inspec_local.sql && \
$P -d inspecprod -f /tmp/inspec_local.sql 2>&1 | grep -v NOTICE
echo "db pronto"
