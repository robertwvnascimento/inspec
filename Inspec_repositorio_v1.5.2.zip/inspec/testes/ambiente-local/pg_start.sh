#!/bin/bash
su postgres -c "/usr/lib/postgresql/16/bin/pg_ctl -D /var/tmp/pgi/data -o '-p 54329 -k /tmp -c listen_addresses=127.0.0.1' -l /var/tmp/pgi/log status >/dev/null || /usr/lib/postgresql/16/bin/pg_ctl -D /var/tmp/pgi/data -o '-p 54329 -k /tmp -c listen_addresses=127.0.0.1' -l /var/tmp/pgi/log start" >/dev/null
sleep 1
