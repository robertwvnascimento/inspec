#!/bin/bash
# sobe o Supabase local: postgres, postgrest, funções (deno) e o proxy
cd "$(dirname "$0")"
./pg_start.sh
pkill -f "postgrest postgrest.conf" 2>/dev/null; pkill -f "server.py" 2>/dev/null; pkill -f "deno run" 2>/dev/null; sleep 0.5
POSTGREST=${POSTGREST:-postgrest}   # binário do PostgREST (https://postgrest.org)
nohup $POSTGREST postgrest.conf > /var/tmp/pgrst.log 2>&1 &
ANON=$(python3 -c "import server;print(server.ANON)"); SERVICE=$(python3 -c "import server;print(server.SERVICE)")
FDIR=${FDIR:-$PWD/../../supabase/functions}
P=3101; FUNCS="{"
for f in criar-usuario excluir-usuario enviar-onepage; do
  if [ -f $FDIR/$f/index.ts ]; then
    SUPABASE_URL=http://127.0.0.1:9000 SUPABASE_ANON_KEY=$ANON SERVICE_KEY=$SERVICE APP_DOMINIO=http://127.0.0.1:9000 EMAIL_KEY=teste \
      PORT=$P FN=$FDIR/$f/index.ts nohup npx -y deno run -A fnwrap.ts > /var/tmp/fn_$f.log 2>&1 &
    FUNCS="$FUNCS\"$f\":$P,"; P=$((P+1))
  fi
done
FUNCS="${FUNCS%,}}"
APP_DIR=${APP_DIR:-$PWD/../../app} FUNCS="$FUNCS" nohup python3 server.py 9000 > /var/tmp/proxy.log 2>&1 &
sleep 3; echo "up: $FUNCS"
