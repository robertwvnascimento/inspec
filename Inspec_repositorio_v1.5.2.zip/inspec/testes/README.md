# Testes do Inspec

Ferramentas usadas para validar o sistema antes de cada versão. **Não fazem parte do site publicado.**

## `ambiente-local/` — Supabase simulado
Sobe, na própria máquina, um Postgres 16 com o `supabase/inspec-completo.sql`, o PostgREST e um proxy (`server.py`, porta 9000) que simula Auth, Storage, Edge Functions e o cabeçalho `X-Forwarded-For` do Supabase.

1. Requisitos: PostgreSQL 16, PostgREST, Python 3, Deno (via `npx deno`).
2. `./pg_start.sh` → `./reset_db.sh` → `./up.sh` (ajuste caminhos e a variável `POSTGREST` se necessário).
3. Para testar o app contra o ambiente local, troque temporariamente o `app/config.js` para `SUPABASE_URL: 'http://127.0.0.1:9000'` e a chave anônima impressa por `python3 -c "import server;print(server.ANON)"`. **Volte o config.js de produção antes de publicar.**

## `e2e/` — testes ponta a ponta (Playwright)
`pip install playwright pypdf pillow` · Chromium do Playwright.
Ordem usada para povoar dados de demonstração: `reset_all.sh`, `t1_bootstrap.py`, `t2_admin.py`, `t3_inspetor.py`, `t4_desvio_qr.py`, `t9_gal.py`, `t14.py`, `t6_gestao.py`. Os demais testam recursos específicos (`t20_v151.py`: inatividade, IP, relatórios em paisagem, bibliotecas). `shots*.py` geram as telas do Guia de Uso em `saida/`.

Os usuários e senhas desses scripts existem **só** no banco local de teste.
