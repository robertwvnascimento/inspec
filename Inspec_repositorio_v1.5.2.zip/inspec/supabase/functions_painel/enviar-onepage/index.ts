// Inspec — envia o One Page de um comunicado de desvio por e-mail (provedor: Resend — decisão D17)
// O app gera o PDF (jsPDF) e envia em base64. Os destinatários vêm do BANCO (tabela destinatarios),
// nunca do navegador. Corpo: { desvio_id, pdf_base64 }
// Secrets: SERVICE_KEY, EMAIL_KEY (API key do Resend), EMAIL_FROM (remetente verificado), APP_DOMINIO
// Versão de arquivo único (para colar no editor do painel do Supabase)
import { createClient, type SupabaseClient } from 'npm:@supabase/supabase-js@2';

/* ---------- utilidades compartilhadas ---------- */
const ORIGENS = (Deno.env.get('APP_DOMINIO') ?? 'https://inspec.rwnitsolutions.com.br')
  .split(',').map((s) => s.trim()).filter(Boolean);

function cors(req: Request): Record<string, string> {
  const origem = req.headers.get('Origin') ?? '';
  const permitida = ORIGENS.includes(origem) || /^https:\/\/([a-z0-9-]+\.)?inspec\.pages\.dev$/.test(origem) || origem === 'http://localhost:8080';
  return {
    'Access-Control-Allow-Origin': permitida ? origem : ORIGENS[0],
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Vary': 'Origin',
  };
}

function json(req: Request, corpo: unknown, status = 200): Response {
  return new Response(JSON.stringify(corpo), { status, headers: { ...cors(req), 'Content-Type': 'application/json' } });
}

/** Cliente com o JWT de quem chamou (respeita a RLS) e o usuário autenticado. */
async function chamador(req: Request): Promise<{ cliente: SupabaseClient; userId: string | null }> {
  // chave pública: a que o app enviou no cabeçalho apikey (ou a injetada pelo Supabase)
  const chave = req.headers.get('apikey') ?? Deno.env.get('SUPABASE_ANON_KEY') ?? '';
  const cliente = createClient(Deno.env.get('SUPABASE_URL')!, chave, {
    global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } },
    auth: { persistSession: false },
  });
  const jwt = (req.headers.get('Authorization') ?? '').replace(/^Bearer\s+/i, '');
  if (!jwt) return { cliente, userId: null };
  const { data } = await cliente.auth.getUser(jwt);
  return { cliente, userId: data.user?.id ?? null };
}

/** Cliente administrativo: a chave secreta só existe aqui (secret SERVICE_KEY).
 *  Testa a chave antes de usar; se falhar, tenta a chave de serviço injetada pelo Supabase. */
let admCache: SupabaseClient | null = null;
async function admin(): Promise<SupabaseClient> {
  if (admCache) return admCache;
  const limpa = (v?: string) => (v ?? '').trim().replace(/^['"]|['"]$/g, '').trim();
  const candidatas = [limpa(Deno.env.get('SERVICE_KEY')), limpa(Deno.env.get('SUPABASE_SERVICE_ROLE_KEY'))].filter(Boolean);
  if (!candidatas.length) throw new Error('Secret SERVICE_KEY não configurado nas Edge Functions');
  let ultimo = '';
  for (const chave of [...new Set(candidatas)]) {
    const c = createClient(Deno.env.get('SUPABASE_URL')!, chave, { auth: { persistSession: false, autoRefreshToken: false } });
    const { error } = await c.from('membros').select('id', { count: 'exact', head: true }).limit(1);
    if (!error) { admCache = c; return c; }
    ultimo = error.message || error.code || 'chave inválida';
  }
  throw new Error(`A chave secreta (SERVICE_KEY) foi recusada pelo banco: ${ultimo}. Confira o secret em Edge Functions → Secrets (cole só o valor sb_secret_..., sem aspas nem espaços).`);
}

/** Confere se o usuário é owner/admin ativo da organização. */
async function exigirAdmin(adm: SupabaseClient, userId: string, orgId: string): Promise<string | null> {
  const { data, error } = await adm.from('membros').select('papel').eq('usuario_id', userId).eq('org_id', orgId).eq('ativo', true).maybeSingle();
  if (error) throw new Error('Falha ao verificar a permissão: ' + error.message);
  return data && ['owner', 'admin'].includes(data.papel) ? data.papel : null;
}

function senhaProvisoria(): string {
  const alf = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  const b = crypto.getRandomValues(new Uint8Array(12));
  return Array.from(b, (x) => alf[x % alf.length]).join('');
}

/* ---------- função ---------- */
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors(req) });
  if (req.method !== 'POST') return json(req, { erro: 'Método não permitido' }, 405);
  try {
    const { cliente, userId } = await chamador(req);
    if (!userId) return json(req, { erro: 'Não autenticado' }, 401);
    const b = await req.json();
    if (!b.desvio_id || typeof b.pdf_base64 !== 'string') return json(req, { erro: 'Dados incompletos' }, 400);
    if (b.pdf_base64.length > 6_000_000) return json(req, { erro: 'PDF grande demais' }, 413);

    // leitura com o JWT do usuário: a RLS garante que ele enxerga este desvio
    const { data: d, error } = await cliente.from('desvios')
      .select('id, numero, org_id, unidade_id, gatilho, status, destinatarios, ponto_id, pontos(codigo, local, gerencia_id)')
      .eq('id', b.desvio_id).maybeSingle();
    if (error || !d) return json(req, { erro: 'Comunicado não encontrado' }, 404);

    const adm = await admin();
    const ponto = (d as any).pontos;
    const { data: dest } = await adm.from('destinatarios').select('email, papel, gerencia_id')
      .eq('org_id', d.org_id).eq('ativo', true)
      .or(`unidade_id.is.null,unidade_id.eq.${d.unidade_id}`);
    const lista = (dest ?? [])
      .filter((x) => !x.gerencia_id || x.gerencia_id === ponto?.gerencia_id)
      .filter((x) => !d.destinatarios?.length || d.destinatarios.includes(x.papel))
      .map((x) => x.email);
    const emails = [...new Set(lista)];
    if (!emails.length) return json(req, { erro: 'Nenhum destinatário cadastrado para este ponto' }, 400);

    const gatilho = { extrativo: 'Extrativo', violacao: 'Violação', combate: 'Em combate' }[d.gatilho as string] ?? d.gatilho;
    if (!Deno.env.get('EMAIL_KEY')) return json(req, { erro: 'Envio de e-mail não configurado: falta o secret EMAIL_KEY.' }, 500);
    let resp: Response;
    try {
      resp = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${Deno.env.get('EMAIL_KEY')}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from: Deno.env.get('EMAIL_FROM') ?? 'Inspec <inspec@rwnitsolutions.com.br>',
        to: emails,
        subject: `[Inspec] ${d.numero} — ${gatilho} — ${ponto?.codigo ?? ''}`,
        html: `<p>Comunicado de desvio <b>${d.numero}</b> (${gatilho}) no ponto <b>${ponto?.codigo ?? ''}</b> — ${ponto?.local ?? ''}.</p>
               <p>Situação: <b>${d.status === 'pendente' ? 'pendente de reposição' : 'encerrado'}</b>. O One Page segue em anexo.</p>
               <p style="color:#6B7C8D;font-size:12px">Mensagem automática do Inspec · ${Deno.env.get('APP_DOMINIO') ?? ''}</p>`,
        attachments: [{ filename: `OnePage_${d.numero}.pdf`, content: b.pdf_base64 }],
      }),
      });
    } catch (falha) {
      const msg = falha instanceof Error ? falha.message : String(falha);
      await adm.from('envios_email').insert({ org_id: d.org_id, desvio_id: d.id, destinatarios: emails, status: 'erro', erro: ('Provedor inacessível: ' + msg).slice(0, 500), enviado_por: userId });
      return json(req, { erro: 'Não foi possível contatar o provedor de e-mail. Tente novamente em alguns minutos.' }, 502);
    }
    const retorno = await resp.json().catch(() => ({}));
    await adm.from('envios_email').insert({
      org_id: d.org_id, desvio_id: d.id, destinatarios: emails, status: resp.ok ? 'enviado' : 'erro',
      id_provedor: (retorno as any)?.id ?? null, erro: resp.ok ? null : JSON.stringify(retorno).slice(0, 500), enviado_por: userId,
    });
    if (!resp.ok) return json(req, { erro: 'O provedor de e-mail recusou o envio', detalhe: retorno }, 502);
    return json(req, { ok: true, destinatarios: emails.length });
  } catch (e) {
    return json(req, { erro: e instanceof Error ? e.message : 'Erro inesperado' }, 500);
  }
});
