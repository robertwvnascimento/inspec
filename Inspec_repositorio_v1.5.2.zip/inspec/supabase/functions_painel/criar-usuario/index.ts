// Inspec — cria um usuário (somente owner/admin da organização)
// Corpo: { org_id, email, nome, papel: 'admin'|'inspetor'|'inspetor_leitura'|'admin_leitura', unidades: uuid[], senha_inicial? }
// Resposta: { usuario_id, senha_inicial }  → o admin repassa a senha; troca obrigatória no 1º acesso.
// Versão de arquivo único (para colar no editor do painel do Supabase)
import { createClient, type SupabaseClient } from 'npm:@supabase/supabase-js@2';

/* ---------- utilidades compartilhadas ---------- */
const ORIGENS = (Deno.env.get('APP_DOMINIO') ?? 'https://inspec.rwnitsolutions.com.br')
  .split(',').map((s) => s.trim()).filter(Boolean);

function cors(req: Request): Record<string, string> {
  const origem = req.headers.get('Origin') ?? '';
  const permitida = ORIGENS.includes(origem) || /^https:\/\/([a-z0-9-]+\.)?inspec\.pages\.dev$/.test(origem) || origem === 'http://localhost:8080';
  return {
    'Access-Control-Allow-Origin': permitida ? origem : ORIGENS[0],
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Vary': 'Origin',
  };
}

function json(req: Request, corpo: unknown, status = 200): Response {
  return new Response(JSON.stringify(corpo), { status, headers: { ...cors(req), 'Content-Type': 'application/json' } });
}

/** Cliente com o JWT de quem chamou (respeita a RLS) e o usuário autenticado. */
async function chamador(req: Request): Promise<{ cliente: SupabaseClient; userId: string | null }> {
  // chave pública: a que o app enviou no cabeçalho apikey (ou a injetada pelo Supabase)
  const chave = req.headers.get('apikey') ?? Deno.env.get('SUPABASE_ANON_KEY') ?? '';
  const cliente = createClient(Deno.env.get('SUPABASE_URL')!, chave, {
    global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } },
    auth: { persistSession: false },
  });
  const jwt = (req.headers.get('Authorization') ?? '').replace(/^Bearer\s+/i, '');
  if (!jwt) return { cliente, userId: null };
  const { data } = await cliente.auth.getUser(jwt);
  return { cliente, userId: data.user?.id ?? null };
}

/** Cliente administrativo: a chave secreta só existe aqui (secret SERVICE_KEY).
 *  Testa a chave antes de usar; se falhar, tenta a chave de serviço injetada pelo Supabase. */
let admCache: SupabaseClient | null = null;
async function admin(): Promise<SupabaseClient> {
  if (admCache) return admCache;
  const limpa = (v?: string) => (v ?? '').trim().replace(/^['"]|['"]$/g, '').trim();
  const candidatas = [limpa(Deno.env.get('SERVICE_KEY')), limpa(Deno.env.get('SUPABASE_SERVICE_ROLE_KEY'))].filter(Boolean);
  if (!candidatas.length) throw new Error('Secret SERVICE_KEY não configurado nas Edge Functions');
  let ultimo = '';
  for (const chave of [...new Set(candidatas)]) {
    const c = createClient(Deno.env.get('SUPABASE_URL')!, chave, { auth: { persistSession: false, autoRefreshToken: false } });
    const { error } = await c.from('membros').select('id', { count: 'exact', head: true }).limit(1);
    if (!error) { admCache = c; return c; }
    ultimo = error.message || error.code || 'chave inválida';
  }
  throw new Error(`A chave secreta (SERVICE_KEY) foi recusada pelo banco: ${ultimo}. Confira o secret em Edge Functions → Secrets (cole só o valor sb_secret_..., sem aspas nem espaços).`);
}

/** Confere se o usuário é owner/admin ativo da organização. */
async function exigirAdmin(adm: SupabaseClient, userId: string, orgId: string): Promise<string | null> {
  const { data, error } = await adm.from('membros').select('papel').eq('usuario_id', userId).eq('org_id', orgId).eq('ativo', true).maybeSingle();
  if (error) throw new Error('Falha ao verificar a permissão: ' + error.message);
  return data && ['owner', 'admin'].includes(data.papel) ? data.papel : null;
}

function senhaProvisoria(): string {
  const alf = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  const b = crypto.getRandomValues(new Uint8Array(12));
  return Array.from(b, (x) => alf[x % alf.length]).join('');
}

/* ---------- função ---------- */
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors(req) });
  if (req.method !== 'POST') return json(req, { erro: 'Método não permitido' }, 405);
  try {
    const { userId } = await chamador(req);
    if (!userId) return json(req, { erro: 'Não autenticado' }, 401);

    const b = await req.json();
    const email = String(b.email ?? '').trim().toLowerCase();
    const nome = String(b.nome ?? '').trim();
    const papel = String(b.papel ?? '');
    const unidades: string[] = Array.isArray(b.unidades) ? b.unidades : [];
    if (!b.org_id || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || nome.length < 2) return json(req, { erro: 'Dados incompletos' }, 400);
    if (!['admin', 'inspetor', 'inspetor_leitura', 'admin_leitura'].includes(papel)) return json(req, { erro: 'Papel inválido' }, 400);

    const adm = await admin();
    const papelChamador = await exigirAdmin(adm, userId, b.org_id);
    if (!papelChamador) return json(req, { erro: 'Somente administradores criam usuários' }, 403);
    if (papel === 'admin' && papelChamador !== 'owner') return json(req, { erro: 'Somente o owner cria administradores' }, 403);

    // as unidades informadas precisam ser da mesma organização
    if (unidades.length) {
      const { count } = await adm.from('unidades').select('id', { count: 'exact', head: true }).eq('org_id', b.org_id).in('id', unidades);
      if (count !== unidades.length) return json(req, { erro: 'Unidade fora da organização' }, 400);
    }

    const senha = typeof b.senha_inicial === 'string' && b.senha_inicial.length >= 8 ? b.senha_inicial : senhaProvisoria();
    const { data: criado, error } = await adm.auth.admin.createUser({ email, password: senha, email_confirm: true, user_metadata: { nome } });
    if (error || !criado.user) return json(req, { erro: error?.message ?? 'Falha ao criar o login' }, 400);

    const { data: membro, error: e2 } = await adm.from('membros')
      .insert({ org_id: b.org_id, usuario_id: criado.user.id, nome, papel, trocar_senha: true }).select('id').single();
    if (e2) { await adm.auth.admin.deleteUser(criado.user.id); return json(req, { erro: e2.message }, 400); }
    if (unidades.length) await adm.from('membro_unidades').insert(unidades.map((u) => ({ membro_id: membro.id, unidade_id: u })));
    await adm.from('usuarios').upsert({ id: criado.user.id, email, nome });
    await adm.from('logs').insert({ org_id: b.org_id, usuario_id: userId, acao: 'usuario_criado', detalhe: { email, papel } });

    return json(req, { usuario_id: criado.user.id, senha_inicial: senha });
  } catch (e) {
    return json(req, { erro: e instanceof Error ? e.message : 'Erro inesperado' }, 500);
  }
});
