// Inspec — exclui o login de um usuário (somente owner/admin). O histórico é preservado:
// inspeções, trocas e alterações mantêm o registro com o autor como "usuário removido".
// Corpo: { org_id, usuario_id }
// Versão de arquivo único (para colar no editor do painel do Supabase)
import { createClient, type SupabaseClient } from 'npm:@supabase/supabase-js@2';

/* ---------- utilidades compartilhadas ---------- */
const ORIGENS = (Deno.env.get('APP_DOMINIO') ?? 'https://inspec.rwnitsolutions.com.br')
  .split(',').map((s) => s.trim()).filter(Boolean);

function cors(req: Request): Record<string, string> {
  const origem = req.headers.get('Origin') ?? '';
  const permitida = ORIGENS.includes(origem) || /^https:\/\/([a-z0-9-]+\.)?inspec\.pages\.dev$/.test(origem) || origem === 'http://localhost:8080';
  return {
    'Access-Control-Allow-Origin': permitida ? origem : ORIGENS[0],
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Vary': 'Origin',
  };
}

function json(req: Request, corpo: unknown, status = 200): Response {
  return new Response(JSON.stringify(corpo), { status, headers: { ...cors(req), 'Content-Type': 'application/json' } });
}

/** Cliente com o JWT de quem chamou (respeita a RLS) e o usuário autenticado. */
async function chamador(req: Request): Promise<{ cliente: SupabaseClient; userId: string | null }> {
  // chave pública: a que o app enviou no cabeçalho apikey (ou a injetada pelo Supabase)
  const chave = req.headers.get('apikey') ?? Deno.env.get('SUPABASE_ANON_KEY') ?? '';
  const cliente = createClient(Deno.env.get('SUPABASE_URL')!, chave, {
    global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } },
    auth: { persistSession: false },
  });
  const jwt = (req.headers.get('Authorization') ?? '').replace(/^Bearer\s+/i, '');
  if (!jwt) return { cliente, userId: null };
  const { data } = await cliente.auth.getUser(jwt);
  return { cliente, userId: data.user?.id ?? null };
}

/** Cliente administrativo: a chave secreta só existe aqui (secret SERVICE_KEY).
 *  Testa a chave antes de usar; se falhar, tenta a chave de serviço injetada pelo Supabase. */
let admCache: SupabaseClient | null = null;
async function admin(): Promise<SupabaseClient> {
  if (admCache) return admCache;
  const limpa = (v?: string) => (v ?? '').trim().replace(/^['"]|['"]$/g, '').trim();
  const candidatas = [limpa(Deno.env.get('SERVICE_KEY')), limpa(Deno.env.get('SUPABASE_SERVICE_ROLE_KEY'))].filter(Boolean);
  if (!candidatas.length) throw new Error('Secret SERVICE_KEY não configurado nas Edge Functions');
  let ultimo = '';
  for (const chave of [...new Set(candidatas)]) {
    const c = createClient(Deno.env.get('SUPABASE_URL')!, chave, { auth: { persistSession: false, autoRefreshToken: false } });
    const { error } = await c.from('membros').select('id', { count: 'exact', head: true }).limit(1);
    if (!error) { admCache = c; return c; }
    ultimo = error.message || error.code || 'chave inválida';
  }
  throw new Error(`A chave secreta (SERVICE_KEY) foi recusada pelo banco: ${ultimo}. Confira o secret em Edge Functions → Secrets (cole só o valor sb_secret_..., sem aspas nem espaços).`);
}

/** Confere se o usuário é owner/admin ativo da organização. */
async function exigirAdmin(adm: SupabaseClient, userId: string, orgId: string): Promise<string | null> {
  const { data, error } = await adm.from('membros').select('papel').eq('usuario_id', userId).eq('org_id', orgId).eq('ativo', true).maybeSingle();
  if (error) throw new Error('Falha ao verificar a permissão: ' + error.message);
  return data && ['owner', 'admin'].includes(data.papel) ? data.papel : null;
}

function senhaProvisoria(): string {
  const alf = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  const b = crypto.getRandomValues(new Uint8Array(12));
  return Array.from(b, (x) => alf[x % alf.length]).join('');
}

/* ---------- função ---------- */
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors(req) });
  if (req.method !== 'POST') return json(req, { erro: 'Método não permitido' }, 405);
  try {
    const { userId } = await chamador(req);
    if (!userId) return json(req, { erro: 'Não autenticado' }, 401);
    const b = await req.json();
    if (!b.org_id || !b.usuario_id) return json(req, { erro: 'Dados incompletos' }, 400);
    if (b.usuario_id === userId) return json(req, { erro: 'Você não pode excluir o próprio usuário' }, 400);

    const adm = await admin();
    if (!(await exigirAdmin(adm, userId, b.org_id))) return json(req, { erro: 'Somente administradores excluem usuários' }, 403);

    const { data: alvo } = await adm.from('membros').select('papel, nome').eq('org_id', b.org_id).eq('usuario_id', b.usuario_id).maybeSingle();
    if (!alvo) return json(req, { erro: 'Usuário não pertence à organização' }, 404);
    if (alvo.papel === 'owner') return json(req, { erro: 'O owner não pode ser excluído' }, 400);

    const { error } = await adm.auth.admin.deleteUser(b.usuario_id);
    if (error) return json(req, { erro: error.message }, 400);
    await adm.from('logs').insert({ org_id: b.org_id, usuario_id: userId, acao: 'usuario_excluido', detalhe: { nome: alvo.nome } });
    return json(req, { ok: true });
  } catch (e) {
    return json(req, { erro: e instanceof Error ? e.message : 'Erro inesperado' }, 500);
  }
});
