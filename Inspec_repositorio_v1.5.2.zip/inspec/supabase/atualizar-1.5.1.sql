-- =====================================================================
-- INSPEC — atualização do banco 1.5 → 1.5.1
-- Supabase → SQL Editor → New query → cole TUDO → Run.
-- Pode rodar mais de uma vez: não apaga dados.
-- Não precisa de e-mail: a organização e o owner já existem.
-- =====================================================================

-- =====================================================================
-- 12. REGISTROS DE ACESSO COM IP (v1.5.1) — Marco Civil da Internet, art. 15
--     Gravados pelo servidor a partir dos cabeçalhos da requisição; somente owner/admin leem;
--     imutáveis e mantidos mesmo quando o sistema é zerado (guarda mínima recomendada: 6 meses).
-- =====================================================================
create table if not exists public.acessos (
  id          bigint generated always as identity primary key,
  org_id      uuid references public.organizacoes(id) on delete cascade,
  usuario_id  uuid,
  email       text,
  evento      text not null,
  ip          text,
  ip_cadeia   text,
  navegador   text,
  criado_em   timestamptz not null default now()
);
create index if not exists acessos_org_data on public.acessos (org_id, criado_em desc);
alter table public.acessos enable row level security;
drop policy if exists acs_sel on public.acessos;
create policy acs_sel on public.acessos for select to authenticated using (app.e_admin(org_id));
revoke insert, update, delete on public.acessos from authenticated, anon;
grant select on public.acessos to authenticated;
grant all on public.acessos to service_role;
drop trigger if exists acessos_imutavel on public.acessos;
create trigger acessos_imutavel before update or delete on public.acessos for each row execute function app.tg_somente_insercao();

-- IP do cliente: cf-connecting-ip (definido pela Cloudflare do Supabase, não forjável pelo cliente) → x-real-ip → x-forwarded-for
create or replace function app.req_cabecalho(p_nome text) returns text
language plpgsql stable as $$
declare h json;
begin
  begin h := nullif(current_setting('request.headers', true), '')::json; exception when others then return null; end;
  return nullif(trim(h ->> p_nome), '');
end $$;

create or replace function app.registrar_acesso(p_org uuid, p_uid uuid, p_email text, p_evento text) returns void
language plpgsql security definer set search_path = public as $$
declare xff text := app.req_cabecalho('x-forwarded-for');
begin
  insert into public.acessos (org_id, usuario_id, email, evento, ip, ip_cadeia, navegador)
  values (p_org, p_uid, lower(p_email), p_evento,
          coalesce(app.req_cabecalho('cf-connecting-ip'), app.req_cabecalho('x-real-ip'), trim(split_part(xff, ',', 1))),
          left(xff, 300), left(app.req_cabecalho('user-agent'), 300));
end $$;

create or replace function public.registrar_evento(p_acao text, p_detalhe jsonb default '{}'::jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare d jsonb := coalesce(p_detalhe, '{}'::jsonb); v_org uuid; v_email text;
begin
  if auth.uid() is null then return; end if;
  if p_acao !~ '^(acesso|app)\.[a-z_]{2,40}$' then raise exception 'Evento inválido'; end if;
  if length(d::text) > 2000 then d := jsonb_build_object('resumo', 'detalhe omitido (muito grande)'); end if;
  insert into public.logs (org_id, usuario_id, acao, detalhe, tabela, rotulo)
  select m.org_id, auth.uid(), p_acao, d, 'app', coalesce(d ->> 'rotulo', m.nome)
    from public.membros m where m.usuario_id = auth.uid() and m.ativo;
  if not found then
    insert into public.logs (org_id, usuario_id, acao, detalhe, tabela) values (null, auth.uid(), p_acao, d, 'app');
  end if;
  if p_acao like 'acesso.%' then
    select m.org_id into v_org from public.membros m where m.usuario_id = auth.uid() and m.ativo limit 1;
    select u.email into v_email from public.usuarios u where u.id = auth.uid();
    perform app.registrar_acesso(v_org, auth.uid(), v_email, p_acao);
  end if;
end $$;

create or replace function public.registrar_falha_login(p_email text) returns void
language plpgsql security definer set search_path = public as $$
declare v_uid uuid; v_org uuid;
begin
  select u.id, m.org_id into v_uid, v_org from auth.users u join public.membros m on m.usuario_id = u.id
   where lower(u.email) = lower(trim(p_email)) limit 1;
  if v_uid is null then return; end if;
  if (select count(*) from public.logs where usuario_id = v_uid and acao = 'acesso.falha_login' and criado_em > now() - interval '1 hour') >= 20 then return; end if;
  insert into public.logs (org_id, usuario_id, acao, detalhe, tabela) values (v_org, v_uid, 'acesso.falha_login', jsonb_build_object('email', lower(trim(p_email))), 'app');
  perform app.registrar_acesso(v_org, v_uid, p_email, 'acesso.falha_login');
end $$;
revoke execute on function app.registrar_acesso(uuid, uuid, text, text) from public, anon, authenticated;
revoke execute on function app.req_cabecalho(text) from public, anon;
grant execute on function public.registrar_falha_login(text) to anon;


-- =====================================================================
-- 12. VERSÃO DO BANCO
-- =====================================================================

-- versão do banco (aparece em Sobre o sistema)
insert into public.versao_banco (id, versao, aplicado_em) values (1, '1.5.1', now())
on conflict (id) do update set versao = excluded.versao, aplicado_em = excluded.aplicado_em;

select 'Banco atualizado para a versão 1.5.1' as resultado;
