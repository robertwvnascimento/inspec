-- =====================================================================
-- INSPEC — testes_rls.sql
-- Roteiro de testes de segurança e das regras de negócio.
-- Roda dentro de uma transação e termina com ROLLBACK: NADA fica gravado.
-- Uso: SQL Editor do Supabase → colar → Run. Resultado esperado: a
-- última linha mostra "TODOS OS TESTES PASSARAM". Qualquer falha
-- interrompe com a mensagem "FALHOU: ...".
-- =====================================================================
begin;

-- usuários fictícios (somente nesta transação)
insert into auth.users (id, email) values
  ('00000000-0000-4000-8000-000000000001', 'owner.teste@inspec.local'),
  ('00000000-0000-4000-8000-000000000002', 'inspetor.teste@inspec.local'),
  ('00000000-0000-4000-8000-000000000003', 'consulta.teste@inspec.local'),
  ('00000000-0000-4000-8000-000000000004', 'outra.org@inspec.local');
insert into public.convites (email) values ('owner.teste@inspec.local'), ('outra.org@inspec.local') on conflict do nothing;

create temp table _t (k text primary key, v text) on commit drop;
grant all on _t to authenticated;

create or replace function pg_temp.como(p_uid text, p_email text) returns void language sql as $$
  select set_config('request.jwt.claim.sub', p_uid, true), set_config('request.jwt.claim.email', p_email, true),
         set_config('request.jwt.claims', json_build_object('sub', p_uid, 'email', p_email, 'role', 'authenticated')::text, true);
$$;
create or replace function pg_temp.ok(c boolean, msg text) returns void language plpgsql as $$
begin if not coalesce(c, false) then raise exception 'FALHOU: %', msg; end if; end $$;

-- ---------------------------------------------------------------- 1. bootstrap
select pg_temp.como('00000000-0000-4000-8000-000000000001', 'owner.teste@inspec.local');
set local role authenticated;
insert into _t values ('org', public.criar_organizacao('Org Teste', 'Unidade Teste', 'Owner Teste')::text);
select pg_temp.ok((select count(*) from public.categorias) = 4, 'bootstrap cria 4 categorias');
reset role;

-- outra organização (isolamento)
select pg_temp.como('00000000-0000-4000-8000-000000000004', 'outra.org@inspec.local');
set local role authenticated;
insert into _t values ('org2', public.criar_organizacao('Outra Org', 'Outra Unidade', 'Outro Owner')::text);
reset role;

-- membros inspetor e consulta (na produção: Edge Function criar-usuario)
insert into _t select 'unid', id::text from public.unidades where org_id = (select v::uuid from _t where k = 'org');
insert into public.membros (org_id, usuario_id, nome, papel) values
  ((select v::uuid from _t where k='org'), '00000000-0000-4000-8000-000000000002', 'Inspetor Teste', 'inspetor'),
  ((select v::uuid from _t where k='org'), '00000000-0000-4000-8000-000000000003', 'Consulta Teste', 'inspetor_leitura');
insert into public.membro_unidades (membro_id, unidade_id)
  select m.id, (select v::uuid from _t where k='unid') from public.membros m
   where m.usuario_id in ('00000000-0000-4000-8000-000000000002', '00000000-0000-4000-8000-000000000003');

-- ---------------------------------------------------------------- 2. importação e QR (owner)
select pg_temp.como('00000000-0000-4000-8000-000000000001', 'owner.teste@inspec.local');
set local role authenticated;
select pg_temp.ok((public.importar_pontos((select v::uuid from _t where k='unid'),
  '[{"codigo":"ACI-001","categoria":"extintor","gerencia":"ACIARIA","sigla":"ACI","area":"Pátio","local":"Pátio de tarugos","subtipo":"PQS BC","capacidade":"4 kg","numero_cilindro":"11111","agente":"Pó Químico Seco BC 4kg","n2":"2026-09","n3":2027},
    {"codigo":"HID-045","categoria":"hidrante","gerencia":"ACIARIA","sigla":"ACI","area":"Forno","local":"Forno panela"}]'::jsonb)->>'novos')::int = 2, 'importa 2 pontos');
select pg_temp.ok((public.importar_pontos((select v::uuid from _t where k='unid'),
  '[{"codigo":"ACI-001","categoria":"extintor","gerencia":"ACIARIA"}]'::jsonb)->>'existentes')::int = 1, 'reimportação não duplica');
select pg_temp.ok((select count(distinct qr_id) from public.pontos) = 2 and (select bool_and(qr_id ~ '^[2-9A-HJKMNP-Z]{8}$') from public.pontos), 'QR único de 8 caracteres');
insert into _t select 'p1', id::text from public.pontos where codigo = 'ACI-001';
insert into _t select 'qr1', qr_id from public.pontos where codigo = 'ACI-001';
select pg_temp.ok((select count(*) from public.alteracoes where campo = 'ponto_cadastrado') = 2, 'cadastro do ponto registrado no histórico');
reset role;

-- ---------------------------------------------------------------- 3. isolamento entre organizações
select pg_temp.como('00000000-0000-4000-8000-000000000004', 'outra.org@inspec.local');
set local role authenticated;
select pg_temp.ok((select count(*) from public.pontos) = 0, 'outra organização não vê os pontos');
select pg_temp.ok((select count(*) from public.resolver_qr((select v from _t where k='qr1'))) = 0, 'outra organização não resolve o QR');
reset role;

-- ---------------------------------------------------------------- 4. inspeção (inspetor)
select pg_temp.como('00000000-0000-4000-8000-000000000002', 'inspetor.teste@inspec.local');
set local role authenticated;
insert into public.inspecoes (id, ponto_id, org_id, unidade_id, categoria_id, inspetor_id, data_inspecao, periodicidade, ciclo_referencia, status, origem)
select '00000000-0000-4000-8000-0000000000a1', p.id, p.org_id, p.unidade_id, p.categoria_id, auth.uid(), now(), '-', '-', 'ok', 'qr'
  from public.pontos p where p.id = (select v::uuid from _t where k='p1');
select pg_temp.ok((select ciclo_referencia = to_char(now() at time zone 'America/Sao_Paulo', 'YYYY-MM') from public.inspecoes where id = '00000000-0000-4000-8000-0000000000a1'), 'ciclo calculado pelo servidor');
select pg_temp.ok((select count(*) from public.pendencias((select v::uuid from _t where k='unid'), 'extintor')) = 0, 'ponto inspecionado sai das pendências');
reset role;

-- inspeção com autor forjado é recusada (gatilho grava auth.uid())
select pg_temp.como('00000000-0000-4000-8000-000000000002', 'inspetor.teste@inspec.local');
set local role authenticated;
insert into public.inspecoes (id, ponto_id, org_id, unidade_id, categoria_id, inspetor_id, data_inspecao, periodicidade, ciclo_referencia, status)
select '00000000-0000-4000-8000-0000000000a2', p.id, p.org_id, p.unidade_id, p.categoria_id, '00000000-0000-4000-8000-000000000001', now(), '-', '-', 'ok'
  from public.pontos p where p.id = (select v::uuid from _t where k='p1');
select pg_temp.ok((select inspetor_id from public.inspecoes where id = '00000000-0000-4000-8000-0000000000a2') = '00000000-0000-4000-8000-000000000002', 'autor da inspeção não pode ser forjado');
reset role;

-- UPDATE e DELETE em inspeção são recusados
do $$ begin
  perform pg_temp.como('00000000-0000-4000-8000-000000000001', 'owner.teste@inspec.local');
  set local role authenticated;
  begin
    update public.inspecoes set status = 'nao_conforme' where id = '00000000-0000-4000-8000-0000000000a1';
    if found then raise exception 'FALHOU: update em inspeção foi aceito'; end if;
  exception when insufficient_privilege then null; end;
  begin
    delete from public.inspecoes where id = '00000000-0000-4000-8000-0000000000a1';
    if found then raise exception 'FALHOU: delete em inspeção foi aceito'; end if;
  exception when insufficient_privilege then null; end;
  reset role;
end $$;

-- consulta não grava
do $$ begin
  perform pg_temp.como('00000000-0000-4000-8000-000000000003', 'consulta.teste@inspec.local');
  set local role authenticated;
  begin
    insert into public.inspecoes (id, ponto_id, org_id, unidade_id, categoria_id, inspetor_id, data_inspecao, periodicidade, ciclo_referencia, status)
    select gen_random_uuid(), p.id, p.org_id, p.unidade_id, p.categoria_id, auth.uid(), now(), '-', '-', 'ok' from public.pontos p limit 1;
    raise exception 'FALHOU: perfil somente leitura conseguiu inspecionar';
  exception when insufficient_privilege then null; end;
  reset role;
end $$;

-- ---------------------------------------------------------------- 5. anulação (admin)
select pg_temp.como('00000000-0000-4000-8000-000000000001', 'owner.teste@inspec.local');
set local role authenticated;
select public.anular_inspecao('00000000-0000-4000-8000-0000000000a2', 'Lançado no ponto errado');
select pg_temp.ok((select anulada from public.inspecoes where id = '00000000-0000-4000-8000-0000000000a2'), 'anulação registrada');
reset role;

-- ---------------------------------------------------------------- 6. reserva, troca e histórico
select pg_temp.como('00000000-0000-4000-8000-000000000001', 'owner.teste@inspec.local');
set local role authenticated;
select public.movimentar_reserva((select v::uuid from _t where k='unid'), 'Pó Químico Seco BC 4kg', 'entrada', 1, 'Estoque inicial', 1);
reset role;

select pg_temp.como('00000000-0000-4000-8000-000000000002', 'inspetor.teste@inspec.local');
set local role authenticated;
select public.registrar_troca(jsonb_build_object('id', '00000000-0000-4000-8000-0000000000b1', 'ponto_id', (select v from _t where k='p1'),
  'motivo', 'Despressurizado', 'fonte', 'reserva', 'cilindro', '22222', 'n2', '2026-10'));
select public.registrar_troca(jsonb_build_object('id', '00000000-0000-4000-8000-0000000000b1', 'ponto_id', (select v from _t where k='p1'),
  'motivo', 'Despressurizado', 'fonte', 'reserva', 'cilindro', '22222', 'n2', '2026-10'));   -- reenvio: não duplica
select pg_temp.ok((select count(*) from public.trocas) = 1, 'troca idempotente');
select pg_temp.ok((select numero_cilindro from public.pontos where id = (select v::uuid from _t where k='p1')) = '22222', 'ponto recebe o equipamento instalado');
select pg_temp.ok((select ret_cilindro from public.trocas limit 1) = '11111', 'troca guarda o retirado');
select pg_temp.ok((select quantidade from public.reserva_estoque limit 1) = 0, 'reserva baixada');
select pg_temp.ok(exists (select 1 from public.alteracoes where campo = 'numero_cilindro' and de = '11111' and para = '22222' and origem = 'troca'), 'alteração do cilindro auditada com origem troca');
reset role;

-- histórico e trocas são imutáveis
do $$ begin
  begin
    delete from public.alteracoes;     -- mesmo como dono do banco
    raise exception 'FALHOU: alteracoes aceitou delete';
  exception when insufficient_privilege then null; end;
  begin
    update public.trocas set motivo = 'x';
    raise exception 'FALHOU: trocas aceitou update';
  exception when insufficient_privilege then null; end;
end $$;

-- ---------------------------------------------------------------- 7. comunicado de desvio
select pg_temp.como('00000000-0000-4000-8000-000000000002', 'inspetor.teste@inspec.local');
set local role authenticated;
-- sem estoque: fica pendente
insert into _t values ('cd1', public.registrar_desvio(jsonb_build_object('id', '00000000-0000-4000-8000-0000000000c1', 'ponto_id', (select v from _t where k='p1'),
  'origem', 'producao', 'gatilho', 'combate', 'acionador_papel', 'lider', 'meio', 'radio', 'acionado_em', now() - interval '15 minutes', 'chegada_em', now(),
  'descricao', 'Usado em princípio de incêndio', 'substituir', true, 'reserva', 'usada', 'cilindro_instalado', '33333', 'n2_instalado', '2026-10')));
select pg_temp.ok((select v from _t where k='cd1') ~ '^CD-\d{4}-0001$', 'numeração CD-AAAA-0001');
select pg_temp.ok((select status from public.desvios where id = '00000000-0000-4000-8000-0000000000c1') = 'pendente', 'sem reserva o desvio fica pendente');
select pg_temp.ok(public.registrar_desvio(jsonb_build_object('id', '00000000-0000-4000-8000-0000000000c1')) = (select v from _t where k='cd1'), 'reenvio do desvio é idempotente');
reset role;
select pg_temp.como('00000000-0000-4000-8000-000000000001', 'owner.teste@inspec.local');
set local role authenticated;
select public.movimentar_reserva((select v::uuid from _t where k='unid'), 'Pó Químico Seco BC 4kg', 'entrada', 2, 'Reposição ArcelorMittal');
reset role;
select pg_temp.como('00000000-0000-4000-8000-000000000002', 'inspetor.teste@inspec.local');
set local role authenticated;
select public.regularizar_desvio('00000000-0000-4000-8000-0000000000c1', '44444', '2026-10', true);
select pg_temp.ok((select status from public.desvios where id = '00000000-0000-4000-8000-0000000000c1') = 'encerrado', 'regularização encerra o desvio');
select pg_temp.ok((select numero_cilindro from public.pontos where id = (select v::uuid from _t where k='p1')) = '44444', 'regularização instala o cilindro');
select pg_temp.ok((select count(*) from public.trocas) = 2, 'regularização registra a troca');
reset role;

-- ---------------------------------------------------------------- 8. QR regerado
select pg_temp.como('00000000-0000-4000-8000-000000000001', 'owner.teste@inspec.local');
set local role authenticated;
select public.regerar_qr((select v::uuid from _t where k='p1'), 'Etiqueta danificada');
select pg_temp.ok((select substituida from public.resolver_qr((select v from _t where k='qr1'))), 'QR antigo resolve como etiqueta substituída');
reset role;

-- ---------------------------------------------------------------- 9. anônimo
set local role anon;
select pg_temp.ok((public.heartbeat()->>'ok')::boolean, 'anônimo executa heartbeat');
do $$ begin
  begin
    perform 1 from public.pontos limit 1;
    raise exception 'FALHOU: anônimo leu pontos';
  exception when insufficient_privilege then null; end;
end $$;
reset role;

-- ---------------------------------------------------------------- 10. auditoria geral
select pg_temp.como('00000000-0000-4000-8000-000000000001', 'owner.teste@inspec.local');
set local role authenticated;
update public.pontos set local = 'Local auditado' where id = (select v::uuid from _t where k='p1');
select pg_temp.ok((select count(*) from public.logs where acao = 'pontos.update' and detalhe ? 'local' and usuario_id = '00000000-0000-4000-8000-000000000001') = 1, 'alteração de ponto gera log com de → para e autor');
select pg_temp.ok((select count(*) from public.logs where acao = 'inspecoes.insert' and org_id = (select v::uuid from _t where k='org')) >= 1, 'inspeção gera log');
select pg_temp.ok((select count(*) from public.logs where acao = 'desvios.insert' and org_id = (select v::uuid from _t where k='org')) = 1, 'comunicado de desvio gera log');
select public.registrar_evento('acesso.login', '{"dispositivo":"teste"}');
select pg_temp.ok((select count(*) from public.logs where acao = 'acesso.login' and usuario_id = '00000000-0000-4000-8000-000000000001') = 1, 'evento de login registrado');
do $$ begin
  begin perform public.registrar_evento('pontos.update', '{}'); raise exception 'FALHOU: evento livre aceito';
  exception when raise_exception then if sqlerrm like 'FALHOU%' then raise; end if; end;
end $$;
select pg_temp.ok((select count(*) from public.membros_acesso((select v::uuid from _t where k='org'))) >= 3, 'admin vê último acesso da equipe');
reset role;
select pg_temp.como('00000000-0000-4000-8000-000000000002', 'inspetor.teste@inspec.local');
set local role authenticated;
select pg_temp.ok((select count(*) from public.logs) = 0, 'inspetor não lê a auditoria');
select pg_temp.ok((select count(*) from public.membros_acesso((select v::uuid from _t where k='org'))) = 0, 'inspetor não vê acessos da equipe');
do $$ begin
  begin update public.logs set acao = 'x'; raise exception 'FALHOU: log alterado';
  exception when insufficient_privilege then null; end;
end $$;
reset role;
set local role anon;
select public.registrar_falha_login('inspetor.teste@inspec.local');
reset role;
select pg_temp.ok((select count(*) from public.logs where acao = 'acesso.falha_login' and usuario_id = '00000000-0000-4000-8000-000000000002') = 1, 'tentativa de senha errada registrada');

-- ---------------------------------------------------------------- 11. agentes extintores
select pg_temp.ok((select count(*) from public.agentes where org_id = (select v::uuid from _t where k='org')) >= 12, 'organização nasce com os agentes padrão');
select pg_temp.ok(not exists (select 1 from public.agentes where nome = 'Outra'), 'agente "Outra" não é cadastrado');
select pg_temp.como('00000000-0000-4000-8000-000000000002', 'inspetor.teste@inspec.local');
set local role authenticated;
do $$ begin
  begin insert into public.agentes (org_id, nome) values ((select org_id from public.membros where usuario_id = auth.uid() limit 1), 'Teste X'); raise exception 'FALHOU: inspetor cadastrou agente';
  exception when insufficient_privilege then null; end;
end $$;
reset role;
select pg_temp.como('00000000-0000-4000-8000-000000000001', 'owner.teste@inspec.local');
set local role authenticated;
select public.renomear_agente((select id from public.agentes where nome = 'Pó Químico Seco BC 4kg' and org_id = (select v::uuid from _t where k='org')), 'PQS BC 4 kg');
reset role;
select pg_temp.ok((select agente from public.pontos where id = (select v::uuid from _t where k='p1')) = 'PQS BC 4 kg', 'renomear agente atualiza os pontos');
insert into public.desvios (id, numero, org_id, unidade_id, ponto_id, origem, gatilho, meio, acionado_em, chegada_em, descricao)
select gen_random_uuid(), 'CD-TESTE', org_id, unidade_id, id, 'producao', 'violacao', 'pessoalmente', now(), now(), 'teste' from public.pontos where id = (select v::uuid from _t where k='p1');
select pg_temp.ok((select count(*) from public.desvios where meio = 'pessoalmente' and numero = 'CD-TESTE') = 1, 'meio de comunicação Pessoalmente aceito');

-- ---------------------------------------------------------------- 12a. registro de acesso com IP (antes do zeramento)
select pg_temp.como('00000000-0000-4000-8000-000000000002', 'inspetor.teste@inspec.local');
select set_config('request.headers', '{"x-forwarded-for":"198.51.100.23, 10.0.0.1","user-agent":"Teste/1.0"}', true);
set local role authenticated;
select public.registrar_evento('acesso.login', '{}'::jsonb);
reset role;
select set_config('request.headers', '', true);
select pg_temp.ok((select count(*) from public.acessos where usuario_id = '00000000-0000-4000-8000-000000000002' and ip = '198.51.100.23' and navegador = 'Teste/1.0') = 1, 'login grava IP e navegador em acessos');

-- ---------------------------------------------------------------- 12. perfis e zeramento
update public.membros set papel = 'admin_leitura' where usuario_id = '00000000-0000-4000-8000-000000000003';
select pg_temp.como('00000000-0000-4000-8000-000000000003', 'consulta.teste@inspec.local');
set local role authenticated;
select pg_temp.ok((select count(*) from public.logs) > 0, 'admin (leitura) lê a auditoria');
select pg_temp.ok((select count(*) from public.pontos) > 0, 'admin (leitura) vê os pontos');
do $$ begin
  begin perform public.zerar_sistema((select org_id from public.membros where usuario_id = auth.uid()), 'ZERAR'); raise exception 'FALHOU: admin leitura zerou';
  exception when insufficient_privilege then null; end;
end $$;
do $$ declare n int; begin update public.pontos set local = 'x'; get diagnostics n = row_count; if n > 0 then raise exception 'FALHOU: admin (leitura) alterou pontos'; end if; end $$;
reset role;
select pg_temp.como('00000000-0000-4000-8000-000000000001', 'owner.teste@inspec.local');
set local role authenticated;
select public.zerar_sistema((select v::uuid from _t where k='org'), 'ZERAR', true);
reset role;
select pg_temp.ok((select count(*) from public.pontos where org_id = (select v::uuid from _t where k='org')) = 0, 'zerar apaga os pontos');
select pg_temp.ok((select count(*) from public.inspecoes where org_id = (select v::uuid from _t where k='org')) = 0, 'zerar apaga as inspeções');
select pg_temp.ok((select count(*) from public.membros where org_id = (select v::uuid from _t where k='org')) >= 3, 'zerar mantém os usuários');
select pg_temp.ok((select count(*) from public.categorias where org_id = (select v::uuid from _t where k='org')) = 4, 'zerar recria as categorias padrão');
select pg_temp.ok((select count(*) from public.logs where org_id = (select v::uuid from _t where k='org')) = 1, 'zerar deixa só o registro do zeramento');

-- ---------------------------------------------------------------- 13. registros de acesso: sigilo e guarda
select pg_temp.ok((select count(*) from public.acessos where usuario_id = '00000000-0000-4000-8000-000000000002' and ip = '198.51.100.23') = 1, 'zerar mantém os registros de acesso (Marco Civil)');
select pg_temp.como('00000000-0000-4000-8000-000000000001', 'owner.teste@inspec.local');
set local role authenticated;
select pg_temp.ok((select count(*) from public.acessos where usuario_id = '00000000-0000-4000-8000-000000000002' and ip = '198.51.100.23') = 1, 'owner lê os registros de acesso');
do $$ begin
  begin insert into public.acessos (org_id, evento, ip) values ((select v::uuid from _t where k='org'), 'acesso.login', '1.1.1.1'); raise exception 'FALHOU: owner inseriu acesso direto';
  exception when insufficient_privilege then null; end;
  begin perform app.registrar_acesso(null, null, 'x', 'acesso.login'); raise exception 'FALHOU: cliente chamou app.registrar_acesso';
  exception when insufficient_privilege then null; end;
end $$;
do $$ declare n int; begin update public.acessos set ip = 'x'; get diagnostics n = row_count; if n > 0 then raise exception 'FALHOU: alterou acesso'; end if;
  exception when insufficient_privilege then null; end $$;
reset role;
select pg_temp.como('00000000-0000-4000-8000-000000000003', 'consulta.teste@inspec.local');
set local role authenticated;
select pg_temp.ok((select count(*) from public.acessos) = 0, 'admin (leitura) não vê os registros de acesso');
reset role;
select pg_temp.como('00000000-0000-4000-8000-000000000002', 'inspetor.teste@inspec.local');
set local role authenticated;
select pg_temp.ok((select count(*) from public.acessos) = 0, 'inspetor não vê os registros de acesso');
reset role;
do $$ begin
  begin update public.acessos set ip = 'x'; raise exception 'FALHOU: acesso alterado pelo dono do banco';
  exception when insufficient_privilege then null; end;
end $$;

select 'TODOS OS TESTES PASSARAM' as resultado;
rollback;
