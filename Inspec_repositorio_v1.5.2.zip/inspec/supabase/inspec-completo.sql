-- =====================================================================
-- INSPEC — inspec-completo.sql  (versão 1.0)
-- Gestão inteligente de inspeções de equipamentos de emergência
--
-- DEPLOY DO ZERO: cole este arquivo inteiro no SQL Editor do Supabase
-- e clique em Run. É IDEMPOTENTE: pode (e deve) ser executado de novo
-- sem erro — rode duas vezes para confirmar.
--
-- Antes de rodar, troque o e-mail do primeiro administrador (owner)
-- na seção 13 (BOOTSTRAP).
--
-- Conteúdo: tabelas · índices · funções de ciclo · gatilhos de
-- auditoria e imutabilidade · funções de negócio (troca, desvio, QR,
-- reserva, importação) · RLS de todas as tabelas · bucket privado de
-- fotos · heartbeat e monitoramento de uso.
-- =====================================================================

create extension if not exists pgcrypto;
create schema if not exists app;

-- =====================================================================
-- 1. BASE MULTI-ORGANIZAÇÃO
-- =====================================================================
create table if not exists public.organizacoes (
  id         uuid primary key default gen_random_uuid(),
  nome       text not null,
  fuso       text not null default 'America/Sao_Paulo',
  config     jsonb not null default '{"regra_foto":"nc","max_fotos":3}'::jsonb,
  criado_em  timestamptz not null default now()
);

create table if not exists public.unidades (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references public.organizacoes(id) on delete cascade,
  nome       text not null,
  criado_em  timestamptz not null default now(),
  unique (org_id, nome)
);

create table if not exists public.usuarios (
  id         uuid primary key references auth.users(id) on delete cascade,
  email      text,
  nome       text,
  criado_em  timestamptz not null default now()
);

create table if not exists public.membros (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references public.organizacoes(id) on delete cascade,
  usuario_id    uuid not null references auth.users(id) on delete cascade,
  nome          text not null,
  papel         text not null check (papel in ('owner','admin','inspetor','inspetor_leitura','admin_leitura')),
  ativo         boolean not null default true,
  trocar_senha  boolean not null default true,
  criado_em     timestamptz not null default now(),
  unique (org_id, usuario_id)
);

create table if not exists public.membro_unidades (
  membro_id   uuid not null references public.membros(id) on delete cascade,
  unidade_id  uuid not null references public.unidades(id) on delete cascade,
  primary key (membro_id, unidade_id)
);

-- convite de bootstrap: só este e-mail pode criar a primeira organização
create table if not exists public.convites (
  email      text primary key,
  papel      text not null default 'owner' check (papel = 'owner'),
  usado_em   timestamptz,
  criado_em  timestamptz not null default now()
);

-- =====================================================================
-- 2. DOMÍNIO: CATEGORIAS, GERÊNCIAS, PONTOS
-- Cada código (ACI-020, HID-045...) é um PONTO: o local onde o
-- equipamento fica. O equipamento instalado muda (trocas).
-- =====================================================================
create table if not exists public.categorias (
  id             uuid primary key default gen_random_uuid(),
  org_id         uuid not null references public.organizacoes(id) on delete cascade,
  chave          text not null check (chave ~ '^[a-z_]+$'),
  nome           text not null,
  nome_plural    text not null,
  prefixo        text,
  periodicidade  text not null check (periodicidade in ('mensal','semanal')),
  checklist      jsonb not null default '{}'::jsonb,
  ordem          int not null default 0,
  ativo          boolean not null default true,
  unique (org_id, chave)
);

create table if not exists public.gerencias (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references public.organizacoes(id) on delete cascade,
  unidade_id  uuid not null references public.unidades(id) on delete cascade,
  nome        text not null,
  sigla       text not null,
  unique (unidade_id, nome)
);

create table if not exists public.pontos (
  id                  uuid primary key default gen_random_uuid(),
  org_id              uuid not null references public.organizacoes(id) on delete cascade,
  unidade_id          uuid not null references public.unidades(id) on delete restrict,
  categoria_id        uuid not null references public.categorias(id) on delete restrict,
  gerencia_id         uuid not null references public.gerencias(id) on delete restrict,
  codigo              text not null check (length(codigo) between 2 and 20),
  area                text not null default '',
  local               text not null default '',
  subtipo             text not null default '',
  capacidade          text not null default '',
  bombeiro_id         uuid references auth.users(id) on delete set null,
  -- etiqueta QR
  qr_id               text,
  qr_gerado_em        timestamptz,
  qr_impresso_em      timestamptz,
  -- equipamento instalado no ponto
  numero_cilindro     text,
  agente              text,
  n2                  text check (n2 is null or n2 ~ '^\d{4}-\d{2}$'),   -- mês da recarga (AAAA-MM)
  n3                  int  check (n3 is null or n3 between 1990 and 2100), -- ano do teste hidrostático
  requer_conferencia  boolean not null default false,
  dados               jsonb not null default '{}'::jsonb,  -- anel, base, materiais, kit, pressurizado, origem da planilha
  ativo               boolean not null default true,
  inativado_em        timestamptz,
  motivo_inativacao   text,
  criado_em           timestamptz not null default now(),
  atualizado_em       timestamptz not null default now()
);
create unique index if not exists pontos_org_codigo_uk on public.pontos (org_id, codigo);
create unique index if not exists pontos_org_qr_uk     on public.pontos (org_id, qr_id) where qr_id is not null;
create index        if not exists pontos_unid_cat_idx  on public.pontos (unidade_id, categoria_id) where ativo;

create table if not exists public.qr_historico (
  id             uuid primary key default gen_random_uuid(),
  org_id         uuid not null references public.organizacoes(id) on delete cascade,
  ponto_id       uuid not null references public.pontos(id) on delete cascade,
  qr_id          text not null,
  gerado_em      timestamptz,
  invalidado_em  timestamptz not null default now(),
  motivo         text not null,
  usuario_id     uuid references auth.users(id) on delete set null,
  unique (org_id, qr_id)
);

-- =====================================================================
-- 3. INSPEÇÕES E FOTOS
-- =====================================================================
create table if not exists public.inspecoes (
  id                uuid primary key,                      -- gerado no aparelho (idempotência da fila)
  ponto_id          uuid not null references public.pontos(id) on delete restrict,
  org_id            uuid not null references public.organizacoes(id) on delete cascade,
  unidade_id        uuid not null references public.unidades(id) on delete restrict,
  categoria_id      uuid not null references public.categorias(id) on delete restrict,
  inspetor_id       uuid references auth.users(id) on delete set null,
  data_inspecao     timestamptz not null,
  recebida_em       timestamptz not null default now(),
  periodicidade     text not null,
  ciclo_referencia  text not null,
  status            text not null check (status in ('ok','nao_conforme')),
  observacoes       text check (observacoes is null or length(observacoes) <= 1000),
  checklist         jsonb not null default '{}'::jsonb,
  resumo_nc         text,
  origem            text not null default 'busca' check (origem in ('qr','busca','lista','nc','desvio','importada')),
  sinc_tardia       boolean not null default false,
  anulada           boolean not null default false,
  anulada_por       uuid references auth.users(id) on delete set null,
  anulada_em        timestamptz,
  motivo_anulacao   text
);
create index if not exists insp_ponto_ciclo_idx on public.inspecoes (ponto_id, ciclo_referencia) where not anulada;
create index if not exists insp_unid_data_idx   on public.inspecoes (unidade_id, data_inspecao desc);
create index if not exists insp_org_ciclo_idx   on public.inspecoes (org_id, ciclo_referencia, status);

create table if not exists public.fotos (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references public.organizacoes(id) on delete cascade,
  unidade_id   uuid not null references public.unidades(id) on delete restrict,
  registro_id  uuid not null,                 -- inspeção ou desvio
  tipo         text not null check (tipo in ('inspecao','desvio')),
  path         text not null unique,          -- {org}/{unidade}/{registro}_{n}.jpg
  bytes        int,
  criado_por   uuid references auth.users(id) on delete set null default auth.uid(),
  criado_em    timestamptz not null default now()
);
create index if not exists fotos_registro_idx on public.fotos (registro_id);

-- =====================================================================
-- 4. COMUNICADOS DE DESVIO, TROCAS, ALTERAÇÕES, RESERVA
-- =====================================================================
create table if not exists public.desvios (
  id                  uuid primary key,              -- gerado no aparelho
  numero              text not null,                 -- CD-2026-0001 (servidor)
  org_id              uuid not null references public.organizacoes(id) on delete cascade,
  unidade_id          uuid not null references public.unidades(id) on delete restrict,
  ponto_id            uuid not null references public.pontos(id) on delete restrict,
  origem              text not null check (origem in ('producao','inspecao')),
  gatilho             text not null check (gatilho in ('extrativo','violacao','combate')),
  acionador_papel     text check (acionador_papel in ('lider','brigada','supervisor','gerente')),
  acionador_nome      text,
  meio                text check (meio in ('email','radio','whatsapp','pessoalmente')),
  acionado_em         timestamptz not null,
  chegada_em          timestamptz not null,
  descricao           text not null,
  substituir          boolean not null default false,
  reserva             text check (reserva in ('usada','indisponivel')),
  agente              text,
  cilindro_retirado   text,
  cilindro_instalado  text,
  n2_instalado        text,
  acao                text,
  pendencias          text,
  destinatarios       text[] not null default '{}',
  status              text not null default 'encerrado' check (status in ('encerrado','pendente')),
  encerrado_em        timestamptz,
  inspecao_origem_id  uuid,
  bombeiro_id         uuid references auth.users(id) on delete set null,
  criado_em           timestamptz not null default now(),
  unique (org_id, numero)
);
create index if not exists desvios_unid_data_idx on public.desvios (unidade_id, acionado_em desc);

create table if not exists public.trocas (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references public.organizacoes(id) on delete cascade,
  unidade_id    uuid not null references public.unidades(id) on delete restrict,
  ponto_id      uuid not null references public.pontos(id) on delete restrict,
  origem        text not null check (origem in ('manual','desvio','inspecao','regularizacao')),
  referencia    text,
  motivo        text not null,
  fonte         text check (fonte in ('reserva','manutencao','remanejamento','outro')),
  ret_cilindro  text, ret_agente text, ret_n2 text, ret_n3 int,
  ins_cilindro  text not null, ins_agente text, ins_n2 text, ins_n3 int,
  observacao    text,
  usuario_id    uuid references auth.users(id) on delete set null,
  criado_em     timestamptz not null default now()
);
create index if not exists trocas_ponto_idx on public.trocas (ponto_id, criado_em desc);

create table if not exists public.alteracoes (
  id          bigint generated always as identity primary key,
  org_id      uuid not null references public.organizacoes(id) on delete cascade,
  unidade_id  uuid not null,
  ponto_id    uuid not null references public.pontos(id) on delete restrict,
  campo       text not null,
  de          text,
  para        text,
  origem      text not null default 'cadastro',
  referencia  text,
  usuario_id  uuid references auth.users(id) on delete set null,
  criado_em   timestamptz not null default now()
);
create index if not exists alt_unid_idx  on public.alteracoes (unidade_id, criado_em desc);
create index if not exists alt_ponto_idx on public.alteracoes (ponto_id, criado_em desc);

create table if not exists public.reserva_estoque (
  org_id         uuid not null references public.organizacoes(id) on delete cascade,
  unidade_id     uuid not null references public.unidades(id) on delete cascade,
  agente         text not null,
  quantidade     int not null default 0 check (quantidade >= 0),
  minimo         int not null default 0 check (minimo >= 0),
  atualizado_em  timestamptz not null default now(),
  primary key (unidade_id, agente)
);

create table if not exists public.reserva_movimentos (
  id          bigint generated always as identity primary key,
  org_id      uuid not null references public.organizacoes(id) on delete cascade,
  unidade_id  uuid not null references public.unidades(id) on delete restrict,
  agente      text not null,
  tipo        text not null check (tipo in ('entrada','saida','ajuste')),
  qtd         int not null,
  desvio_id   uuid,
  referencia  text,
  usuario_id  uuid references auth.users(id) on delete set null,
  criado_em   timestamptz not null default now()
);

create table if not exists public.destinatarios (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references public.organizacoes(id) on delete cascade,
  unidade_id   uuid references public.unidades(id) on delete cascade,
  gerencia_id  uuid references public.gerencias(id) on delete cascade,  -- nulo = todas as gerências
  papel        text not null,          -- ex.: Gerência da área, Gerência de SST
  nome         text not null,
  email        text not null check (email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  ativo        boolean not null default true
);

create table if not exists public.envios_email (
  id             uuid primary key default gen_random_uuid(),
  org_id         uuid not null references public.organizacoes(id) on delete cascade,
  desvio_id      uuid not null references public.desvios(id) on delete cascade,
  destinatarios  text[] not null,
  status         text not null check (status in ('enviado','erro')),
  id_provedor    text,
  erro           text,
  enviado_por    uuid references auth.users(id) on delete set null,
  enviado_em     timestamptz not null default now()
);

create table if not exists public.logs (
  id          bigint generated always as identity primary key,
  org_id      uuid references public.organizacoes(id) on delete cascade,
  usuario_id  uuid references auth.users(id) on delete set null,
  acao        text not null,
  detalhe     jsonb,
  criado_em   timestamptz not null default now()
);
-- auditoria geral (v1.1): tabela/registro afetados e rótulo legível
alter table public.logs add column if not exists tabela     text;
alter table public.logs add column if not exists registro   text;
alter table public.logs add column if not exists rotulo     text;
alter table public.logs add column if not exists unidade_id uuid;
create index if not exists logs_org_data_idx on public.logs (org_id, criado_em desc);
create index if not exists logs_usuario_idx  on public.logs (usuario_id, criado_em desc);
create index if not exists logs_acao_idx     on public.logs (acao);

create table if not exists public.heartbeat (
  id           int primary key default 1 check (id = 1),
  ultimo_ping  timestamptz
);
insert into public.heartbeat (id, ultimo_ping) values (1, null) on conflict (id) do nothing;

create table if not exists public.uso_diario (
  dia        date primary key default current_date,
  banco_mb   numeric,
  fotos_mb   numeric,
  fotos_qtd  int,
  criado_em  timestamptz not null default now()
);

-- agentes extintores cadastrados pelo administrador (v1.1)
create table if not exists public.agentes (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references public.organizacoes(id) on delete cascade,
  nome       text not null check (length(trim(nome)) between 2 and 60),
  criado_em  timestamptz not null default now(),
  unique (org_id, nome)
);
-- meio de comunicação "Pessoalmente" (bancos criados antes da v1.1)
alter table public.desvios drop constraint if exists desvios_meio_check;
alter table public.desvios add constraint desvios_meio_check check (meio in ('email','radio','whatsapp','pessoalmente'));
-- perfis v1.5: Owner, Admin, Inspetor, Inspetor (leitura), Admin (leitura); "consulta" vira Admin (leitura)
alter table public.membros drop constraint if exists membros_papel_check;
update public.membros set papel = 'admin_leitura' where papel = 'consulta';
alter table public.membros add constraint membros_papel_check check (papel in ('owner','admin','inspetor','inspetor_leitura','admin_leitura'));
-- categorias gerenciáveis: ícone
alter table public.categorias add column if not exists icone text;


-- =====================================================================
-- 5. FUNÇÕES DE APOIO (acesso, ciclo, QR)
-- =====================================================================
create or replace function app.papel(p_org uuid) returns text
language sql stable security definer set search_path = public as $$
  select papel from public.membros where usuario_id = auth.uid() and org_id = p_org and ativo;
$$;

create or replace function app.e_admin(p_org uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(app.papel(p_org) in ('owner','admin'), false);
$$;

-- o usuário enxerga a unidade? (owner/admin: toda a organização)
create or replace function app.can_unit(p_org uuid, p_unid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.membros m
     where m.usuario_id = auth.uid() and m.org_id = p_org and m.ativo
       and (m.papel in ('owner','admin','admin_leitura')
            or exists (select 1 from public.membro_unidades mu where mu.membro_id = m.id and mu.unidade_id = p_unid)));
$$;

-- gestor: vê a administração (owner, admin, admin somente leitura)
create or replace function app.e_gestor(p_org uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(app.papel(p_org) in ('owner','admin','admin_leitura'), false);
$$;

create or replace function app.can_write(p_org uuid, p_unid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select app.can_unit(p_org, p_unid) and coalesce(app.papel(p_org) in ('owner','admin','inspetor'), false);
$$;

create or replace function app.membro_da_org(p_org uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.membros where usuario_id = auth.uid() and org_id = p_org and ativo);
$$;

-- ciclo de referência de uma data, no fuso da organização (semana ISO: ano ISO)
create or replace function app.ciclo_de(p_ts timestamptz, p_per text, p_fuso text default 'America/Sao_Paulo')
returns text language sql immutable as $$
  select case p_per
    when 'mensal'  then to_char(p_ts at time zone p_fuso, 'YYYY-MM')
    when 'semanal' then to_char(p_ts at time zone p_fuso, 'IYYY-"W"IW')
  end;
$$;

-- ID da etiqueta QR: 8 caracteres de um alfabeto sem ambiguidade (sem 0/O, 1/I/L)
create or replace function app.gerar_qr_id(p_org uuid) returns text
language plpgsql volatile security definer set search_path = public, extensions as $$
declare
  alf constant text := '23456789ABCDEFGHJKMNPQRSTUVWXYZ';
  v text; i int;
begin
  loop
    v := '';
    for i in 1..8 loop
      v := v || substr(alf, 1 + (get_byte(gen_random_bytes(1), 0) % length(alf)), 1);
    end loop;
    exit when not exists (select 1 from public.pontos where org_id = p_org and qr_id = v)
          and not exists (select 1 from public.qr_historico where org_id = p_org and qr_id = v);
  end loop;
  return v;
end $$;

-- =====================================================================
-- 6. GATILHOS
-- =====================================================================
-- 6.1 perfil espelhado de auth.users
create or replace function app.tg_novo_usuario() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.usuarios (id, email) values (new.id, new.email) on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function app.tg_novo_usuario();

-- 6.2 pontos: QR na criação, carimbo de atualização, auditoria
create or replace function app.tg_ponto_bi() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.qr_id is null then
    new.qr_id := app.gerar_qr_id(new.org_id);
    new.qr_gerado_em := now();
  end if;
  return new;
end $$;
drop trigger if exists pontos_bi on public.pontos;
create trigger pontos_bi before insert on public.pontos
  for each row execute function app.tg_ponto_bi();

create or replace function app.tg_ponto_bu() returns trigger
language plpgsql as $$
begin
  new.atualizado_em := now();
  new.org_id := old.org_id;           -- um ponto nunca muda de organização
  return new;
end $$;
drop trigger if exists pontos_bu on public.pontos;
create trigger pontos_bu before update on public.pontos
  for each row execute function app.tg_ponto_bu();

-- toda mudança de cadastro vira um registro em alteracoes, venha de onde vier
create or replace function app.tg_ponto_auditoria() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  c text;
  o text := coalesce(nullif(current_setting('app.origem', true), ''), 'cadastro');
  r text := nullif(current_setting('app.referencia', true), '');
begin
  foreach c in array array['codigo','area','local','gerencia_id','bombeiro_id','subtipo','capacidade',
                           'numero_cilindro','agente','n2','n3','ativo','qr_id','unidade_id'] loop
    if to_jsonb(new) ->> c is distinct from to_jsonb(old) ->> c then
      insert into public.alteracoes (org_id, unidade_id, ponto_id, campo, de, para, origem, referencia, usuario_id)
      values (new.org_id, new.unidade_id, new.id, c, to_jsonb(old) ->> c, to_jsonb(new) ->> c, o, r, auth.uid());
    end if;
  end loop;
  return new;
end $$;
drop trigger if exists pontos_auditoria on public.pontos;
create trigger pontos_auditoria after update on public.pontos
  for each row execute function app.tg_ponto_auditoria();

create or replace function app.tg_ponto_criado() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.alteracoes (org_id, unidade_id, ponto_id, campo, de, para, origem, usuario_id)
  values (new.org_id, new.unidade_id, new.id, 'ponto_cadastrado', null, new.codigo,
          coalesce(nullif(current_setting('app.origem', true), ''), 'cadastro'), auth.uid());
  return new;
end $$;
drop trigger if exists pontos_criado on public.pontos;
create trigger pontos_criado after insert on public.pontos
  for each row execute function app.tg_ponto_criado();

-- 6.3 inspeções: o servidor completa e valida (o cliente não forja autor, ciclo nem escopo)
create or replace function app.tg_inspecao_bi() returns trigger
language plpgsql security definer set search_path = public as $$
declare p record; v_fuso text;
begin
  select pt.org_id, pt.unidade_id, pt.categoria_id, pt.ativo, c.periodicidade
    into p
    from public.pontos pt join public.categorias c on c.id = pt.categoria_id
   where pt.id = new.ponto_id;
  if not found then raise exception 'Ponto inexistente' using errcode = '23503'; end if;
  if not p.ativo then raise exception 'Ponto inativo: inspeção recusada' using errcode = 'P0001'; end if;
  select fuso into v_fuso from public.organizacoes where id = p.org_id;
  if new.data_inspecao > now() + interval '10 minutes' then
    raise exception 'Data da inspeção no futuro' using errcode = 'P0001';
  end if;
  new.org_id           := p.org_id;
  new.unidade_id       := p.unidade_id;
  new.categoria_id     := p.categoria_id;
  new.periodicidade    := p.periodicidade;
  new.ciclo_referencia := app.ciclo_de(new.data_inspecao, p.periodicidade, coalesce(v_fuso, 'America/Sao_Paulo'));
  new.recebida_em      := now();
  new.sinc_tardia      := now() - new.data_inspecao > interval '72 hours';
  if current_setting('app.origem', true) is distinct from 'importacao' then
    new.inspetor_id := auth.uid();
  end if;
  new.anulada := false; new.anulada_por := null; new.anulada_em := null; new.motivo_anulacao := null;
  return new;
end $$;
drop trigger if exists inspecoes_bi on public.inspecoes;
create trigger inspecoes_bi before insert on public.inspecoes
  for each row execute function app.tg_inspecao_bi();

-- só a função anular_inspecao altera uma inspeção, e apenas as colunas de anulação
create or replace function app.tg_inspecao_bu() returns trigger
language plpgsql as $$
begin
  if current_setting('app.anulando', true) is distinct from 'sim' then
    raise exception 'Inspeções são imutáveis (use a anulação)' using errcode = '42501';
  end if;
  if (to_jsonb(new) - array['anulada','anulada_por','anulada_em','motivo_anulacao'])
     is distinct from (to_jsonb(old) - array['anulada','anulada_por','anulada_em','motivo_anulacao']) then
    raise exception 'A anulação não altera os dados da inspeção' using errcode = '42501';
  end if;
  return new;
end $$;
drop trigger if exists inspecoes_bu on public.inspecoes;
create trigger inspecoes_bu before update on public.inspecoes
  for each row execute function app.tg_inspecao_bu();

-- 6.4 registros imutáveis
create or replace function app.tg_somente_insercao() returns trigger
language plpgsql as $$
begin
  if current_setting('app.zerando', true) = 'sim' and tg_op = 'DELETE' then return old; end if;   -- só zerar_sistema()
  raise exception 'Registro imutável: % não aceita %', tg_table_name, tg_op using errcode = '42501';
end $$;
do $$
declare t text;
begin
  foreach t in array array['trocas','alteracoes','reserva_movimentos','qr_historico','logs','envios_email'] loop
    execute format('drop trigger if exists %I on public.%I', t || '_imutavel', t);
    execute format('create trigger %I before update or delete on public.%I for each row execute function app.tg_somente_insercao()', t || '_imutavel', t);
  end loop;
  execute 'drop trigger if exists inspecoes_sem_delete on public.inspecoes';
  execute 'create trigger inspecoes_sem_delete before delete on public.inspecoes for each row execute function app.tg_somente_insercao()';
end $$;

-- =====================================================================
-- 7. FUNÇÕES DE NEGÓCIO (RPC) — atômicas e idempotentes
-- =====================================================================
-- 7.1 bootstrap: o e-mail convidado cria a primeira organização
create or replace function public.criar_organizacao(p_nome text, p_unidade text, p_nome_owner text)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_org uuid; v_unid uuid; v_mem uuid;
begin
  if auth.uid() is null then raise exception 'Não autenticado' using errcode = '42501'; end if;
  if not exists (select 1 from public.convites where lower(email) = lower(auth.email()) and usado_em is null) then
    raise exception 'Sem convite de bootstrap para este e-mail' using errcode = '42501';
  end if;
  insert into public.organizacoes (nome) values (p_nome) returning id into v_org;
  insert into public.unidades (org_id, nome) values (v_org, p_unidade) returning id into v_unid;
  insert into public.membros (org_id, usuario_id, nome, papel, trocar_senha)
       values (v_org, auth.uid(), p_nome_owner, 'owner', false) returning id into v_mem;
  insert into public.membro_unidades (membro_id, unidade_id) values (v_mem, v_unid);
  update public.convites set usado_em = now() where lower(email) = lower(auth.email());
  perform app.semear_categorias(v_org);
  perform app.semear_agentes(v_org);
  insert into public.logs (org_id, usuario_id, acao, detalhe) values (v_org, auth.uid(), 'organizacao_criada', jsonb_build_object('nome', p_nome));
  return v_org;
end $$;

create or replace function app.semear_categorias(p_org uuid) returns void
language sql security definer set search_path = public as $$
  insert into public.categorias (org_id, chave, nome, nome_plural, prefixo, periodicidade, ordem, checklist) values
  (p_org, 'extintor', 'Extintor', 'Extintores', null, 'mensal', 1,
   '{"itens":[{"k":"manometro","l":"Manômetro","na":true},{"k":"mangueira","l":"Mangueira","na":true},{"k":"difusor","l":"Difusor","na":true},{"k":"lacre","l":"Lacre","na":true},{"k":"sinalizacao","l":"Sinalização","na":true}],"troca":["Validade da Carga N2","Validade do Cilindro (Teste Hidrostático) N3","Corrosão","Amassados","Lacre rompido","Manômetro danificado","Despressurizado"]}'),
  (p_org, 'hidrante', 'Hidrante', 'Hidrantes', 'HID', 'mensal', 2,
   '{"itens":[{"k":"integridade","l":"Integridade do hidrante"},{"k":"abrigo","l":"Integridade do abrigo"},{"k":"acesso","l":"Acesso"},{"k":"sinal_v","l":"Sinalização vertical"},{"k":"sinal_h","l":"Sinalização horizontal"},{"k":"lacre","l":"Lacre"}],"quantidades":["mangueiras","storz","agulheta","regulavel"]}'),
  (p_org, 'maca', 'Maca', 'Macas', 'MAC', 'mensal', 3,
   '{"itens":[{"k":"lacre","l":"Lacre/Suporte"},{"k":"acesso","l":"Acesso"},{"k":"sinalizacao","l":"Sinalização"}]}'),
  (p_org, 'chuveiro', 'Chuveiro / lava-olhos', 'Chuveiros', 'CHV', 'semanal', 4,
   '{"itens":[{"k":"acesso","l":"Acesso"},{"k":"integridade","l":"Integridade do equipamento"},{"k":"agua","l":"Água limpa"},{"k":"sinalizacao","l":"Sinalização"},{"k":"pressao","l":"Pressão da água","na":true},{"k":"temperatura","l":"Temperatura da água (16 °C a 38 °C)","na":true}]}')
  on conflict (org_id, chave) do nothing;
$$;

create or replace function app.semear_agentes(p_org uuid) returns void
language sql security definer set search_path = public as $$
  insert into public.agentes (org_id, nome)
  select p_org, n from unnest(array['Pó Químico Seco BC 4kg','Pó Químico BC 6kg','Pó Químico BC 8kg','Pó Químico BC 9kg','Pó Químico Seco ABC 6kg',
    'Pó Químico BC Carreta 20kg','Pó Químico BC Carreta 25kg','CO₂ 4kg','CO₂ 6kg','CO₂ Carreta 25kg','Água','Espuma']) n
  union
  select p_org, agente from public.pontos where org_id = p_org and agente is not null and agente <> 'Outra' and length(trim(agente)) >= 2
  on conflict (org_id, nome) do nothing;
$$;

-- renomeia um agente e atualiza os pontos e a reserva que usam o nome antigo (admin)
create or replace function public.renomear_agente(p_id uuid, p_nome text) returns void
language plpgsql security definer set search_path = public as $$
declare a public.agentes; v text := trim(p_nome);
begin
  select * into a from public.agentes where id = p_id;
  if a.id is null then raise exception 'Agente não encontrado'; end if;
  if not app.e_admin(a.org_id) then raise exception 'Somente administradores' using errcode = '42501'; end if;
  if length(v) < 2 then raise exception 'Informe o nome do agente'; end if;
  if v = a.nome then return; end if;
  update public.agentes set nome = v where id = p_id;
  perform set_config('app.origem', 'cadastro', true);
  perform set_config('app.referencia', 'Agente renomeado', true);
  update public.pontos set agente = v where org_id = a.org_id and agente = a.nome;
  perform set_config('app.origem', '', true);
  perform set_config('app.referencia', '', true);
  update public.reserva_estoque r set agente = v where r.org_id = a.org_id and r.agente = a.nome
     and not exists (select 1 from public.reserva_estoque x where x.unidade_id = r.unidade_id and x.agente = v);
end $$;

-- 7.2 o usuário concluiu a troca obrigatória de senha
create or replace function public.senha_trocada() returns void
language sql security definer set search_path = public as $$
  update public.membros set trocar_senha = false where usuario_id = auth.uid();
$$;

-- 7.3 anulação de inspeção (admin, com motivo)
create or replace function public.anular_inspecao(p_id uuid, p_motivo text) returns void
language plpgsql security definer set search_path = public as $$
declare v_org uuid;
begin
  select org_id into v_org from public.inspecoes where id = p_id;
  if v_org is null then raise exception 'Inspeção não encontrada'; end if;
  if not app.e_admin(v_org) then raise exception 'Somente administradores anulam inspeções' using errcode = '42501'; end if;
  if length(coalesce(trim(p_motivo), '')) < 5 then raise exception 'Informe o motivo (mín. 5 caracteres)'; end if;
  perform set_config('app.anulando', 'sim', true);
  update public.inspecoes set anulada = true, anulada_por = auth.uid(), anulada_em = now(), motivo_anulacao = trim(p_motivo)
   where id = p_id and not anulada;
  perform set_config('app.anulando', '', true);
  insert into public.logs (org_id, usuario_id, acao, detalhe) values (v_org, auth.uid(), 'inspecao_anulada', jsonb_build_object('id', p_id, 'motivo', p_motivo));
end $$;

-- 7.4 baixa/entrada na reserva técnica (uso interno)
create or replace function app.mover_reserva(p_org uuid, p_unid uuid, p_agente text, p_tipo text, p_qtd int, p_desvio uuid, p_ref text)
returns boolean language plpgsql security definer set search_path = public as $$
declare v_q int;
begin
  insert into public.reserva_estoque (org_id, unidade_id, agente) values (p_org, p_unid, p_agente)
  on conflict (unidade_id, agente) do nothing;
  select quantidade into v_q from public.reserva_estoque where unidade_id = p_unid and agente = p_agente for update;
  if p_tipo = 'saida' and v_q < p_qtd then return false; end if;
  update public.reserva_estoque
     set quantidade = case p_tipo when 'saida' then v_q - p_qtd when 'entrada' then v_q + p_qtd else p_qtd end,
         atualizado_em = now()
   where unidade_id = p_unid and agente = p_agente;
  insert into public.reserva_movimentos (org_id, unidade_id, agente, tipo, qtd, desvio_id, referencia, usuario_id)
  values (p_org, p_unid, p_agente, p_tipo, p_qtd, p_desvio, p_ref, auth.uid());
  return true;
end $$;

-- entrada, ajuste de inventário e estoque mínimo (admin)
create or replace function public.movimentar_reserva(p_unidade uuid, p_agente text, p_tipo text, p_qtd int, p_obs text default null, p_minimo int default null)
returns void language plpgsql security definer set search_path = public as $$
declare v_org uuid;
begin
  select org_id into v_org from public.unidades where id = p_unidade;
  if not app.e_admin(v_org) then raise exception 'Somente administradores movimentam a reserva' using errcode = '42501'; end if;
  if p_tipo not in ('entrada','ajuste') or p_qtd < 0 then raise exception 'Movimento inválido'; end if;
  perform app.mover_reserva(v_org, p_unidade, p_agente, p_tipo, p_qtd, null, p_obs);
  if p_minimo is not null then update public.reserva_estoque set minimo = p_minimo where unidade_id = p_unidade and agente = p_agente; end if;
end $$;

-- 7.5 troca de equipamento no ponto (retirado → instalado)
create or replace function app.aplicar_troca(p_ponto uuid, p_origem text, p_motivo text, p_fonte text,
  p_cil text, p_agente text, p_n2 text, p_n3 int, p_obs text, p_ref text, p_id uuid default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare pt public.pontos; v_id uuid;
begin
  select * into pt from public.pontos where id = p_ponto for update;
  insert into public.trocas (id, org_id, unidade_id, ponto_id, origem, referencia, motivo, fonte,
                             ret_cilindro, ret_agente, ret_n2, ret_n3, ins_cilindro, ins_agente, ins_n2, ins_n3, observacao, usuario_id)
  values (coalesce(p_id, gen_random_uuid()), pt.org_id, pt.unidade_id, pt.id, p_origem, p_ref, p_motivo, p_fonte,
          pt.numero_cilindro, pt.agente, pt.n2, pt.n3, p_cil, coalesce(p_agente, pt.agente), coalesce(p_n2, pt.n2), coalesce(p_n3, pt.n3), p_obs, auth.uid())
  returning id into v_id;
  perform set_config('app.origem', case p_origem when 'desvio' then 'desvio' when 'inspecao' then 'inspecao' else 'troca' end, true);
  perform set_config('app.referencia', coalesce(p_ref, ''), true);
  update public.pontos set numero_cilindro = p_cil, agente = coalesce(p_agente, agente),
                           n2 = coalesce(p_n2, n2), n3 = coalesce(p_n3, n3)
   where id = p_ponto;
  perform set_config('app.origem', '', true);
  perform set_config('app.referencia', '', true);
  return v_id;
end $$;

create or replace function public.registrar_troca(p jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare pt public.pontos; v_id uuid := coalesce((p->>'id')::uuid, gen_random_uuid());
begin
  if exists (select 1 from public.trocas where id = v_id) then return v_id; end if;   -- reenvio da fila
  select * into pt from public.pontos where id = (p->>'ponto_id')::uuid;
  if pt.id is null then raise exception 'Ponto inexistente'; end if;
  if not app.can_write(pt.org_id, pt.unidade_id) then raise exception 'Sem permissão para este ponto' using errcode = '42501'; end if;
  if coalesce(trim(p->>'cilindro'), '') = '' then raise exception 'Informe o equipamento instalado'; end if;
  if p->>'fonte' = 'reserva' then
    if not app.mover_reserva(pt.org_id, pt.unidade_id, coalesce(p->>'agente', pt.agente), 'saida', 1, null, 'Troca no ponto ' || pt.codigo) then
      raise exception 'Sem estoque de % na reserva técnica', coalesce(p->>'agente', pt.agente) using errcode = 'P0001';
    end if;
  end if;
  perform app.aplicar_troca(pt.id, 'manual', coalesce(p->>'motivo', 'Outro'), p->>'fonte', trim(p->>'cilindro'),
                            nullif(p->>'agente', ''), nullif(p->>'n2', ''), nullif(p->>'n3', '')::int, p->>'observacao', null, v_id);
  insert into public.logs (org_id, usuario_id, acao, detalhe) values (pt.org_id, auth.uid(), 'troca_registrada', jsonb_build_object('id', v_id, 'ponto', pt.codigo));
  return v_id;
end $$;

-- 7.6 comunicado de desvio: desvio + reserva + troca + inspeção do ponto, numa transação
create or replace function public.registrar_desvio(p jsonb) returns text
language plpgsql security definer set search_path = public as $$
declare
  pt public.pontos; cat text; v_id uuid := (p->>'id')::uuid; v_num text; v_ano text; v_seq int;
  v_sub boolean := coalesce((p->>'substituir')::boolean, false);
  v_res text := nullif(p->>'reserva', ''); v_status text := 'encerrado'; v_agente text;
begin
  if v_id is null then raise exception 'id do comunicado é obrigatório'; end if;
  select numero into v_num from public.desvios where id = v_id;
  if v_num is not null then return v_num; end if;                                      -- reenvio da fila
  select * into pt from public.pontos where id = (p->>'ponto_id')::uuid;
  if pt.id is null then raise exception 'Ponto inexistente'; end if;
  if not app.can_write(pt.org_id, pt.unidade_id) then raise exception 'Sem permissão para este ponto' using errcode = '42501'; end if;
  select c.chave into cat from public.categorias c where c.id = pt.categoria_id;
  v_agente := coalesce(nullif(p->>'agente', ''), pt.agente, 'Outra');

  -- numeração sequencial por organização e ano (trava por organização)
  perform pg_advisory_xact_lock(hashtext('desvio:' || pt.org_id::text));
  v_ano := to_char(coalesce((p->>'acionado_em')::timestamptz, now()) at time zone 'America/Sao_Paulo', 'YYYY');
  select count(*) + 1 into v_seq from public.desvios where org_id = pt.org_id and numero like 'CD-' || v_ano || '-%';
  v_num := 'CD-' || v_ano || '-' || lpad(v_seq::text, 4, '0');

  if v_sub and v_res = 'usada' and cat = 'extintor' then
    if not app.mover_reserva(pt.org_id, pt.unidade_id, v_agente, 'saida', 1, v_id, v_num) then
      v_res := 'indisponivel';                     -- outro aparelho levou a última unidade
    end if;
  end if;
  if v_sub and v_res = 'indisponivel' then v_status := 'pendente'; end if;

  insert into public.desvios (id, numero, org_id, unidade_id, ponto_id, origem, gatilho, acionador_papel, acionador_nome, meio,
       acionado_em, chegada_em, descricao, substituir, reserva, agente, cilindro_retirado, cilindro_instalado, n2_instalado,
       acao, pendencias, destinatarios, status, encerrado_em, inspecao_origem_id, bombeiro_id)
  values (v_id, v_num, pt.org_id, pt.unidade_id, pt.id, p->>'origem', p->>'gatilho', nullif(p->>'acionador_papel', ''), nullif(p->>'acionador_nome', ''),
       nullif(p->>'meio', ''), coalesce((p->>'acionado_em')::timestamptz, now()), coalesce((p->>'chegada_em')::timestamptz, now()),
       p->>'descricao', v_sub, case when v_sub then v_res end, v_agente, pt.numero_cilindro,
       case when v_status = 'encerrado' and v_sub then nullif(p->>'cilindro_instalado', '') end,
       case when v_status = 'encerrado' and v_sub then nullif(p->>'n2_instalado', '') end,
       p->>'acao', p->>'pendencias', coalesce(array(select jsonb_array_elements_text(p->'destinatarios')), '{}'),
       v_status, case when v_status = 'encerrado' then now() end, nullif(p->>'inspecao_origem_id', '')::uuid, auth.uid());

  if v_sub and v_status = 'encerrado' then
    if cat = 'extintor' then
      if coalesce(p->>'cilindro_instalado', '') = '' then raise exception 'Informe o nº do cilindro instalado'; end if;
      perform app.aplicar_troca(pt.id, 'desvio', case p->>'gatilho' when 'extrativo' then 'Extintor ausente (extrativo)'
                 when 'violacao' then 'Lacre rompido' else 'Uso em combate' end, case when v_res = 'usada' then 'reserva' else 'outro' end,
                 p->>'cilindro_instalado', v_agente, nullif(p->>'n2_instalado', ''), null, null, v_num);
    end if;
    -- o ponto volta a ficar coberto: inspeção conforme de origem "desvio"
    perform set_config('app.origem', 'desvio', true);
    insert into public.inspecoes (id, ponto_id, org_id, unidade_id, categoria_id, data_inspecao, periodicidade, ciclo_referencia, status, observacoes, origem)
    values (gen_random_uuid(), pt.id, pt.org_id, pt.unidade_id, pt.categoria_id, now(), '-', '-', 'ok', 'Recomposto no comunicado de desvio ' || v_num, 'desvio');
    perform set_config('app.origem', '', true);
  end if;
  return v_num;
end $$;

-- 7.7 regularização do desvio pendente (a reposição chegou)
create or replace function public.regularizar_desvio(p_id uuid, p_cilindro text, p_n2 text, p_da_reserva boolean default true)
returns void language plpgsql security definer set search_path = public as $$
declare d public.desvios; cat text;
begin
  select * into d from public.desvios where id = p_id for update;
  if d.id is null or d.status <> 'pendente' then raise exception 'Comunicado não está pendente'; end if;
  if not app.can_write(d.org_id, d.unidade_id) then raise exception 'Sem permissão' using errcode = '42501'; end if;
  select c.chave into cat from public.pontos pt join public.categorias c on c.id = pt.categoria_id where pt.id = d.ponto_id;
  if p_da_reserva and cat = 'extintor' then
    if not app.mover_reserva(d.org_id, d.unidade_id, d.agente, 'saida', 1, d.id, d.numero) then
      raise exception 'Ainda sem estoque de % na reserva técnica', d.agente using errcode = 'P0001';
    end if;
  end if;
  if cat = 'extintor' then
    perform app.aplicar_troca(d.ponto_id, 'regularizacao', 'Regularização de ' || d.numero, case when p_da_reserva then 'reserva' else 'outro' end,
                              p_cilindro, d.agente, nullif(p_n2, ''), null, null, d.numero);
  end if;
  update public.desvios set status = 'encerrado', encerrado_em = now(), cilindro_instalado = p_cilindro, n2_instalado = nullif(p_n2, ''),
         reserva = case when p_da_reserva then 'usada' else reserva end
   where id = d.id;   -- (desvios não tem gatilho de imutabilidade: o encerramento é a única atualização prevista)
  perform set_config('app.origem', 'desvio', true);
  insert into public.inspecoes (id, ponto_id, org_id, unidade_id, categoria_id, data_inspecao, periodicidade, ciclo_referencia, status, observacoes, origem)
  select gen_random_uuid(), pt.id, pt.org_id, pt.unidade_id, pt.categoria_id, now(), '-', '-', 'ok', 'Regularizado no comunicado ' || d.numero, 'desvio'
    from public.pontos pt where pt.id = d.ponto_id;
  perform set_config('app.origem', '', true);
end $$;

-- 7.8 etiquetas QR
create or replace function public.regerar_qr(p_ponto uuid, p_motivo text) returns text
language plpgsql security definer set search_path = public as $$
declare pt public.pontos; v_novo text;
begin
  select * into pt from public.pontos where id = p_ponto for update;
  if not app.e_admin(pt.org_id) then raise exception 'Somente administradores geram novo QR' using errcode = '42501'; end if;
  insert into public.qr_historico (org_id, ponto_id, qr_id, gerado_em, motivo, usuario_id)
  values (pt.org_id, pt.id, pt.qr_id, pt.qr_gerado_em, coalesce(nullif(trim(p_motivo), ''), 'Não informado'), auth.uid());
  v_novo := app.gerar_qr_id(pt.org_id);
  perform set_config('app.origem', 'qr', true);
  update public.pontos set qr_id = v_novo, qr_gerado_em = now(), qr_impresso_em = null where id = pt.id;
  perform set_config('app.origem', '', true);
  return v_novo;
end $$;

create or replace function public.marcar_etiquetas_impressas(p_ids uuid[]) returns int
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  update public.pontos set qr_impresso_em = now() where id = any(p_ids) and app.e_admin(org_id);
  get diagnostics n = row_count;
  return n;
end $$;

-- resolve o ID lido no QR (atual ou de etiqueta substituída)
create or replace function public.resolver_qr(p_qr text) returns table (ponto_id uuid, substituida boolean, invalidado_em timestamptz, motivo text)
language sql stable security definer set search_path = public as $$
  select id, false, null::timestamptz, null::text from public.pontos
   where qr_id = upper(replace(p_qr, '-', '')) and app.can_unit(org_id, unidade_id)
  union all
  select h.ponto_id, true, h.invalidado_em, h.motivo from public.qr_historico h join public.pontos pt on pt.id = h.ponto_id
   where h.qr_id = upper(replace(p_qr, '-', '')) and app.can_unit(pt.org_id, pt.unidade_id)
  limit 1;
$$;

-- 7.9 importação da planilha (somente novos; códigos e QR existentes preservados)
-- p_itens: [{codigo, categoria, gerencia, sigla, area, local, subtipo, capacidade, numero_cilindro, agente, n2, n3, requer_conferencia, dados}]
create or replace function public.importar_pontos(p_unidade uuid, p_itens jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_org uuid; it jsonb; v_cat uuid; v_ger uuid; novos int := 0; existentes int := 0; erros jsonb := '[]'::jsonb; v_id uuid;
begin
  select org_id into v_org from public.unidades where id = p_unidade;
  if not app.e_admin(v_org) then raise exception 'Somente administradores importam' using errcode = '42501'; end if;
  perform set_config('app.origem', 'importacao', true);
  for it in select * from jsonb_array_elements(p_itens) loop
    begin
      select id into v_cat from public.categorias where org_id = v_org and chave = it->>'categoria';
      if v_cat is null then raise exception 'categoria %', it->>'categoria'; end if;
      insert into public.gerencias (org_id, unidade_id, nome, sigla) values (v_org, p_unidade, upper(trim(it->>'gerencia')), upper(coalesce(it->>'sigla', left(it->>'gerencia', 3))))
      on conflict (unidade_id, nome) do nothing;
      select id into v_ger from public.gerencias where unidade_id = p_unidade and nome = upper(trim(it->>'gerencia'));
      insert into public.pontos (org_id, unidade_id, categoria_id, gerencia_id, codigo, area, local, subtipo, capacidade,
                                 numero_cilindro, agente, n2, n3, requer_conferencia, dados)
      values (v_org, p_unidade, v_cat, v_ger, upper(trim(it->>'codigo')), coalesce(it->>'area', ''), coalesce(it->>'local', ''),
              coalesce(it->>'subtipo', ''), coalesce(it->>'capacidade', ''), nullif(it->>'numero_cilindro', ''), nullif(it->>'agente', ''),
              nullif(it->>'n2', ''), nullif(it->>'n3', '')::int, coalesce((it->>'requer_conferencia')::boolean, false), coalesce(it->'dados', '{}'::jsonb))
      on conflict (org_id, codigo) do nothing
      returning id into v_id;
      if v_id is null then existentes := existentes + 1; else novos := novos + 1; end if;
      v_id := null;
    exception when others then
      erros := erros || jsonb_build_object('codigo', it->>'codigo', 'erro', sqlerrm);
    end;
  end loop;
  perform set_config('app.origem', '', true);
  insert into public.logs (org_id, usuario_id, acao, detalhe) values (v_org, auth.uid(), 'importacao', jsonb_build_object('novos', novos, 'existentes', existentes, 'erros', jsonb_array_length(erros)));
  return jsonb_build_object('novos', novos, 'existentes', existentes, 'erros', erros);
end $$;

-- 7.10 pendências do ciclo corrente (respeita a RLS de quem chama)
create or replace function public.pendencias(p_unidade uuid, p_categoria text default null)
returns setof public.pontos language sql stable security invoker set search_path = public as $$
  select pt.* from public.pontos pt
    join public.categorias c on c.id = pt.categoria_id
    join public.organizacoes o on o.id = pt.org_id
   where pt.unidade_id = p_unidade and pt.ativo
     and (p_categoria is null or c.chave = p_categoria)
     and not exists (select 1 from public.inspecoes i
                      where i.ponto_id = pt.id and not i.anulada
                        and i.ciclo_referencia = app.ciclo_de(now(), c.periodicidade, o.fuso))
   order by pt.codigo;
$$;

-- 7.11 heartbeat diário (Cloudflare Worker) + retrato do consumo
create or replace function public.heartbeat() returns jsonb
language plpgsql security definer set search_path = public, storage as $$
declare r record;
begin
  update public.heartbeat set ultimo_ping = now() where id = 1;
  select round(pg_database_size(current_database()) / 1048576.0, 1) as banco_mb,
         round(coalesce(sum((o.metadata ->> 'size')::bigint), 0) / 1048576.0, 1) as fotos_mb,
         count(o.*)::int as fotos_qtd
    into r from storage.objects o where o.bucket_id = 'fotos';
  insert into public.uso_diario (dia, banco_mb, fotos_mb, fotos_qtd) values (current_date, r.banco_mb, r.fotos_mb, r.fotos_qtd)
  on conflict (dia) do update set banco_mb = excluded.banco_mb, fotos_mb = excluded.fotos_mb, fotos_qtd = excluded.fotos_qtd, criado_em = now();
  return jsonb_build_object('ok', true, 'em', now());      -- não devolve números ao anônimo
end $$;


-- 7.12 o e-mail logado tem convite de bootstrap pendente?
create or replace function public.meu_convite() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.convites where lower(email) = lower(auth.email()) and usado_em is null);
$$;

-- 7.13 conferência feita na inspeção: o inspetor corrige o equipamento instalado do ponto
-- (cilindro diferente = troca identificada na inspeção; demais campos = alteração auditada)
create or replace function public.conferir_ponto(p jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare pt public.pontos; v_cil text := nullif(trim(p->>'numero_cilindro'), '');
begin
  select * into pt from public.pontos where id = (p->>'ponto_id')::uuid for update;
  if pt.id is null then raise exception 'Ponto inexistente'; end if;
  if not app.can_write(pt.org_id, pt.unidade_id) then raise exception 'Sem permissão para este ponto' using errcode = '42501'; end if;
  if v_cil is not null and v_cil is distinct from pt.numero_cilindro then
    perform app.aplicar_troca(pt.id, 'inspecao', 'Equipamento diferente encontrado no ponto', null, v_cil,
      nullif(p->>'agente', ''), nullif(p->>'n2', ''), nullif(p->>'n3', '')::int, 'Identificado na conferência da inspeção', p->>'inspecao_id');
  else
    perform set_config('app.origem', 'inspecao', true);
    perform set_config('app.referencia', coalesce(p->>'inspecao_id', ''), true);
    update public.pontos set
      agente = coalesce(nullif(p->>'agente', ''), agente),
      n2     = coalesce(nullif(p->>'n2', ''), n2),
      n3     = coalesce(nullif(p->>'n3', '')::int, n3)
     where id = pt.id;
  end if;
  update public.pontos set dados = dados || jsonb_strip_nulls(jsonb_build_object(
      'anel', p->'anel', 'base', p->'base', 'qtd', p->'qtd', 'kit_vencimento', p->'kit_vencimento', 'pressurizado', p->'pressurizado',
      'th_ultimo', p->'th_ultimo', 'th_proximo', p->'th_proximo', 'mangueiras', p->'mangueiras'))
   where id = pt.id;
  perform set_config('app.origem', '', true);
  perform set_config('app.referencia', '', true);
end $$;

-- 7.14 vincula o bombeiro responsável (nome da planilha → usuário) — admin
create or replace function public.vincular_responsaveis(p_org uuid, p_mapa jsonb) returns int
language plpgsql security definer set search_path = public as $$
declare k text; n int := 0; c int;
begin
  if not app.e_admin(p_org) then raise exception 'Somente administradores' using errcode = '42501'; end if;
  for k in select jsonb_object_keys(p_mapa) loop
    update public.pontos set bombeiro_id = nullif(p_mapa->>k, '')::uuid
     where org_id = p_org and dados->>'responsavel' = k and bombeiro_id is distinct from nullif(p_mapa->>k, '')::uuid;
    get diagnostics c = row_count; n := n + c;
  end loop;
  return n;
end $$;


-- 7.15 zerar o sistema (somente owner): apaga os dados de teste e recomeça.
--      Usuários, organização e unidades são mantidos. As fotos do armazenamento são apagadas pelo app antes.
create or replace function public.zerar_sistema(p_org uuid, p_confirmacao text, p_configuracoes boolean default false) returns jsonb
language plpgsql security definer set search_path = public as $$
declare n_pontos int; n_insp int;
begin
  if app.papel(p_org) is distinct from 'owner' then raise exception 'Somente o owner pode zerar o sistema' using errcode = '42501'; end if;
  if p_confirmacao is distinct from 'ZERAR' then raise exception 'Digite ZERAR para confirmar'; end if;
  select count(*) into n_pontos from public.pontos where org_id = p_org;
  select count(*) into n_insp from public.inspecoes where org_id = p_org;
  perform set_config('app.zerando', 'sim', true);
  delete from public.envios_email where org_id = p_org;
  delete from public.fotos where org_id = p_org;
  delete from public.desvios where org_id = p_org;
  delete from public.inspecoes where org_id = p_org;
  delete from public.trocas where org_id = p_org;
  delete from public.alteracoes where org_id = p_org;
  delete from public.qr_historico where org_id = p_org;
  delete from public.reserva_movimentos where org_id = p_org;
  delete from public.reserva_estoque where org_id = p_org;
  delete from public.pontos where org_id = p_org;
  if p_configuracoes then
    delete from public.gerencias where org_id = p_org;
    delete from public.destinatarios where org_id = p_org;
    delete from public.agentes where org_id = p_org;
    delete from public.categorias where org_id = p_org;
    perform app.semear_categorias(p_org);
    perform app.semear_agentes(p_org);
  end if;
  delete from public.logs where org_id = p_org;
  perform set_config('app.zerando', '', true);
  insert into public.logs (org_id, usuario_id, acao, detalhe, tabela, rotulo)
  values (p_org, auth.uid(), 'sistema_zerado', jsonb_build_object('pontos', n_pontos, 'inspecoes', n_insp, 'configuracoes', p_configuracoes), 'app', 'Sistema zerado');
  return jsonb_build_object('pontos', n_pontos, 'inspecoes', n_insp);
end $$;

-- =====================================================================
-- 8. ROW-LEVEL SECURITY
-- =====================================================================
do $$
declare t text;
begin
  foreach t in array array['organizacoes','unidades','usuarios','membros','membro_unidades','convites','categorias','gerencias',
                           'pontos','qr_historico','inspecoes','fotos','desvios','trocas','alteracoes','reserva_estoque',
                           'reserva_movimentos','destinatarios','envios_email','logs','heartbeat','uso_diario','agentes'] loop
    execute format('alter table public.%I enable row level security', t);
  end loop;
end $$;

-- organizações e unidades
drop policy if exists org_sel on public.organizacoes;
create policy org_sel on public.organizacoes for select to authenticated using (app.membro_da_org(id));
drop policy if exists org_upd on public.organizacoes;
create policy org_upd on public.organizacoes for update to authenticated using (app.papel(id) = 'owner') with check (app.papel(id) = 'owner');

drop policy if exists unid_sel on public.unidades;
create policy unid_sel on public.unidades for select to authenticated using (app.can_unit(org_id, id));
drop policy if exists unid_ins on public.unidades;
create policy unid_ins on public.unidades for insert to authenticated with check (app.e_admin(org_id));
drop policy if exists unid_upd on public.unidades;
create policy unid_upd on public.unidades for update to authenticated using (app.e_admin(org_id)) with check (app.e_admin(org_id));

-- usuários e membros
drop policy if exists usu_sel on public.usuarios;
create policy usu_sel on public.usuarios for select to authenticated using (
  id = auth.uid() or exists (select 1 from public.membros m where m.usuario_id = usuarios.id and app.membro_da_org(m.org_id)));
drop policy if exists usu_upd on public.usuarios;
create policy usu_upd on public.usuarios for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists mem_sel on public.membros;
create policy mem_sel on public.membros for select to authenticated using (usuario_id = auth.uid() or app.membro_da_org(org_id));
drop policy if exists mem_upd on public.membros;
create policy mem_upd on public.membros for update to authenticated using (app.e_admin(org_id)) with check (app.e_admin(org_id) and papel <> 'owner');
-- inserção e exclusão de membros: somente pelas Edge Functions (service role)

drop policy if exists mu_sel on public.membro_unidades;
create policy mu_sel on public.membro_unidades for select to authenticated using (
  exists (select 1 from public.membros m where m.id = membro_id and (m.usuario_id = auth.uid() or app.membro_da_org(m.org_id))));
drop policy if exists mu_all on public.membro_unidades;
create policy mu_all on public.membro_unidades for all to authenticated
  using (exists (select 1 from public.membros m where m.id = membro_id and app.e_admin(m.org_id)))
  with check (exists (select 1 from public.membros m join public.unidades u on u.org_id = m.org_id
                      where m.id = membro_id and u.id = unidade_id and app.e_admin(m.org_id)));
-- convites: nenhuma política (só SQL Editor / service role)

-- cadastro
drop policy if exists cat_sel on public.categorias;
create policy cat_sel on public.categorias for select to authenticated using (app.membro_da_org(org_id));
drop policy if exists cat_upd on public.categorias;
create policy cat_upd on public.categorias for update to authenticated using (app.e_admin(org_id)) with check (app.e_admin(org_id));

drop policy if exists cat_ins on public.categorias;
create policy cat_ins on public.categorias for insert to authenticated with check (app.e_admin(org_id));
drop policy if exists cat_del on public.categorias;
create policy cat_del on public.categorias for delete to authenticated using (app.e_admin(org_id));

drop policy if exists ger_sel on public.gerencias;
create policy ger_sel on public.gerencias for select to authenticated using (app.can_unit(org_id, unidade_id));
drop policy if exists ger_ins on public.gerencias;
create policy ger_ins on public.gerencias for insert to authenticated with check (app.e_admin(org_id));
drop policy if exists ger_upd on public.gerencias;
create policy ger_upd on public.gerencias for update to authenticated using (app.e_admin(org_id)) with check (app.e_admin(org_id));

drop policy if exists pt_sel on public.pontos;
create policy pt_sel on public.pontos for select to authenticated using (app.can_unit(org_id, unidade_id));
drop policy if exists pt_ins on public.pontos;
create policy pt_ins on public.pontos for insert to authenticated with check (app.e_admin(org_id) and app.can_unit(org_id, unidade_id));
drop policy if exists pt_upd on public.pontos;
create policy pt_upd on public.pontos for update to authenticated using (app.e_admin(org_id)) with check (app.e_admin(org_id) and app.can_unit(org_id, unidade_id));
-- sem DELETE: ponto se inativa (histórico preservado)

drop policy if exists qrh_sel on public.qr_historico;
create policy qrh_sel on public.qr_historico for select to authenticated using (app.membro_da_org(org_id));

-- inspeções: inserção pelo inspetor da unidade; nunca update/delete direto
drop policy if exists insp_sel on public.inspecoes;
create policy insp_sel on public.inspecoes for select to authenticated using (app.can_unit(org_id, unidade_id));
drop policy if exists insp_ins on public.inspecoes;
create policy insp_ins on public.inspecoes for insert to authenticated with check (app.can_write(org_id, unidade_id) and inspetor_id = auth.uid());

drop policy if exists foto_sel on public.fotos;
create policy foto_sel on public.fotos for select to authenticated using (app.can_unit(org_id, unidade_id));
drop policy if exists foto_ins on public.fotos;
create policy foto_ins on public.fotos for insert to authenticated with check (
  app.can_write(org_id, unidade_id) and criado_por = auth.uid()
  and (select count(*) from public.fotos f where f.registro_id = fotos.registro_id) < 3);

-- desvios, trocas, alterações, reserva: leitura na unidade; escrita só por funções
drop policy if exists dsv_sel on public.desvios;
create policy dsv_sel on public.desvios for select to authenticated using (app.can_unit(org_id, unidade_id));
drop policy if exists trc_sel on public.trocas;
create policy trc_sel on public.trocas for select to authenticated using (app.can_unit(org_id, unidade_id));
drop policy if exists alt_sel on public.alteracoes;
create policy alt_sel on public.alteracoes for select to authenticated using (app.can_unit(org_id, unidade_id));
drop policy if exists res_sel on public.reserva_estoque;
create policy res_sel on public.reserva_estoque for select to authenticated using (app.can_unit(org_id, unidade_id));
drop policy if exists mov_sel on public.reserva_movimentos;
create policy mov_sel on public.reserva_movimentos for select to authenticated using (app.can_unit(org_id, unidade_id));

drop policy if exists dst_all on public.destinatarios;
create policy dst_all on public.destinatarios for all to authenticated using (app.e_admin(org_id)) with check (app.e_admin(org_id));
drop policy if exists dst_sel on public.destinatarios;
create policy dst_sel on public.destinatarios for select to authenticated using (app.membro_da_org(org_id));

drop policy if exists env_sel on public.envios_email;
create policy env_sel on public.envios_email for select to authenticated using (app.membro_da_org(org_id));
drop policy if exists log_sel on public.logs;
create policy log_sel on public.logs for select to authenticated using (app.e_gestor(org_id));
drop policy if exists hb_sel on public.heartbeat;
create policy hb_sel on public.heartbeat for select to authenticated using (true);
drop policy if exists uso_sel on public.uso_diario;
create policy uso_sel on public.uso_diario for select to authenticated using (
  exists (select 1 from public.membros where usuario_id = auth.uid() and ativo and papel in ('owner','admin','admin_leitura')));

drop policy if exists agt_sel on public.agentes;
create policy agt_sel on public.agentes for select to authenticated using (app.membro_da_org(org_id));
drop policy if exists agt_ins on public.agentes;
create policy agt_ins on public.agentes for insert to authenticated with check (app.e_admin(org_id));
drop policy if exists agt_upd on public.agentes;
create policy agt_upd on public.agentes for update to authenticated using (app.e_admin(org_id)) with check (app.e_admin(org_id));
drop policy if exists agt_del on public.agentes;
create policy agt_del on public.agentes for delete to authenticated using (app.e_admin(org_id));

-- =====================================================================
-- 8b. AUDITORIA GERAL — tudo o que muda no sistema vira um registro em logs
--     (quem, quando, o quê, de → para). Logs são imutáveis e só o admin lê.
-- =====================================================================
create or replace function app.tg_auditoria() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  n jsonb := case when tg_op <> 'DELETE' then to_jsonb(new) end;
  o jsonb := case when tg_op <> 'INSERT' then to_jsonb(old) end;
  r jsonb := coalesce(n, o);
  v_org uuid; v_unid uuid; v_rot text; v_det jsonb; v_id text;
begin
  if current_setting('app.zerando', true) = 'sim' then return null; end if;
  v_id := coalesce(r ->> 'id', r ->> 'membro_id', r ->> 'agente');
  v_org := case tg_table_name when 'organizacoes' then (r ->> 'id')::uuid else (r ->> 'org_id')::uuid end;
  v_unid := case tg_table_name when 'unidades' then (r ->> 'id')::uuid else nullif(r ->> 'unidade_id', '')::uuid end;
  if tg_table_name = 'membro_unidades' then
    select m.org_id, m.nome into v_org, v_rot from public.membros m where m.id = (r ->> 'membro_id')::uuid;
    v_rot := coalesce(v_rot, '') || ' → ' || coalesce((select nome from public.unidades where id = (r ->> 'unidade_id')::uuid), '');
  end if;
  if tg_op = 'UPDATE' then
    select jsonb_object_agg(k, jsonb_build_array(o -> k, n -> k)) into v_det
      from jsonb_object_keys(n) k
     where (o -> k) is distinct from (n -> k) and k not in ('atualizado_em', 'recebida_em');
    if v_det is null then return null; end if;               -- nada mudou de fato
  else
    v_det := r - 'checklist';
  end if;
  v_rot := coalesce(v_rot, case tg_table_name
    when 'pontos'             then r ->> 'codigo'
    when 'inspecoes'          then (select codigo from public.pontos where id = (r ->> 'ponto_id')::uuid) || ' · ' || coalesce(r ->> 'status', '')
    when 'trocas'             then (select codigo from public.pontos where id = (r ->> 'ponto_id')::uuid)
    when 'fotos'              then (select coalesce((select codigo from public.pontos p join public.inspecoes i on i.ponto_id = p.id where i.id = (r ->> 'registro_id')::uuid),
                                                    (select numero from public.desvios where id = (r ->> 'registro_id')::uuid)))
    when 'desvios'            then coalesce(r ->> 'numero', '') || ' · ' || coalesce((select codigo from public.pontos where id = (r ->> 'ponto_id')::uuid), '')
    when 'envios_email'       then (select numero from public.desvios where id = (r ->> 'desvio_id')::uuid)
    when 'membros'            then r ->> 'nome'
    when 'gerencias'          then r ->> 'nome'
    when 'unidades'           then r ->> 'nome'
    when 'organizacoes'       then r ->> 'nome'
    when 'categorias'         then r ->> 'nome'
    when 'destinatarios'      then coalesce(r ->> 'nome', '') || ' <' || coalesce(r ->> 'email', '') || '>'
    when 'reserva_estoque'    then r ->> 'agente'
    when 'agentes'            then r ->> 'nome'
    when 'reserva_movimentos' then coalesce(r ->> 'agente', '') || ' · ' || coalesce(r ->> 'tipo', '') || ' ' || coalesce(r ->> 'qtd', '')
    when 'qr_historico'       then (select codigo from public.pontos where id = (r ->> 'ponto_id')::uuid)
  end);
  if length(v_det::text) > 4000 then v_det := jsonb_build_object('resumo', 'registro grande — detalhe omitido'); end if;
  insert into public.logs (org_id, usuario_id, acao, detalhe, tabela, registro, rotulo, unidade_id)
  values (v_org, auth.uid(), tg_table_name || '.' || lower(tg_op), v_det, tg_table_name, v_id, v_rot, v_unid);
  return null;
end $$;

do $$
declare t text;
begin
  foreach t in array array['organizacoes','unidades','membros','membro_unidades','categorias','gerencias','pontos','qr_historico',
                           'inspecoes','fotos','desvios','trocas','reserva_estoque','reserva_movimentos','destinatarios','envios_email','agentes'] loop
    execute format('drop trigger if exists %I on public.%I', t || '_auditoria_geral', t);
    execute format('create trigger %I after insert or update or delete on public.%I for each row execute function app.tg_auditoria()', t || '_auditoria_geral', t);
  end loop;
end $$;

-- eventos do aplicativo: login, logout, sessão, senha, exportações, relatórios, backups
create or replace function public.registrar_evento(p_acao text, p_detalhe jsonb default '{}'::jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare d jsonb := coalesce(p_detalhe, '{}'::jsonb);
begin
  if auth.uid() is null then return; end if;
  if p_acao !~ '^(acesso|app)\.[a-z_]{2,40}$' then raise exception 'Evento inválido'; end if;
  if length(d::text) > 2000 then d := jsonb_build_object('resumo', 'detalhe omitido (muito grande)'); end if;
  insert into public.logs (org_id, usuario_id, acao, detalhe, tabela, rotulo)
  select m.org_id, auth.uid(), p_acao, d, 'app', coalesce(d ->> 'rotulo', m.nome)
    from public.membros m where m.usuario_id = auth.uid() and m.ativo;
  if not found then
    insert into public.logs (org_id, usuario_id, acao, detalhe, tabela) values (null, auth.uid(), p_acao, d, 'app');
  end if;
end $$;

-- tentativa de login com senha errada (chamada sem login; só registra e-mails de membros, no máximo 20/h)
create or replace function public.registrar_falha_login(p_email text) returns void
language plpgsql security definer set search_path = public as $$
declare v_uid uuid; v_org uuid;
begin
  select u.id, m.org_id into v_uid, v_org from auth.users u join public.membros m on m.usuario_id = u.id
   where lower(u.email) = lower(trim(p_email)) limit 1;
  if v_uid is null then return; end if;
  if (select count(*) from public.logs where usuario_id = v_uid and acao = 'acesso.falha_login' and criado_em > now() - interval '1 hour') >= 20 then return; end if;
  insert into public.logs (org_id, usuario_id, acao, detalhe, tabela) values (v_org, v_uid, 'acesso.falha_login', jsonb_build_object('email', lower(trim(p_email))), 'app');
end $$;

-- último acesso de cada membro (lido do Supabase Auth) — somente admin
create or replace function public.membros_acesso(p_org uuid) returns table (usuario_id uuid, ultimo_login timestamptz)
language sql stable security definer set search_path = public, auth as $$
  select m.usuario_id, u.last_sign_in_at from public.membros m join auth.users u on u.id = m.usuario_id
   where m.org_id = p_org and app.e_gestor(p_org);
$$;

-- =====================================================================
-- 9. PRIVILÉGIOS
-- =====================================================================
revoke all on all tables    in schema public from anon;
revoke all on all sequences in schema public from anon;
-- concessões explícitas (projetos novos podem vir sem os privilégios padrão da Data API); a RLS continua decidindo cada linha
grant usage on schema public to anon, authenticated, service_role;
grant select, insert, update, delete on all tables in schema public to authenticated, service_role;
grant usage, select on all sequences in schema public to authenticated, service_role;
revoke execute on all functions in schema public from public, anon;
grant  execute on all functions in schema public to authenticated, service_role;
grant  execute on function public.heartbeat() to anon;
grant  execute on function public.registrar_falha_login(text) to anon;
grant  usage on schema app to authenticated, service_role;
revoke execute on all functions in schema app from public, anon;
grant  execute on all functions in schema app to authenticated, service_role;
-- o cliente só escreve diretamente em: pontos/gerências/unidades (admin, via RLS), inspeções, fotos, destinatários
revoke insert, update, delete on public.trocas, public.alteracoes, public.reserva_estoque, public.reserva_movimentos,
       public.qr_historico, public.desvios, public.envios_email, public.logs, public.convites, public.membros,
       public.heartbeat, public.uso_diario from authenticated;
grant update on public.membros to authenticated;   -- admin altera papel/ativo (a RLS restringe)
revoke update on public.inspecoes from authenticated;

-- =====================================================================
-- 10. STORAGE — bucket privado de fotos
-- caminho: {org_id}/{unidade_id}/{registro_id}_{n}.jpg
-- =====================================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('fotos', 'fotos', false, 1048576, array['image/jpeg'])
on conflict (id) do update set public = false, file_size_limit = 1048576, allowed_mime_types = array['image/jpeg'];

drop policy if exists inspec_fotos_ler on storage.objects;
create policy inspec_fotos_ler on storage.objects for select to authenticated using (
  bucket_id = 'fotos' and app.can_unit(((storage.foldername(name))[1])::uuid, ((storage.foldername(name))[2])::uuid));
drop policy if exists inspec_fotos_enviar on storage.objects;
create policy inspec_fotos_enviar on storage.objects for insert to authenticated with check (
  bucket_id = 'fotos'
  and app.can_write(((storage.foldername(name))[1])::uuid, ((storage.foldername(name))[2])::uuid)
  and lower(storage.extension(name)) = 'jpg');
drop policy if exists inspec_fotos_apagar on storage.objects;
create policy inspec_fotos_apagar on storage.objects for delete to authenticated using (
  bucket_id = 'fotos' and app.e_admin(((storage.foldername(name))[1])::uuid));

-- =====================================================================
-- 11. VIEWS DE APOIO (respeitam a RLS de quem consulta)
-- =====================================================================
create or replace view public.evidencias_pendentes with (security_invoker = true) as
  select i.id, i.ponto_id, i.unidade_id, i.org_id, i.data_inspecao
    from public.inspecoes i
   where i.status = 'nao_conforme' and not i.anulada
     and i.recebida_em < now() - interval '24 hours'
     and not exists (select 1 from public.fotos f where f.registro_id = i.id);

create or replace view public.ncs_abertas with (security_invoker = true) as
  select distinct on (i.ponto_id) i.*
    from public.inspecoes i
   where not i.anulada
   order by i.ponto_id, i.data_inspecao desc;
-- (o app filtra status = 'nao_conforme' sobre a última inspeção de cada ponto)

-- =====================================================================
-- 12. REGISTROS DE ACESSO COM IP (v1.5.1) — Marco Civil da Internet, art. 15
--     Gravados pelo servidor a partir dos cabeçalhos da requisição; somente owner/admin leem;
--     imutáveis e mantidos mesmo quando o sistema é zerado (guarda mínima recomendada: 6 meses).
-- =====================================================================
create table if not exists public.acessos (
  id          bigint generated always as identity primary key,
  org_id      uuid references public.organizacoes(id) on delete cascade,
  usuario_id  uuid,
  email       text,
  evento      text not null,
  ip          text,
  ip_cadeia   text,
  navegador   text,
  criado_em   timestamptz not null default now()
);
create index if not exists acessos_org_data on public.acessos (org_id, criado_em desc);
alter table public.acessos enable row level security;
drop policy if exists acs_sel on public.acessos;
create policy acs_sel on public.acessos for select to authenticated using (app.e_admin(org_id));
revoke insert, update, delete on public.acessos from authenticated, anon;
grant select on public.acessos to authenticated;
grant all on public.acessos to service_role;
drop trigger if exists acessos_imutavel on public.acessos;
create trigger acessos_imutavel before update or delete on public.acessos for each row execute function app.tg_somente_insercao();

-- IP do cliente: cf-connecting-ip (definido pela Cloudflare do Supabase, não forjável pelo cliente) → x-real-ip → x-forwarded-for
create or replace function app.req_cabecalho(p_nome text) returns text
language plpgsql stable as $$
declare h json;
begin
  begin h := nullif(current_setting('request.headers', true), '')::json; exception when others then return null; end;
  return nullif(trim(h ->> p_nome), '');
end $$;

create or replace function app.registrar_acesso(p_org uuid, p_uid uuid, p_email text, p_evento text) returns void
language plpgsql security definer set search_path = public as $$
declare xff text := app.req_cabecalho('x-forwarded-for');
begin
  insert into public.acessos (org_id, usuario_id, email, evento, ip, ip_cadeia, navegador)
  values (p_org, p_uid, lower(p_email), p_evento,
          coalesce(app.req_cabecalho('cf-connecting-ip'), app.req_cabecalho('x-real-ip'), trim(split_part(xff, ',', 1))),
          left(xff, 300), left(app.req_cabecalho('user-agent'), 300));
end $$;

create or replace function public.registrar_evento(p_acao text, p_detalhe jsonb default '{}'::jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare d jsonb := coalesce(p_detalhe, '{}'::jsonb); v_org uuid; v_email text;
begin
  if auth.uid() is null then return; end if;
  if p_acao !~ '^(acesso|app)\.[a-z_]{2,40}$' then raise exception 'Evento inválido'; end if;
  if length(d::text) > 2000 then d := jsonb_build_object('resumo', 'detalhe omitido (muito grande)'); end if;
  insert into public.logs (org_id, usuario_id, acao, detalhe, tabela, rotulo)
  select m.org_id, auth.uid(), p_acao, d, 'app', coalesce(d ->> 'rotulo', m.nome)
    from public.membros m where m.usuario_id = auth.uid() and m.ativo;
  if not found then
    insert into public.logs (org_id, usuario_id, acao, detalhe, tabela) values (null, auth.uid(), p_acao, d, 'app');
  end if;
  if p_acao like 'acesso.%' then
    select m.org_id into v_org from public.membros m where m.usuario_id = auth.uid() and m.ativo limit 1;
    select u.email into v_email from public.usuarios u where u.id = auth.uid();
    perform app.registrar_acesso(v_org, auth.uid(), v_email, p_acao);
  end if;
end $$;

create or replace function public.registrar_falha_login(p_email text) returns void
language plpgsql security definer set search_path = public as $$
declare v_uid uuid; v_org uuid;
begin
  select u.id, m.org_id into v_uid, v_org from auth.users u join public.membros m on m.usuario_id = u.id
   where lower(u.email) = lower(trim(p_email)) limit 1;
  if v_uid is null then return; end if;
  if (select count(*) from public.logs where usuario_id = v_uid and acao = 'acesso.falha_login' and criado_em > now() - interval '1 hour') >= 20 then return; end if;
  insert into public.logs (org_id, usuario_id, acao, detalhe, tabela) values (v_org, v_uid, 'acesso.falha_login', jsonb_build_object('email', lower(trim(p_email))), 'app');
  perform app.registrar_acesso(v_org, v_uid, p_email, 'acesso.falha_login');
end $$;
revoke execute on function app.registrar_acesso(uuid, uuid, text, text) from public, anon, authenticated;
revoke execute on function app.req_cabecalho(text) from public, anon;
grant execute on function public.registrar_falha_login(text) to anon;


-- =====================================================================
-- 12. VERSÃO DO BANCO
-- =====================================================================
create table if not exists public.versao_banco (id int primary key default 1 check (id = 1), versao text, aplicado_em timestamptz);
alter table public.versao_banco enable row level security;
drop policy if exists vb_sel on public.versao_banco;
create policy vb_sel on public.versao_banco for select to authenticated using (true);
insert into public.versao_banco (id, versao, aplicado_em) values (1, '1.5.1', now())
on conflict (id) do update set versao = excluded.versao, aplicado_em = excluded.aplicado_em;

-- agentes para organizações já existentes (idempotente)
do $$ declare o uuid; begin for o in select id from public.organizacoes loop perform app.semear_agentes(o); end loop; end $$;

-- =====================================================================
-- 13. BOOTSTRAP — e-mail do primeiro administrador (owner)
-- >>> TROQUE pelo e-mail real antes de rodar (decisão D10) <<<
-- =====================================================================
insert into public.convites (email) values ('SEU-EMAIL@exemplo.com.br') on conflict (email) do nothing;

-- Fim. Rode este arquivo uma segunda vez: deve terminar sem erro.
