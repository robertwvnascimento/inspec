// Inspec — cria um usuário (somente owner/admin da organização)
// Corpo: { org_id, email, nome, papel: 'admin'|'inspetor'|'inspetor_leitura'|'admin_leitura', unidades: uuid[], senha_inicial? }
// Resposta: { usuario_id, senha_inicial }  → o admin repassa a senha; troca obrigatória no 1º acesso.
import { admin, chamador, cors, exigirAdmin, json, senhaProvisoria } from '../_shared/comum.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors(req) });
  if (req.method !== 'POST') return json(req, { erro: 'Método não permitido' }, 405);
  try {
    const { userId } = await chamador(req);
    if (!userId) return json(req, { erro: 'Não autenticado' }, 401);

    const b = await req.json();
    const email = String(b.email ?? '').trim().toLowerCase();
    const nome = String(b.nome ?? '').trim();
    const papel = String(b.papel ?? '');
    const unidades: string[] = Array.isArray(b.unidades) ? b.unidades : [];
    if (!b.org_id || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || nome.length < 2) return json(req, { erro: 'Dados incompletos' }, 400);
    if (!['admin', 'inspetor', 'inspetor_leitura', 'admin_leitura'].includes(papel)) return json(req, { erro: 'Papel inválido' }, 400);

    const adm = await admin();
    const papelChamador = await exigirAdmin(adm, userId, b.org_id);
    if (!papelChamador) return json(req, { erro: 'Somente administradores criam usuários' }, 403);
    if (papel === 'admin' && papelChamador !== 'owner') return json(req, { erro: 'Somente o owner cria administradores' }, 403);

    // as unidades informadas precisam ser da mesma organização
    if (unidades.length) {
      const { count } = await adm.from('unidades').select('id', { count: 'exact', head: true }).eq('org_id', b.org_id).in('id', unidades);
      if (count !== unidades.length) return json(req, { erro: 'Unidade fora da organização' }, 400);
    }

    const senha = typeof b.senha_inicial === 'string' && b.senha_inicial.length >= 8 ? b.senha_inicial : senhaProvisoria();
    const { data: criado, error } = await adm.auth.admin.createUser({ email, password: senha, email_confirm: true, user_metadata: { nome } });
    if (error || !criado.user) return json(req, { erro: error?.message ?? 'Falha ao criar o login' }, 400);

    const { data: membro, error: e2 } = await adm.from('membros')
      .insert({ org_id: b.org_id, usuario_id: criado.user.id, nome, papel, trocar_senha: true }).select('id').single();
    if (e2) { await adm.auth.admin.deleteUser(criado.user.id); return json(req, { erro: e2.message }, 400); }
    if (unidades.length) await adm.from('membro_unidades').insert(unidades.map((u) => ({ membro_id: membro.id, unidade_id: u })));
    await adm.from('usuarios').upsert({ id: criado.user.id, email, nome });
    await adm.from('logs').insert({ org_id: b.org_id, usuario_id: userId, acao: 'usuario_criado', detalhe: { email, papel } });

    return json(req, { usuario_id: criado.user.id, senha_inicial: senha });
  } catch (e) {
    return json(req, { erro: e instanceof Error ? e.message : 'Erro inesperado' }, 500);
  }
});
