// Inspec — exclui o login de um usuário (somente owner/admin). O histórico é preservado:
// inspeções, trocas e alterações mantêm o registro com o autor como "usuário removido".
// Corpo: { org_id, usuario_id }
import { admin, chamador, cors, exigirAdmin, json } from '../_shared/comum.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors(req) });
  if (req.method !== 'POST') return json(req, { erro: 'Método não permitido' }, 405);
  try {
    const { userId } = await chamador(req);
    if (!userId) return json(req, { erro: 'Não autenticado' }, 401);
    const b = await req.json();
    if (!b.org_id || !b.usuario_id) return json(req, { erro: 'Dados incompletos' }, 400);
    if (b.usuario_id === userId) return json(req, { erro: 'Você não pode excluir o próprio usuário' }, 400);

    const adm = await admin();
    if (!(await exigirAdmin(adm, userId, b.org_id))) return json(req, { erro: 'Somente administradores excluem usuários' }, 403);

    const { data: alvo } = await adm.from('membros').select('papel, nome').eq('org_id', b.org_id).eq('usuario_id', b.usuario_id).maybeSingle();
    if (!alvo) return json(req, { erro: 'Usuário não pertence à organização' }, 404);
    if (alvo.papel === 'owner') return json(req, { erro: 'O owner não pode ser excluído' }, 400);

    const { error } = await adm.auth.admin.deleteUser(b.usuario_id);
    if (error) return json(req, { erro: error.message }, 400);
    await adm.from('logs').insert({ org_id: b.org_id, usuario_id: userId, acao: 'usuario_excluido', detalhe: { nome: alvo.nome } });
    return json(req, { ok: true });
  } catch (e) {
    return json(req, { erro: e instanceof Error ? e.message : 'Erro inesperado' }, 500);
  }
});
