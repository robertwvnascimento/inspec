/* Inspec — UI: toast, diálogos, componentes, busca, calendário de período */
import { A } from './ns.js';
import { Store, Regras } from './dados.js';
import { ico, esc, Util, Periodo, fmtDia, diaDe, MESES, PAPEIS } from './util.js';

export const UI = {
  toast(msg, ms = 3200) { const t = document.getElementById('toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(this._t); this._t = setTimeout(() => t.classList.remove('on'), ms); },
  dialogo({ titulo, corpo, rodape = '', largo = false, aoAbrir }) {
    const d = document.getElementById('dlg');
    d.className = largo ? 'wide' : '';
    d.innerHTML = `${titulo ? `<div class="dlg-h"><h2 id="dlg-title">${titulo}</h2><button class="iconbtn" data-action="fechar-dlg" aria-label="Fechar">${ico('x')}</button></div>` : ''}<div class="dlg-b">${corpo}</div>${rodape ? `<div class="dlg-f">${rodape}</div>` : ''}`;
    if (!d.open) d.showModal();
    aoAbrir && aoAbrir(d);
    return d;
  },
  fechar() { const d = document.getElementById('dlg'); if (d.open) d.close(); },
  confirmar({ titulo, texto, ok = 'Confirmar', perigo = false, campo = null }) {
    return new Promise(res => {
      UI.dialogo({ titulo, corpo: `<p style="margin:0">${texto}</p>${campo ? `<label class="field" style="margin-top:12px"><span>${esc(campo.rotulo)}</span><input class="input" id="dlg-campo" maxlength="${campo.max || 200}" value="${esc(campo.valor || '')}"></label>` : ''}<div class="err" id="dlg-err" role="alert"></div>`,
        rodape: `<button class="btn btn-sec" data-action="fechar-dlg">Cancelar</button><button class="btn ${perigo ? 'btn-danger' : 'btn-pri'}" id="dlg-ok">${ok}</button>` });
      const d = document.getElementById('dlg'); let feito = false;
      document.getElementById('dlg-ok').onclick = () => {
        const v = campo ? document.getElementById('dlg-campo').value.trim() : true;
        if (campo && v.length < (campo.min || 0)) { document.getElementById('dlg-err').textContent = `Informe ${campo.rotulo.toLowerCase()} (mín. ${campo.min} caracteres).`; return; }
        feito = true; res(v); UI.fechar();
      };
      d.addEventListener('close', () => { if (!feito) res(false); }, { once: true });
    });
  },
  /** botão em estado "aguarde" durante uma operação assíncrona */
  async ocupado(btn, fn) {
    const html = btn?.innerHTML; if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spin" aria-hidden="true"></span>Aguarde…'; }
    try { return await fn(); } finally { if (btn && btn.isConnected) { btn.disabled = false; btn.innerHTML = html; } }
  },
  tip(el, ev) {
    const t = document.getElementById('tip'); if (!el) { t.style.display = 'none'; return; }
    t.innerHTML = el.dataset.tip; t.style.display = 'block';
    const x = Math.min(ev.clientX + 14, innerWidth - t.offsetWidth - 8), y = Math.max(8, ev.clientY - t.offsetHeight - 12);
    t.style.left = x + 'px'; t.style.top = y + 'px';
  }
};

export const Comp = {
  tagSituacao(e, s = Regras.situacao(e)) {
    if (!e.ativo) return '<span class="tag t-off">Inativo</span>';
    const fila = s.noCiclo.some(i => i.sync === 'fila') ? '<span class="tag t-fila">Na fila</span>' : '';
    if (s.pendente) return s.perdido ? '<span class="tag t-lost">Ciclo perdido</span>' : s.vence ? '<span class="tag t-warn">Vence em breve</span>' : '<span class="tag t-pend">Pendente</span>';
    return (s.statusCiclo === 'nc' ? '<span class="tag t-nc">Não conforme</span>' : '<span class="tag t-ok">Inspecionado</span>') + fila;
  },
  tagN2(e) { const n = e.cat === 'extintor' && Regras.n2(e); return !n ? '' : n.st === 'vencida' ? `<span class="tag t-nc">N2 vencida ${n.rot}</span>` : n.st === 'mes' ? `<span class="tag t-warn">N2 vence ${n.rot}</span>` : ''; },
  linhaEq(e, { termos = [], href } = {}) {
    const g = Store.ger(e.ger), d = Util.destacar;
    const alvo = href || (Regras.pode('inspecionar') && e.ativo ? `#/inspecao/${e.id}` : `#/ponto/${e.id}`);
    return `<a class="row" href="${alvo}">
      <span class="ic">${ico(Store.cat(e.cat).icone)}</span>
      <span class="body">
        <span class="l1"><span class="code">${d(e.codigo, termos)}</span>${Comp.tagSituacao(e)}${Comp.tagN2(e)}</span>
        <span class="l2">${d(e.subtipo || Store.cat(e.cat).nome, termos)}${e.fab ? ' · cil. ' + d(e.fab, termos) : ''}${e.resp ? ' · ' + d(Store.usuario(e.resp).nome.split(' ')[0], termos) : ''}</span>
        <span class="l3">${d(g.sigla, termos)} › ${d(e.local || e.area, termos)}</span>
      </span><span class="chev">${ico('chev')}</span></a>`;
  },
  vazio(icone, titulo, texto) { return `<div class="empty">${ico(icone)}<b>${titulo}</b>${texto}</div>`; },
  selectGerencia(id, valor, rotuloTodas = 'Todas as gerências') {
    return `<label class="sr" for="${id}">Gerência</label><select class="select" id="${id}" data-input="${id}"><option value="">${rotuloTodas}</option>${Store.S.gers.map(g => `<option value="${g.id}" ${g.id === valor ? 'selected' : ''}>${esc(g.nome)}</option>`).join('')}</select>`;
  },
  selectCategoria(id, valor, rotulo = 'Todas as categorias') {
    return `<label class="sr" for="${id}">Categoria</label><select class="select" id="${id}" data-input="${id}"><option value="">${rotulo}</option>${Store.categorias().map(c => `<option value="${c.chave}" ${c.chave === valor ? 'selected' : ''}>${esc(c.plural)}</option>`).join('')}</select>`;
  },
  papel: p => PAPEIS[p] || p,
  kpi: (l, v, s = '', cor = '') => `<div class="kpi"><div class="l">${l}</div><div class="v" ${cor ? `style="color:${cor}"` : ''}>${v}</div>${s ? `<div class="s">${s}</div>` : ''}</div>`
};

export const Busca = {
  termos: q => Util.norm(q).split(/\s+/).filter(Boolean),
  executar({ q, cats = [], ger = '', soPend = false, inativos = false }) {
    const termos = Busca.termos(q), res = [];
    for (const e of Store.S.pontos) {
      if (!inativos && !e.ativo) continue;
      if (cats.length && !cats.includes(e.cat)) continue;
      if (ger && e.ger !== ger) continue;
      const hay = Util.norm(Regras.textoBusca(e));
      if (!termos.every(t => hay.includes(t))) continue;
      const s = soPend ? Regras.situacao(e) : null;
      if (soPend && !s.pendente) continue;
      const cod = Util.norm(e.codigo); let score = 0;
      for (const t of termos) { if (cod === t) score += 100; else if (cod.startsWith(t)) score += 40; else if (cod.includes(t)) score += 20; else if (Util.norm(e.area).includes(t)) score += 8; else score += 3; }
      res.push({ e, score });
    }
    res.sort((a, b) => b.score - a.score || a.e.codigo.localeCompare(b.e.codigo, 'pt', { numeric: true }));
    return { termos, res };
  }
};

/* ---------------- calendário de período (um dia ou intervalo) ---------------- */
export const Cal = {
  alvos: {}, st: null,
  botao(id, per, set, rotulo = 'Período') { Cal.alvos[id] = { per: { de: per.de || '', ate: per.ate || '' }, set }; return `<div class="calwrap"><span class="lb">${rotulo}</span><button type="button" class="calbtn" data-action="cal-open" data-id="${id}" aria-haspopup="dialog">${ico('calendar')}<span>${esc(Periodo.rot(per))}</span>${ico('chevdown')}</button></div>`; },
  abrir(el) {
    const a = Cal.alvos[el.dataset.id]; if (!a) return;
    const base = a.per.ate || a.per.de || Periodo.hoje();
    Cal.st = { id: el.dataset.id, de: a.per.de, ate: a.per.ate, view: base.slice(0, 7), anc: el };
    Cal.render(); document.getElementById('calpop').classList.add('on'); Cal.posicionar();
  },
  posicionar() {
    const st = Cal.st, p = document.getElementById('calpop'); if (!st || innerWidth <= 620) return;
    const el = document.querySelector(`[data-action="cal-open"][data-id="${st.id}"]`) || st.anc, r = el.getBoundingClientRect(), w = p.offsetWidth, h = p.offsetHeight;
    p.style.left = Math.max(8, Math.min(r.left, innerWidth - w - 8)) + 'px';
    p.style.top = Math.max(8, Math.min(r.bottom + h + 8 < innerHeight ? r.bottom + 6 : r.top - h - 6, innerHeight - h - 8)) + 'px';
  },
  fechar() { const p = document.getElementById('calpop'); p.classList.remove('on'); Cal.st = null; },
  render() {
    const st = Cal.st, [a, m] = st.view.split('-').map(Number), prim = new Date(a, m - 1, 1), hoje = Periodo.hoje();
    const ini = new Date(a, m - 1, 1 - ((prim.getDay() + 6) % 7)), cells = [];
    for (let k = 0; k < 42; k++) {
      const d = new Date(ini.getFullYear(), ini.getMonth(), ini.getDate() + k), ds = diaDe(d);
      const cls = [d.getMonth() !== m - 1 ? 'fora' : '', ds === hoje ? 'hoje' : '', st.de && (ds === st.de || ds === st.ate) ? 'ponta' : '', st.de && st.ate && ds > st.de && ds < st.ate ? 'meio' : ''].join(' ');
      cells.push(`<button type="button" class="${cls}" data-action="cal-dia" data-d="${ds}" ${ds > hoje ? 'disabled' : ''} aria-label="${fmtDia(ds)}">${d.getDate()}</button>`);
    }
    const sel = !st.de ? 'Toque no dia inicial (ou num dia só) e depois no dia final.' : !st.ate ? `Início <b>${fmtDia(st.de)}</b> — toque no dia final ou aplique para ver <b>só este dia</b>.` : `<b>${esc(Periodo.rot(st))}</b> · ${Periodo.dias(st).length} dia(s)`;
    document.getElementById('calpop').innerHTML = `<div class="cal-pre">${Periodo.presets().map(([n, de, ate]) => `<button type="button" data-action="cal-pre" data-de="${de}" data-ate="${ate}" aria-pressed="${st.de === de && (st.ate || st.de) === ate}">${n}</button>`).join('')}</div>
      <div class="cal-main"><div class="cal-nav"><button type="button" class="iconbtn" data-action="cal-mes" data-d="-1" aria-label="Mês anterior">${ico('back')}</button><b>${MESES[m - 1]} ${a}</b><button type="button" class="iconbtn" data-action="cal-mes" data-d="1" aria-label="Próximo mês" ${st.view >= hoje.slice(0, 7) ? 'disabled' : ''}>${ico('chev')}</button></div>
      <div class="cal-grid">${['seg', 'ter', 'qua', 'qui', 'sex', 'sáb', 'dom'].map(x => `<span class="dw">${x}</span>`).join('')}${cells.join('')}</div>
      <p class="cal-sel">${sel}</p><div class="cal-f"><button type="button" class="btn btn-sec btn-sm" data-action="cal-fechar">Cancelar</button><button type="button" class="btn btn-sec btn-sm" data-action="cal-limpar">Todo o período</button><button type="button" class="btn btn-pri btn-sm" data-action="cal-aplicar">Aplicar</button></div></div>`;
  },
  aplicar(de, ate) { const a = Cal.alvos[Cal.st.id]; Cal.fechar(); a.per = { de, ate }; a.set(de, ate); }
};
Object.assign(A.Acoes, {
  'fechar-dlg': () => UI.fechar(),
  'cal-open': el => Cal.st && Cal.st.id === el.dataset.id ? Cal.fechar() : Cal.abrir(el),
  'cal-fechar': () => Cal.fechar(),
  'cal-dia': el => { const st = Cal.st, d = el.dataset.d; if (!st.de || st.ate) { st.de = d; st.ate = ''; } else if (d < st.de) { st.ate = st.de; st.de = d; } else st.ate = d; Cal.render(); },
  'cal-pre': el => Cal.aplicar(el.dataset.de, el.dataset.ate),
  'cal-mes': el => { const st = Cal.st, [a, m] = st.view.split('-').map(Number), d = new Date(a, m - 1 + Number(el.dataset.d), 1); st.view = `${d.getFullYear()}-${Util.pad(d.getMonth() + 1)}`; Cal.render(); },
  'cal-limpar': () => Cal.aplicar('', ''),
  'cal-aplicar': () => { const st = Cal.st; Cal.aplicar(st.de, st.ate || st.de); }
});
