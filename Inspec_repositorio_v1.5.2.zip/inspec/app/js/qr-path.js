/* QR lido pela câmera comum: https://dominio/Q/ABCD2345 → /#/q/ABCD2345 (antes de carregar o app) */
(function () { var m = location.pathname.match(/^\/q\/([0-9A-Za-z-]{8,9})\/?$/i); if (m) location.replace('/#/q/' + m[1].toUpperCase()); })();
