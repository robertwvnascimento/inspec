/* Inspec — abre um documento imprimível numa nova aba (relatórios, etiquetas, One Page)
   Sem scripts inline (CSP): os botões são ligados a partir desta janela. */
import { UI } from './ui.js';
import { esc } from './util.js';
import { evento } from './db.js';

export function abrirDocumento(titulo, css, corpo, { excel, aoImprimir, botoes = [] } = {}) {
  const w = window.open('', '_blank');
  if (!w) { UI.toast('Permita pop-ups deste site para abrir o documento.'); return null; }
  w.document.open();
  w.document.write(`<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(titulo)}</title>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600;700&family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>${css}
    .bar{position:sticky;top:0;z-index:5;background:#0A2F57;color:#fff;display:flex;gap:8px;align-items:center;padding:10px 16px;font:13px Inter,Arial,sans-serif}.bar b{flex:1}.bar button{background:#fff;color:#0A2F57;border:0;border-radius:8px;padding:8px 14px;font-weight:700;cursor:pointer}.bar button.alt{background:rgba(255,255,255,.14);color:#fff}
    @media print{.bar{display:none}}</style></head><body>
    <div class="bar"><b>${esc(titulo)}</b>${botoes.map((b, i) => `<button class="alt" id="b-x${i}">${esc(b.rotulo)}</button>`).join('')}${excel ? '<button class="alt" id="b-xlsx">Baixar Excel</button>' : ''}<button id="b-imp">Imprimir / salvar PDF</button><button class="alt" id="b-fechar">Fechar</button></div>${corpo}</body></html>`);
  w.document.close();
  w.document.getElementById('b-imp').addEventListener('click', () => { aoImprimir?.(); evento('app.impressao', { rotulo: titulo }); w.print(); });
  evento(/^Etiquetas/.test(titulo) ? 'app.etiquetas' : 'app.relatorio', { rotulo: titulo });
  w.document.getElementById('b-fechar').addEventListener('click', () => w.close());
  if (excel) w.document.getElementById('b-xlsx').addEventListener('click', excel);
  botoes.forEach((b, i) => w.document.getElementById('b-x' + i).addEventListener('click', b.acao));
  return w;
}
