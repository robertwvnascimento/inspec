/* =====================================================================
   Inspec — núcleo: autenticação, casca, roteador, eventos, sincronização
   ===================================================================== */
import { A } from './ns.js';
import { sb, rpc, msgErro, ehRede, configurado, evento } from './db.js';
import { Store, Fila, Regras, IDB } from './dados.js';
import { UI, Cal } from './ui.js';
import { ico, esc, Util, LOGO, SYM, PAPEIS } from './util.js';
import { Scan } from './qr.js';
import './views/inicio.js';
import './views/buscar.js';
import './views/inspecao.js';
import './views/ponto.js';
import './views/ncs.js';
import './views/desvios.js';
import './views/historico.js';
import './views/painel.js';
import './views/relatorios.js';
import './views/admin.js';
import './views/menu.js';
import './views/auditoria.js';
import './views/galeria.js';

import { VERSAO } from './versoes.js';
import { PWA } from './pwa.js';
import './views/sobre.js';
export { VERSAO };
A.VERSAO = VERSAO;
const V = A.V;

/* ---------------- telas fora da casca ---------------- */
const telaCentral = (corpo) => `<main class="login"><div class="login-card"><img class="logo" src="${LOGO}" alt="Inspec — Gestão inteligente de inspeções">${corpo}</div></main>`;
V.carregando = (msg = 'Carregando…') => telaCentral(`<p class="lead" style="text-align:center"><span class="spin" aria-hidden="true"></span>${esc(msg)}</p>`);
V.login = (aviso = '') => telaCentral(`
  ${aviso ? `<div class="notice n-amber" style="margin-bottom:12px">${ico('info')}<div>${aviso}</div></div>` : ''}
  <p class="lead">Acesse com o e-mail e a senha fornecidos pelo administrador.</p>
  <form id="form-login" novalidate>
    <label class="field"><span>E-mail</span><input class="input" type="email" id="lg-email" autocomplete="username" inputmode="email" required></label>
    <label class="field"><span>Senha</span><input class="input" type="password" id="lg-senha" autocomplete="current-password" required></label>
    <div class="err" id="lg-err" role="alert"></div>
    <button class="btn btn-pri btn-block" type="submit" id="lg-btn">Entrar</button>
  </form>
  <div style="text-align:center;margin-top:6px"><button class="linkbtn" type="button" data-action="esqueci">Esqueci minha senha</button></div>
  ${A.PWA && A.PWA.podeInstalar() ? `<div style="text-align:center;margin-top:14px"><button class="btn btn-sec btn-sm" type="button" data-action="pwa-instalar">${ico('download')}Instalar o Inspec no aparelho</button></div>` : ''}
  ${configurado() ? '' : `<div class="notice n-red" style="margin-top:14px">${ico('alert')}<div><b>Configuração pendente.</b> Edite <code>config.js</code> com a Project URL e a Publishable key do Supabase.</div></div>`}`);
V.novaSenha = (primeiro) => telaCentral(`
  <p class="lead">${primeiro ? `Olá, <b>${esc((Store.S?.eu?.nome || '').split(' ')[0])}</b>. Este é o seu primeiro acesso: defina uma senha só sua para continuar.` : 'Defina sua nova senha de acesso.'}</p>
  <form id="form-senha" novalidate>
    <label class="field"><span>Nova senha</span><input class="input" type="password" id="ts-1" autocomplete="new-password" minlength="8" required></label>
    <label class="field"><span>Confirmar a nova senha</span><input class="input" type="password" id="ts-2" autocomplete="new-password" minlength="8" required></label>
    <p class="hint" style="margin:0 0 6px">Mínimo de 8 caracteres, com letras e números.</p>
    <div class="err" id="ts-err" role="alert"></div>
    <button class="btn btn-pri btn-block" type="submit" id="ts-btn">Confirmar e entrar</button>
  </form>
  <div style="text-align:center;margin-top:6px"><button class="linkbtn" type="button" data-action="sair">Voltar ao login</button></div>`);
V.bootstrap = (email) => telaCentral(`
  <p class="lead"><b>Primeiro acesso do administrador.</b> O e-mail <b>${esc(email)}</b> foi autorizado a criar a organização. Preencha os dados abaixo (você poderá alterar depois).</p>
  <form id="form-org" novalidate>
    <label class="field"><span>Nome da organização</span><input class="input" id="og-nome" maxlength="120" placeholder="Ex.: Bombeiros Civis SESI — ArcelorMittal" required></label>
    <label class="field"><span>Unidade (planta/site)</span><input class="input" id="og-unid" maxlength="120" placeholder="Ex.: Juiz de Fora" required></label>
    <label class="field"><span>Seu nome</span><input class="input" id="og-eu" maxlength="80" required></label>
    <div class="err" id="og-err" role="alert"></div>
    <button class="btn btn-pri btn-block" type="submit" id="og-btn">Criar organização</button>
  </form>
  <div style="text-align:center;margin-top:6px"><button class="linkbtn" type="button" data-action="sair">Sair</button></div>`);
V.semAcesso = (email) => telaCentral(`
  <div class="notice n-amber">${ico('alert')}<div><b>Usuário sem organização.</b> O login <b>${esc(email)}</b> existe, mas não está vinculado a nenhuma organização ativa. Peça ao administrador do Inspec para liberar o seu acesso.</div></div>
  <button class="btn btn-sec btn-block" style="margin-top:14px" data-action="sair">Sair</button>`);
V.erroCarga = (msg) => telaCentral(`
  <div class="notice n-red">${ico('alert')}<div><b>Não foi possível carregar os dados.</b><br>${esc(msg)}</div></div>
  <div class="chips" style="margin-top:14px;justify-content:center"><button class="btn btn-pri" data-action="recarregar">${ico('refresh')}Tentar novamente</button><button class="btn btn-sec" data-action="sair">Sair</button></div>`);

/* ---------------- casca ---------------- */
const NAV = [   // ordem da barra lateral (computador); `mob` = ordem da barra inferior (celular)
  { id: 'inicio', rota: '#/inicio', nome: 'Início', icone: 'home', mob: 1 },
  { id: 'nova', rota: '#/nova', nome: 'Inspecionar', nomeLongo: 'Nova inspeção', icone: 'clipboard', perm: 'inspecionar', mob: 2 },
  { id: 'historico', rota: '#/historico', nome: 'Inspeções', icone: 'history', soDesktop: true },
  { id: 'ncs', rota: '#/ncs', nome: 'NCs', nomeLongo: 'Não conformidades', icone: 'alert', mob: 4 },
  { id: 'desvio', rota: '#/desvio/novo', nome: 'Desvio', nomeLongo: 'Novo comunicado de desvio', icone: 'headset', perm: 'inspecionar', mob: 3 },
  { id: 'desvios', rota: '#/desvios', nome: 'Desvios', icone: 'flame', soDesktop: true, mobSem: 'inspecionar', mob: 3 },
  { id: 'buscar', rota: '#/buscar', nome: 'Buscar', icone: 'search', soDesktop: true },
  { id: 'relatorios', rota: '#/relatorios', nome: 'Relatórios', icone: 'file', soDesktop: true },
  { id: 'galeria', rota: '#/galeria', nome: 'Galeria de fotos', icone: 'camera', soDesktop: true, perm: 'verAdmin' },
  { id: 'admin', rota: '#/admin/pontos', nome: 'Administração', icone: 'admin', soDesktop: true, perm: 'verAdmin' },
  { id: 'menu', rota: '#/menu', nome: 'Menu', icone: 'menu', mob: 9 }
];
V.shell = () => {
  const eu = Store.S.eu;
  return `<div class="shell">
  <aside class="side" aria-label="Navegação principal">
    <img class="logo" src="${LOGO}" alt="Inspec">
    <nav id="side-nav"></nav>
    <div class="who"><b>${esc(eu.nome)}</b><span class="hint">${PAPEIS[eu.papel]} · ${esc(Store.S.unidade.nome)}</span></div>
  </aside>
  <div class="main"><header class="top" id="top"></header><main class="view" id="view" tabindex="-1"></main></div>
  <nav class="bottom" id="bottom-nav" aria-label="Navegação principal"></nav>
</div>`;
};
function renderNav(ativo) {
  const nNc = Regras.ncsAbertas().length, gestor = Regras.pode('gestor');
  const itens = NAV.filter(n => !n.perm || Regras.pode(n.perm)).map(n => n.id === 'inicio' && gestor ? { ...n, nome: 'Painel', nomeLongo: 'Painel de gestão', icone: 'grid' } : n);
  const link = (n, longo) => `<a href="${n.rota}" ${ativo === n.id ? 'aria-current="page"' : ''}>${ico(n.icone)}<span>${longo ? (n.nomeLongo || n.nome) : n.nome}</span>${n.id === 'ncs' && nNc ? `<span class="badge-n" aria-label="${nNc} abertas">${nNc}</span>` : ''}</a>`;
  document.getElementById('side-nav').innerHTML = itens.map(n => (n.id === 'menu' ? '<div class="sep"></div>' : '') + link(n, true)).join('');
  const mob = itens.filter(n => !n.soDesktop || (n.mobSem && !Regras.pode(n.mobSem))).sort((a, b) => (a.mob || 5) - (b.mob || 5));
  const bn = document.getElementById('bottom-nav'); bn.style.gridTemplateColumns = `repeat(${mob.length},1fr)`; bn.innerHTML = mob.map(n => link(n, false)).join('');
}
function renderTop({ titulo, voltar }) {
  const fila = Fila.pendentes().length, erros = Fila.comErro().length, off = !navigator.onLine;
  const pill = off ? `<a class="pill pill-off" href="#/menu" title="Sem conexão"><span class="d"></span>Offline${fila ? ' · ' + fila + ' na fila' : ''}</a>`
    : Fila.enviando ? `<span class="pill pill-sync"><span class="d"></span>Enviando…</span>`
    : erros ? `<a class="pill pill-off" href="#/menu" title="Itens com erro de envio"><span class="d"></span>${erros} com erro</a>`
    : fila ? `<a class="pill pill-sync" href="#/menu"><span class="d"></span>${fila} na fila</a>` : `<span class="pill pill-on"><span class="d"></span>Online</span>`;
  document.getElementById('top').innerHTML = `
    ${voltar ? `<button class="iconbtn" data-action="voltar" data-href="${voltar}" aria-label="Voltar">${ico('back')}</button>` : `<a class="brand" href="#/inicio" aria-label="Início"><img src="${SYM}" alt=""><b>Inspec</b></a>`}
    <div class="title">${voltar || innerWidth >= 960 ? esc(titulo) : ''}</div>
    <button class="iconbtn" data-action="scan-abrir" aria-label="Ler QR Code" title="Ler QR Code">${ico('scan')}</button>
    <a class="iconbtn" href="#/buscar" aria-label="Buscar ponto">${ico('search')}</a>
    ${pill}
    <a class="avatar" href="#/menu" aria-label="Menu e perfil" style="text-decoration:none">${esc(Util.iniciais(Store.S.eu.nome))}</a>`;
}

/* ---------------- roteador ---------------- */
export const Router = {
  modo: 'boot', _shell: false,
  parse() {
    const h = location.hash.replace(/^#\/?/, '') || 'inicio';
    const [caminho, qs] = h.split('?'); const [rota, param] = caminho.split('/');
    return { rota, param, q: new URLSearchParams(qs || '') };
  },
  tela(html) { this._shell = false; document.getElementById('root').innerHTML = html; },
  render(forcar) {
    if (this.modo !== 'app') return;
    const root = document.getElementById('root');
    let { rota, param, q } = this.parse();
    if (!this._shell || forcar) { root.innerHTML = V.shell(); this._shell = true; }
    const view = document.getElementById('view'), gestor = Regras.pode('gestor');
    view.className = 'view' + (['relatorios', 'admin', 'historico', 'ncs', 'desvios', 'painel'].includes(rota) ? ' wide' : '');
    let html = '', titulo = '', voltar = null, ativo = rota;
    try {
      switch (rota) {
        case 'inicio': if (gestor) { html = V.painel(q); titulo = 'Painel de gestão'; view.className = 'view wide'; } else { html = V.inicio(); titulo = 'Início'; } break;
        case 'painel': html = V.painel(q); titulo = 'Painel de gestão'; ativo = 'inicio'; break;
        case 'pendencias': html = V.inicio(); titulo = 'Pendências do ciclo'; ativo = 'inicio'; break;
        case 'lista': html = V.lista(param, q); titulo = Store.cat(param).plural; voltar = '#/pendencias'; ativo = 'inicio'; break;
        case 'buscar': html = V.buscar(q); titulo = 'Buscar ponto'; break;
        case 'q': Scan.deepLink(param); return;
        case 'nova': html = V.nova(q); titulo = 'Nova inspeção'; if (q.get('ger')) voltar = q.get('cat') ? `#/nova?ger=${q.get('ger')}` : '#/nova'; break;
        case 'inspecao': { const e = Store.eq(param); html = V.inspecao(param, q); titulo = 'Registrar inspeção'; voltar = q.get('de') === 'lista' && e ? `#/nova?ger=${e.ger}&cat=${e.cat}` : '#/buscar'; ativo = q.get('de') === 'lista' ? 'nova' : 'buscar'; break; }
        case 'ponto': html = V.ponto(param); titulo = 'Ficha do ponto'; voltar = '#/buscar'; ativo = 'buscar'; break;
        case 'ncs': html = V.ncs(q); titulo = 'Não conformidades'; break;
        case 'desvios': html = V.desvios(q); titulo = 'Comunicados de desvio'; break;
        case 'desvio': if (param === 'novo') { html = V.desvioNovo(q); titulo = 'Novo comunicado de desvio'; ativo = 'desvio'; } else { const d = Store.idx.desvio.get(param); html = V.desvioDet(param, q); titulo = d?.numero || 'Comunicado de desvio'; voltar = '#/desvios'; ativo = 'desvios'; } break;
        case 'historico': html = V.historico(q); titulo = 'Inspeções'; break;
        case 'relatorios': html = V.relatorios(q); titulo = 'Relatórios'; voltar = innerWidth < 960 ? '#/menu' : null; break;
        case 'admin': html = V.admin(param || 'pontos', q); titulo = 'Administração'; voltar = innerWidth < 960 ? '#/menu' : null; break;
        case 'menu': html = V.menu(); titulo = 'Menu'; break;
        case 'galeria': html = V.galeria(); titulo = 'Galeria de fotos'; view.className = 'view wide'; voltar = innerWidth < 960 ? '#/menu' : null; break;
        case 'sobre': html = V.sobre(); titulo = 'Sobre o sistema'; voltar = '#/menu'; ativo = 'menu'; break;
        default: html = V.naoEncontrado(); titulo = 'Inspec';
      }
    } catch (e) { console.error(e); html = `<div class="notice n-red">${ico('alert')}<div><b>Erro ao montar a tela.</b> ${esc(e.message)}</div></div>`; }
    if (html === '') return;
    view.innerHTML = html;
    renderNav(ativo); renderTop({ titulo, voltar });
    this._titulo = titulo; this._voltar = voltar;
    document.title = `Inspec — ${titulo || 'Início'}`;
    A.depoisRender?.forEach(f => f(rota, param));
  },
  chrome() { if (this.modo === 'app' && this._shell) { const { rota } = this.parse(); renderNav(rota === 'inicio' ? 'inicio' : rota); renderTop({ titulo: this._titulo, voltar: this._voltar }); } }
};
A.Router = Router;
A.render = (f) => Router.render(f);
V.naoEncontrado = () => `<div class="empty">${ico('info')}<b>Página não encontrada</b><a href="#/inicio">Voltar ao início</a></div>`;

/* ---------------- autenticação e início ---------------- */
export const Auth = {
  async iniciar() {
    Router.modo = 'boot'; Router.tela(V.carregando());
    if (!configurado()) { Router.modo = 'login'; Router.tela(V.login()); return; }
    const recuperacao = /type=recovery/.test(location.hash);
    const { data: { session } } = await sb.auth.getSession();
    if (!session) { Router.modo = 'login'; Router.tela(V.login()); return; }
    if (recuperacao) { Store.sessao = session; history.replaceState(null, '', '#/'); Router.modo = 'senha'; Router.tela(V.novaSenha(false)); return; }
    Store.sessao = session;
    await this.entrarComSessao(session.user);
  },
  async entrarComSessao(user) {
    Router.tela(V.carregando('Carregando seus dados…'));
    let eu;
    try { eu = await Store.perfil(user); }
    catch (e) {
      if (ehRede(e) && await Store.lerCache(user.id)) { this.abrirApp(); UI.toast('Sem conexão: usando os dados salvos no aparelho.'); return; }
      Router.modo = 'erro'; Router.tela(V.erroCarga(msgErro(e))); return;
    }
    if (!eu) {
      let convite = false; try { convite = await rpc('meu_convite'); } catch (e) { /* sem convite */ }
      Router.modo = 'bootstrap'; Router.tela(convite ? V.bootstrap(user.email) : V.semAcesso(user.email)); return;
    }
    Store.S = Store.S && Store.S.eu?.id === eu.id ? Store.S : Store.vazio();
    Store.S.eu = eu;
    if (eu.trocar) { Router.modo = 'senha'; Router.tela(V.novaSenha(true)); return; }
    try {
      const temCache = await Store.lerCache(user.id);
      if (temCache) { Store.S.eu = eu; this.abrirApp(); Sync.recarregar(true); return; }
      let unid; try { unid = localStorage.getItem('inspec-unidade'); } catch (e) { /* armazenamento indisponível */ }
      await Store.carregar(eu, unid);
      this.abrirApp();
    } catch (e) {
      console.error(e);
      if (ehRede(e) && await Store.lerCache(user.id)) { this.abrirApp(); return; }
      Router.modo = 'erro'; Router.tela(V.erroCarga(msgErro(e)));
    }
  },
  abrirApp() {
    Router.modo = 'app'; Router._shell = false;
    document.body.classList.toggle('ro', Regras.pode('leitura'));
    if (Inatividade.aoAbrir()) return;
    try { if (!sessionStorage.getItem('inspec-sessao-log')) { sessionStorage.setItem('inspec-sessao-log', '1'); evento('acesso.sessao'); } } catch (e) { /* ignore */ }
    if (!location.hash || location.hash === '#/' || location.hash === '#/login') history.replaceState(null, '', '#/inicio');
    Router.render(true);
    Sync.agendar();
    const pend = sessionStorage.getItem('inspec-qr'); if (pend) { sessionStorage.removeItem('inspec-qr'); Scan.deepLink(pend); }
  },
  async sair({ inatividade = false } = {}) {
    if (!inatividade && Fila.cache.length && !confirm(`Há ${Fila.cache.length} registro(s) ainda não enviados neste aparelho. Ao sair, eles serão perdidos. Sair mesmo assim?`)) return;
    Inatividade.parar();
    if (inatividade && navigator.onLine) { try { await Fila.processar(); } catch (e) { /* segue */ } }
    await evento(inatividade ? 'acesso.inatividade' : 'acesso.logout');
    try { await sb.auth.signOut(); } catch (e) { /* offline: limpa localmente */ }
    await Fila.itens();
    // por inatividade, registros ainda não enviados ficam guardados (só o próprio usuário os envia ao entrar de novo)
    if (inatividade && Fila.cache.length) await IDB.del('retrato').catch(() => {}); else await IDB.limpar().catch(() => {});
    try { localStorage.removeItem('inspec-auth'); sessionStorage.removeItem('inspec-sessao-log'); } catch (e) { /* ignore */ }
    Store.S = null; Store.sessao = null; Router.modo = 'login';
    Router.tela(V.login(inatividade ? `<b>Sessão encerrada por inatividade.</b> Por segurança, o Inspec desconecta após 5 minutos sem uso.${Fila.cache.length ? ` ${Fila.cache.length === 1 ? '1 registro ainda não enviado ficou guardado e será enviado' : `${Fila.cache.length} registros ainda não enviados ficaram guardados e serão enviados`} quando você entrar de novo.` : ''}` : ''));
    history.replaceState(null, '', '#/login');
  }
};

/* ---------------- inatividade: quem não é Owner/Admin sai após 5 min sem uso ---------------- */
const LIMITE_INATIVO = 5 * 60e3, AVISO_ANTES = 30e3, CHAVE_ATIVO = 'inspec-ativo';
export const Inatividade = {
  _t: null, _mem: 0, _grav: 0, avisando: false, loginNovo: false,
  aplica() { return Router.modo === 'app' && !!Store.S?.eu && !Regras.pode('admin'); },
  ultima() { let v = 0; try { v = +localStorage.getItem(CHAVE_ATIVO) || 0; } catch (e) { /* ignore */ } return Math.max(v, this._mem); },
  marcar(forcar = false) {
    const agora = Date.now(); this._mem = agora;
    if (forcar || agora - this._grav > 5000) { this._grav = agora; try { localStorage.setItem(CHAVE_ATIVO, String(agora)); } catch (e) { /* ignore */ } }
    if (this.avisando) this.fecharAviso();
  },
  /** chamado ao abrir o app; devolve true se a sessão foi encerrada */
  aoAbrir() {
    if (!this.aplica()) { this.parar(); return false; }
    const u = this.ultima();
    if (!this.loginNovo && u && Date.now() - u >= LIMITE_INATIVO) { this.encerrar(); return true; }
    this.loginNovo = false; this.marcar(true);
    clearInterval(this._t); this._t = setInterval(() => this.verificar(), 5000);
    return false;
  },
  parar() { clearInterval(this._t); this._t = null; this.fecharAviso(); },
  verificar() {
    if (!this.aplica()) return;
    const ocioso = Date.now() - this.ultima();
    if (ocioso >= LIMITE_INATIVO) return this.encerrar();
    if (ocioso >= LIMITE_INATIVO - AVISO_ANTES) this.aviso(Math.max(1, Math.ceil((LIMITE_INATIVO - ocioso) / 1000)));
    else if (this.avisando) this.fecharAviso();
  },
  aviso(seg) {
    let el = document.getElementById('aviso-inativo');
    if (!el) {
      el = document.createElement('div'); el.id = 'aviso-inativo'; el.className = 'aviso-inativo'; el.setAttribute('role', 'alertdialog');
      el.innerHTML = `${ico('clock')}<div><b>Você será desconectado por inatividade</b><span id="aviso-inativo-s"></span></div><button class="btn btn-pri btn-sm" data-action="inativo-continuar">Continuar conectado</button>`;
      document.body.appendChild(el);
    }
    this.avisando = true; document.getElementById('aviso-inativo-s').textContent = `em ${seg} segundo${seg > 1 ? 's' : ''}. Toque em qualquer lugar para continuar.`;
  },
  fecharAviso() { document.getElementById('aviso-inativo')?.remove(); this.avisando = false; },
  async encerrar() {
    this.parar();
    try { Scan.fechar(); } catch (e) { /* ignore */ }
    try { UI.fechar(); } catch (e) { /* ignore */ }
    await Auth.sair({ inatividade: true });
  }
};
A.Inatividade = Inatividade;
['pointerdown', 'keydown', 'wheel', 'touchstart', 'scroll', 'input'].forEach(t => window.addEventListener(t, () => { if (Inatividade._t) Inatividade.marcar(); }, { passive: true, capture: true }));

A.Envios['form-login'] = async () => {
  const email = document.getElementById('lg-email').value.trim(), senha = document.getElementById('lg-senha').value, err = document.getElementById('lg-err');
  if (!email || !senha) { err.textContent = 'Informe e-mail e senha.'; return; }
  err.textContent = '';
  await UI.ocupado(document.getElementById('lg-btn'), async () => {
    const { data, error } = await sb.auth.signInWithPassword({ email, password: senha });
    if (error) { err.textContent = msgErro(error); if (/Invalid login/i.test(error.message)) sb.rpc('registrar_falha_login', { p_email: email }).then(() => {}, () => {}); return; }
    Store.sessao = data.session; Inatividade.loginNovo = true;
    try { sessionStorage.setItem('inspec-sessao-log', '1'); } catch (e) { /* ignore */ }
    evento('acesso.login');
    await Auth.entrarComSessao(data.user);
  });
};
A.Envios['form-senha'] = async () => {
  const a = document.getElementById('ts-1').value, b = document.getElementById('ts-2').value, err = document.getElementById('ts-err');
  if (a.length < 8 || !/[A-Za-z]/.test(a) || !/\d/.test(a)) { err.textContent = 'A senha precisa ter ao menos 8 caracteres, com letras e números.'; return; }
  if (a !== b) { err.textContent = 'As senhas não são iguais.'; return; }
  await UI.ocupado(document.getElementById('ts-btn'), async () => {
    const { error } = await sb.auth.updateUser({ password: a });
    if (error) { err.textContent = /different from the old/i.test(error.message) ? 'A nova senha precisa ser diferente da atual.' : msgErro(error); return; }
    try { await rpc('senha_trocada'); } catch (e) { /* membro inexistente na recuperação */ }
    evento(Router.modo === 'senha' && Store.S?.eu?.trocar ? 'acesso.senha_definida' : 'acesso.senha_alterada', { motivo: Store.S?.eu?.trocar ? 'primeiro acesso' : 'recuperação ou troca' });
    UI.toast('Senha definida.');
    const { data: { user } } = await sb.auth.getUser();
    await Auth.entrarComSessao(user);
  });
};
A.Envios['form-org'] = async () => {
  const nome = document.getElementById('og-nome').value.trim(), unid = document.getElementById('og-unid').value.trim(), eu = document.getElementById('og-eu').value.trim(), err = document.getElementById('og-err');
  if (nome.length < 3 || unid.length < 2 || eu.length < 3) { err.textContent = 'Preencha os três campos.'; return; }
  await UI.ocupado(document.getElementById('og-btn'), async () => {
    try { await rpc('criar_organizacao', { p_nome: nome, p_unidade: unid, p_nome_owner: eu }); }
    catch (e) { err.textContent = msgErro(e); return; }
    const { data: { user } } = await sb.auth.getUser();
    await Auth.entrarComSessao(user);
    location.hash = '#/admin/importacao';
    UI.toast('Organização criada. Próximo passo: carga inicial dos pontos.', 5000);
  });
};

/* ---------------- sincronização ---------------- */
export const Sync = {
  _t: null,
  agendar() {
    clearInterval(this._t);
    this._t = setInterval(() => { if (document.visibilityState === 'visible') Sync.ciclo(); }, 120e3);
    this.ciclo();
  },
  async ciclo() {
    if (!navigator.onLine || Router.modo !== 'app') return;
    const r = await Fila.processar();
    if (r.enviados) { UI.toast(`${Util.plural(r.enviados, 'registro enviado', 'registros enviados')} ao servidor.`); await this.recarregar(true); }
    else if (Date.now() - (Store.ultimaCarga || 0) > 10 * 60e3) await this.recarregar(true);
  },
  async recarregar(silencioso) {
    if (!navigator.onLine || !Store.S?.eu) return;
    try { await Store.carregar(Store.S.eu, Store.S.unidade?.id); A.galeriaInvalidar?.(); if (!document.querySelector('#dlg[open]') && !A.tmp.editando && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName || '')) Router.render(); else Router.chrome(); }
    catch (e) { if (!silencioso) UI.toast(msgErro(e)); console.warn('recarga', e); }
  }
};
A.Sync = Sync;
Fila.ouvintes.add(() => Router.chrome());

/* ---------------- ações globais ---------------- */
Object.assign(A.Acoes, {
  'inativo-continuar': () => Inatividade.marcar(true),
  ir: el => { location.hash = el.dataset.href; },
  voltar: el => { if (history.length > 1 && A.tmp.veioDeDentro) history.back(); else location.hash = el.dataset.href; },
  sair: () => Auth.sair(),
  recarregar: () => Auth.iniciar(),
  atualizar: async el => { await UI.ocupado(el, async () => { await Fila.processar(); await Sync.recarregar(false); }); UI.toast('Dados atualizados.'); },
  esqueci: () => UI.dialogo({ titulo: 'Recuperar senha', corpo: `<p style="margin-top:0">Informe seu e-mail. Enviaremos um link para você definir uma nova senha.</p><label class="field"><span>E-mail</span><input class="input" type="email" id="rec-email" autocomplete="email" value="${esc(document.getElementById('lg-email')?.value || '')}"></label><p class="hint" id="rec-msg" role="status"></p>`, rodape: `<button class="btn btn-sec" data-action="fechar-dlg">Cancelar</button><button class="btn btn-pri" data-action="esqueci-enviar">Enviar link</button>` }),
  'esqueci-enviar': async el => {
    const email = document.getElementById('rec-email').value.trim(), m = document.getElementById('rec-msg');
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { m.textContent = 'Informe um e-mail válido.'; return; }
    await UI.ocupado(el, async () => {
      const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin + '/' });
      m.textContent = error ? msgErro(error) : 'Se o e-mail estiver cadastrado, o link chegará em alguns minutos. Confira também o spam.';
    });
  }
});

/* ---------------- perfis somente leitura ---------------- */
const ESCRITA = new Set(['pt-novo', 'pt-editar', 'pt-salvar', 'pt-inativar', 'pt-reativar', 'qr-regerar', 'user-novo', 'user-editar', 'user-salvar', 'user-del',
  'vinc-abrir', 'vinc-ok', 'ger-nova', 'ger-editar', 'ger-salvar', 'agt-novo', 'agt-editar', 'agt-salvar', 'agt-excluir', 'cat-nova', 'cat-editar', 'cat-salvar', 'cat-excluir',
  'res-mov', 'res-ok', 'dst-novo', 'dst-editar', 'dst-salvar', 'dst-del', 'imp-carga', 'imp-confirmar', 'cfg-foto', 'org-nome', 'unid-nova', 'anular', 'troca-abrir', 'troca-ok',
  'dv-regularizar', 'dv-reg-ok', 'dv-email', 'backup-json', 'zerar-abrir', 'zerar-ok']);
{ const st = document.createElement('style'); st.textContent = `body.ro :is(${[...ESCRITA].map(a => `[data-action="${a}"]`).join(',')}),body.ro label:has([data-change="imp-file"]){display:none!important}`; document.head.appendChild(st); }

/* ---------------- eventos globais ---------------- */
document.addEventListener('click', ev => {
  if (Cal.st && !ev.target.closest('#calpop') && !ev.target.closest('[data-action="cal-open"]')) Cal.fechar();
  if (ev.target.closest('#dlg a[href^="#/"]')) UI.fechar();
  const el = ev.target.closest('[data-action]'); if (!el) return;
  const fn = A.Acoes[el.dataset.action]; if (!fn) return;
  if (Router.modo === 'app' && Regras.pode('leitura') && ESCRITA.has(el.dataset.action)) { ev.preventDefault(); UI.toast('Seu perfil é somente leitura: não é possível alterar dados.'); return; }
  if (el.tagName !== 'A' && el.type !== 'checkbox') ev.preventDefault();
  Promise.resolve().then(() => fn(el, ev)).catch(e => { console.error(e); UI.toast(msgErro(e)); });
});
document.addEventListener('input', ev => { const k = ev.target.dataset?.input; if (k && A.Inputs[k]) A.Inputs[k](ev.target, ev); });
document.addEventListener('change', ev => { const k = ev.target.dataset?.change; if (k && A.Inputs[k]) A.Inputs[k](ev.target, ev); });
document.addEventListener('submit', ev => {
  const fn = A.Envios[ev.target.id]; if (!fn) return;
  ev.preventDefault(); Promise.resolve().then(() => fn(ev)).catch(e => { console.error(e); UI.toast(msgErro(e)); });
});
document.addEventListener('keydown', ev => {
  if (ev.key === 'Escape' && Cal.st) { Cal.fechar(); return; }
  if (ev.key === 'Escape' && Scan.st) { Scan.fechar(); return; }
  if (ev.key === 'Enter' && ev.target.id === 'busca') { ev.preventDefault(); const a = document.querySelector('#busca-res .row'); if (a) location.hash = a.getAttribute('href'); }
});
document.addEventListener('mousemove', ev => { const el = ev.target.closest('[data-tip]'); UI.tip(el, ev); });
window.addEventListener('hashchange', () => { A.tmp.veioDeDentro = true; if (Scan.st) Scan.fechar(); UI.fechar(); Cal.fechar(); Router.render(); window.scrollTo(0, 0); });
window.addEventListener('scroll', () => { if (Cal.st) Cal.posicionar(); }, { passive: true });
let larguraAnt = innerWidth;
window.addEventListener('resize', () => {
  if (innerWidth === larguraAnt) return;                       // teclado do celular abrindo/fechando muda só a altura
  larguraAnt = innerWidth;
  clearTimeout(Router._rz); Router._rz = setTimeout(() => { if (Router.modo === 'app' && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName || '')) Router.render(); }, 250);
});
window.addEventListener('online', () => { Router.chrome(); UI.toast('Conexão restabelecida. Enviando registros…'); Sync.ciclo(); });
window.addEventListener('offline', () => { Router.chrome(); UI.toast('Sem conexão: as inspeções ficam salvas no aparelho.'); });
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') { Inatividade.verificar(); Sync.ciclo(); } });
document.getElementById('scan-foto').addEventListener('change', ev => Scan.foto(ev.target.files[0]));

sb.auth.onAuthStateChange((evento, sessao) => {
  if (sessao) Store.sessao = sessao;
  if (evento === 'PASSWORD_RECOVERY') { Router.modo = 'senha'; Router.tela(V.novaSenha(false)); }
  if (evento === 'SIGNED_OUT' && Router.modo === 'app') { Store.sessao = null; Router.modo = 'login'; Router.tela(V.login()); }
});

/* ---------------- PWA: ver js/pwa.js ---------------- */

Auth.iniciar().catch(e => { console.error(e); Router.tela(V.erroCarga(msgErro(e))); });
