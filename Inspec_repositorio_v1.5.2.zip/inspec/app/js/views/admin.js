/* Inspec — Administração: pontos e etiquetas, alterações, equipe, gerências, reserva,
   destinatários, importação (carga inicial), configurações, backup e auditoria */
import { A } from '../ns.js';
import { Store, Regras } from '../dados.js';
import { sb, rpc, funcao, todos, msgErro, evento } from '../db.js';
import { UI, Comp, Busca, Cal } from '../ui.js';
import { QR } from '../qr.js';
import { linhasAlt } from './ponto.js';
import { Rel } from './relatorios.js';
import { ico, esc, Util, Periodo, ORIGEM_ALT, PAPEIS, RESERVA_MIN_PADRAO, INSPECIONA, CK } from '../util.js';

const V = A.V;
const ABAS = [['pontos', 'Pontos e etiquetas'], ['alteracoes', 'Histórico de alterações'], ['equipe', 'Equipe'], ['gerencias', 'Gerências'], ['categorias', 'Categorias'], ['agentes', 'Agentes extintores'], ['reserva', 'Reserva técnica'], ['destinatarios', 'Destinatários'], ['importacao', 'Importação'], ['config', 'Configurações'], ['backup', 'Backup e uso'], ['acessos', 'Registros de acesso (IP)', 'admin'], ['auditoria', 'Histórico do sistema']];
const online = () => { if (!navigator.onLine) { UI.toast('A administração precisa de conexão com a internet.'); return false; } return true; };

V.admin = (aba, q) => {
  if (!Regras.pode('verAdmin')) return Comp.vazio('shield', 'Acesso restrito', 'Esta área é exclusiva dos administradores.');
  const corpo = { pontos: V.admPontos, alteracoes: V.admAlt, equipe: V.admEquipe, gerencias: V.admGer, agentes: V.admAgentes, categorias: V.admCats, reserva: V.admReserva, destinatarios: V.admDest, importacao: V.admImport, config: V.admConfig, backup: V.admBackup, acessos: () => Regras.pode('admin') ? V.admAcessos() : Comp.vazio('shield', 'Acesso restrito', 'Os registros de acesso com IP são visíveis apenas para Owner e Admin.'), auditoria: (q) => V.admAud(q) }[aba] || V.admPontos;
  return `<div class="tabs" role="tablist" aria-label="Seções da administração" style="margin-bottom:12px">${ABAS.filter(([, , perm]) => !perm || Regras.pode(perm)).map(([k, n]) => `<a href="#/admin/${k}" role="tab" aria-selected="${aba === k}">${n}</a>`).join('')}</div>${corpo(q)}`;
};

/* ---------------- pontos e etiquetas ---------------- */
V.admPontos = () => {
  const f = A.tmp.adm || (A.tmp.adm = { q: '', cat: '', inativos: false }), naoImp = Store.S.pontos.filter(e => e.ativo && !e.qrImpresso).length;
  return `
  <div class="toolbar" style="margin-top:0">
    <label class="sr" for="adm-q">Buscar ponto</label><input class="input" id="adm-q" type="search" data-input="adm-q" value="${esc(f.q)}" placeholder="Buscar por código, tipo, local, cilindro…">
    ${Comp.selectCategoria('adm-cat', f.cat)}
  </div>
  <div class="chips" style="margin-bottom:12px"><button class="chip" data-action="adm-inativos" aria-pressed="${f.inativos}">Mostrar inativos</button><span style="margin-left:auto;display:flex;gap:8px;flex-wrap:wrap"><button class="btn btn-sec btn-sm" data-action="etq-abrir">${ico('qr')}Etiquetas QR${naoImp ? ` <span class="tag t-nc" style="margin-left:2px">${naoImp} a imprimir</span>` : ''}</button><button class="btn btn-pri btn-sm" data-action="pt-novo">${ico('plus')}Novo ponto</button></span></div>
  <div id="adm-list">${V.admPontosLista()}</div>`;
};
V.admPontosLista = () => {
  const f = A.tmp.adm, { termos, res } = Busca.executar({ q: f.q, cats: f.cat ? [f.cat] : [], inativos: f.inativos });
  const l = f.inativos ? res.map(r => r.e) : res.map(r => r.e).filter(e => e.ativo);
  return `<p class="res-count" style="margin-top:0">${Util.plural(l.length, 'ponto')} · ${Store.S.pontos.filter(e => e.ativo).length} ativos no total</p>
  <div class="list">${l.slice(0, 100).map(e => Comp.linhaEq(e, { termos, href: `#/ponto/${e.id}` })).join('')}${l.length > 100 ? `<p class="hint" style="padding:10px 14px;margin:0">Mostrando 100 de ${l.length}. Refine a busca.</p>` : ''}</div>`;
};
V.dlgEtiquetas = () => {
  const st = A.tmp.etq || (A.tmp.etq = { filtro: 'nao', ger: '', cat: '', modelo: 'meiaA4', pular: 0 });
  const l = V.etqLista();
  UI.dialogo({ titulo: 'Placas e etiquetas QR', largo: true, corpo: `
    <p class="hint" style="margin-top:0">Cada ponto tem um QR único gerado pelo banco. Imprima em 100% de escala (sem “ajustar à página”). A <b>placa de meia A4</b> sai 2 por folha, com linha de corte; para uso externo, plastifique ou imprima em papel adesivo/vinil. Os modelos Pimaco continuam disponíveis para etiquetas pequenas.</p>
    <div class="grid-2" style="gap:0 12px">
      <label class="field"><span>Quais etiquetas</span><select class="select" data-input="etq" data-k="filtro"><option value="nao" ${st.filtro === 'nao' ? 'selected' : ''}>Ainda não impressas</option><option value="todas" ${st.filtro === 'todas' ? 'selected' : ''}>Todas</option></select></label>
      <label class="field"><span>Modelo</span><select class="select" data-input="etq" data-k="modelo">${Object.entries(QR.MODELOS).map(([k, m]) => `<option value="${k}" ${st.modelo === k ? 'selected' : ''}>${esc(m.nome)}</option>`).join('')}</select></label>
      <label class="field"><span>Gerência</span><select class="select" data-input="etq" data-k="ger"><option value="">Todas</option>${Store.S.gers.map(g => `<option value="${g.id}" ${st.ger === g.id ? 'selected' : ''}>${esc(g.nome)}</option>`).join('')}</select></label>
      <label class="field"><span>Tipo de ponto</span><select class="select" data-input="etq" data-k="cat"><option value="">Todos</option>${Store.categorias().map(c => `<option value="${c.chave}" ${st.cat === c.chave ? 'selected' : ''}>${esc(c.plural)}</option>`).join('')}</select></label>
      <label class="field"><span>${QR.MODELOS[st.modelo]?.placa ? 'Pular a metade de cima da 1ª folha (0 ou 1)' : 'Pular posições na 1ª folha (etiquetas já usadas)'}</span><input class="input" type="number" min="0" max="23" data-input="etq-pular" value="${st.pular}"></label>
    </div>
    <p id="etq-n"><b>${Util.plural(l.length, QR.MODELOS[st.modelo]?.placa ? 'placa' : 'etiqueta')}</b> selecionada(s).</p>
    ${l[0] ? (QR.MODELOS[st.modelo]?.placa ? `<div class="etq-prev pl-prev"><div class="pl-esc">${QR.placa(l[0])}</div></div><p class="hint" style="margin:-4px 0 0;text-align:center">Prévia reduzida · tamanho real 210 × 148 mm · ${Util.plural(Math.ceil(l.length / 2), 'folha')} A4</p>` : `<div class="etq-prev">${QR.etiqueta(l[0])}</div>`) : ''}`,
    rodape: `<button class="btn btn-sec" data-action="fechar-dlg">Fechar</button><button class="btn btn-pri" data-action="etq-imprimir" ${l.length ? '' : 'disabled'}>${ico('printer')}Abrir para imprimir</button>` });
};
V.etqLista = () => { const st = A.tmp.etq; return Store.S.pontos.filter(e => e.ativo && e.qr && (st.filtro === 'todas' || !e.qrImpresso) && (!st.ger || e.ger === st.ger) && (!st.cat || e.cat === st.cat)).sort((a, b) => a.codigo.localeCompare(b.codigo, 'pt', { numeric: true })); };

/* ---------------- histórico de alterações (todas) ---------------- */
V.admAlt = () => {
  const f = A.tmp.aud || (A.tmp.aud = { ...Periodo.mesAtual(), orig: '', ger: '', q: '' }), termos = Busca.termos(f.q);
  const l = Store.S.alts.filter(a => { const e = Store.eq(a.ponto_id); if (!Periodo.ok(a.criado_em, f)) return false; if (f.orig && a.origem !== f.orig) return false; if (f.ger && e?.ger !== f.ger) return false; if (termos.length) { const h = Util.norm([e?.codigo, e?.local, a.campo, a.de, a.para, a.referencia, Store.usuario(a.usuario_id).nome].join(' ')); if (!termos.every(t => h.includes(t))) return false; } return true; });
  return `<p class="hint" style="margin:0 0 10px">Rastreabilidade de tudo o que mudou nos pontos: trocas de equipamento, correções feitas na inspeção, edições de cadastro, etiquetas QR e situação. O banco grava automaticamente e não permite editar nem apagar estes registros.</p>
  <div class="fbar" style="margin-top:0">${Cal.botao('aud-per', f, (de, ate) => { f.de = de; f.ate = ate; A.render(); })}
    <label><span>Origem</span><select class="select" data-input="aud" data-k="orig"><option value="">Todas</option>${Object.entries(ORIGEM_ALT).map(([k, [n]]) => `<option value="${k}" ${f.orig === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
    <label><span>Gerência</span><select class="select" data-input="aud" data-k="ger"><option value="">Todas</option>${Store.S.gers.map(g => `<option value="${g.id}" ${f.ger === g.id ? 'selected' : ''}>${esc(g.nome)}</option>`).join('')}</select></label>
    <label><span>Texto</span><input class="input" style="min-height:38px;font-size:14px" type="search" data-input="aud-q" value="${esc(f.q)}" placeholder="ponto, cilindro, campo…"></label>
  </div>
  <div class="kpis kpis-4" style="margin-top:12px">${Comp.kpi('Registros no período', l.length, esc(Periodo.rot(f)))}${Comp.kpi('Trocas de equipamento', Store.S.trocas.filter(t => Periodo.ok(t.criado_em, f)).length)}${Comp.kpi('Pontos alterados', new Set(l.map(a => a.ponto_id)).size)}${Comp.kpi('Correções na inspeção', l.filter(a => a.origem === 'inspecao').length)}</div>
  <div class="chips" style="margin:12px 0"><span class="res-count" style="margin:0">${Util.plural(l.length, 'registro')}${l.length > 200 ? ' · mostrando os 200 mais recentes' : ''}</span><button class="btn btn-sec btn-sm" data-action="aud-xlsx" style="margin-left:auto">${ico('download')}Excel</button></div>
  <section class="card">${l.length ? linhasAlt(l.slice(0, 200), true) : Comp.vazio('history', 'Nenhuma alteração', 'Ajuste o período ou os filtros.')}</section>`;
};

/* ---------------- equipe ---------------- */
V.admEquipe = () => {
  const S = Store.S, eu = S.eu, resp = [...new Set(S.pontos.map(p => p.dados?.responsavel).filter(Boolean))], semVinc = resp.filter(n => S.pontos.some(p => p.dados?.responsavel === n && !p.resp));
  return `
  <div class="chips" style="margin-bottom:12px;justify-content:space-between"><p class="hint" style="margin:0;max-width:640px">Só entra no Inspec quem for cadastrado aqui (não há cadastro público). O usuário recebe uma senha provisória e troca no 1º acesso.</p><button class="btn btn-pri btn-sm" data-action="user-novo">${ico('plus')}Criar usuário</button></div>
  ${semVinc.length ? `<div class="notice n-amber" style="margin:0 0 12px">${ico('users')}<div><b>${Util.plural(semVinc.length, 'bombeiro da planilha ainda não vinculado', 'bombeiros da planilha ainda não vinculados')}</b> aos pontos (${esc(semVinc.join(', '))}). Crie os usuários e use <b>Vincular responsáveis</b> para o filtro “Meus pontos”. <button class="linkbtn" data-action="vinc-abrir" style="padding:0">Vincular responsáveis</button></div></div>` : (resp.length ? `<p><button class="btn btn-sec btn-sm" data-action="vinc-abrir">${ico('users')}Vincular responsáveis da planilha</button></p>` : '')}
  <div class="list">${S.membros.map(m => { const n = S.insp.filter(i => i.ins === m.usuario_id).length, email = S.usuarios.find(u => u.id === m.usuario_id)?.email || '', np = S.pontos.filter(p => p.ativo && p.resp === m.usuario_id).length; return `
    <div class="row" style="${m.ativo ? '' : 'opacity:.6'}"><span class="avatar" style="flex:none">${esc(Util.iniciais(m.nome))}</span>
    <span class="body"><span class="l1"><span class="code" style="font-size:14.5px">${esc(m.nome)}</span><span class="tag ${m.papel === 'admin' || m.papel === 'owner' ? 't-info' : m.papel.endsWith('_leitura') ? 't-pend' : 't-ok'}">${PAPEIS[m.papel]}</span>${m.trocar_senha ? '<span class="tag t-warn">Aguardando 1º acesso</span>' : ''}${m.ativo ? '' : '<span class="tag t-off">Bloqueado</span>'}</span>
    <span class="l3">${esc(email)} · ${Util.plural(n, 'inspeção', 'inspeções')} (período carregado)${np ? ` · ${np} pontos sob responsabilidade` : ''}</span></span>
    ${m.usuario_id !== eu.id && m.papel !== 'owner' ? `<button class="btn btn-sec btn-sm" data-action="user-editar" data-id="${m.id}">${ico('edit')}Editar</button>` : '<span class="hint">' + (m.usuario_id === eu.id ? 'Você' : 'Owner') + '</span>'}</div>`; }).join('')}</div>`;
};
V.dlgUsuario = (m) => {
  const S = Store.S, novo = !m, podeAdmin = Regras.pode('owner');
  UI.dialogo({ titulo: novo ? 'Criar usuário' : `Editar ${esc(m.nome)}`, corpo: `
    ${novo ? `<label class="field"><span>Nome completo</span><input class="input" id="us-nome" maxlength="80"></label>
    <label class="field"><span>E-mail (login)</span><input class="input" id="us-email" type="email" maxlength="120"></label>` : `<label class="field"><span>Nome</span><input class="input" id="us-nome" maxlength="80" value="${esc(m.nome)}"></label>`}
    <label class="field"><span>Perfil</span><select class="select" id="us-papel">
      <option value="inspetor" ${m?.papel === 'inspetor' ? 'selected' : ''}>Inspetor (bombeiro) — registra inspeções, trocas e desvios</option>
      <option value="inspetor_leitura" ${m?.papel === 'inspetor_leitura' ? 'selected' : ''}>Inspetor (leitura) — vê o que o inspetor vê, sem alterar nada</option>
      <option value="admin_leitura" ${['admin_leitura', 'consulta'].includes(m?.papel) ? 'selected' : ''}>Admin (leitura) — vê tudo o que o administrador vê, sem alterar nada</option>
      ${podeAdmin ? `<option value="admin" ${m?.papel === 'admin' ? 'selected' : ''}>Administrador — tudo, exceto zerar o sistema e o backup completo (JSON)</option>` : ''}
    </select></label>
    ${S.unidades.length > 1 || novo ? `<div class="lbl"><span>Unidades com acesso</span></div>${S.unidades.map(u => `<label class="checkline"><input type="checkbox" class="us-unid" value="${u.id}" ${novo ? (u.id === S.unidade.id ? 'checked' : '') : (m.unidades.includes(u.id) ? 'checked' : '')}> ${esc(u.nome)}</label>`).join('')}` : ''}
    ${novo ? '' : `<label class="checkline"><input type="checkbox" id="us-ativo" ${m.ativo ? 'checked' : ''}> Acesso liberado (desmarque para bloquear sem apagar o histórico)</label>`}
    <div class="err" id="us-err" role="alert"></div>`,
    rodape: `${novo ? '' : `<button class="btn btn-danger" data-action="user-del" data-id="${m.id}" style="margin-right:auto">Excluir login</button>`}<button class="btn btn-sec" data-action="fechar-dlg">Cancelar</button><button class="btn btn-pri" data-action="user-salvar" data-id="${m?.id || ''}">${ico('check')}${novo ? 'Criar' : 'Salvar'}</button>` });
};
V.dlgVincular = () => {
  const S = Store.S, nomes = [...new Set(S.pontos.map(p => p.dados?.responsavel).filter(Boolean))].sort(), ins = S.membros.filter(m => m.ativo && INSPECIONA.includes(m.papel));
  const sugestao = n => ins.find(m => Util.norm(m.nome) === Util.norm(n)) || ins.find(m => Util.norm(m.nome).split(' ')[0] === Util.norm(n).split(' ')[0]);
  UI.dialogo({ titulo: 'Vincular responsáveis da planilha', largo: true, corpo: `<p class="hint" style="margin-top:0">A planilha indica o bombeiro responsável por cada extintor (só o nome). Escolha o usuário correspondente: os pontos passam a aparecer em “Meus pontos” dele.</p>
    <div class="tbl-wrap"><table class="tbl"><thead><tr><th>Nome na planilha</th><th class="num">Pontos</th><th>Usuário do Inspec</th></tr></thead><tbody>${nomes.map(n => { const atual = S.pontos.find(p => p.dados?.responsavel === n && p.resp)?.resp || sugestao(n)?.usuario_id || ''; return `<tr><td>${esc(n)}</td><td class="num">${S.pontos.filter(p => p.dados?.responsavel === n).length}</td><td><select class="select vinc" data-nome="${esc(n)}"><option value="">— não vincular —</option>${ins.map(m => `<option value="${m.usuario_id}" ${m.usuario_id === atual ? 'selected' : ''}>${esc(m.nome)}</option>`).join('')}</select></td></tr>`; }).join('')}</tbody></table></div><div class="err" id="vc-err" role="alert"></div>`,
    rodape: `<button class="btn btn-sec" data-action="fechar-dlg">Cancelar</button><button class="btn btn-pri" data-action="vinc-ok">${ico('check')}Aplicar vínculos</button>` });
};

/* ---------------- gerências ---------------- */
V.admGer = () => {
  const S = Store.S, cats = Store.categorias();
  return `<div class="chips" style="margin-bottom:12px;justify-content:flex-end"><button class="btn btn-pri btn-sm" data-action="ger-nova">${ico('plus')}Nova gerência</button></div>
  <div class="card tbl-wrap"><table class="tbl"><thead><tr><th>Gerência</th><th>Sigla</th>${cats.map(c => `<th class="num">${esc(c.plural)}</th>`).join('')}<th class="num">Total</th><th></th></tr></thead><tbody>
  ${S.gers.map(g => { const cs = cats.map(c => S.pontos.filter(e => e.ativo && e.ger === g.id && e.cat === c.chave).length); return `<tr><td><b>${esc(g.nome)}</b></td><td>${esc(g.sigla)}</td>${cs.map(n => `<td class="num">${n}</td>`).join('')}<td class="num"><b>${cs.reduce((a, b) => a + b, 0)}</b></td><td><button class="linkbtn" data-action="ger-editar" data-id="${g.id}">Editar</button></td></tr>`; }).join('') || `<tr><td colspan="${cats.length + 4}">Nenhuma gerência. Elas são criadas na importação ou pelo botão acima.</td></tr>`}
  </tbody></table></div>`;
};
V.dlgGer = g => UI.dialogo({ titulo: g ? 'Editar gerência' : 'Nova gerência', corpo: `<label class="field"><span>Nome</span><input class="input" id="gr-nome" maxlength="80" value="${esc(g?.nome || '')}" style="text-transform:uppercase"></label><label class="field"><span>Sigla (3 a 5 letras)</span><input class="input" id="gr-sigla" maxlength="5" value="${esc(g?.sigla || '')}" style="text-transform:uppercase"></label><div class="err" id="gr-err" role="alert"></div>`, rodape: `<button class="btn btn-sec" data-action="fechar-dlg">Cancelar</button><button class="btn btn-pri" data-action="ger-salvar" data-id="${g?.id || ''}">Salvar</button>` });

/* ---------------- categorias (tipos de ponto) ---------------- */
const ICONES_CAT = ['extintor', 'hidrante', 'maca', 'chuveiro', 'box', 'shield', 'flame', 'bolt', 'clipboard', 'building', 'alert', 'map'];
const PADRAO = ['extintor', 'hidrante', 'maca', 'chuveiro'];
V.admCats = () => {
  const S = Store.S, n = c => S.pontos.filter(p => p.cat === c.chave).length;
  return `<div class="p-head" style="margin-bottom:12px"><p class="hint" style="margin:0;max-width:700px">Tipos de ponto inspecionados. As 4 categorias padrão seguem o checklist do Forms (com campos próprios: cilindro e N2/N3 no extintor, mangueiras no hidrante, kit na maca, pressurizado no chuveiro) — nelas você altera nome, periodicidade e ícone. Nas categorias novas você define os itens do checklist.</p><button class="btn btn-pri btn-sm" data-action="cat-nova">${ico('plus')}Nova categoria</button></div>
  <div class="card tbl-wrap"><table class="tbl"><thead><tr><th>Categoria</th><th>Periodicidade</th><th>Itens do checklist</th><th class="num">Pontos</th><th>Situação</th><th></th></tr></thead><tbody>
  ${Store.categorias(true).map(c => `<tr style="${c.ativo === false ? 'opacity:.55' : ''}"><td><span style="display:inline-flex;align-items:center;gap:8px"><span style="width:20px;height:20px;display:inline-flex;color:var(--navy)">${ico(c.icone)}</span><b>${esc(c.nome)}</b> <span class="hint">(${esc(c.plural)})</span></span></td><td>${c.per === 'semanal' ? 'Semanal' : 'Mensal'}</td><td>${PADRAO.includes(c.chave) ? '<span class="hint">padrão (Forms)</span>' : (CK[c.chave]?.itens || []).length}</td><td class="num">${n(c)}</td><td>${c.ativo === false ? '<span class="tag t-off">Inativa</span>' : '<span class="tag t-ok">Ativa</span>'}</td><td style="white-space:nowrap;text-align:right"><button class="linkbtn" data-action="cat-editar" data-id="${c.id}">Editar</button> <button class="linkbtn" style="color:var(--red)" data-action="cat-excluir" data-id="${c.id}">Excluir</button></td></tr>`).join('')}
  </tbody></table></div>`;
};
V.dlgCat = c => {
  const padrao = c && PADRAO.includes(c.chave), its = c ? (c.checklist?.itens || []) : [{ l: 'Integridade', na: false }, { l: 'Acesso', na: false }, { l: 'Sinalização', na: false }];
  A.tmp.catIts = its.map(i => ({ l: i.l, na: !!i.na, k: i.k }));
  UI.dialogo({ titulo: c ? `Editar categoria — ${esc(c.nome)}` : 'Nova categoria', largo: true, corpo: `
    <div class="grid-2" style="gap:0 12px">
      <label class="field"><span>Nome (singular)</span><input class="input" id="ct-nome" maxlength="40" value="${esc(c?.nome || '')}" placeholder="Ex.: Alarme de incêndio"></label>
      <label class="field"><span>Nome no plural</span><input class="input" id="ct-plural" maxlength="40" value="${esc(c?.plural || '')}" placeholder="Ex.: Alarmes de incêndio"></label>
      <label class="field"><span>Periodicidade da inspeção</span><select class="select" id="ct-per"><option value="mensal" ${c?.per !== 'semanal' ? 'selected' : ''}>Mensal</option><option value="semanal" ${c?.per === 'semanal' ? 'selected' : ''}>Semanal</option></select></label>
      <label class="field"><span>Prefixo do código (opcional)</span><input class="input" id="ct-pref" maxlength="5" value="${esc(c?.prefixo || '')}" style="text-transform:uppercase" placeholder="Ex.: ALM"></label>
    </div>
    <div class="lbl"><span>Ícone</span></div><div class="chips" id="ct-icones">${ICONES_CAT.map(i => `<button type="button" class="chip" data-action="cat-icone" data-v="${i}" aria-pressed="${(c?.icone || 'clipboard') === i}" style="padding:6px 10px">${ico(i)}</button>`).join('')}</div>
    ${padrao ? '<p class="hint" style="margin-top:12px">Checklist padrão do Forms — os itens desta categoria não são editáveis aqui.</p>' : `<div class="lbl" style="margin-top:12px"><span>Itens do checklist</span><span class="hint">C / NC (e NA, se marcado)</span></div><div id="ct-its"></div><button type="button" class="btn btn-sec btn-sm" data-action="cat-item-add">${ico('plus')}Adicionar item</button>`}
    <div class="err" id="ct-err" role="alert"></div>`,
    rodape: `<button class="btn btn-sec" data-action="fechar-dlg">Cancelar</button><button class="btn btn-pri" data-action="cat-salvar" data-id="${c?.id || ''}">Salvar</button>` });
  A.tmp.catIcone = c?.icone || 'clipboard';
  if (!padrao) renderItens();
};
function renderItens() {
  const el = document.getElementById('ct-its'); if (!el) return;
  el.innerHTML = A.tmp.catIts.map((it, i) => `<div style="display:grid;grid-template-columns:1fr auto auto;gap:8px;align-items:center;margin-bottom:6px"><input class="input" data-input="cat-item" data-i="${i}" value="${esc(it.l)}" maxlength="60" placeholder="Ex.: Botoeira funcionando"><label class="checkline" style="margin:0;white-space:nowrap"><input type="checkbox" data-change="cat-na" data-i="${i}" ${it.na ? 'checked' : ''}> permite NA</label><button type="button" class="iconbtn" data-action="cat-item-del" data-i="${i}" aria-label="Remover item">${ico('x')}</button></div>`).join('') || '<p class="hint">Nenhum item. Adicione ao menos um.</p>';
}
const slug = t => Util.norm(t).replace(/[^a-z]+/g, '_').replace(/^_|_$/g, '').slice(0, 30) || 'categoria';

/* ---------------- agentes extintores ---------------- */
V.admAgentes = () => {
  const S = Store.S, uso = n => S.pontos.filter(p => p.agente === n).length, cad = new Set((S.agentes || []).map(a => a.nome));
  const fora = [...new Set(S.pontos.filter(p => p.ativo && p.agente && !cad.has(p.agente)).map(p => p.agente))];
  return `<div class="p-head" style="margin-bottom:12px"><p class="hint" style="margin:0;max-width:680px">Lista de agentes que aparece em <b>Equipamento instalado no ponto</b>, nas trocas, no cadastro de pontos e na reserva técnica. Só o administrador cadastra: se o bombeiro não encontrar o agente, ele deve pedir a inclusão aqui.</p><button class="btn btn-pri btn-sm" data-action="agt-novo">${ico('plus')}Novo agente</button></div>
  ${fora.length ? `<div class="notice n-amber" style="margin:0 0 12px">${ico('alert')}<div>Há pontos com agente fora da lista: <b>${esc(fora.join(', '))}</b>. Cadastre o agente correto e ajuste esses pontos pela troca ou pela conferência na inspeção.</div></div>` : ''}
  <div class="card tbl-wrap"><table class="tbl"><thead><tr><th>Agente extintor</th><th class="num">Pontos com este agente</th><th class="num">Estoque na reserva</th><th></th></tr></thead><tbody>
  ${(S.agentes || []).map(a => `<tr><td><b>${esc(a.nome)}</b></td><td class="num">${uso(a.nome)}</td><td class="num">${S.reserva.find(r => r.agente === a.nome)?.quantidade ?? '—'}</td><td style="white-space:nowrap;text-align:right"><button class="linkbtn" data-action="agt-editar" data-id="${a.id}">Editar</button> <button class="linkbtn" style="color:var(--red)" data-action="agt-excluir" data-id="${a.id}">Excluir</button></td></tr>`).join('') || '<tr><td colspan="4">Nenhum agente cadastrado.</td></tr>'}
  </tbody></table></div>`;
};
V.dlgAgente = a => UI.dialogo({ titulo: a ? 'Editar agente extintor' : 'Novo agente extintor', corpo: `<label class="field"><span>Nome do agente</span><input class="input" id="ag-nome" maxlength="60" value="${esc(a?.nome || '')}" placeholder="Ex.: Pó Químico Seco ABC 4kg"></label>${a && Store.S.pontos.some(p => p.agente === a.nome) ? `<p class="hint" style="margin:0">Ao renomear, os ${Store.S.pontos.filter(p => p.agente === a.nome).length} pontos com este agente e a reserva técnica são atualizados (fica registrado no histórico).</p>` : ''}<div class="err" id="ag-err" role="alert"></div>`, rodape: `<button class="btn btn-sec" data-action="fechar-dlg">Cancelar</button><button class="btn btn-pri" data-action="agt-salvar" data-id="${a?.id || ''}">Salvar</button>` });

/* ---------------- reserva técnica ---------------- */
V.admReserva = () => {
  const S = Store.S;
  return `<div class="p-head" style="margin-bottom:12px"><p class="hint" style="margin:0;max-width:640px">Extintores de reposição disponíveis na unidade. Cada comunicado de desvio com substituição e cada troca com origem “Reserva técnica” dão baixa automática. Registre aqui as entradas e o inventário.</p><button class="btn btn-pri btn-sm" data-action="res-mov">${ico('plus')}Entrada / inventário</button></div>
  <div class="pgrid" style="margin-top:0">
    <section class="card chart"><h3>Estoque por agente</h3><p class="sub">Mínimo definido pelo administrador</p><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Agente</th><th class="num">Estoque</th><th class="num">Mínimo</th><th>Situação</th></tr></thead><tbody>${S.reserva.map(r => `<tr><td>${esc(r.agente)}</td><td class="num"><b>${r.quantidade}</b></td><td class="num">${r.minimo}</td><td>${r.minimo && r.quantidade <= r.minimo ? '<span class="tag t-nc">Repor</span>' : '<span class="tag t-ok">OK</span>'}</td></tr>`).join('') || '<tr><td colspan="4">Nenhum agente cadastrado. Registre a primeira entrada.</td></tr>'}</tbody></table></div></section>
    <section class="card chart"><h3>Movimentações</h3><p class="sub">Entradas, ajustes e saídas (desvios e trocas)</p><div class="list" style="max-height:420px;overflow:auto">${S.movs.map(m => `<div class="row" style="padding:8px 12px"><span class="ic" style="${m.tipo === 'saida' ? 'background:var(--red-bg);color:var(--red)' : 'background:var(--ok-bg);color:var(--ok)'}">${ico(m.tipo === 'saida' ? 'upload' : 'download')}</span><span class="body"><span class="l1"><b>${m.tipo === 'saida' ? '−' : m.tipo === 'ajuste' ? '=' : '+'}${m.qtd}</b> <span class="l2">${esc(m.agente)}</span></span><span class="l3">${Util.fmtCurta(m.criado_em)} · ${esc(m.referencia || m.tipo)} · ${esc(Store.usuario(m.usuario_id).nome)}</span></span></div>`).join('') || '<p class="hint" style="padding:12px">Sem movimentações.</p>'}</div></section>
  </div>`;
};
V.dlgReserva = () => {
  const ags = [...new Set([...Store.agentes(), ...Store.S.reserva.map(r => r.agente)])];
  UI.dialogo({ titulo: 'Reserva técnica — movimentar', corpo: `
    <label class="field"><span>Agente extintor</span><select class="select" id="rs-ag">${ags.map(a => `<option>${esc(a)}</option>`).join('')}</select></label>
    <label class="field"><span>Movimento</span><select class="select" id="rs-tipo"><option value="entrada">Entrada (soma ao estoque)</option><option value="ajuste">Inventário (define a quantidade contada)</option></select></label>
    <div class="grid-2" style="gap:0 12px"><label class="field"><span>Quantidade</span><input class="input" id="rs-qtd" type="number" min="0" max="999" value="1"></label><label class="field"><span>Estoque mínimo (opcional)</span><input class="input" id="rs-min" type="number" min="0" max="999" placeholder=""></label></div>
    <label class="field"><span>Observação / nota fiscal</span><input class="input" id="rs-obs" maxlength="120"></label><div class="err" id="rs-err" role="alert"></div>`,
    rodape: `<button class="btn btn-sec" data-action="fechar-dlg">Cancelar</button><button class="btn btn-pri" data-action="res-ok">${ico('check')}Registrar</button>`,
    aoAbrir: d => { const s = d.querySelector('#rs-ag'), m = d.querySelector('#rs-min'); const f = () => { const r = Store.S.reserva.find(x => x.agente === s.value); m.placeholder = r ? `atual: ${r.minimo}` : `sugestão: ${RESERVA_MIN_PADRAO[s.value] ?? 1}`; }; s.addEventListener('change', f); f(); } });
};

/* ---------------- destinatários do One Page ---------------- */
V.admDest = () => {
  const S = Store.S;
  return `<div class="p-head" style="margin-bottom:12px"><p class="hint" style="margin:0;max-width:640px">Quem recebe o One Page dos comunicados de desvio. Os e-mails ficam no banco: o celular nunca escolhe para onde enviar. Um destinatário pode valer para todas as gerências ou só para uma.</p><button class="btn btn-pri btn-sm" data-action="dst-novo">${ico('plus')}Novo destinatário</button></div>
  <div class="card tbl-wrap"><table class="tbl"><thead><tr><th>Papel</th><th>Nome</th><th>E-mail</th><th>Gerência</th><th>Situação</th><th></th></tr></thead><tbody>
  ${S.dests.map(d => `<tr style="${d.ativo ? '' : 'opacity:.55'}"><td><b>${esc(d.papel)}</b></td><td>${esc(d.nome)}</td><td>${esc(d.email)}</td><td>${d.gerencia_id ? esc(Store.ger(d.gerencia_id).nome) : 'Todas'}</td><td>${d.ativo ? '<span class="tag t-ok">Ativo</span>' : '<span class="tag t-off">Inativo</span>'}</td><td><button class="linkbtn" data-action="dst-editar" data-id="${d.id}">Editar</button></td></tr>`).join('') || '<tr><td colspan="6">Nenhum destinatário cadastrado.</td></tr>'}
  </tbody></table></div>`;
};
V.dlgDest = d => {
  const papeis = [...new Set(['Gerência da área', 'Gerência de SST', 'Coordenação da brigada', 'Supervisão de turno', ...Store.S.dests.map(x => x.papel)])];
  UI.dialogo({ titulo: d ? 'Editar destinatário' : 'Novo destinatário', corpo: `
    <label class="field"><span>Papel</span><input class="input" id="ds-papel" list="dl-papeis" maxlength="60" value="${esc(d?.papel || '')}"><datalist id="dl-papeis">${papeis.map(p => `<option value="${esc(p)}">`).join('')}</datalist></label>
    <label class="field"><span>Nome</span><input class="input" id="ds-nome" maxlength="80" value="${esc(d?.nome || '')}"></label>
    <label class="field"><span>E-mail</span><input class="input" id="ds-email" type="email" maxlength="120" value="${esc(d?.email || '')}"></label>
    <label class="field"><span>Gerência</span><select class="select" id="ds-ger"><option value="">Todas as gerências</option>${Store.S.gers.map(g => `<option value="${g.id}" ${g.id === d?.gerencia_id ? 'selected' : ''}>${esc(g.nome)}</option>`).join('')}</select></label>
    <label class="checkline"><input type="checkbox" id="ds-ativo" ${!d || d.ativo ? 'checked' : ''}> Ativo</label><div class="err" id="ds-err" role="alert"></div>`,
    rodape: `${d ? `<button class="btn btn-danger" data-action="dst-del" data-id="${d.id}" style="margin-right:auto">Excluir</button>` : ''}<button class="btn btn-sec" data-action="fechar-dlg">Cancelar</button><button class="btn btn-pri" data-action="dst-salvar" data-id="${d?.id || ''}">Salvar</button>` });
};

/* ---------------- importação ---------------- */
const COLS_MODELO = ['codigo', 'categoria', 'gerencia', 'sigla', 'area', 'local', 'subtipo', 'capacidade', 'numero_cilindro', 'agente', 'n2', 'n3', 'responsavel', 'requer_conferencia', 'observacao'];
V.admImport = () => {
  const n = Store.S.pontos.length, imp = A.tmp.imp;
  return `<section class="card pad">
    <h2 style="font-size:16px">Carga inicial — planilha de equipamentos de emergência</h2>
    <p class="hint">A planilha <b>Equipamentos_de_emergência.xlsx</b> já foi convertida e revisada para o Inspec: <b>814 pontos</b> (623 extintores, 133 hidrantes, 35 chuveiros/lava-olhos e 23 macas), com gerências, bombeiro responsável, nº do cilindro, agente, N2 e N3. Cada ponto recebe um <b>QR único</b> gerado pelo banco.</p>
    <p class="hint"><b>Nada é duplicado:</b> pontos com código já existente são ignorados (o QR e o histórico deles são preservados). Pode rodar mais de uma vez com segurança.</p>
    ${n ? `<div class="notice n-info">${ico('info')}<div>Esta unidade já tem <b>${n} pontos</b>. A carga só acrescentará os que faltarem.</div></div>` : ''}
    <div class="chips" style="margin-top:12px"><button class="btn btn-pri btn-sm" data-action="imp-carga">${ico('upload')}Ver prévia da carga inicial</button></div>
  </section>
  <section class="card pad" style="margin-top:12px">
    <h2 style="font-size:16px">Importar novos pontos por planilha</h2>
    <p class="hint">Para acrescentar pontos em lote, baixe o modelo, preencha uma linha por ponto e envie. Colunas: ${COLS_MODELO.map(c => `<code>${c}</code>`).join(', ')}. Categoria: <code>extintor</code>, <code>hidrante</code>, <code>maca</code> ou <code>chuveiro</code>; N2 no formato <code>AAAA-MM</code>.</p>
    <div class="chips"><button class="btn btn-sec btn-sm" data-action="imp-modelo">${ico('download')}Baixar modelo (.xlsx)</button><label class="btn btn-navy btn-sm" style="cursor:pointer">${ico('upload')}Enviar planilha preenchida<input type="file" accept=".xlsx,.xls,.csv" class="sr" data-change="imp-file"></label></div>
  </section>
  <div id="imp-prev">${imp ? V.impPrevia(imp) : ''}</div>`;
};
V.impPrevia = (imp) => {
  const existentes = new Set(Store.S.pontos.map(p => p.codigo.toUpperCase()));
  const novos = imp.itens.filter(i => !existentes.has(String(i.codigo).toUpperCase())), cont = k => novos.filter(i => i.categoria === k).length;
  return `<section class="card pad" style="margin-top:12px"><h2 style="font-size:16px">Prévia: ${esc(imp.nome)}</h2>
  <div class="kpis kpis-4" style="margin-top:8px">${Comp.kpi('Linhas válidas', imp.itens.length)}${Comp.kpi('Novos a cadastrar', novos.length, `${cont('extintor')} ext · ${cont('hidrante')} hid · ${cont('chuveiro')} chv · ${cont('maca')} mac`)}${Comp.kpi('Já existentes (ignorados)', imp.itens.length - novos.length)}${Comp.kpi('Avisos', imp.avisos.length)}</div>
  ${imp.erros.length ? `<div class="notice n-red" style="margin-top:12px">${ico('alert')}<div><b>${imp.erros.length} linha(s) com erro</b> não serão importadas: ${esc(imp.erros.slice(0, 8).join(' · '))}${imp.erros.length > 8 ? '…' : ''}</div></div>` : ''}
  ${imp.avisos.length ? `<details style="margin-top:12px"><summary style="cursor:pointer;font-weight:600">Ver ${imp.avisos.length} aviso(s) da conversão</summary><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Aba</th><th class="num">Linha</th><th>Código</th><th>Aviso</th></tr></thead><tbody>${imp.avisos.map(a => `<tr><td>${esc(a[0])}</td><td class="num">${esc(a[1])}</td><td>${esc(a[2])}</td><td>${esc(a[3])}</td></tr>`).join('')}</tbody></table></div></details>` : ''}
  <div id="imp-prog"></div>
  <div class="chips" style="margin-top:12px;justify-content:flex-end"><button class="btn btn-sec btn-sm" data-action="imp-cancelar">Cancelar</button><button class="btn btn-pri btn-sm" data-action="imp-confirmar" ${novos.length ? '' : 'disabled'}>${ico('check')}Importar ${Util.plural(novos.length, 'ponto novo', 'pontos novos')}</button></div></section>`;
};

/* ---------------- configurações ---------------- */
V.admConfig = () => {
  const S = Store.S, f = S.org.config.regra_foto, owner = Regras.pode('owner');
  const op = [['todas', 'Obrigatória em todas as inspeções', 'Como no Forms atual'], ['nc', 'Obrigatória só quando houver não conformidade', 'Recomendado: agiliza as inspeções e economiza armazenamento'], ['opcional', 'Opcional', 'O bombeiro decide']];
  return `<section class="card pad"><h2 style="font-size:16px;margin-bottom:4px">Evidência fotográfica</h2><p class="hint" style="margin:0 0 12px">Cada foto é comprimida no celular (~150 KB) e guardada em bucket privado, aberta só por link temporário.${owner ? '' : ' <b>Somente o owner altera esta regra.</b>'}</p>
    <div class="menu-list">${op.map(([v, n, d]) => `<button class="menu-item" data-action="cfg-foto" data-v="${v}" role="radio" aria-checked="${f === v}" ${owner ? '' : 'disabled'}><span style="width:20px;height:20px;border-radius:50%;border:2px solid ${f === v ? 'var(--green)' : '#B8C6D3'};display:inline-flex;align-items:center;justify-content:center;flex:none">${f === v ? '<span style="width:10px;height:10px;border-radius:50%;background:var(--green)"></span>' : ''}</span><span>${n}<br><span class="hint">${d}</span></span></button>`).join('')}</div></section>
  <section class="card pad" style="margin-top:12px"><h2 style="font-size:16px;margin-bottom:8px">Organização e unidades</h2>
    <dl class="kv"><dt>Organização</dt><dd>${esc(S.org.nome)}${owner ? ` <button class="linkbtn" data-action="org-nome">Renomear</button>` : ''}</dd><dt>Fuso horário</dt><dd>${esc(S.org.fuso)}</dd><dt>Unidades</dt><dd>${S.unidades.map(u => esc(u.nome)).join(', ')} <button class="linkbtn" data-action="unid-nova">Nova unidade</button></dd></dl></section>
  <section class="card pad" style="margin-top:12px"><h2 style="font-size:16px;margin-bottom:8px">Bombeiros e pontos</h2><p class="hint" style="margin:0 0 10px">Distribuição dos pontos por bombeiro responsável. Hidrantes, macas e chuveiros normalmente são da equipe toda.</p>
    <div class="tbl-wrap"><table class="tbl"><thead><tr><th>Bombeiro</th><th class="num">Pontos</th><th class="num">Inspecionados no ciclo</th><th class="num">Pendentes</th></tr></thead><tbody>${S.membros.filter(m => INSPECIONA.includes(m.papel)).map(m => { const l = S.pontos.filter(e => e.ativo && e.resp === m.usuario_id); const p = l.filter(e => Regras.situacao(e).pendente).length; return l.length ? `<tr><td>${esc(m.nome)}</td><td class="num">${l.length}</td><td class="num">${l.length - p}</td><td class="num">${p}</td></tr>` : ''; }).join('') || '<tr><td colspan="4">Nenhum ponto com responsável vinculado (Equipe → Vincular responsáveis).</td></tr>'}</tbody></table></div></section>
  ${owner ? `<section class="card pad danger-zone" style="margin-top:12px"><h2 style="font-size:16px;margin-bottom:4px;color:var(--red)">Zerar o sistema</h2>
    <p class="hint" style="margin:0 0 10px">Apaga todos os pontos, inspeções, fotos, comunicados de desvio, trocas, reserva, etiquetas QR e o histórico do sistema, para recomeçar do zero (por exemplo, depois da fase de testes). <b>Usuários, organização e unidades são mantidos.</b> Não há como desfazer: faça antes um backup.</p>
    <button class="btn btn-danger" data-action="zerar-abrir">${ico('alert')}Zerar o sistema…</button></section>` : ''}`;
};

/* ---------------- backup e uso ---------------- */
V.admBackup = () => {
  let ult = null; try { ult = localStorage.getItem('inspec-ultimo-backup'); } catch (e) { /* ignore */ }
  const uso = A.tmp.uso;
  return `<section class="card pad"><h2 style="font-size:16px">Backup completo (Excel + JSON)</h2>
    <p class="hint">Recomendado todo início de mês, junto com o relatório do ciclo. O plano gratuito do Supabase não guarda backups automáticos — além deste arquivo, o repositório GitHub roda um <code>pg_dump</code> semanal (ver DEPLOY).</p>
    <p style="margin:10px 0">Último backup neste aparelho: <b>${ult ? Util.fmtDataHora(ult) : 'nunca realizado'}</b></p>
    <div class="chips"><button class="btn btn-pri" data-action="backup-xlsx">${ico('download')}Backup em Excel</button>${Regras.pode('owner') ? `<button class="btn btn-sec" data-action="backup-json">${ico('download')}Backup completo (JSON)</button>` : ''}</div>
    <p class="hint" style="margin:10px 0 0">O backup busca no servidor <b>todo</b> o histórico da unidade (não só o período carregado no aparelho). Fotos não entram no arquivo: ficam no bucket.</p></section>
  <section class="card pad" style="margin-top:12px"><h2 style="font-size:16px">Uso do plano gratuito</h2>
    <p class="hint">Gravado diariamente pelo heartbeat (Cloudflare Worker). Limites do plano Free: banco 500 MB · armazenamento 1 GB.</p>
    ${uso ? (uso.length ? `<div class="kpis kpis-4">${Comp.kpi('Banco de dados', uso[0].banco_mb + ' MB', Util.pct(uso[0].banco_mb, 500) + '% de 500 MB', uso[0].banco_mb > 400 ? 'var(--red)' : '')}${Comp.kpi('Fotos', uso[0].fotos_mb + ' MB', Util.pct(uso[0].fotos_mb, 1024) + '% de 1 GB', uso[0].fotos_mb > 800 ? 'var(--red)' : '')}${Comp.kpi('Quantidade de fotos', uso[0].fotos_qtd)}${Comp.kpi('Último heartbeat', Util.fmtData(uso[0].dia))}</div>` : '<p class="hint">Sem registros: confira se o heartbeat está ativo (DEPLOY, Parte D).</p>') : `<button class="btn btn-sec btn-sm" data-action="uso-ver">${ico('chart')}Consultar uso</button>`}
  </section>`;
};

/* ---------------- planilha → itens ---------------- */
async function lerPlanilha(file) {
  if (!window.XLSX) await new Promise((ok, er) => { const sc = document.createElement('script'); sc.src = '/vendor/xlsx.mini.min.js'; sc.onload = ok; sc.onerror = er; document.head.appendChild(sc); });
  const wb = window.XLSX.read(await file.arrayBuffer(), { type: 'array' });
  const linhas = window.XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { defval: '' });
  const itens = [], erros = [], cats = Store.categorias().map(c => c.chave);
  linhas.forEach((r, k) => {
    const L = {}; for (const [kk, v] of Object.entries(r)) L[Util.norm(kk).trim().replace(/\s+/g, '_')] = typeof v === 'string' ? v.trim() : v;
    const n = k + 2, cat = Util.norm(L.categoria);
    if (!L.codigo) { if (Object.values(L).some(v => v !== '')) erros.push(`linha ${n}: sem código`); return; }
    if (!cats.includes(cat)) { erros.push(`linha ${n} (${L.codigo}): categoria “${L.categoria}” inválida`); return; }
    if (!L.gerencia) { erros.push(`linha ${n} (${L.codigo}): sem gerência`); return; }
    let n2 = String(L.n2 || ''); if (/^\d{2}\/\d{4}$/.test(n2)) n2 = n2.slice(3) + '-' + n2.slice(0, 2);
    if (n2 && !/^\d{4}-\d{2}$/.test(n2)) { erros.push(`linha ${n} (${L.codigo}): N2 “${L.n2}” fora do formato AAAA-MM`); return; }
    const n3 = L.n3 ? Number(L.n3) : null; if (n3 && (n3 < 1990 || n3 > 2100)) { erros.push(`linha ${n} (${L.codigo}): N3 inválido`); return; }
    itens.push({ codigo: String(L.codigo).toUpperCase(), categoria: cat, gerencia: String(L.gerencia).toUpperCase(), sigla: String(L.sigla || L.gerencia.slice(0, 3)).toUpperCase(), area: String(L.area || ''), local: String(L.local || ''), subtipo: String(L.subtipo || ''), capacidade: String(L.capacidade || ''), numero_cilindro: String(L.numero_cilindro || ''), agente: String(L.agente || ''), n2, n3, requer_conferencia: /^(sim|s|true|1)$/i.test(String(L.requer_conferencia)), dados: { origem: { aba: file.name, linha: n, ...(L.observacao ? { observacao: String(L.observacao) } : {}) }, ...(L.responsavel ? { responsavel: String(L.responsavel) } : {}) } });
  });
  const cad = new Set(Store.agentes()), avisos = itens.filter(i => i.agente && !cad.has(i.agente)).map(i => [file.name, i.dados.origem.linha, i.codigo, `Agente “${i.agente}” não está cadastrado em Administração → Agentes extintores`]);
  return { nome: file.name, itens, erros, avisos };
}

/* ---------------- ações ---------------- */
let tA;
Object.assign(A.Inputs, {
  'cat-item': el => { A.tmp.catIts[Number(el.dataset.i)].l = el.value; },
  'cat-na': el => { A.tmp.catIts[Number(el.dataset.i)].na = el.checked; },
  'adm-q': el => { A.tmp.adm.q = el.value; clearTimeout(tA); tA = setTimeout(() => { document.getElementById('adm-list').innerHTML = V.admPontosLista(); }, 150); },
  'adm-cat': el => { A.tmp.adm.cat = el.value; document.getElementById('adm-list').innerHTML = V.admPontosLista(); },
  etq: el => { A.tmp.etq[el.dataset.k] = el.value; V.dlgEtiquetas(); },
  'etq-pular': el => { A.tmp.etq.pular = Math.max(0, Number(el.value) || 0); },
  aud: el => { A.tmp.aud[el.dataset.k] = el.value; A.render(); },
  'aud-q': el => { A.tmp.aud.q = el.value; clearTimeout(tA); tA = setTimeout(() => { const pos = el.selectionStart; A.render(); const n = document.querySelector('[data-input="aud-q"]'); if (n) { n.focus(); n.setSelectionRange(pos, pos); } }, 300); },
  'imp-file': async el => { const f = el.files[0]; if (!f) return; try { A.tmp.imp = await lerPlanilha(f); document.getElementById('imp-prev').innerHTML = V.impPrevia(A.tmp.imp); } catch (e) { UI.toast('Não foi possível ler a planilha: ' + e.message); } el.value = ''; }
});
Object.assign(A.Acoes, {
  'adm-inativos': () => { A.tmp.adm.inativos = !A.tmp.adm.inativos; A.render(); },
  'pt-novo': () => { if (online()) V.dlgPonto(null); },
  'etq-abrir': () => V.dlgEtiquetas(),
  'etq-imprimir': () => { const l = V.etqLista(), st = A.tmp.etq; QR.imprimir(l, { modelo: st.modelo, pular: st.pular, aoImprimir: () => A.marcarImpressas(l.map(e => e.id)) }); UI.fechar(); UI.toast('As etiquetas serão marcadas como impressas quando você clicar em Imprimir.', 5000); },
  'aud-xlsx': () => Rel.excel('inspec_alteracoes_' + Util.hojeISO(), Rel.rastreioAbas(A.tmp.aud)),
  'user-novo': () => { if (online()) V.dlgUsuario(null); },
  'user-editar': el => { if (online()) V.dlgUsuario(Store.S.membros.find(m => m.id === el.dataset.id)); },
  'user-salvar': async el => {
    const S = Store.S, id = el.dataset.id, err = document.getElementById('us-err'), nome = document.getElementById('us-nome').value.trim(), papel = document.getElementById('us-papel').value;
    const unidades = [...document.querySelectorAll('.us-unid:checked')].map(x => x.value);
    if (nome.length < 3) { err.textContent = 'Informe o nome completo.'; return; }
    await UI.ocupado(el, async () => {
      try {
        if (!id) {
          const email = document.getElementById('us-email').value.trim().toLowerCase();
          if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { err.textContent = 'Informe um e-mail válido.'; return; }
          if (!unidades.length) { err.textContent = 'Marque ao menos uma unidade.'; return; }
          const r = await funcao('criar-usuario', { org_id: S.org.id, email, nome, papel, unidades });
          UI.dialogo({ titulo: 'Usuário criado', corpo: `<div class="notice n-ok" style="margin:0 0 12px">${ico('check')}<div><b>${esc(nome)}</b> já pode entrar no Inspec.</div></div><dl class="kv"><dt>Endereço</dt><dd>${esc(location.origin)}</dd><dt>Login</dt><dd>${esc(email)}</dd><dt>Senha provisória</dt><dd><code style="font-size:16px;letter-spacing:.05em">${esc(r.senha_inicial)}</code></dd></dl><p class="hint">Repasse pessoalmente ou por um canal seguro. A troca de senha é obrigatória no 1º acesso. Esta senha não será mostrada de novo.</p>`, rodape: `<button class="btn btn-sec" data-action="copiar" data-t="${esc(`Inspec: ${location.origin}\nLogin: ${email}\nSenha provisória: ${r.senha_inicial}`)}">Copiar dados</button><button class="btn btn-pri" data-action="fechar-dlg">Concluir</button>` });
        } else {
          const m = S.membros.find(x => x.id === id), ativo = document.getElementById('us-ativo').checked;
          const { error } = await sb.from('membros').update({ nome, papel, ativo }).eq('id', id); if (error) throw error;
          if (document.querySelector('.us-unid')) {
            const atuais = m.unidades, rem = atuais.filter(u => !unidades.includes(u)), add = unidades.filter(u => !atuais.includes(u));
            if (rem.length) { const { error: e1 } = await sb.from('membro_unidades').delete().eq('membro_id', id).in('unidade_id', rem); if (e1) throw e1; }
            if (add.length) { const { error: e2 } = await sb.from('membro_unidades').insert(add.map(u => ({ membro_id: id, unidade_id: u }))); if (e2) throw e2; }
          }
          UI.fechar(); UI.toast('Usuário atualizado.');
        }
        await A.Sync.recarregar(true);
      } catch (e) { err.textContent = msgErro(e); }
    });
  },
  'user-del': async el => {
    const m = Store.S.membros.find(x => x.id === el.dataset.id);
    if (!await UI.confirmar({ titulo: `Excluir ${esc(m.nome)}`, texto: 'O login é removido definitivamente. Inspeções, trocas e alterações feitas por esta pessoa continuam no histórico. Para apenas suspender o acesso, use “Acesso liberado” desmarcado.', ok: 'Excluir login', perigo: true })) return;
    try { await funcao('excluir-usuario', { org_id: Store.S.org.id, usuario_id: m.usuario_id }); await A.Sync.recarregar(true); UI.toast('Login excluído.'); } catch (e) { UI.toast(msgErro(e)); }
  },
  copiar: async el => { try { await navigator.clipboard.writeText(el.dataset.t); UI.toast('Copiado.'); } catch (e) { UI.toast('Não foi possível copiar.'); } },
  'vinc-abrir': () => { if (online()) V.dlgVincular(); },
  'vinc-ok': async el => {
    const mapa = {}; document.querySelectorAll('select.vinc').forEach(s => { mapa[s.dataset.nome] = s.value; });
    await UI.ocupado(el, async () => { try { const n = await rpc('vincular_responsaveis', { p_org: Store.S.org.id, p_mapa: mapa }); UI.fechar(); await A.Sync.recarregar(true); UI.toast(`${Util.plural(n, 'ponto atualizado', 'pontos atualizados')}.`); } catch (e) { document.getElementById('vc-err').textContent = msgErro(e); } });
  },
  'ger-nova': () => { if (online()) V.dlgGer(null); },
  'ger-editar': el => { if (online()) V.dlgGer(Store.ger(el.dataset.id)); },
  'ger-salvar': async el => {
    const nome = document.getElementById('gr-nome').value.trim().toUpperCase(), sigla = document.getElementById('gr-sigla').value.trim().toUpperCase(), err = document.getElementById('gr-err');
    if (nome.length < 2 || sigla.length < 2) { err.textContent = 'Informe nome e sigla.'; return; }
    await UI.ocupado(el, async () => {
      const S = Store.S, q = el.dataset.id ? sb.from('gerencias').update({ nome, sigla }).eq('id', el.dataset.id) : sb.from('gerencias').insert({ org_id: S.org.id, unidade_id: S.unidade.id, nome, sigla });
      const { error } = await q; if (error) { err.textContent = msgErro(error); return; }
      UI.fechar(); await A.Sync.recarregar(true); UI.toast('Gerência salva.');
    });
  },
  'cat-nova': () => { if (online()) V.dlgCat(null); },
  'cat-editar': el => { if (online()) V.dlgCat(Store.S.cats.find(c => c.id === el.dataset.id)); },
  'cat-icone': el => { A.tmp.catIcone = el.dataset.v; document.querySelectorAll('#ct-icones .chip').forEach(b => b.setAttribute('aria-pressed', b.dataset.v === el.dataset.v)); },
  'cat-item-add': () => { A.tmp.catIts.push({ l: '', na: false }); renderItens(); document.querySelector(`[data-input="cat-item"][data-i="${A.tmp.catIts.length - 1}"]`)?.focus(); },
  'cat-item-del': el => { A.tmp.catIts.splice(Number(el.dataset.i), 1); renderItens(); },
  'cat-salvar': async el => {
    const g = id => document.getElementById(id), err = g('ct-err'), id = el.dataset.id, c = id && Store.S.cats.find(x => x.id === id);
    const nome = g('ct-nome').value.trim(), plural = g('ct-plural').value.trim() || nome, per = g('ct-per').value, prefixo = g('ct-pref').value.trim().toUpperCase() || null;
    if (nome.length < 3) { err.textContent = 'Informe o nome da categoria.'; return; }
    if (Store.S.cats.some(x => Util.norm(x.nome) === Util.norm(nome) && x.id !== id)) { err.textContent = 'Já existe uma categoria com este nome.'; return; }
    const padrao = c && PADRAO.includes(c.chave);
    const its = A.tmp.catIts.map(i => ({ ...i, l: i.l.trim() })).filter(i => i.l);
    if (!padrao && !its.length) { err.textContent = 'Adicione ao menos um item ao checklist.'; return; }
    const checklist = padrao ? c.checklist : { ...(c?.checklist || {}), itens: its.map((i, n) => ({ k: i.k || slug(i.l) + '_' + n, l: i.l, na: i.na })) };
    const row = { nome, nome_plural: plural, periodicidade: per, prefixo, icone: A.tmp.catIcone, checklist };
    await UI.ocupado(el, async () => {
      let q;
      if (c) q = sb.from('categorias').update(row).eq('id', c.id);
      else { let chave = slug(nome); while (Store.S.cats.some(x => x.chave === chave)) chave += '_x'; q = sb.from('categorias').insert({ ...row, org_id: Store.S.org.id, chave, ordem: Math.max(0, ...Store.S.cats.map(x => x.ordem || 0)) + 1 }); }
      const { error } = await q; if (error) { err.textContent = msgErro(error); return; }
      UI.fechar(); await A.Sync.recarregar(true); UI.toast('Categoria salva.');
    });
  },
  'cat-excluir': async el => {
    if (!online()) return;
    const c = Store.S.cats.find(x => x.id === el.dataset.id), n = Store.S.pontos.filter(p => p.cat === c.chave).length;
    if (n) {
      if (!await UI.confirmar({ titulo: `Categoria “${esc(c.nome)}” em uso`, texto: `Há ${n} ponto(s) desta categoria, então ela não pode ser excluída (o histórico deles seria perdido). Deseja <b>${c.ativo === false ? 'reativar' : 'inativar'}</b> a categoria? ${c.ativo === false ? '' : 'Ela some das listas e dos filtros, mas os pontos e o histórico são mantidos.'}`, ok: c.ativo === false ? 'Reativar' : 'Inativar', perigo: c.ativo !== false })) return;
      const { error } = await sb.from('categorias').update({ ativo: c.ativo === false }).eq('id', c.id); if (error) return UI.toast(msgErro(error));
    } else {
      if (!await UI.confirmar({ titulo: `Excluir “${esc(c.nome)}”`, texto: 'A categoria não tem pontos e será excluída.', ok: 'Excluir', perigo: true })) return;
      const { error } = await sb.from('categorias').delete().eq('id', c.id); if (error) return UI.toast(msgErro(error));
    }
    await A.Sync.recarregar(true); UI.toast('Categoria atualizada.');
  },
  'agt-novo': () => { if (online()) V.dlgAgente(null); },
  'agt-editar': el => { if (online()) V.dlgAgente(Store.S.agentes.find(a => a.id === el.dataset.id)); },
  'agt-salvar': async el => {
    const nome = document.getElementById('ag-nome').value.trim().replace(/\s+/g, ' '), err = document.getElementById('ag-err'), id = el.dataset.id;
    if (nome.length < 2) { err.textContent = 'Informe o nome do agente.'; return; }
    if (/^outr[oa]s?$/i.test(nome)) { err.textContent = 'Cadastre o agente específico (o sistema não usa a opção "Outra").'; return; }
    if (Store.S.agentes.some(a => a.nome.toLowerCase() === nome.toLowerCase() && a.id !== id)) { err.textContent = 'Este agente já está cadastrado.'; return; }
    await UI.ocupado(el, async () => {
      try {
        if (id) await rpc('renomear_agente', { p_id: id, p_nome: nome });
        else { const { error } = await sb.from('agentes').insert({ org_id: Store.S.org.id, nome }); if (error) throw error; }
        UI.fechar(); await A.Sync.recarregar(true); UI.toast('Agente salvo.');
      } catch (e) { err.textContent = msgErro(e); }
    });
  },
  'agt-excluir': async el => {
    if (!online()) return;
    const a = Store.S.agentes.find(x => x.id === el.dataset.id), n = Store.S.pontos.filter(p => p.agente === a.nome).length;
    if (!await UI.confirmar({ titulo: `Excluir “${esc(a.nome)}”`, texto: n ? `${n} ponto(s) estão com este agente. Eles mantêm o valor atual, mas o agente deixa de aparecer nas listas para novas inspeções, trocas e cadastros. Prefira <b>Editar</b> se a ideia é corrigir o nome.` : 'O agente deixa de aparecer nas listas.', ok: 'Excluir', perigo: true })) return;
    const { error } = await sb.from('agentes').delete().eq('id', a.id); if (error) return UI.toast(msgErro(error));
    await A.Sync.recarregar(true); UI.toast('Agente excluído.');
  },
  'zerar-abrir': () => {
    if (!online() || !Regras.pode('owner')) return;
    UI.dialogo({ titulo: 'Zerar o sistema', corpo: `<div class="notice n-red" style="margin:0 0 12px">${ico('alert')}<div><b>Ação definitiva.</b> Serão apagados ${Store.S.pontos.length} pontos e todo o histórico da organização (todas as unidades): inspeções, fotos, desvios, trocas, reserva, QR e auditoria. Usuários são mantidos.</div></div>
      <label class="checkline"><input type="checkbox" id="zr-cfg"> Apagar também as configurações (gerências, destinatários, agentes e categorias — categorias e agentes voltam ao padrão)</label>
      <label class="field" style="margin-top:10px"><span>Para confirmar, digite <b>ZERAR</b></span><input class="input" id="zr-txt" autocomplete="off" style="text-transform:uppercase"></label>
      <div class="err" id="zr-err" role="alert"></div><p class="hint" id="zr-prog"></p>`,
      rodape: `<button class="btn btn-sec" data-action="fechar-dlg">Cancelar</button><button class="btn btn-danger" data-action="zerar-ok">${ico('alert')}Zerar definitivamente</button>` });
  },
  'zerar-ok': async el => {
    const txt = document.getElementById('zr-txt').value.trim().toUpperCase(), err = document.getElementById('zr-err'), prog = document.getElementById('zr-prog');
    if (txt !== 'ZERAR') { err.textContent = 'Digite ZERAR para confirmar.'; return; }
    await UI.ocupado(el, async () => {
      try {
        prog.textContent = 'Apagando as fotos do armazenamento…';
        const fotos = await todos(() => sb.from('fotos').select('path').eq('org_id', Store.S.org.id));
        for (let i = 0; i < fotos.length; i += 100) { await sb.storage.from('fotos').remove(fotos.slice(i, i + 100).map(f => f.path)); prog.textContent = `Apagando fotos… ${Math.min(i + 100, fotos.length)} de ${fotos.length}`; }
        prog.textContent = 'Apagando os dados…';
        const r = await rpc('zerar_sistema', { p_org: Store.S.org.id, p_confirmacao: 'ZERAR', p_configuracoes: document.getElementById('zr-cfg').checked });
        const { IDB } = await import('../dados.js'); await IDB.limpar();
        UI.fechar(); A.tmp = {}; A.galeriaInvalidar?.();
        await A.Sync.recarregar(true); location.hash = '#/admin/importacao';
        UI.toast(`Sistema zerado: ${r.pontos} pontos e ${r.inspecoes} inspeções apagados. Comece pela carga dos pontos.`, 7000);
      } catch (e) { err.textContent = msgErro(e); prog.textContent = ''; }
    });
  },
  'res-mov': () => { if (online()) V.dlgReserva(); },
  'res-ok': async el => {
    const g = id => document.getElementById(id), qtd = Number(g('rs-qtd').value), min = g('rs-min').value, err = g('rs-err');
    if (!Number.isInteger(qtd) || qtd < 0) { err.textContent = 'Quantidade inválida.'; return; }
    await UI.ocupado(el, async () => { try { await rpc('movimentar_reserva', { p_unidade: Store.S.unidade.id, p_agente: g('rs-ag').value, p_tipo: g('rs-tipo').value, p_qtd: qtd, p_obs: g('rs-obs').value.trim() || null, p_minimo: min === '' ? null : Number(min) }); UI.fechar(); await A.Sync.recarregar(true); UI.toast('Reserva atualizada.'); } catch (e) { err.textContent = msgErro(e); } });
  },
  'dst-novo': () => { if (online()) V.dlgDest(null); },
  'dst-editar': el => { if (online()) V.dlgDest(Store.S.dests.find(d => d.id === el.dataset.id)); },
  'dst-salvar': async el => {
    const g = id => document.getElementById(id), err = g('ds-err'), S = Store.S;
    const row = { papel: g('ds-papel').value.trim(), nome: g('ds-nome').value.trim(), email: g('ds-email').value.trim().toLowerCase(), gerencia_id: g('ds-ger').value || null, ativo: g('ds-ativo').checked };
    if (row.papel.length < 3 || row.nome.length < 2 || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(row.email)) { err.textContent = 'Preencha papel, nome e um e-mail válido.'; return; }
    await UI.ocupado(el, async () => {
      const q = el.dataset.id ? sb.from('destinatarios').update(row).eq('id', el.dataset.id) : sb.from('destinatarios').insert({ ...row, org_id: S.org.id, unidade_id: S.unidade.id });
      const { error } = await q; if (error) { err.textContent = msgErro(error); return; }
      UI.fechar(); await A.Sync.recarregar(true); UI.toast('Destinatário salvo.');
    });
  },
  'dst-del': async el => { if (!await UI.confirmar({ titulo: 'Excluir destinatário', texto: 'Ele deixará de receber os próximos One Pages.', ok: 'Excluir', perigo: true })) return; const { error } = await sb.from('destinatarios').delete().eq('id', el.dataset.id); if (error) return UI.toast(msgErro(error)); await A.Sync.recarregar(true); },
  'imp-carga': async el => { await UI.ocupado(el, async () => { const r = await fetch('/data/carga_inicial.json', { cache: 'no-store' }); const j = await r.json(); A.tmp.imp = { nome: 'Carga inicial — Equipamentos_de_emergência.xlsx', itens: j.pontos, erros: [], avisos: j.avisos || [] }; document.getElementById('imp-prev').innerHTML = V.impPrevia(A.tmp.imp); document.getElementById('imp-prev').scrollIntoView({ behavior: 'smooth' }); }); },
  'imp-cancelar': () => { A.tmp.imp = null; document.getElementById('imp-prev').innerHTML = ''; },
  'imp-modelo': async () => { await Rel.excel('inspec_modelo_importacao', [{ nome: 'Pontos', head: COLS_MODELO, rows: [['ACI-999', 'extintor', 'ACIARIA', 'ACI', 'PÁTIO DE SUCATA', 'Próximo à balança', 'CO2 6 kg', '6 kg', '55123', 'CO₂ 6kg', '2026-09', 2029, 'Glauco Gonçalves', 'não', ''], ['HID-999', 'hidrante', 'ACIARIA', 'ACI', 'PÁTIO DE SUCATA', 'Coluna 12', 'Hidrante', '', '', '', '', '', '', 'não', '']] }]); },
  'imp-confirmar': async el => {
    if (!online()) return;
    const S = Store.S, existentes = new Set(S.pontos.map(p => p.codigo.toUpperCase()));
    const novos = A.tmp.imp.itens.filter(i => !existentes.has(String(i.codigo).toUpperCase())), prog = document.getElementById('imp-prog');
    let tot = { novos: 0, existentes: 0, erros: [] };
    await UI.ocupado(el, async () => {
      try {
        for (let i = 0; i < novos.length; i += 150) {
          const r = await rpc('importar_pontos', { p_unidade: S.unidade.id, p_itens: novos.slice(i, i + 150) });
          tot.novos += r.novos; tot.existentes += r.existentes; tot.erros.push(...r.erros);
          prog.innerHTML = `<p class="hint" style="margin-top:10px"><span class="spin" aria-hidden="true"></span>Gravando… ${Math.min(i + 150, novos.length)} de ${novos.length}</p>`;
        }
        A.tmp.imp = null; await A.Sync.recarregar(true);
        UI.dialogo({ titulo: 'Importação concluída', corpo: `<div class="notice n-ok" style="margin:0 0 10px">${ico('check')}<div><b>${tot.novos} pontos cadastrados</b>, cada um com QR único. ${tot.existentes ? `${tot.existentes} já existiam e foram preservados.` : ''}</div></div>${tot.erros.length ? `<div class="notice n-red">${ico('alert')}<div>${tot.erros.length} com erro: ${esc(tot.erros.slice(0, 6).map(e => `${e.codigo}: ${e.erro}`).join(' · '))}</div></div>` : ''}<p class="hint">Próximos passos: criar os usuários da equipe, <b>vincular responsáveis</b> e imprimir as <b>etiquetas QR</b>.</p>`, rodape: `<a class="btn btn-sec" href="#/admin/equipe">Equipe</a><a class="btn btn-pri" href="#/admin/pontos">Etiquetas QR</a>` });
      } catch (e) { prog.innerHTML = `<div class="notice n-red" style="margin-top:10px">${ico('alert')}<div>${esc(msgErro(e))} — ${tot.novos} já gravados. Pode clicar em importar de novo: nada é duplicado.</div></div>`; }
    });
  },
  'cfg-foto': async el => {
    if (!online()) return; const S = Store.S, cfg = { ...S.org.config, regra_foto: el.dataset.v };
    const { error } = await sb.from('organizacoes').update({ config: cfg }).eq('id', S.org.id); if (error) return UI.toast(msgErro(error));
    S.org.config = cfg; Store.salvarCache(); A.render(); UI.toast('Regra de foto atualizada.');
  },
  'org-nome': async () => { if (!online()) return; const v = await UI.confirmar({ titulo: 'Renomear organização', texto: '', ok: 'Salvar', campo: { rotulo: 'Nome', min: 3, valor: Store.S.org.nome, max: 120 } }); if (!v) return; const { error } = await sb.from('organizacoes').update({ nome: v }).eq('id', Store.S.org.id); if (error) return UI.toast(msgErro(error)); await A.Sync.recarregar(true); },
  'unid-nova': async () => { if (!online()) return; const v = await UI.confirmar({ titulo: 'Nova unidade', texto: 'Cada unidade tem seus pontos, gerências e reserva. Owner e administradores enxergam todas.', ok: 'Criar', campo: { rotulo: 'Nome da unidade', min: 2, max: 120 } }); if (!v) return; const { error } = await sb.from('unidades').insert({ org_id: Store.S.org.id, nome: v }); if (error) return UI.toast(msgErro(error)); await A.Sync.recarregar(true); UI.toast('Unidade criada. Troque de unidade pelo Menu.'); },
  'uso-ver': async () => { if (!online()) return; const { data, error } = await sb.from('uso_diario').select('*').order('dia', { ascending: false }).limit(30); if (error) return UI.toast(msgErro(error)); A.tmp.uso = data; A.render(); },
  'backup-xlsx': async el => {
    if (!online()) return;
    await UI.ocupado(el, async () => {
      const b = await baixarTudo(), S = Store.S, nomeP = id => b.pontos.find(p => p.id === id)?.codigo || id;
      const obj = (rows, nome) => { const cols = rows.length ? Object.keys(rows[0]) : ['vazio']; return { nome, head: cols, rows: rows.map(r => cols.map(c => typeof r[c] === 'object' && r[c] !== null ? JSON.stringify(r[c]) : r[c])) }; };
      await Rel.excel(`inspec_backup_${S.unidade.nome}_${Util.hojeISO()}`, [obj(b.pontos, 'pontos'), obj(b.inspecoes.map(i => ({ ponto: nomeP(i.ponto_id), ...i })), 'inspecoes'), obj(b.trocas, 'trocas'), obj(b.alteracoes, 'alteracoes'), obj(b.desvios, 'desvios'), obj(b.reserva, 'reserva'), obj(b.movimentos, 'movimentos'), obj(b.gerencias, 'gerencias'), obj(b.membros, 'membros'), obj(b.fotos, 'fotos')]);
      try { localStorage.setItem('inspec-ultimo-backup', new Date().toISOString()); } catch (e) { /* ignore */ }
      A.render();
    });
  },
  'backup-json': async el => {
    if (!online() || !Regras.pode('owner')) return;
    await UI.ocupado(el, async () => {
      const b = await baixarTudo();
      evento('app.backup', { rotulo: 'Backup JSON', registros: Object.values(b).reduce((a, x) => a + x.length, 0) });
      Util.baixar(`inspec_backup_${Util.hojeISO()}.json`, JSON.stringify({ geradoEm: new Date().toISOString(), versao: 1, org: Store.S.org, unidade: Store.S.unidade, ...b }), 'application/json');
      try { localStorage.setItem('inspec-ultimo-backup', new Date().toISOString()); } catch (e) { /* ignore */ }
      A.render();
    });
  }
});
async function baixarTudo() {
  const U = Store.S.unidade.id, org = Store.S.org.id;
  const [pontos, inspecoes, trocas, alteracoes, desvios, reserva, movimentos, gerencias, membros, fotos, destinatarios, qr_historico] = await Promise.all([
    todos(() => sb.from('pontos').select('*').eq('unidade_id', U).order('codigo')),
    todos(() => sb.from('inspecoes').select('*').eq('unidade_id', U).order('data_inspecao')),
    todos(() => sb.from('trocas').select('*').eq('unidade_id', U).order('criado_em')),
    todos(() => sb.from('alteracoes').select('*').eq('unidade_id', U).order('id')),
    todos(() => sb.from('desvios').select('*').eq('unidade_id', U).order('acionado_em')),
    todos(() => sb.from('reserva_estoque').select('*').eq('unidade_id', U)),
    todos(() => sb.from('reserva_movimentos').select('*').eq('unidade_id', U).order('id')),
    todos(() => sb.from('gerencias').select('*').eq('unidade_id', U)),
    todos(() => sb.from('membros').select('id, usuario_id, nome, papel, ativo, criado_em').eq('org_id', org)),
    todos(() => sb.from('fotos').select('*').eq('unidade_id', U)),
    todos(() => sb.from('destinatarios').select('*').eq('org_id', org)),
    todos(() => sb.from('qr_historico').select('*').eq('org_id', org))
  ]);
  return { pontos, inspecoes, trocas, alteracoes, desvios, reserva, movimentos, gerencias, membros, fotos, destinatarios, qr_historico };
}
