/* Inspec — Não conformidades abertas */
import { A } from '../ns.js';
import { Store, Regras } from '../dados.js';
import { Comp } from '../ui.js';
import { ico, esc, Util } from '../util.js';

A.V.ncs = (q) => {
  const cat = q.get('cat') || '', ger = A.Escopo.ger, agora = new Date();
  const lista = Regras.ncsAbertas(ger).filter(x => !cat || x.e.cat === cat);
  let fechadas = 0, somaDias = 0;
  for (const e of Store.S.pontos) {
    const v = Store.inspecoesDe(e.id).filter(i => !i.anulada).slice().reverse();
    for (let k = 1; k < v.length; k++) if (v[k].st === 'ok' && v[k - 1].st === 'nc' && Util.diasEntre(v[k].dt, agora) <= 30) { fechadas++; somaDias += Math.max(0, Util.diasEntre(v[k - 1].dt, v[k].dt)); }
  }
  return `
  <div class="kpis" style="grid-template-columns:repeat(3,1fr)">
    ${Comp.kpi('Abertas', lista.length, '', 'var(--red)')}${Comp.kpi('Fechadas (30 dias)', fechadas)}${Comp.kpi('Tempo médio p/ fechar', `${fechadas ? Math.round(somaDias / fechadas) : 0}<span style="font-size:14px"> dias</span>`)}
  </div>
  <div class="toolbar">${Comp.selectCategoria('f-cat-ncs', cat)}${Comp.selectGerencia('f-ger-ncs', ger)}</div>
  ${lista.length ? `<div class="list">${lista.map(({ e, s, desde }) => { const dias = Util.diasEntre(desde, agora), nf = Store.fotosDe(s.ultima.id).length; return `
    <div class="row" style="align-items:flex-start">
      <span class="ic" style="background:var(--red-bg);color:var(--red)">${ico(Store.cat(e.cat).icone)}</span>
      <span class="body"><span class="l1"><span class="code">${esc(e.codigo)}</span><span class="tag ${dias > 7 ? 't-lost' : 't-nc'}">há ${Util.plural(dias, 'dia')}</span>${nf ? `<span class="tag t-pend">${ico('camera')}${nf}</span>` : ''}</span>
        <span class="l2" style="white-space:normal"><b>${esc(Regras.textoNC(s.ultima))}</b></span>
        <span class="l3">${esc(Store.ger(e.ger).sigla)} › ${esc(e.local || e.area)} · por ${esc(Store.usuario(s.ultima.ins).nome)}</span>
        <span class="chips" style="margin-top:8px">${Regras.pode('inspecionar') ? `<a class="btn btn-pri btn-sm" href="#/inspecao/${e.id}?de=nc">Reinspecionar</a><a class="btn btn-sec btn-sm" href="#/desvio/novo?eq=${e.id}&origem=inspecao">${ico('headset')}Desvio</a>` : ''}<a class="btn btn-sec btn-sm" href="#/ponto/${e.id}">Ficha</a></span>
      </span></div>`; }).join('')}</div>` : Comp.vazio('check', 'Nenhuma não conformidade aberta', 'Quando uma inspeção for marcada como “Não conforme”, ela aparece aqui até o ponto ser reinspecionado como conforme.')}`;
};
Object.assign(A.Inputs, {
  'f-cat-ncs': el => { location.hash = `#/ncs?cat=${el.value}`; },
  'f-ger-ncs': el => { A.Escopo.ger = el.value; A.render(); }
});
