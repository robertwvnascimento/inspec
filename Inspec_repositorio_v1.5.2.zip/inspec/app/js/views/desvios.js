/* Inspec — Comunicado de desvio: registro em 7 etapas, lista, detalhe, One Page (PDF) e e-mail */
import { A } from '../ns.js';
import { Store, Regras, Fila, Fotos } from '../dados.js';
import { rpc, funcao, msgErro, evento } from '../db.js';
import { UI, Comp, Busca, Cal } from '../ui.js';
import { thumbsFotos } from './ponto.js';
import { abrirDocumento } from '../janela.js';
import { ico, esc, Util, Ciclos, Periodo, GATILHOS, ACIONADORES, MEIOS, COR, LOGO } from '../util.js';

const V = A.V;
const loc = d => new Date(d.getTime() - d.getTimezoneOffset() * 60e3).toISOString().slice(0, 16);
const papeisDest = (e) => [...new Set(Store.S.dests.filter(d => d.ativo && (!d.unidade_id || d.unidade_id === Store.S.unidade.id) && (!e || !d.gerencia_id || d.gerencia_id === e.ger)).map(d => d.papel))];
const estoque = ag => Store.S.reserva.find(r => r.agente === ag)?.quantidade ?? 0;
export const tempoResp = d => d.origem === 'producao' ? Math.max(0, Math.round((new Date(d.chegada_em) - new Date(d.acionado_em)) / 60e3)) : null;

const D = {
  novo(q) {
    const agora = new Date(), antes = new Date(agora.getTime() - 12 * 60e3), eq = q.get('eq') || '';
    return { eq, origem: q.get('origem') || 'producao', gatilho: q.get('gatilho') || '', papel: '', acionNome: '', meio: '', dtAcion: loc(antes), dtChegada: loc(agora), localOk: false,
      descricao: '', substituir: null, reserva: null, instFab: '', instN2: Ciclos.mensal(agora), cobertura: false, acao: '', pendencias: '', fotos: [], dest: papeisDest(eq && Store.eq(eq)), busca: '', insp: q.get('insp') || '' };
  },
  faltas(f) {
    const m = [], e = f.eq && Store.eq(f.eq);
    if (!f.gatilho) m.push('Escolha o gatilho.');
    if (f.origem === 'producao') { if (!f.papel) m.push('Informe quem acionou.'); if (!f.meio) m.push('Informe o meio de comunicação.'); if (new Date(f.dtChegada) < new Date(f.dtAcion)) m.push('A chegada não pode ser antes do acionamento.'); }
    if (new Date(f.dtChegada) > new Date(Date.now() + 5 * 60e3)) m.push('A data/hora não pode estar no futuro.');
    if (!e) m.push('Selecione o ponto.');
    if (!f.localOk) m.push('Confirme o local e o equipamento.');
    if ((f.descricao || '').trim().length < 5) m.push('Descreva objetivamente a situação encontrada.');
    if (f.substituir === null) m.push('Informe se há necessidade de substituição/recomposição.');
    if (f.substituir && !f.reserva) m.push('Verifique a reserva técnica (disponível ou não).');
    if (f.substituir && f.reserva === 'usada') { if (e && e.cat === 'extintor' && !f.instFab.trim()) m.push('Informe o nº do cilindro instalado.'); if (!f.cobertura) m.push('Confirme que a cobertura de emergência foi restabelecida.'); }
    if ((f.acao || '').trim().length < 5 && !(f.substituir && f.reserva)) m.push('Descreva a ação executada.');
    if (!f.dest.length && papeisDest(e).length) m.push('Escolha ao menos um destinatário do comunicado.');
    return m;
  }
};

V.desvioNovo = (q) => {
  if (!Regras.pode('inspecionar')) return Comp.vazio('shield', 'Somente bombeiros registram comunicados de desvio', 'Seu perfil é de consulta.');
  const f = A.tmp.desvio && (!q.get('eq') || A.tmp.desvio.eq === q.get('eq')) ? A.tmp.desvio : (A.tmp.desvio = D.novo(q));
  return `<nav class="steps" aria-label="Etapas do fluxo">${['Origem', 'Acionamento', 'Ponto', 'Avaliação', 'Reserva técnica', 'Ação e evidências', 'Comunicado'].map((n, i) => `<span class="step ${i === 0 ? 'on' : ''}"><b>${i + 1}</b>${n}</span>`).join('')}</nav>
  <form id="form-desvio" novalidate><div id="dv-corpo">${V.dvCorpo(f)}</div><div class="err" id="dv-err" role="alert"></div>
  <div class="save-bar"><button type="submit" class="btn btn-pri btn-block" id="dv-btn">${ico('check')}Salvar comunicado de desvio</button></div></form>`;
};
V.dvCorpo = (f) => {
  const e = f.eq && Store.eq(f.eq), seg = (acao, v, ops) => `<div class="seg neutral" role="radiogroup">${ops.map(([k, n]) => `<button type="button" data-action="${acao}" data-v="${k}" role="radio" aria-pressed="${v === k}" aria-checked="${v === k}">${n}</button>`).join('')}</div>`;
  const ext = !e || e.cat === 'extintor', est = e && ext ? estoque(e.agente || '') : 1;
  const resp = f.origem === 'producao' && f.dtAcion && f.dtChegada ? Math.round((new Date(f.dtChegada) - new Date(f.dtAcion)) / 60e3) : null;
  const papeis = papeisDest(e);
  return `
  <section class="fsec card pad"><h3 style="margin:0 0 10px">1. Origem e gatilho</h3>
    <div class="ck-top" style="margin-bottom:12px;flex-wrap:wrap"><span class="ck-l">Como a ocorrência chegou?</span>${seg('dv-origem', f.origem, [['producao', 'Acionamento pela produção'], ['inspecao', 'Identificado na inspeção']])}</div>
    <div class="gat-grid">${Object.entries(GATILHOS).map(([k, g]) => `<button type="button" class="gat ${f.gatilho === k ? 'on' : ''}" data-action="dv-gat" data-v="${k}" aria-pressed="${f.gatilho === k}" style="--c:${g.cor}"><span class="gi">${ico(g.icone)}</span><b>${g.nome}</b><span>${g.desc}</span></button>`).join('')}</div>
  </section>
  ${f.origem === 'producao' ? `<section class="fsec card pad"><h3 style="margin:0 0 10px">2. Acionamento</h3>
    <div class="lbl" style="margin-top:0"><span>Acionado por</span></div><div class="chips">${Object.entries(ACIONADORES).map(([k, n]) => `<button type="button" class="chip" data-action="dv-papel" data-v="${k}" aria-pressed="${f.papel === k}">${ico('user')}${n}</button>`).join('')}</div>
    <label class="field" style="margin-top:10px"><span>Nome de quem acionou (opcional)</span><input class="input" data-input="dv-f" data-k="acionNome" value="${esc(f.acionNome)}" maxlength="80"></label>
    <div class="lbl"><span>Meio de comunicação</span></div><div class="chips">${Object.entries(MEIOS).map(([k, m]) => `<button type="button" class="chip" data-action="dv-meio" data-v="${k}" aria-pressed="${f.meio === k}">${ico(m.icone)}${m.nome}</button>`).join('')}</div>
    <div class="cab" style="margin-top:12px"><label class="field"><span>Acionamento</span><input class="input" type="datetime-local" data-input="dv-f" data-k="dtAcion" value="${esc(f.dtAcion)}"></label><label class="field"><span>Chegada ao local</span><input class="input" type="datetime-local" data-input="dv-f" data-k="dtChegada" value="${esc(f.dtChegada)}"></label></div>
    <p class="hint" style="margin:0" id="dv-resp">${resp != null ? `Tempo de resposta: <b>${resp} min</b>` : ''}</p>
  </section>` : `<section class="fsec card pad"><h3 style="margin:0 0 6px">2. Identificação durante a inspeção</h3><p class="hint" style="margin:0 0 8px">O desvio foi identificado pelo próprio bombeiro na inspeção rotineira${f.insp ? ' (vinculado à inspeção que você acabou de salvar)' : ''}.</p><label class="field" style="max-width:280px"><span>Data e hora</span><input class="input" type="datetime-local" data-input="dv-f" data-k="dtChegada" value="${esc(f.dtChegada)}"></label></section>`}
  <section class="fsec card pad"><h3 style="margin:0 0 10px">3. Ponto e local</h3>
    ${e ? `<div class="eqpick"><span class="ic">${ico(Store.cat(e.cat).icone)}</span><span><b>${esc(e.codigo)}</b> · ${esc(e.subtipo)}<br><span class="hint">${esc(Store.ger(e.ger).nome)} › ${esc(e.local || e.area)}${e.cat === 'extintor' ? ` · cilindro ${esc(e.fab || '—')}` : ''}</span></span><button type="button" class="btn btn-sec btn-sm" data-action="dv-trocar-eq">Trocar</button></div>
      <label class="checkline"><input type="checkbox" data-change="dv-chk" data-k="localOk" ${f.localOk ? 'checked' : ''}> Confirmei o local e o equipamento envolvido</label>`
    : `<div class="search-box">${ico('search')}<label class="sr" for="dv-busca">Buscar ponto</label><input class="input" id="dv-busca" type="search" data-input="dv-busca" value="${esc(f.busca)}" placeholder="extintor, maca, hidrante, lava-olhos, ACI-010, tarugos…" autocomplete="off"></div>
      <div class="cat-chips"><button type="button" class="chip" data-action="scan-abrir" data-modo="desvio" style="background:#0A2F57;color:#fff;border-color:transparent">${ico('scan')}Ler QR</button></div>
      <div id="dv-res">${V.dvRes(f.busca)}</div>`}
    <label class="field" style="margin-top:12px"><span>Descrição objetiva da situação encontrada</span><textarea class="textarea" data-input="dv-f" data-k="descricao" maxlength="600" placeholder="Ex.: lacre rompido e pino solto; extintor fora do suporte.">${esc(f.descricao)}</textarea></label>
  </section>
  <section class="fsec card pad"><h3 style="margin:0 0 10px">4. Avaliação do equipamento</h3>
    <div class="ck-top"><span class="ck-l">Necessita substituição/recomposição?</span><div class="seg" role="radiogroup"><button type="button" data-action="dv-subs" data-v="Não" aria-pressed="${f.substituir === false}">Não</button><button type="button" data-action="dv-subs" data-v="Sim" aria-pressed="${f.substituir === true}">Sim</button></div></div>
  </section>
  ${f.substituir ? `<section class="fsec card pad"><h3 style="margin:0 0 4px">5. Reserva técnica</h3>
    ${e && !ext ? `<p class="hint" style="margin:0 0 10px">Reposição de materiais de ${esc(Store.cat(e.cat).nome.toLowerCase())} (sem controle de estoque).</p>` : e ? `<p class="hint" style="margin:0 0 10px">Agente <b>${esc(e.agente || 'não informado')}</b> · disponível na reserva: <b style="color:${est ? COR.c : COR.nc}">${est} un.</b>${navigator.onLine ? '' : ' (último dado sincronizado)'}</p>` : '<p class="hint">Selecione o ponto para consultar o estoque.</p>'}
    <div class="res-grid"><button type="button" class="resopt ok ${f.reserva === 'usada' ? 'on' : ''}" data-action="dv-res" data-v="usada" ${est ? '' : 'disabled'}><b>Existe equipamento disponível</b><span>Retirar da reserva, substituir e restabelecer a cobertura</span></button><button type="button" class="resopt no ${f.reserva === 'indisponivel' ? 'on' : ''}" data-action="dv-res" data-v="indisponivel"><b>Não existe disponível</b><span>Registrar indisponibilidade e manter como pendência</span></button></div>
    ${f.reserva === 'usada' && !ext ? `<label class="checkline"><input type="checkbox" data-change="dv-chk" data-k="cobertura" ${f.cobertura ? 'checked' : ''}> Condição segura do ponto restabelecida</label>` : ''}
    ${f.reserva === 'usada' && ext ? `<div class="cab" style="margin-top:12px"><label class="field"><span>Nº do cilindro retirado</span><input class="input" value="${esc(e ? e.fab : '')}" disabled></label><label class="field"><span>Nº do cilindro instalado</span><input class="input" data-input="dv-f" data-k="instFab" value="${esc(f.instFab)}" maxlength="20"></label><label class="field"><span>N2 do instalado</span><input class="input" type="month" data-input="dv-f" data-k="instN2" value="${esc(f.instN2)}"></label></div>
      <label class="checkline"><input type="checkbox" data-change="dv-chk" data-k="cobertura" ${f.cobertura ? 'checked' : ''}> Cobertura de emergência do local restabelecida</label><p class="hint" style="margin:6px 0 0">Ao salvar: baixa de 1 unidade na reserva, troca registrada no ponto e inspeção conforme lançada.</p>` : ''}
    ${f.reserva === 'indisponivel' ? `<div class="notice n-amber">${ico('alert')}<div>A ocorrência ficará como <b>pendência de regularização</b>. O One Page informará a indisponibilidade e você registrará a reposição depois.</div></div>` : ''}
  </section>` : ''}
  <section class="fsec card pad"><h3 style="margin:0 0 10px">6. Ação executada e evidências</h3>
    <label class="field"><span>Ação executada ${f.substituir && f.reserva ? '<span class="hint">(complementar — o texto da substituição é gerado)</span>' : ''}</span><textarea class="textarea" data-input="dv-f" data-k="acao" maxlength="600" placeholder="Ex.: equipamento relacrado e recolocado no suporte.">${esc(f.acao)}</textarea></label>
    <label class="field"><span>Pendências / recomendações (opcional)</span><input class="input" data-input="dv-f" data-k="pendencias" value="${esc(f.pendencias)}" maxlength="300"></label>
    <div class="lbl"><span>Evidências fotográficas (até 3)</span></div><div class="thumbs" id="thumbs">${V.thumbs(f)}</div>
  </section>
  <section class="fsec card pad"><h3 style="margin:0 0 4px">7. Comunicado por e-mail (One Page)</h3>
    ${papeis.length ? `<p class="hint" style="margin:0 0 10px">Destinatários do One Page (os e-mails são os cadastrados pelo administrador):</p><div class="dest">${papeis.map(p => { const ds = Store.S.dests.filter(d => d.ativo && d.papel === p && (!e || !d.gerencia_id || d.gerencia_id === e.ger)); return `<label class="checkline"><input type="checkbox" data-change="dv-dest" value="${esc(p)}" ${f.dest.includes(p) ? 'checked' : ''}> <span>${esc(p)}<br><span class="hint">${ds.map(d => esc(d.nome)).join(', ')}</span></span></label>`; }).join('')}</div>`
      : `<div class="notice n-amber">${ico('mail')}<div>Nenhum destinatário cadastrado${e ? ' para a gerência deste ponto' : ''}. O comunicado será salvo e o One Page poderá ser baixado; o envio por e-mail depende do cadastro em Administração → Destinatários.</div></div>`}
  </section>`;
};
V.dvRes = (txt) => {
  const termos = Busca.termos(txt || ''), lim = 25;
  if (!termos.length) return '<p class="hint" style="margin:8px 0 0">Digite o tipo (extintor, maca, hidrante, chuveiro/lava-olhos), o código, o local ou o nº do cilindro — ou leia o QR.</p>';
  const res = Busca.executar({ q: txt }).res.map(r => r.e);
  if (!res.length) return '<p class="hint">Nenhum ponto encontrado.</p>';
  return `<p class="res-count" style="margin:10px 2px 6px">${Util.plural(res.length, 'ponto')}${res.length > lim ? ` — mostrando ${lim}; refine com o local ou o código` : ''}</p>
  <div class="list">${res.slice(0, lim).map(x => `<button type="button" class="row" data-action="dv-eq" data-id="${x.id}"><span class="ic">${ico(Store.cat(x.cat).icone)}</span><span class="body"><span class="l1"><span class="code">${Util.destacar(x.codigo, termos)}</span><span class="tag t-info">${esc(Store.cat(x.cat).nome)}</span>${Comp.tagN2(x)}</span><span class="l2">${Util.destacar(x.subtipo, termos)}${x.cat === 'extintor' ? ` · cilindro ${esc(x.fab || '—')}` : ''}</span><span class="l3">${esc(Store.ger(x.ger).sigla)} › ${Util.destacar(x.local || x.area, termos)}</span></span></button>`).join('')}</div>`;
};

const reDv = () => { const y = scrollY; document.getElementById('dv-corpo').innerHTML = V.dvCorpo(A.tmp.desvio); scrollTo(0, y); };
let tB;
Object.assign(A.Acoes, {
  'dv-origem': el => { A.tmp.desvio.origem = el.dataset.v; reDv(); },
  'dv-gat': el => { A.tmp.desvio.gatilho = el.dataset.v; reDv(); },
  'dv-papel': el => { A.tmp.desvio.papel = el.dataset.v; reDv(); },
  'dv-meio': el => { A.tmp.desvio.meio = el.dataset.v; reDv(); },
  'dv-subs': el => { const f = A.tmp.desvio; f.substituir = el.dataset.v === 'Sim'; if (!f.substituir) f.reserva = null; reDv(); },
  'dv-res': el => { A.tmp.desvio.reserva = el.dataset.v; reDv(); },
  'dv-eq': el => { const f = A.tmp.desvio; f.eq = el.dataset.id; f.localOk = false; f.reserva = null; f.dest = papeisDest(Store.eq(f.eq)); reDv(); },
  'dv-trocar-eq': () => { const f = A.tmp.desvio; f.eq = ''; f.localOk = false; reDv(); document.getElementById('dv-busca')?.focus(); }
});
Object.assign(A.Inputs, {
  'dv-f': el => { const f = A.tmp.desvio; f[el.dataset.k] = el.value; if (['dtAcion', 'dtChegada'].includes(el.dataset.k)) { const r = document.getElementById('dv-resp'); if (r && f.dtAcion && f.dtChegada) r.innerHTML = `Tempo de resposta: <b>${Math.round((new Date(f.dtChegada) - new Date(f.dtAcion)) / 60e3)} min</b>`; } },
  'dv-chk': el => { A.tmp.desvio[el.dataset.k] = el.checked; },
  'dv-dest': el => { const f = A.tmp.desvio; f.dest = el.checked ? [...new Set([...f.dest, el.value])] : f.dest.filter(x => x !== el.value); },
  'dv-busca': el => { A.tmp.desvio.busca = el.value; clearTimeout(tB); tB = setTimeout(() => { document.getElementById('dv-res').innerHTML = V.dvRes(el.value); }, 150); }
});

A.Envios['form-desvio'] = async () => {
  const f = A.tmp.desvio, err = document.getElementById('dv-err'), faltas = D.faltas(f);
  if (faltas.length) { err.innerHTML = faltas.map(esc).join('<br>'); err.scrollIntoView({ block: 'center', behavior: 'smooth' }); return; }
  const S = Store.S, e = Store.eq(f.eq), id = Util.uuid(), agora = new Date(), ext = e.cat === 'extintor';
  const ag = ext ? (e.agente || 'Agente não informado') : `Materiais de ${Store.cat(e.cat).nome.toLowerCase()}`;
  const semRes = f.substituir && f.reserva === 'indisponivel';
  const acaoAuto = f.substituir ? (f.reserva === 'usada' ? (ext ? `Extintor substituído por equipamento da reserva técnica (${ag}). Cobertura de emergência restabelecida.` : `${ag} repostos/substituídos. Condição segura do ponto restabelecida.`) : 'Indisponibilidade na reserva técnica registrada; ocorrência mantida como pendência de regularização; responsáveis comunicados.') : '';
  const p = {
    id, ponto_id: e.id, origem: f.origem, gatilho: f.gatilho,
    acionador_papel: f.origem === 'producao' ? f.papel : null, acionador_nome: f.origem === 'producao' ? f.acionNome.trim() || null : null, meio: f.origem === 'producao' ? f.meio : null,
    acionado_em: new Date(f.origem === 'producao' ? f.dtAcion : f.dtChegada).toISOString(), chegada_em: new Date(f.dtChegada).toISOString(),
    descricao: f.descricao.trim(), substituir: !!f.substituir, reserva: f.substituir ? f.reserva : null, agente: ext ? ag : null,
    cilindro_instalado: f.substituir && f.reserva === 'usada' ? (ext ? f.instFab.trim() : 'material reposto') : null, n2_instalado: f.substituir && f.reserva === 'usada' && ext ? f.instN2 : null,
    acao: [acaoAuto, f.acao.trim()].filter(Boolean).join(' '), pendencias: f.pendencias.trim() || (semRes ? `Aguardando reposição de ${ag}.` : null),
    destinatarios: f.dest, inspecao_origem_id: f.insp || null
  };
  const local = { ...p, numero: null, unidade_id: S.unidade.id, cilindro_retirado: e.fab || null, status: semRes ? 'pendente' : 'encerrado', encerrado_em: semRes ? null : agora.toISOString(), bombeiro_id: S.eu.id, criado_em: agora.toISOString(), _fila: true };
  await Fila.incluir('desvio', p, id, { local });
  for (let n = 0; n < f.fotos.length; n++) {
    const path = `${S.org.id}/${S.unidade.id}/${id}_${n + 1}.jpg`;
    const it = await Fila.incluir('foto', { org_id: S.org.id, unidade_id: S.unidade.id, registro_id: id, tipo: 'desvio', path }, id, { blob: f.fotos[n] });
    S.fotos.push({ id: it.id, registro_id: id, tipo: 'desvio', path, _blob: f.fotos[n], _fila: true });
  }
  S.desvios.unshift(local);
  if (f.substituir && f.reserva === 'usada' && ext) { e.fab = p.cilindro_instalado; e.n2 = p.n2_instalado || e.n2; }
  Store.reindexar(); Store.salvarCache();
  A.tmp.desvio = null;
  location.hash = `#/desvio/${id}?novo=1`;
  A.Sync.ciclo();
};

/* ---------------- lista ---------------- */
V.linhaDv = d => { const e = Store.eq(d.ponto_id), g = GATILHOS[d.gatilho]; return `<a class="row" href="#/desvio/${d.id}"><span class="ic" style="background:${g.cor}1A;color:${g.cor}">${ico(g.icone)}</span><span class="body"><span class="l1"><span class="code">${esc(d.numero || 'Aguardando envio')}</span><span class="tag" style="background:${g.cor}1A;color:${g.cor}">${g.nome}</span>${d.status === 'pendente' ? '<span class="tag t-warn">Pendente de reposição</span>' : '<span class="tag t-ok">Encerrado</span>'}${d._fila ? '<span class="tag t-fila">Na fila</span>' : ''}</span><span class="l2">${esc(e ? e.codigo : '—')} · ${esc(e ? (e.local || e.area) : '')}</span><span class="l3">${Util.fmtCurta(d.acionado_em)} · ${d.origem === 'producao' ? `acionado por ${esc(ACIONADORES[d.acionador_papel] || '—')} (${esc(MEIOS[d.meio]?.nome || '')})` : 'identificado na inspeção'} · ${esc(Store.usuario(d.bombeiro_id).nome)}</span></span><span class="chev">${ico('chev')}</span></a>`; };
V.desvios = (q) => {
  const f = A.tmp.dvf || (A.tmp.dvf = { ...Periodo.mesAtual(), gat: '', st: '', q: '' }), termos = Busca.termos(f.q);
  const l = Store.S.desvios.filter(d => Periodo.ok(d.acionado_em, f) && (!f.gat || d.gatilho === f.gat) && (!f.st || d.status === f.st) && (!termos.length || (() => { const e = Store.eq(d.ponto_id); const h = Util.norm([d.numero, e?.codigo, e?.local, e?.area, d.descricao, d.acao].join(' ')); return termos.every(t => h.includes(t)); })()));
  const resp = l.map(tempoResp).filter(x => x != null), media = resp.length ? Math.round(resp.reduce((a, b) => a + b, 0) / resp.length) : 0;
  const pend = Store.S.desvios.filter(d => d.status === 'pendente');
  return `<div class="p-head"><div><p class="hint" style="margin:0">Ocorrências de extrativo, violação ou uso em combate — com reserva técnica, troca no ponto e One Page.</p></div>${Regras.pode('inspecionar') ? `<a class="btn btn-pri btn-sm" href="#/desvio/novo">${ico('plus')}Novo comunicado</a>` : ''}</div>
  <div class="fbar">${Cal.botao('dv-per', f, (de, ate) => { f.de = de; f.ate = ate; A.render(); })}
    <label><span>Gatilho</span><select class="select" data-input="dvf" data-k="gat"><option value="">Todos</option>${Object.entries(GATILHOS).map(([k, g]) => `<option value="${k}" ${f.gat === k ? 'selected' : ''}>${g.nome}</option>`).join('')}</select></label>
    <label><span>Situação</span><select class="select" data-input="dvf" data-k="st"><option value="">Todas</option><option value="pendente" ${f.st === 'pendente' ? 'selected' : ''}>Pendente de reposição</option><option value="encerrado" ${f.st === 'encerrado' ? 'selected' : ''}>Encerrado</option></select></label>
    <label><span>Texto</span><input class="input" style="min-height:38px;font-size:14px" type="search" data-input="dvf-q" value="${esc(f.q)}" placeholder="nº, ponto, local…"></label>
  </div>
  <div class="kpis kpis-4" style="margin-top:12px">${Comp.kpi('Comunicados no período', l.length, esc(Periodo.rot(f)))}${Comp.kpi('Tempo médio de resposta', media + '<span style="font-size:14px"> min</span>', 'acionamentos pela produção')}${Comp.kpi('Pendentes de reposição', pend.length, 'todos os períodos', pend.length ? 'var(--amber)' : '')}${Comp.kpi('Com substituição', l.filter(d => d.substituir).length)}</div>
  <div class="chips" style="margin:12px 0"><span class="res-count" style="margin:0">${Util.plural(l.length, 'comunicado')}</span>${Object.entries(GATILHOS).map(([k, g]) => `<span class="tag" style="background:${g.cor}1A;color:${g.cor}">${g.nome}: ${l.filter(d => d.gatilho === k).length}</span>`).join('')}</div>
  ${l.length ? `<div class="list">${l.slice(0, 200).map(V.linhaDv).join('')}</div>` : Comp.vazio('flame', 'Nenhum comunicado de desvio', 'Ajuste o período ou os filtros.')}`;
};
let tQ;
Object.assign(A.Inputs, {
  dvf: el => { A.tmp.dvf[el.dataset.k] = el.value; A.render(); },
  'dvf-q': el => { A.tmp.dvf.q = el.value; clearTimeout(tQ); tQ = setTimeout(() => { const pos = el.selectionStart; A.render(); const n = document.querySelector('[data-input="dvf-q"]'); if (n) { n.focus(); n.setSelectionRange(pos, pos); } }, 300); }
});

/* ---------------- detalhe ---------------- */
V.desvioDet = (id, q) => {
  const d = Store.idx.desvio.get(id); if (!d) return V.naoEncontrado();
  const e = Store.eq(d.ponto_id), g = GATILHOS[d.gatilho], resp = tempoResp(d);
  const envios = Store.S.envios.filter(x => x.desvio_id === d.id), ok = envios.find(x => x.status === 'enviado');
  const passo = (s, t, x) => `<li class="${s === true ? 'ok' : s === 'warn' ? 'warn' : ''}"><span class="dot"></span><div><b>${t}</b>${x ? `<div class="meta">${x}</div>` : ''}</div></li>`;
  return `${q.get('novo') ? `<div class="notice n-ok" style="margin:0 0 12px">${ico('check')}<div><b>Comunicado de desvio registrado.</b> ${d._fila ? 'Salvo no aparelho — o número CD será atribuído pelo servidor quando a conexão voltar.' : 'Gere o One Page e envie aos responsáveis.'}</div></div>` : ''}
  <section class="card eq-head"><div class="top-line"><span class="code">${esc(d.numero || 'Aguardando envio')}</span><span class="tag" style="background:${g.cor}1A;color:${g.cor}">${ico(g.icone)}${g.nome}</span>${d.status === 'pendente' ? '<span class="tag t-warn">Pendente de reposição</span>' : '<span class="tag t-ok">Encerrado</span>'}${ok ? '<span class="tag t-info">One Page enviado</span>' : '<span class="tag t-pend">One Page não enviado</span>'}${d._fila ? '<span class="tag t-fila">Na fila</span>' : ''}</div>
    <div class="desc">${e ? `${esc(e.codigo)} · ${esc(e.subtipo)} · ${esc(Store.ger(e.ger).nome)} › ${esc(e.local || e.area)}` : ''}</div>
    <div class="chips"><button class="btn btn-pri btn-sm" data-action="dv-ver" data-id="${d.id}" ${d._fila ? 'disabled title="Aguardando envio ao servidor"' : ''}>${ico('file')}Visualizar One Page</button><button class="btn btn-sec btn-sm" data-action="dv-onepage" data-id="${d.id}" ${d._fila ? 'disabled title="Aguardando envio ao servidor"' : ''}>${ico('file')}Baixar PDF</button><button class="btn btn-navy btn-sm" data-action="dv-email" data-id="${d.id}" ${d._fila ? 'disabled' : ''}>${ico('mail')}${ok ? 'Reenviar' : 'Enviar'} por e-mail</button>${d.status === 'pendente' && Regras.pode('inspecionar') && !d._fila ? `<button class="btn btn-sec btn-sm" data-action="dv-regularizar" data-id="${d.id}">${ico('check')}Registrar reposição</button>` : ''}${e ? `<a class="btn btn-sec btn-sm" href="#/ponto/${e.id}">Ficha do ponto</a>` : ''}</div></section>
  <div class="grid-2" style="margin-top:12px">
    <section class="card pad"><h2 style="font-size:15px;margin-bottom:10px">Dados do comunicado</h2><dl class="kv">
      <dt>Origem</dt><dd>${d.origem === 'producao' ? 'Acionamento pela produção' : 'Identificado na inspeção'}</dd>
      ${d.origem === 'producao' ? `<dt>Acionado por</dt><dd>${esc(ACIONADORES[d.acionador_papel] || '—')}${d.acionador_nome ? ` — ${esc(d.acionador_nome)}` : ''}</dd><dt>Meio</dt><dd>${esc(MEIOS[d.meio]?.nome || '—')}</dd>` : ''}
      <dt>Acionamento</dt><dd>${Util.fmtDataHora(d.acionado_em)}</dd><dt>Chegada</dt><dd>${Util.fmtDataHora(d.chegada_em)}${resp != null ? ` · <b>${resp} min</b>` : ''}</dd>
      <dt>Bombeiro</dt><dd>${esc(Store.usuario(d.bombeiro_id).nome)}</dd><dt>Situação</dt><dd>${esc(d.descricao)}</dd><dt>Ação</dt><dd>${esc(d.acao || '—')}</dd>
      ${d.substituir ? `<dt>Substituição</dt><dd>${d.cilindro_instalado ? `Retirado ${esc(d.cilindro_retirado || '—')} → instalado <b>${esc(d.cilindro_instalado)}</b>${d.n2_instalado ? ` (N2 ${esc(Util.mes(d.n2_instalado))})` : ''}` : '<span style="color:var(--red)">Sem equipamento na reserva técnica</span>'}</dd>` : ''}
      ${d.pendencias ? `<dt>Pendências</dt><dd>${esc(d.pendencias)}</dd>` : ''}
      <dt>Destinatários</dt><dd>${esc((d.destinatarios || []).join(', ') || '—')}</dd></dl>
      ${thumbsFotos(d.id)}</section>
    <section class="card pad"><h2 style="font-size:15px;margin-bottom:6px">Fluxo da ocorrência</h2><ol class="flow">
      ${passo(true, d.origem === 'producao' ? '1. Ocorrência identificada pela produção' : '1. Desvio identificado na inspeção', g.nome)}
      ${d.origem === 'producao' ? passo(true, '2–3. Acionamento e comunicação aos bombeiros', `${esc(ACIONADORES[d.acionador_papel] || '')} · ${esc(MEIOS[d.meio]?.nome || '')} · ${Util.fmtCurta(d.acionado_em)}`) : passo(true, '2. Avaliação do equipamento', 'Equipamento, localização e necessidade de substituição')}
      ${passo(true, '4. Atendimento pelo bombeiro', `${esc(Store.usuario(d.bombeiro_id).nome)} · chegada ${Util.fmtCurta(d.chegada_em)}`)}
      ${d.substituir ? passo(d.reserva === 'usada' ? true : 'warn', 'Verificação da reserva técnica', d.reserva === 'usada' ? 'Equipamento disponível — retirado, substituído e movimentação registrada' : 'Indisponível — pendência de regularização') : ''}
      ${passo(ok ? true : 'warn', '5–6. One Page emitido e enviado por e-mail', ok ? `${Util.fmtCurta(ok.enviado_em)} · ${ok.destinatarios.length} destinatário(s)` : envios.length ? `Falha no último envio: ${esc(envios[0].erro || '')}` : 'Pendente de envio')}
      ${passo(d.status === 'encerrado' ? true : 'warn', '7. Registro, rastreabilidade e encerramento', d.status === 'encerrado' ? `Encerrado em ${Util.fmtCurta(d.encerrado_em)}` : 'Aguardando regularização')}
    </ol></section>
  </div>`;
};

/* ---------------- One Page (jsPDF) ---------------- */
/** carrega a imagem e devolve JPEG em dataURL (normaliza formato e tamanho) */
async function imagemJPEG(url) {
  if (!url) return null;
  try {
    const blob = await (await fetch(url)).blob(), bmp = await createImageBitmap(blob);
    const k = Math.min(1, 1400 / Math.max(bmp.width, bmp.height)), cv = document.createElement('canvas');
    cv.width = Math.round(bmp.width * k); cv.height = Math.round(bmp.height * k); cv.getContext('2d').drawImage(bmp, 0, 0, cv.width, cv.height);
    return { url: cv.toDataURL('image/jpeg', 0.82), w: cv.width, h: cv.height };
  } catch (e) { console.warn('foto One Page', e); return null; }
}
const dataURL = async (url) => { const r = await fetch(url); const b = await r.blob(); return await new Promise(ok => { const fr = new FileReader(); fr.onload = () => ok(fr.result); fr.readAsDataURL(b); }); };
export async function gerarOnePage(d) {
  const { jsPDF } = window.jspdf; const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  const limpa = s => String(s).replace(/₂/g, '2').replace(/→/g, '->').replace(/›/g, '>').replace(/[^\x00-\xFF\u2014\u2013\u2018\u2019\u201C\u201D\u2022\u2026]/g, '');
  const _t = doc.text.bind(doc); doc.text = (s, ...r) => _t(Array.isArray(s) ? s.map(limpa) : limpa(s), ...r);
  const e = Store.eq(d.ponto_id), g = GATILHOS[d.gatilho], S = Store.S, W = 210, M = 14; let y = 14;
  try { doc.addImage(await dataURL(LOGO), 'PNG', M, y - 2, 38, 12); } catch (x) { /* sem logo */ }
  doc.setFont('helvetica', 'bold'); doc.setFontSize(9); doc.setTextColor(107, 124, 141);
  doc.text(`${S.org.nome} · ${S.unidade.nome}`, W - M, y + 2, { align: 'right' }); doc.text(`Emitido em ${Util.fmtDataHora(new Date())}`, W - M, y + 7, { align: 'right' });
  y += 16; doc.setFillColor(10, 47, 87); doc.rect(M, y, W - 2 * M, 16, 'F');
  doc.setTextColor(255, 255, 255); doc.setFontSize(15); doc.text(`Comunicado de Desvio ${d.numero}`, M + 4, y + 7);
  doc.setFontSize(10); doc.setFont('helvetica', 'normal'); doc.text(`${g.nome} · ${d.status === 'pendente' ? 'PENDENTE DE REPOSIÇÃO' : 'ENCERRADO'}`, M + 4, y + 13);
  y += 22; doc.setTextColor(22, 34, 46);
  const bloco = (titulo, linhas) => {
    if (y > 260) { doc.addPage(); y = 16; }
    doc.setFont('helvetica', 'bold'); doc.setFontSize(10.5); doc.setTextColor(10, 47, 87); doc.text(titulo, M, y); y += 1.5; doc.setDrawColor(0, 168, 126); doc.setLineWidth(0.6); doc.line(M, y, M + 30, y); y += 5;
    doc.setFontSize(9.5); doc.setTextColor(22, 34, 46);
    for (const [k, v] of linhas) { if (v == null || v === '') continue; doc.setFont('helvetica', 'bold'); doc.text(k, M, y); doc.setFont('helvetica', 'normal'); const t = doc.splitTextToSize(String(v), W - 2 * M - 46); doc.text(t, M + 46, y); y += Math.max(5, t.length * 4.4); if (y > 280) { doc.addPage(); y = 16; } }
    y += 3;
  };
  const resp = tempoResp(d);
  bloco('Ponto', [['Ponto', e ? `${e.codigo} — ${Store.cat(e.cat).nome}` : ''], ['Gerência / local', e ? `${Store.ger(e.ger).nome} › ${e.area}${e.local && e.local !== e.area ? ' · ' + e.local : ''}` : ''], ['Equipamento', e?.subtipo]]);
  bloco('Ocorrência', [['Origem', d.origem === 'producao' ? 'Acionamento pela produção' : 'Identificado na inspeção'], ['Acionado por', d.origem === 'producao' ? `${ACIONADORES[d.acionador_papel] || ''}${d.acionador_nome ? ' — ' + d.acionador_nome : ''} (${MEIOS[d.meio]?.nome || ''})` : ''], ['Acionamento', Util.fmtDataHora(d.acionado_em)], ['Chegada ao local', Util.fmtDataHora(d.chegada_em) + (resp != null ? ` · tempo de resposta ${resp} min` : '')], ['Situação encontrada', d.descricao]]);
  bloco('Atendimento', [['Bombeiro', Store.usuario(d.bombeiro_id).nome], ['Ação executada', d.acao], ['Substituição', d.substituir ? (d.cilindro_instalado ? `Cilindro ${d.cilindro_retirado || '—'} → ${d.cilindro_instalado}${d.n2_instalado ? ' (N2 ' + Util.mes(d.n2_instalado) + ')' : ''} · reserva técnica` : 'Sem equipamento disponível na reserva técnica') : 'Não necessária'], ['Pendências', d.pendencias], ['Encerramento', d.status === 'encerrado' ? Util.fmtDataHora(d.encerrado_em) : 'Aguardando regularização']]);
  const fs = Store.fotosDe(d.id);
  if (fs.length) {
    const urls = await Fotos.urlsDe(fs);
    if (y > 200) { doc.addPage(); y = 16; }
    doc.setFont('helvetica', 'bold'); doc.setFontSize(10.5); doc.setTextColor(10, 47, 87); doc.text(`Evidências fotográficas (${fs.length})`, M, y); y += 1.5; doc.setDrawColor(0, 168, 126); doc.setLineWidth(0.6); doc.line(M, y, M + 30, y); y += 4;
    const larg = (W - 2 * M - 6) / 2; let col = 0, alturaLinha = 0;
    for (const f of fs) {
      const im = await imagemJPEG(urls[f.path]);
      if (!im) { doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.setTextColor(192, 54, 44); doc.text('Foto indisponível', M + col * (larg + 6), y + 5); alturaLinha = Math.max(alturaLinha, 10); }
      else {
        const h = Math.min(larg * im.h / im.w, 95), w = h * im.w / im.h;
        if (y + h > 282) { doc.addPage(); y = 16; col = 0; alturaLinha = 0; }
        doc.addImage(im.url, 'JPEG', M + col * (larg + 6), y, w, h); alturaLinha = Math.max(alturaLinha, h);
      }
      col++; if (col === 2) { col = 0; y += alturaLinha + 5; alturaLinha = 0; }
    }
    if (col) y += alturaLinha + 5;
  }
  doc.setFontSize(8); doc.setTextColor(107, 124, 141); doc.text('Inspec · Gestão inteligente de inspeções — documento gerado pelo sistema', M, 290); doc.text('Referências: NR-23 · NBR 12962', W - M, 290, { align: 'right' });
  return doc;
}
Object.assign(A.Acoes, {
  'dv-ver': async el => {
    const d = Store.idx.desvio.get(el.dataset.id);
    await UI.ocupado(el, async () => {
      const e = Store.eq(d.ponto_id), g = GATILHOS[d.gatilho], resp = tempoResp(d), fs = Store.fotosDe(d.id), urls = await Fotos.urlsDe(fs), S = Store.S;
      const lin = (k, v) => v == null || v === '' ? '' : `<tr><th>${esc(k)}</th><td>${esc(v)}</td></tr>`;
      const css = `*{box-sizing:border-box}body{margin:0;background:#E9EEF3;font-family:Inter,Arial,sans-serif;color:#16222E;-webkit-print-color-adjust:exact;print-color-adjust:exact}
        .pg{width:210mm;min-height:297mm;margin:14px auto;background:#fff;padding:13mm 14mm;box-shadow:0 4px 20px rgba(0,0,0,.12)}
        .cab{display:flex;justify-content:space-between;align-items:center}.cab img{height:40px}.cab span{font-size:10.5px;color:#6B7C8D;text-align:right}
        .tt{background:#0A2F57;color:#fff;border-radius:8px;padding:12px 16px;margin:12px 0 14px}.tt b{display:block;font-size:19px;font-family:Poppins,Inter,Arial}.tt span{font-size:12px;opacity:.85}
        h3{font-size:13px;color:#0A2F57;margin:14px 0 6px;padding-bottom:3px;border-bottom:2px solid #00A87E;display:inline-block}
        table{width:100%;border-collapse:collapse;font-size:12px}th{text-align:left;width:46mm;color:#44576A;font-weight:600;padding:3px 6px 3px 0;vertical-align:top}td{padding:3px 0;vertical-align:top}
        .fotos{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:6px}.fotos img{width:100%;max-height:95mm;object-fit:contain;border-radius:6px;border:1px solid #DCE4EC;background:#F4F7FA}
        .rod{margin-top:16px;border-top:1px solid #E6ECF2;padding-top:5px;font-size:9.5px;color:#8795A1;display:flex;justify-content:space-between}
        @media print{body{background:#fff}.pg{margin:0;box-shadow:none;width:auto;min-height:auto;padding:10mm 12mm}@page{size:A4;margin:0}}`;
      const corpo = `<div class="pg"><div class="cab"><img src="${location.origin}${LOGO}" alt="Inspec"><span>${esc(S.org.nome)} · ${esc(S.unidade.nome)}<br>Emitido em ${Util.fmtDataHora(new Date())}</span></div>
        <div class="tt"><b>Comunicado de Desvio ${esc(d.numero || '')}</b><span>${esc(g.nome)} · ${d.status === 'pendente' ? 'PENDENTE DE REPOSIÇÃO' : 'ENCERRADO'}</span></div>
        <h3>Ponto</h3><table>${lin('Ponto', e ? `${e.codigo} — ${Store.cat(e.cat).nome}` : '')}${lin('Gerência / local', e ? `${Store.ger(e.ger).nome} › ${e.area}${e.local && e.local !== e.area ? ' · ' + e.local : ''}` : '')}${lin('Equipamento', e?.subtipo)}</table>
        <h3>Ocorrência</h3><table>${lin('Origem', d.origem === 'producao' ? 'Acionamento pela produção' : 'Identificado na inspeção')}${d.origem === 'producao' ? lin('Acionado por', `${ACIONADORES[d.acionador_papel] || ''}${d.acionador_nome ? ' — ' + d.acionador_nome : ''} (${MEIOS[d.meio]?.nome || ''})`) : ''}${lin('Acionamento', Util.fmtDataHora(d.acionado_em))}${lin('Chegada ao local', Util.fmtDataHora(d.chegada_em) + (resp != null ? ` · tempo de resposta ${resp} min` : ''))}${lin('Situação encontrada', d.descricao)}</table>
        <h3>Atendimento</h3><table>${lin('Bombeiro', Store.usuario(d.bombeiro_id).nome)}${lin('Ação executada', d.acao)}${lin('Substituição', d.substituir ? (d.cilindro_instalado ? `Cilindro ${d.cilindro_retirado || '—'} → ${d.cilindro_instalado}${d.n2_instalado ? ' (N2 ' + Util.mes(d.n2_instalado) + ')' : ''} · reserva técnica` : 'Sem equipamento disponível na reserva técnica') : 'Não necessária')}${lin('Pendências', d.pendencias)}${lin('Encerramento', d.status === 'encerrado' ? Util.fmtDataHora(d.encerrado_em) : 'Aguardando regularização')}</table>
        ${fs.length ? `<h3>Evidências fotográficas (${fs.length})</h3><div class="fotos">${fs.map(f => urls[f.path] ? `<img src="${urls[f.path]}" alt="Evidência">` : '<p>Foto indisponível sem conexão.</p>').join('')}</div>` : ''}
        <div class="rod"><span>Inspec · Gestão inteligente de inspeções — documento gerado pelo sistema</span><span>Referências: NR-23 · NBR 12962</span></div></div>`;
      abrirDocumento(`One Page ${d.numero || ''}`, css, corpo, { botoes: [{ rotulo: 'Baixar PDF', acao: async () => { const doc = await gerarOnePage(d); doc.save(`OnePage_${d.numero}.pdf`); evento('app.onepage', { rotulo: d.numero }); } }] });
    });
  },
  'dv-onepage': async el => { const d = Store.idx.desvio.get(el.dataset.id); await UI.ocupado(el, async () => { const doc = await gerarOnePage(d); doc.save(`OnePage_${d.numero}.pdf`); evento('app.onepage', { rotulo: d.numero }); }); },
  'dv-email': async el => {
    const d = Store.idx.desvio.get(el.dataset.id);
    if (!navigator.onLine) return UI.toast('O envio por e-mail precisa de conexão.');
    await UI.ocupado(el, async () => {
      try {
        const doc = await gerarOnePage(d); const b64 = doc.output('datauristring').split(',')[1];
        const r = await funcao('enviar-onepage', { desvio_id: d.id, pdf_base64: b64 });
        UI.toast(`One Page enviado a ${Util.plural(r.destinatarios, 'destinatário')}.`); await A.Sync.recarregar(true);
      } catch (e) { UI.toast(msgErro(e), 6000); await A.Sync.recarregar(true); }
    });
  },
  'dv-regularizar': el => {
    const d = Store.idx.desvio.get(el.dataset.id), e = Store.eq(d.ponto_id), ext = e?.cat === 'extintor';
    UI.dialogo({ titulo: `Registrar reposição — ${esc(d.numero)}`, corpo: `<p class="hint" style="margin-top:0">A reposição chegou? Registre o equipamento instalado: o comunicado é encerrado, a troca entra no histórico do ponto e uma inspeção conforme é lançada.</p>
      ${ext ? `<div class="grid-2" style="gap:0 12px"><label class="field"><span>Nº do cilindro instalado</span><input class="input" id="rg-fab" maxlength="20"></label><label class="field"><span>N2 do instalado</span><input class="input" type="month" id="rg-n2" value="${Ciclos.mensal(new Date())}"></label></div>
      <label class="checkline"><input type="checkbox" id="rg-res" checked> Retirado da reserva técnica (baixa de 1 ${esc(d.agente || '')}; estoque atual: ${estoque(d.agente)})</label>` : `<label class="field"><span>Material reposto</span><input class="input" id="rg-fab" maxlength="40" value="Material reposto"></label>`}
      <div class="err" id="rg-err" role="alert"></div>`,
      rodape: `<button class="btn btn-sec" data-action="fechar-dlg">Cancelar</button><button class="btn btn-pri" data-action="dv-reg-ok" data-id="${d.id}">${ico('check')}Encerrar comunicado</button>` });
  },
  'dv-reg-ok': async el => {
    const d = Store.idx.desvio.get(el.dataset.id), fab = document.getElementById('rg-fab').value.trim(), err = document.getElementById('rg-err');
    if (!fab) { err.textContent = 'Informe o equipamento instalado.'; return; }
    if (!navigator.onLine) { err.textContent = 'A regularização precisa de conexão (confere o estoque no servidor).'; return; }
    await UI.ocupado(el, async () => {
      try { await rpc('regularizar_desvio', { p_id: d.id, p_cilindro: fab, p_n2: document.getElementById('rg-n2')?.value || null, p_da_reserva: document.getElementById('rg-res')?.checked ?? false }); UI.fechar(); await A.Sync.recarregar(true); UI.toast(`${d.numero} encerrado. Envie o One Page atualizado.`); }
      catch (e) { err.textContent = msgErro(e); }
    });
  }
});
