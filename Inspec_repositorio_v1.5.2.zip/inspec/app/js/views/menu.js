/* Inspec — Menu: perfil, conexão e fila de envio, unidade, atalhos, senha, sobre */
import { A } from '../ns.js';
import { Store, Regras, Fila } from '../dados.js';
import { sb, msgErro, evento } from '../db.js';
import { UI } from '../ui.js';
import { ico, esc, Util, PAPEIS, LOGO } from '../util.js';

const V = A.V;
const ROT = { inspecao: 'Inspeção', conferir: 'Conferência do ponto', foto: 'Foto', troca: 'Troca de equipamento', desvio: 'Comunicado de desvio' };
const descr = it => {
  const d = it.dados, e = Store.eq(d.ponto_id || it.local?.eq || Store.S.insp.find(i => i.id === d.registro_id)?.eq || Store.S.desvios.find(x => x.id === d.registro_id)?.ponto_id);
  return `${ROT[it.tipo]}${e ? ' · ' + esc(e.codigo) : ''}`;
};

V.menu = () => {
  const S = Store.S, eu = S.eu, fila = Fila.pendentes(), erros = Fila.comErro(), off = !navigator.onLine;
  return `
  <section class="card profile"><span class="avatar">${esc(Util.iniciais(eu.nome))}</span><span><b>${esc(eu.nome)}</b><span>${PAPEIS[eu.papel]} · ${esc(eu.email)}</span></span></section>
  <div class="sec-h"><h2>Conexão e envio</h2></div>
  <div class="menu-list">
    <div class="menu-item">${ico(off ? 'wifioff' : 'wifi')}<span>${off ? 'Sem conexão' : 'Conectado'}<br><span class="hint">${off ? 'Inspeções, trocas, fotos e desvios ficam salvos no aparelho e são enviados quando a internet voltar.' : `Dados carregados em ${Util.fmtDataHora(S.cargaEm)}`}</span></span>${off ? '' : `<button class="btn btn-sec btn-sm" data-action="atualizar" style="margin-left:auto">${ico('refresh')}Atualizar</button>`}</div>
    <div class="menu-item">${ico('send')}<span>Fila de envio<br><span class="hint">${fila.length ? `${Util.plural(fila.length, 'registro', 'registros')} aguardando envio` : 'Tudo enviado'}</span></span>${fila.length && !off ? `<button class="btn btn-pri btn-sm" data-action="enviar-fila" style="margin-left:auto">Enviar agora</button>` : `<span class="r">${fila.length}</span>`}</div>
    ${fila.map(it => `<div class="menu-item" style="padding-left:50px"><span>${descr(it)}<br><span class="hint">${Util.fmtCurta(it.criado)}</span></span><span class="r"><span class="tag t-fila">Na fila</span></span></div>`).join('')}
    ${erros.map(it => `<div class="menu-item" style="padding-left:50px;align-items:flex-start"><span>${descr(it)}<br><span class="hint" style="color:var(--red)">Recusado pelo servidor: ${esc(it.erro)}</span></span><span class="r" style="display:flex;gap:6px"><button class="btn btn-sec btn-sm" data-action="fila-repetir">Tentar de novo</button><button class="btn btn-danger btn-sm" data-action="fila-descartar" data-id="${it.id}">Descartar</button></span></div>`).join('')}
  </div>
  ${S.unidades.length > 1 ? `<div class="sec-h"><h2>Unidade</h2></div><div class="menu-list">${S.unidades.map(u => `<button class="menu-item" data-action="unidade" data-id="${u.id}" role="radio" aria-checked="${u.id === S.unidade.id}">${ico('building')}${esc(u.nome)}${u.id === S.unidade.id ? '<span class="r"><span class="tag t-ok">Atual</span></span>' : ''}</button>`).join('')}</div>` : ''}
  ${A.PWA && !A.PWA.instalado() ? `<div class="sec-h"><h2>Aplicativo</h2></div><div class="menu-list"><button class="menu-item" data-action="pwa-instalar">${ico('download')}<span>Instalar o Inspec neste aparelho<br><span class="hint">Abre pelo ícone na tela inicial, em tela cheia e sem internet</span></span></button></div>` : ''}
  <div class="sec-h"><h2>Atalhos</h2></div>
  <div class="menu-list">
    <a class="menu-item" href="#/desvios">${ico('flame')}Comunicados de desvio</a>
    <a class="menu-item" href="#/pendencias">${ico('clipboard')}Pendências do ciclo</a>
    ${Regras.pode('gestor') ? `<a class="menu-item" href="#/painel">${ico('grid')}Painel de gestão</a>` : ''}
    <a class="menu-item" href="#/relatorios">${ico('file')}Relatórios</a>
    <a class="menu-item" href="#/buscar">${ico('search')}Buscar ponto</a>
    <a class="menu-item" href="#/historico">${ico('history')}Inspeções</a>
    ${Regras.pode('verAdmin') ? `<a class="menu-item" href="#/admin/pontos">${ico('admin')}Administração</a><a class="menu-item" href="#/galeria">${ico('camera')}Galeria de fotos</a><a class="menu-item" href="#/admin/auditoria">${ico('shield')}Histórico do sistema (auditoria)</a>` : ''}
    <button class="menu-item" data-action="guia-rapido">${ico('book')}Guia rápido do inspetor</button>
  </div>
  <div class="sec-h"><h2>Conta</h2></div>
  <div class="menu-list">
    <button class="menu-item" data-action="senha-trocar">${ico('shield')}Trocar minha senha</button>
    <a class="menu-item" href="#/sobre">${ico('info')}Sobre o sistema<span class="r">v${esc(A.VERSAO || '1.0')}</span></a>
    <button class="menu-item" data-action="sair" style="color:var(--red)">${ico('logout')}Sair</button>
  </div>`;
};

Object.assign(A.Acoes, {
  'enviar-fila': async el => { await UI.ocupado(el, async () => { const r = await Fila.processar(); if (r.enviados) { UI.toast(`${Util.plural(r.enviados, 'registro enviado', 'registros enviados')}.`); await A.Sync.recarregar(true); } else if (r.erros) UI.toast('Alguns registros foram recusados. Veja abaixo.'); }); A.render(); },
  'fila-repetir': async () => { await Fila.tentarDeNovo(); await A.Sync.recarregar(true); A.render(); },
  'fila-descartar': async el => { if (!await UI.confirmar({ titulo: 'Descartar registro', texto: 'O registro recusado (e as fotos e conferências ligadas a ele) será apagado deste aparelho. Use quando o servidor indicar um problema que não se resolve tentando de novo.', ok: 'Descartar', perigo: true })) return; await Fila.descartar(el.dataset.id); A.render(); },
  unidade: async el => {
    if (el.dataset.id === Store.S.unidade.id) return;
    if (!navigator.onLine) return UI.toast('Trocar de unidade precisa de conexão.');
    if (Fila.cache.length) return UI.toast('Envie a fila antes de trocar de unidade.');
    try { localStorage.setItem('inspec-unidade', el.dataset.id); } catch (e) { /* ignore */ }
    await UI.ocupado(el, async () => { try { await Store.carregar(Store.S.eu, el.dataset.id); A.tmp = {}; A.Router.render(true); UI.toast(`Unidade: ${Store.S.unidade.nome}`); } catch (e) { UI.toast(msgErro(e)); } });
  },
  'senha-trocar': () => UI.dialogo({ titulo: 'Trocar minha senha', corpo: `<label class="field"><span>Nova senha</span><input class="input" type="password" id="ms-1" autocomplete="new-password"></label><label class="field"><span>Confirmar</span><input class="input" type="password" id="ms-2" autocomplete="new-password"></label><p class="hint" style="margin:0">Mínimo de 8 caracteres, com letras e números.</p><div class="err" id="ms-err" role="alert"></div>`, rodape: `<button class="btn btn-sec" data-action="fechar-dlg">Cancelar</button><button class="btn btn-pri" data-action="senha-ok">Salvar</button>` }),
  'senha-ok': async el => {
    const a = document.getElementById('ms-1').value, b = document.getElementById('ms-2').value, err = document.getElementById('ms-err');
    if (a.length < 8 || !/[A-Za-z]/.test(a) || !/\d/.test(a)) { err.textContent = 'Mínimo de 8 caracteres, com letras e números.'; return; }
    if (a !== b) { err.textContent = 'As senhas não são iguais.'; return; }
    await UI.ocupado(el, async () => { const { error } = await sb.auth.updateUser({ password: a }); if (error) { err.textContent = msgErro(error); return; } evento('acesso.senha_alterada', { motivo: 'troca pelo menu' }); UI.fechar(); UI.toast('Senha alterada.'); });
  },
  sobre: () => UI.dialogo({ titulo: 'Sobre o sistema', corpo: `<div style="text-align:center;margin-bottom:12px"><img src="${LOGO}" alt="Inspec" style="width:200px"></div><dl class="kv"><dt>Sistema</dt><dd>Inspec — Gestão inteligente de inspeções de equipamentos de emergência</dd><dt>Versão</dt><dd>${esc(A.VERSAO || '1.0')}</dd><dt>Organização</dt><dd>${esc(Store.S.org.nome)}</dd><dt>Unidade</dt><dd>${esc(Store.S.unidade.nome)}</dd><dt>Referências</dt><dd>NR-23 · NBR 12962 · NBR 13714 · NBR 16291</dd><dt>Dados</dt><dd>Supabase (região São Paulo) com segurança por linha (RLS); fotos em armazenamento privado.</dd></dl>` }),
  'guia-rapido': () => UI.dialogo({ titulo: 'Guia rápido do inspetor', largo: true, corpo: `<ol style="padding-left:20px;line-height:1.6;margin:0">
    <li><b>No ponto, leia o QR</b> (ícone de leitor no topo ou a câmera do celular). O Inspec abre o ponto certo.</li>
    <li><b>Confira o equipamento instalado</b> com a etiqueta (nº do cilindro, agente, N2, N3). Se mudou, corrija: a troca fica registrada no histórico do ponto.</li>
    <li><b>Responda o checklist</b>: C, NC ou NA. Em NC, escolha ou descreva o problema e tire a foto.</li>
    <li><b>Salve.</b> Sem internet, tudo fica no aparelho e é enviado sozinho quando o sinal voltar — o selo no topo mostra quantos estão na fila.</li>
    <li><b>Trocou o extintor?</b> Na ficha do ponto, use <b>Registrar troca</b> (retirado → instalado). Com origem “Reserva técnica”, o estoque baixa sozinho.</li>
    <li><b>Extrativo, violação ou uso em combate?</b> Abra um <b>Comunicado de desvio</b>: ele registra o atendimento, a reserva técnica, a troca e gera o One Page para e-mail.</li>
    <li>Use <b>Início</b> para ver as pendências do ciclo (mensal; chuveiros semanal) e <b>NCs</b> para reinspecionar o que ficou não conforme.</li></ol>` })
});
