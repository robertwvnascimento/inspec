/* Inspec — Registrar inspeção (checklist do Forms, conferência do equipamento, fotos, fila offline) */
import { A } from '../ns.js';
import { Store, Regras, Fila, Fotos } from '../dados.js';
import { UI, Comp } from '../ui.js';
import { ico, esc, Util, CK, itensDe, Ciclos } from '../util.js';

const V = A.V;
const ORIGENS = ['qr', 'busca', 'lista', 'nc'];

export const Form = {
  novo(e) {
    const d = e.dados || {}, it = {};
    if (e.cat === 'extintor' && /co2|co₂/i.test(e.agente || e.subtipo)) it.manometro = 'NA';
    return { eq: e.id, it, desc: {}, troca: null, motivo: '', obs: '', fotos: [],
      cab: { fab: e.fab || '', agente: e.agente || '', n2: e.n2 || '', n3: e.n3 ? String(e.n3) : '', thUlt: d.th_ultimo || '', thProx: d.th_proximo || '', kitVenc: d.kit_vencimento || '' },
      op: { anel: d.anel || '', base: d.base || '' }, qtd: { ...(d.qtd || {}) }, qtdRef: { ...(d.qtd || {}) }, mang: Form.mangIni(d), press: !!d.pressurizado, inicio: new Date().toISOString() };
  },
  /** testes hidrostáticos de cada mangueira do abrigo (mês/ano) */
  mangIni(d) { const l = Array.isArray(d.mangueiras) ? d.mangueiras.map(m => ({ ult: m.ult || '', prox: m.prox || '' })) : []; const n = d.qtd?.mangueiras ?? l.length; while (l.length < n) l.push({ ult: '', prox: '' }); return l.slice(0, n); },
  itens: (e, f) => itensDe(e.cat, f.press),
  pendencias(e, f) {
    const faltam = [], semDesc = [], m = [];
    for (const it of Form.itens(e, f)) { if (!f.it[it.k]) faltam.push(it.l); else if (f.it[it.k] === 'NC' && (f.desc[it.k] || '').trim().length < 3) semDesc.push(it.l); }
    if (faltam.length) m.push(`Responda: ${faltam.join(', ')}.`);
    if (semDesc.length) m.push(`Descreva a não conformidade em: ${semDesc.join(', ')}.`);
    if (e.cat === 'extintor') {
      if (!f.cab.fab.trim()) m.push('Informe o nº do cilindro instalado (etiqueta).');
      if (f.cab.n3 && !/^\d{4}$/.test(f.cab.n3)) m.push('N3: informe o ano com 4 dígitos.');
      if (!f.op.anel) m.push('Escolha a cor do anel.');
      if (!f.op.base) m.push('Escolha a base.');
      if (!f.troca) m.push('Informe se haverá troca do extintor.');
      else if (f.troca === 'Sim' && !f.motivo) m.push('Escolha o motivo da troca.');
    }
    if (e.cat === 'hidrante') {
      const n = f.qtd.mangueiras ?? 0, falta = [], inv = [];
      for (let i = 0; i < n; i++) { const m = f.mang[i] || {}; if (!m.ult || !m.prox) falta.push(i + 1); else if (m.prox <= m.ult) inv.push(i + 1); }
      if (falta.length) m.push(`Informe o mês/ano do último e do próximo teste hidrostático da mangueira ${falta.join(', ')}.`);
      if (inv.length) m.push(`Mangueira ${inv.join(', ')}: o próximo teste precisa ser depois do último.`);
    }
    const regra = Store.S.org.config.regra_foto, temNC = Object.values(f.it).includes('NC') || f.troca === 'Sim';
    if (!f.fotos.length && (regra === 'todas' || (regra === 'nc' && temNC))) m.push(regra === 'todas' ? 'Adicione ao menos 1 foto do equipamento.' : 'Adicione ao menos 1 foto da não conformidade.');
    return m;
  },
  respondidos(e, f) { const its = Form.itens(e, f); return [its.filter(i => f.it[i.k]).length, its.length]; }
};

V.inspecao = (id, q) => {
  const e = Store.eq(id); if (!e) return V.naoEncontrado();
  if (!Regras.pode('inspecionar')) { location.replace(`#/ponto/${id}`); return ''; }
  if (!e.ativo) return Comp.vazio('alert', 'Ponto inativo', `${esc(e.codigo)} foi inativado${e.motivoInativacao ? ': ' + esc(e.motivoInativacao) : ''}. <a href="#/ponto/${e.id}">Ver ficha</a>`);
  const s = Regras.situacao(e), g = Store.ger(e.ger), c = Store.cat(e.cat);
  const f = A.tmp.form?.eq === id ? A.tmp.form : (A.tmp.form = Form.novo(e));
  const de = q && q.get('de'); if (de) f.origem = ORIGENS.includes(de) ? de : 'busca';
  const ult = s.ultima, n2 = Regras.n2(e), agora = new Date();
  return `
  <section class="card eq-head">
    <div class="top-line"><span class="code">${esc(e.codigo)}</span><span class="tag t-info">${ico(c.icone)}${esc(c.nome)}</span>${Comp.tagSituacao(e, s)}</div>
    <div class="desc">${esc(e.subtipo)}${e.resp ? ` · ponto de ${esc(Store.usuario(e.resp).nome)}` : ''}</div>
    <dl class="kv"><dt>Local</dt><dd>${esc(g.sigla)} › ${esc(e.area)}${e.local && e.local !== e.area ? ' · ' + esc(e.local) : ''}</dd><dt>Última</dt><dd>${ult ? `${Util.fmtCurta(ult.dt)} · ${ult.st === 'ok' ? 'Conforme' : 'Não conforme'} · ${esc(Store.usuario(ult.ins).nome)}` : 'Nenhuma inspeção registrada'}</dd></dl>
    ${!s.pendente ? `<div class="notice n-amber">${ico('info')}<div>Já inspecionado neste ciclo em <b>${Util.fmtCurta(s.noCiclo[0].dt)}</b> por <b>${esc(Store.usuario(s.noCiclo[0].ins).nome)}</b>. Uma nova inspeção (ex.: após correção) fica registrada junto no histórico.</div></div>` : ''}
    ${s.ncAberta ? `<div class="notice n-red">${ico('alert')}<div>Não conformidade aberta: <b>${esc(Regras.textoNC(ult))}</b>. Uma inspeção toda conforme encerra a NC.</div></div>` : ''}
    ${n2 && n2.st === 'vencida' ? `<div class="notice n-red">${ico('clock')}<div>Recarga (N2) <b>vencida em ${n2.rot}</b> segundo o cadastro. Se a etiqueta confirmar, marque a troca por “Validade da Carga N2”. <button class="linkbtn" data-action="aplicar-n2" style="padding:0;display:block">Marcar troca por validade N2</button></div></div>` : ''}
    ${e.dados?.origem?.observacao ? `<div class="notice n-info">${ico('file')}<div>Observação da planilha: <b>${esc(e.dados.origem.observacao)}</b></div></div>` : ''}
    ${e.conferir ? `<div class="notice n-amber">${ico('alert')}<div>Cadastro marcado como <b>“requer conferência”</b>. Confira os dados abaixo com a etiqueta do equipamento.</div></div>` : ''}
  </section>
  <section class="fsec card pad">
    <h3 style="margin:0 0 10px">Identificação <span class="hint">preenchida automaticamente</span></h3>
    <div class="auto">
      <div><span>Data da inspeção</span><b>${Util.fmtDataHora(agora)}</b></div>
      <div><span>Bombeiro</span><b>${esc(Store.S.eu.nome)}</b></div>
      <div><span>Gerência</span><b>${esc(g.nome)}</b></div>
      <div><span>Tipo de ponto</span><b>${esc(c.nome)}</b></div>
      <div><span>Nº do ponto</span><b>${esc(e.codigo)}</b></div>
      <div><span>Local / referência</span><b>${esc(e.local || e.area)}</b></div>
    </div>
  </section>
  <form id="form-insp" novalidate><div id="insp-corpo">${V.inspCorpo(e, f)}</div>
    <div class="err" id="insp-err" role="alert"></div>
    <div class="save-bar"><button type="submit" class="btn btn-pri btn-block" id="btn-salvar">${ico('check')}Salvar inspeção${navigator.onLine ? '' : ' (offline)'}</button></div>
  </form>`;
};

V.inspCorpo = (e, f) => {
  const ck = CK[e.cat], [resp, tot] = Form.respondidos(e, f);
  const ags = Store.agentes(e.agente);
  const campo = c => {
    const v = f.cab[c.k] || '', id = `cab-${c.k}`;
    const ctl = c.t === 'select' ? `<select class="select" id="${id}" data-input="cab" data-k="${c.k}"><option value="">— selecione —</option>${ags.map(o => `<option ${o === v ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select>`
      : `<input class="input" id="${id}" data-input="cab" data-k="${c.k}" type="${c.t === 'year' ? 'number' : c.t}" ${c.t === 'year' ? 'min="1990" max="2100" inputmode="numeric"' : ''} ${c.k === 'fab' ? 'maxlength="20" inputmode="text"' : ''} value="${esc(v)}">`;
    return `<label class="field"><span>${esc(c.l)}</span>${ctl}</label>`;
  };
  const seg = (k, v, ops, acao = 'ck', cls = '') => `<div class="seg ${cls}" role="radiogroup">${ops.map(o => `<button type="button" data-action="${acao}" data-k="${k}" data-v="${o}" role="radio" aria-pressed="${v === o}" aria-checked="${v === o}">${o}</button>`).join('')}</div>`;
  const item = it => {
    const v = f.it[it.k];
    return `<div class="ck-item"><div class="ck-top"><span class="ck-l">${esc(it.l)}${it.k === 'manometro' && f.it.manometro === 'NA' && /co2|co₂/i.test(e.agente || e.subtipo) ? '<small>CO₂ não tem manômetro — NA já marcado</small>' : ''}</span>${seg(it.k, v, it.na ? ['C', 'NC', 'NA'] : ['C', 'NC'])}</div>
      ${v === 'NC' ? `<div class="ck-nc"><div class="chips">${it.sug.map(t => `<button type="button" class="chip" data-action="ck-sug" data-k="${it.k}" data-t="${esc(t)}" aria-pressed="${(f.desc[it.k] || '') === t}">${esc(t)}</button>`).join('')}</div>
        <label class="sr" for="d-${it.k}">Descrever NC em ${esc(it.l)}</label><input class="input" id="d-${it.k}" data-input="ck-desc" data-k="${it.k}" value="${esc(f.desc[it.k] || '')}" placeholder="Descrever NC — ${esc(it.l)}" maxlength="200"></div>` : ''}</div>`;
  };
  let h = '';
  if (ck.cab) h += `<section class="fsec card pad"><h3 style="margin:0 0 4px">Equipamento instalado no ponto <span class="hint">confira com a etiqueta</span></h3><p class="hint" style="margin:0 0 10px">Já vêm do cadastro. Se algo mudou (ex.: cilindro diferente ou recarga nova), corrija aqui — o ponto é atualizado e a mudança fica no histórico.</p><div class="cab">${ck.cab.map(campo).join('')}</div>${e.cat === 'extintor' ? '<p class="hint" style="margin:6px 0 0">Agente não está na lista? Fale com o administrador do sistema para cadastrá-lo.</p>' : ''}</section>`;
  if (e.cat === 'chuveiro') h += `<section class="fsec card pad"><div class="ck-top"><span class="ck-l">Equipamento pressurizado?</span>${seg('press', f.press ? 'Sim' : 'Não', ['Sim', 'Não'], 'ck-press', 'neutral')}</div></section>`;
  h += `<section class="fsec"><h3>Checklist <button type="button" class="btn btn-sec btn-sm" data-action="ck-tudo">${ico('check')}Tudo conforme</button></h3>
    <div class="progress-ck"><div class="bar"><i style="width:${Util.pct(resp, tot)}%"></i></div><span class="hint">${resp} de ${tot}</span></div>
    <div class="card" style="padding:2px 14px">${Form.itens(e, f).map(item).join('')}</div></section>`;
  if (ck.opcoes) h += `<section class="fsec card pad">${ck.opcoes.map(o => `<div class="lbl" style="margin-top:4px"><span>${esc(o.l)}</span></div><div class="chips" style="margin-bottom:8px">${o.op.map(v => `<button type="button" class="chip" data-action="ck-op" data-k="${o.k}" data-v="${esc(v)}" aria-pressed="${f.op[o.k] === v}">${esc(v)}</button>`).join('')}</div>`).join('')}</section>`;
  if (ck.qtd) h += `<section class="fsec card pad"><h3 style="margin:0 0 4px">Materiais do abrigo</h3>${ck.qtd.map(q => { const v = f.qtd[q.k] ?? 0, ref = f.qtdRef[q.k]; return `<div class="qtd-row"><span><b>${esc(q.l)}</b>${ref != null && v < ref ? `<span class="hint" style="color:var(--red)">Havia ${ref} na última inspeção</span>` : `<span class="hint">Última inspeção: ${ref ?? '—'}</span>`}</span><span class="stepper"><button type="button" data-action="qtd" data-k="${q.k}" data-d="-1" aria-label="Diminuir ${esc(q.l)}">−</button><output>${v}</output><button type="button" data-action="qtd" data-k="${q.k}" data-d="1" aria-label="Aumentar ${esc(q.l)}">+</button></span></div>${q.k === 'mangueiras' ? V.mangTestes(f) : ''}`; }).join('')}</section>`;
  if (ck.troca) h += `<section class="fsec card pad"><div class="ck-top"><span class="ck-l">${ck.troca.l}</span>${seg('troca', f.troca, ['Não', 'Sim'], 'ck-troca')}</div>
    ${f.troca === 'Sim' ? `<div class="lbl"><span>Qual o motivo?</span></div><div class="chips">${ck.troca.motivos.map(m => `<button type="button" class="chip" data-action="ck-motivo" data-v="${esc(m)}" aria-pressed="${f.motivo === m}">${esc(m)}</button>`).join('')}</div><p class="hint" style="margin:8px 0 0">A necessidade de troca deixa a inspeção como não conforme. Quando o novo extintor for instalado, registre a troca na ficha do ponto.</p>` : ''}</section>`;
  const regra = Store.S.org.config.regra_foto;
  h += `<section class="fsec card pad"><label class="lbl" for="insp-obs" style="margin-top:0"><span>Observação</span><span class="hint" style="font-weight:500">opcional</span></label>
    <textarea class="textarea" id="insp-obs" data-input="insp-obs" maxlength="1000" placeholder="Algo mais a registrar?">${esc(f.obs)}</textarea>
    <div class="lbl"><span>Evidências fotográficas <span class="hint" style="font-weight:500">(até 3)</span></span>${regra === 'todas' ? '<span class="req">obrigatória</span>' : regra === 'nc' ? '<span class="hint">obrigatória se houver NC</span>' : ''}</div>
    <div class="thumbs" id="thumbs">${V.thumbs(f)}</div></section>`;
  return h;
};
V.mangTestes = f => {
  const n = f.qtd.mangueiras ?? 0; if (!n) return '';
  const hoje = Ciclos.mensal(new Date());
  return `<div class="mang"><p class="hint" style="margin:0 0 8px">Teste hidrostático de cada mangueira (mês/ano) — obrigatório para as ${n}.</p>${Array.from({ length: n }, (_, i) => { const m = f.mang[i] || {}, venc = m.prox && m.prox < hoje; return `<div class="mang-l"><b>Mangueira ${i + 1}</b>
    <label class="field"><span>Último teste</span><input class="input" type="month" data-input="mang" data-i="${i}" data-k="ult" value="${esc(m.ult || '')}" max="${hoje}"></label>
    <label class="field"><span>Próximo teste</span><input class="input" type="month" data-input="mang" data-i="${i}" data-k="prox" value="${esc(m.prox || '')}">${venc ? '<small style="color:var(--red);font-weight:600">Teste vencido</small>' : ''}</label></div>`; }).join('')}</div>`;
};
V.thumbs = f => f.fotos.map((b, i) => `<div class="thumb"><img src="${b._url || (b._url = URL.createObjectURL(b))}" alt="Foto ${i + 1}"><button type="button" data-action="foto-del" data-i="${i}" aria-label="Remover foto ${i + 1}">${ico('x')}</button></div>`).join('')
  + (f.fotos.length < 3 ? `<label class="addphoto">${ico('camera')}Tirar foto<input type="file" accept="image/*" capture="environment" data-change="foto" class="sr"></label><label class="addphoto">${ico('upload')}Da galeria<input type="file" accept="image/*" data-change="foto" class="sr"></label>` : '');

const reInsp = () => { const f = A.tmp.form, e = Store.eq(f.eq), y = scrollY; document.getElementById('insp-corpo').innerHTML = V.inspCorpo(e, f); scrollTo(0, y); };
const rascunho = () => A.tmp.form || A.tmp.desvio;

Object.assign(A.Acoes, {
  ck: el => { const f = A.tmp.form; f.it[el.dataset.k] = el.dataset.v; if (el.dataset.v !== 'NC') delete f.desc[el.dataset.k]; reInsp(); if (el.dataset.v === 'NC') document.getElementById('d-' + el.dataset.k)?.focus({ preventScroll: true }); },
  'ck-sug': el => { const f = A.tmp.form; f.desc[el.dataset.k] = el.dataset.t; reInsp(); },
  'ck-tudo': () => { const f = A.tmp.form, e = Store.eq(f.eq); for (const it of Form.itens(e, f)) if (!f.it[it.k] || f.it[it.k] === 'NC') { f.it[it.k] = 'C'; delete f.desc[it.k]; } if (e.cat === 'extintor' && !f.troca) f.troca = 'Não'; reInsp(); },
  'ck-op': el => { A.tmp.form.op[el.dataset.k] = el.dataset.v; reInsp(); },
  'ck-troca': el => { const f = A.tmp.form; f.troca = el.dataset.v; if (f.troca === 'Não') f.motivo = ''; reInsp(); },
  'ck-motivo': el => { A.tmp.form.motivo = el.dataset.v; reInsp(); },
  'ck-press': el => { A.tmp.form.press = el.dataset.v === 'Sim'; reInsp(); },
  qtd: el => { const f = A.tmp.form; f.qtd[el.dataset.k] = Math.max(0, Math.min(20, (f.qtd[el.dataset.k] || 0) + Number(el.dataset.d))); if (el.dataset.k === 'mangueiras') { while (f.mang.length < f.qtd.mangueiras) f.mang.push({ ult: '', prox: '' }); f.mang.length = f.qtd.mangueiras; } reInsp(); },
  'aplicar-n2': () => { const f = A.tmp.form; f.troca = 'Sim'; f.motivo = 'Validade da Carga N2'; reInsp(); document.querySelector('[data-action="ck-troca"]')?.scrollIntoView({ block: 'center', behavior: 'smooth' }); },
  'foto-del': el => { const d = rascunho(); const [b] = d.fotos.splice(Number(el.dataset.i), 1); if (b?._url) URL.revokeObjectURL(b._url); document.getElementById('thumbs').innerHTML = V.thumbs(d); }
});
Object.assign(A.Inputs, {
  cab: el => { A.tmp.form.cab[el.dataset.k] = el.value; },
  mang: el => { const f = A.tmp.form, i = Number(el.dataset.i); (f.mang[i] || (f.mang[i] = { ult: '', prox: '' }))[el.dataset.k] = el.value; },
  'ck-desc': el => { A.tmp.form.desc[el.dataset.k] = el.value; },
  'insp-obs': el => { A.tmp.form.obs = el.value; },
  foto: async el => {
    const file = el.files[0]; if (!file) return; const d = rascunho(); if (!d) return;
    try { const blob = await Fotos.comprimir(file); d.fotos.push(blob); document.getElementById('thumbs').innerHTML = V.thumbs(d); }
    catch (e) { UI.toast('Não foi possível ler a imagem.'); }
  }
});

/* ---------------- salvar ---------------- */
A.Envios['form-insp'] = async () => {
  const f = A.tmp.form, e = Store.eq(f.eq), err = document.getElementById('insp-err');
  const faltas = Form.pendencias(e, f);
  if (faltas.length) { err.innerHTML = faltas.map(esc).join('<br>'); err.scrollIntoView({ block: 'center', behavior: 'smooth' }); return; }
  const btn = document.getElementById('btn-salvar'); btn.disabled = true;
  try {
    const S = Store.S, agora = new Date(), id = Util.uuid(), per = Store.cat(e.cat).per, itens = Form.itens(e, f);
    const ncs = itens.filter(it => f.it[it.k] === 'NC').map(it => `${it.l}: ${f.desc[it.k].trim()}`);
    if (f.troca === 'Sim') ncs.push(`Troca do extintor: ${f.motivo}`);
    const st = ncs.length ? 'nc' : 'ok';
    const ck = { it: { ...f.it }, desc: { ...f.desc }, cab: { ...f.cab }, op: { ...f.op }, qtd: { ...f.qtd }, ...(e.cat === 'hidrante' ? { mang: f.mang.slice(0, f.qtd.mangueiras ?? 0) } : {}), press: f.press, troca: f.troca, motivo: f.motivo, fotos: f.fotos.length, v: 1 };
    const linha = { id, ponto_id: e.id, data_inspecao: agora.toISOString(), status: st === 'ok' ? 'ok' : 'nao_conforme', observacoes: f.obs.trim() || null, checklist: ck, resumo_nc: ncs.join(' · ') || null, origem: f.origem || 'busca' };
    const local = { id, eq: e.id, dt: linha.data_inspecao, ciclo: Ciclos.de(agora, per), per, st, ck, resumo: linha.resumo_nc || '', obs: linha.observacoes || '', ins: S.eu.id, origem: linha.origem, anulada: false, sync: 'fila' };
    await Fila.incluir('inspecao', linha, id, { local });

    // conferência: só envia se algo mudou no equipamento do ponto
    const mud = [], conf = { ponto_id: e.id, inspecao_id: id };
    if (e.cat === 'extintor') {
      if (f.cab.fab.trim() !== (e.fab || '')) { conf.numero_cilindro = f.cab.fab.trim(); mud.push('nº do cilindro (troca identificada)'); }
      if (f.cab.agente && f.cab.agente !== e.agente) { conf.agente = f.cab.agente; mud.push('agente'); }
      if (f.cab.n2 && f.cab.n2 !== e.n2) { conf.n2 = f.cab.n2; mud.push('N2'); }
      if (f.cab.n3 && f.cab.n3 !== String(e.n3 || '')) { conf.n3 = Number(f.cab.n3); mud.push('N3'); }
      if (f.op.anel !== (e.dados.anel || '')) conf.anel = f.op.anel;
      if (f.op.base !== (e.dados.base || '')) conf.base = f.op.base;
    }
    if (e.cat === 'hidrante') {
      if (JSON.stringify(f.qtd) !== JSON.stringify(e.dados.qtd || {})) conf.qtd = f.qtd;
      const mg = f.mang.slice(0, f.qtd.mangueiras ?? 0);
      if (JSON.stringify(mg) !== JSON.stringify(e.dados.mangueiras || [])) { conf.mangueiras = mg; mud.push('testes hidrostáticos das mangueiras'); }
    }
    if (e.cat === 'maca' && f.cab.kitVenc && f.cab.kitVenc !== (e.dados.kit_vencimento || '')) { conf.kit_vencimento = f.cab.kitVenc; mud.push('vencimento do kit'); }
    if (e.cat === 'chuveiro' && f.press !== !!e.dados.pressurizado) { conf.pressurizado = f.press; mud.push('pressurizado'); }
    if (Object.keys(conf).length > 2) {
      await Fila.incluir('conferir', conf, id);
      // reflexo imediato no aparelho (o servidor confirma na próxima carga)
      if (conf.numero_cilindro) e.fab = conf.numero_cilindro;
      if (conf.agente) e.agente = conf.agente; if (conf.n2) e.n2 = conf.n2; if (conf.n3) e.n3 = conf.n3;
      Object.assign(e.dados, { ...(conf.anel ? { anel: conf.anel } : {}), ...(conf.base ? { base: conf.base } : {}), ...(conf.qtd ? { qtd: conf.qtd } : {}), ...(conf.mangueiras ? { mangueiras: conf.mangueiras } : {}), ...(conf.kit_vencimento ? { kit_vencimento: conf.kit_vencimento } : {}), ...(conf.th_ultimo ? { th_ultimo: conf.th_ultimo } : {}), ...(conf.th_proximo ? { th_proximo: conf.th_proximo } : {}), ...('pressurizado' in conf ? { pressurizado: conf.pressurizado } : {}) });
    }
    // fotos
    for (let n = 0; n < f.fotos.length; n++) {
      const path = `${S.org.id}/${S.unidade.id}/${id}_${n + 1}.jpg`;
      const it = await Fila.incluir('foto', { org_id: S.org.id, unidade_id: S.unidade.id, registro_id: id, tipo: 'inspecao', path }, id, { blob: f.fotos[n] });
      S.fotos.push({ id: it.id, registro_id: id, tipo: 'inspecao', path, _blob: f.fotos[n], _fila: true });
    }
    Store.addInsp(local);
    A.tmp.form = null;
    if (A.tmp.busca?.q) A.guardarRecente(A.tmp.busca.q);
    const prox = A.Escopo.proximo(e), off = !navigator.onLine;
    UI.dialogo({ corpo: `<div class="success ${st}"><div class="ic">${ico(st === 'ok' ? 'check' : 'alert')}</div><h2>${esc(e.codigo)} — ${st === 'ok' ? 'Conforme' : 'Não conforme'}</h2><p>${off ? 'Salvo no aparelho. Será enviado quando a conexão voltar.' : 'Inspeção registrada.'}${st === 'nc' ? ' A NC foi adicionada à lista de abertas.' : ''}</p>${st === 'nc' ? `<p class="hint" style="margin-top:8px">${esc(local.resumo)}</p>` : ''}${mud.length ? `<p class="hint" style="margin-top:8px">Ponto atualizado: ${esc(mud.join(', '))}.</p>` : ''}${prox ? `<p class="hint" style="margin-top:10px">Próximo pendente perto: <b>${esc(prox.codigo)}</b> · ${esc(prox.local)}</p>` : ''}</div>`,
      rodape: `<a class="btn btn-sec" href="#/nova?ger=${e.ger}&cat=${e.cat}">Lista</a>${st === 'nc' ? `<a class="btn btn-sec" href="#/desvio/novo?eq=${e.id}&origem=inspecao&insp=${id}">${ico('headset')}Comunicado de desvio</a>` : ''}${prox ? `<a class="btn btn-pri" href="#/inspecao/${prox.id}?de=lista">Próximo: ${esc(prox.codigo)}</a>` : `<a class="btn btn-pri" href="#/inicio">Início</a>`}` });
    A.Router.chrome();
    A.Sync.ciclo();
  } finally { btn.disabled = false; }
};
