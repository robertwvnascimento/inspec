/* Inspec — Relatórios: documentos A4 (imprimir/PDF) e planilhas Excel */
import { A } from '../ns.js';
import { Store, Regras } from '../dados.js';
import { UI, Comp, Cal } from '../ui.js';
import { abrirDocumento } from '../janela.js';
import { evento } from '../db.js';
import { Dados } from './painel.js';
import { tempoResp } from './desvios.js';
import { valorAlt } from './ponto.js';
import { QR } from '../qr.js';
import { ico, esc, Util, Periodo, Ciclos, CK, itensDe, GATILHOS, ACIONADORES, MEIOS, ORIGENS_TROCA, ORIGEM_ALT, CAMPOS_ALT, LOGO } from '../util.js';

const V = A.V;
const CSS = `*{box-sizing:border-box}body{margin:0;background:#E9EEF3;font-family:Inter,Arial,sans-serif;color:#16222E;font-size:12px;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.pg{width:210mm;min-height:297mm;margin:14px auto;background:#fff;padding:14mm 14mm 16mm;box-shadow:0 4px 20px rgba(0,0,0,.12);position:relative}
.cab{display:flex;justify-content:space-between;align-items:center;border-bottom:3px solid #00A87E;padding-bottom:10px;margin-bottom:14px}.cab img{height:38px}.cab .t{text-align:right}.cab .t b{display:block;font-family:Poppins,Arial;font-size:16px;color:#0A2F57}.cab .t span{color:#6B7C8D;font-size:10.5px}
.capa{background:linear-gradient(120deg,#082646,#0A2F57 60%,#123F70);color:#fff;border-radius:10px;padding:20px 22px;margin-bottom:14px}.capa h1{font-family:Poppins,Arial;margin:0 0 4px;font-size:22px}.capa p{margin:0;opacity:.85}.capa .f{margin-top:12px;display:flex;flex-wrap:wrap;gap:6px}.capa .f span{background:rgba(255,255,255,.14);border-radius:999px;padding:3px 10px;font-size:10.5px}
h2{font-family:Poppins,Arial;font-size:14px;color:#0A2F57;margin:16px 0 8px;padding-bottom:4px;border-bottom:1px solid #DCE4EC;break-after:avoid}
.kp{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.kp div{border:1px solid #DCE4EC;border-radius:8px;padding:8px 10px}.kp span{display:block;font-size:10px;color:#6B7C8D;font-weight:600}.kp b{font-family:Poppins,Arial;font-size:20px;color:#0B2440}.kp small{display:block;color:#44576A;font-size:10px}
table.t{width:100%;border-collapse:collapse;font-size:10.5px;margin-top:4px}.t th{background:#0A2F57;color:#fff;text-align:left;padding:5px 6px;font-weight:600}.t td{border-bottom:1px solid #E6ECF2;padding:4px 6px;vertical-align:top}.t tr:nth-child(even) td{background:#F7FAFC}.t .n{text-align:right;font-variant-numeric:tabular-nums}
.tag{display:inline-block;border-radius:4px;padding:1px 6px;font-weight:700;font-size:9.5px}.ok{background:#E4F5EC;color:#1E8E5A}.nc{background:#FDECEA;color:#C0362C}.wr{background:#FFF4DC;color:#A86A00}
.ass{display:grid;grid-template-columns:1fr 1fr;gap:30px;margin-top:34px}.ass div{border-top:1px solid #8795A1;padding-top:4px;font-size:10px;color:#6B7C8D}
.rod{margin-top:18px;display:flex;justify-content:space-between;color:#8795A1;font-size:9px;border-top:1px solid #E6ECF2;padding-top:4px}
@media print{body{background:#fff}.pg{margin:0;box-shadow:none;width:auto;min-height:auto;padding:10mm 11mm 12mm}@page{size:A4;margin:0}}
.t td{overflow-wrap:break-word}.t td:first-child{white-space:nowrap}.t thead{display:table-header-group}`;
/* relatórios com muitas colunas saem em A4 paisagem */
const CSS_PAISAGEM = CSS + `.pg{width:297mm;min-height:210mm}@media print{@page{size:A4 landscape;margin:0}}`;

export const Rel = {
  pagina(titulo, sub, filtros, conteudo) {
    const S = Store.S;
    return `<div class="pg"><div class="cab"><img src="${location.origin}${LOGO}" alt="Inspec"><div class="t"><b>${esc(titulo)}</b><span>${esc(S.org.nome)} · ${esc(S.unidade.nome)} · emitido em ${Util.fmtDataHora(new Date())} por ${esc(S.eu.nome)}</span></div></div>
      <div class="capa"><h1>${esc(titulo)}</h1><p>${esc(sub)}</p><div class="f">${filtros.map(x => `<span>${esc(x)}</span>`).join('')}</div></div>${conteudo}
      <div class="ass"><div>Responsável técnico — Brigada / Bombeiros Civis</div><div>Gerência de Saúde e Segurança do Trabalho</div></div>
      <div class="rod"><span>Inspec · Gestão inteligente de inspeções — documento gerado pelo sistema</span><span>Referências: NR-23 · NBR 12962 · NBR 13714</span></div></div>`;
  },
  kp: itens => `<div class="kp">${itens.map(([l, v, s]) => `<div><span>${l}</span><b>${v}</b>${s ? `<small>${s}</small>` : ''}</div>`).join('')}</div>`,
  tab: (head, rows, num = []) => `<table class="t"><thead><tr>${head.map((h, i) => `<th class="${num.includes(i) ? 'n' : ''}">${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${r.map((c, i) => `<td class="${num.includes(i) ? 'n' : ''}">${String(c ?? '').startsWith('<span class="tag') ? c : esc(c)}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${head.length}">Sem registros.</td></tr>`}</tbody></table>`,
  st: i => i.st === 'ok' ? '<span class="tag ok">Conforme</span>' : '<span class="tag nc">Não conforme</span>',
  async excel(nome, abas) {
    if (!window.XLSX) await new Promise((ok, er) => { const sc = document.createElement('script'); sc.src = '/vendor/xlsx.mini.min.js'; sc.onload = ok; sc.onerror = er; document.head.appendChild(sc); });
    const X = window.XLSX, wb = X.utils.book_new();
    for (const sh of abas) {
      const ws = X.utils.aoa_to_sheet([sh.head, ...sh.rows]);
      ws['!cols'] = sh.head.map((h, i) => ({ wch: Math.min(48, Math.max(String(h).length + 2, ...sh.rows.slice(0, 300).map(r => String(r[i] ?? '').length + 1))) }));
      if (sh.rows.length) ws['!autofilter'] = { ref: X.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: sh.rows.length, c: sh.head.length - 1 } }) };
      X.utils.book_append_sheet(wb, ws, sh.nome.slice(0, 31));
    }
    X.writeFile(wb, nome + '.xlsx'); evento('app.exportacao', { rotulo: nome + '.xlsx', abas: abas.map(a => `${a.nome} (${a.rows.length})`).join(', ') }); UI.toast(`Excel gerado (${Util.plural(abas.length, 'aba')}).`);
  },
  /* ---------- planilhas ---------- */
  formsAba(lista) {
    const cols = ['Data da inspeção', 'Bombeiro', 'Gerência', 'Tipo de ponto', 'Nº do ponto', 'Área', 'Local', 'Nº do cilindro', 'Agente extintor', 'N2', 'N3'];
    const itensCols = []; for (const c of ['extintor', 'hidrante', 'maca']) for (const it of CK[c].itens) itensCols.push([c, it]); for (const it of [...CK.chuveiro.pressurizado, ...CK.chuveiro.itens]) itensCols.push(['chuveiro', it]);
    const head = [...cols, ...itensCols.flatMap(([c, it]) => [`${CK[c].secao} · ${it.l}`, `Descrever NC · ${it.l}`]), 'Cor do anel', 'Base', 'Troca do extintor?', 'Motivo da troca', 'Qtd mangueiras', 'Qtd chaves Storz', 'Qtd esguicho agulheta', 'Qtd esguicho regulável', 'Mangueiras — teste hidrostático (último → próximo)', 'Vencimento kit (maca)', 'Pressurizado?', 'Observação', 'Qtd fotos', 'Resultado', 'Ciclo', 'Origem', 'ID do registro'];
    const rows = lista.map(i => { const e = Store.eq(i.eq), ck = i.ck || {}, cab = ck.cab || {};
      const base = [Util.fmtDataHora(i.dt), Store.usuario(i.ins).nome, Store.ger(e.ger).nome, Store.cat(e.cat).nome, e.codigo, e.area, e.local, cab.fab ?? '', cab.agente ?? '', Util.mes(cab.n2) || '', cab.n3 ?? ''];
      const its = itensCols.flatMap(([c, it]) => c !== e.cat ? ['', ''] : [(ck.it && ck.it[it.k]) || '', (ck.desc && ck.desc[it.k]) || '']);
      return [...base, ...its, ck.op?.anel || '', ck.op?.base || '', e.cat === 'extintor' ? (ck.troca || '') : '', ck.motivo || '', ck.qtd?.mangueiras ?? '', ck.qtd?.storz ?? '', ck.qtd?.agulheta ?? '', ck.qtd?.regulavel ?? '', (ck.mang || []).map((m, i) => `M${i + 1}: ${Util.mes(m.ult)} → ${Util.mes(m.prox)}`).join(' · '), cab.kitVenc || '', e.cat === 'chuveiro' ? (ck.press ? 'Sim' : 'Não') : '', i.obs, Store.fotosDe(i.id).length, i.st === 'ok' ? 'Conforme' : 'Não conforme', Ciclos.rotulo(i.ciclo), i.origem, i.id]; });
    return { nome: 'Inspeções', head, rows };
  },
  excelForms(lista, nome) { return Rel.excel(nome, [Rel.formsAba(lista)]); },
  ncsAba(f) {
    const l = Regras.ncsAbertas(f.ger).filter(x => !f.cat || x.e.cat === f.cat);
    return { nome: 'NCs abertas', head: ['Ponto', 'Tipo', 'Gerência', 'Área', 'Local', 'Aberta desde', 'Dias', 'Não conformidade', 'Registrada por', 'Fotos'], rows: l.map(({ e, s, desde }) => [e.codigo, Store.cat(e.cat).nome, Store.ger(e.ger).nome, e.area, e.local, Util.fmtData(desde), Util.diasEntre(desde, new Date()), Regras.textoNC(s.ultima), Store.usuario(s.ultima.ins).nome, Store.fotosDe(s.ultima.id).length]) };
  },
  n2Aba(f) {
    const l = Store.S.pontos.filter(e => e.ativo && e.cat === 'extintor' && Dados.eqOk(e, f)).map(e => ({ e, n: Regras.n2(e) })).sort((a, b) => (a.e.n2 || '9').localeCompare(b.e.n2 || '9'));
    const rot = { vencida: 'Vencida', mes: 'Vence neste mês', proxima: 'Próximos 75 dias', ok: 'Em dia' };
    return { nome: 'Validade N2', head: ['Ponto', 'Gerência', 'Área', 'Local', 'Nº do cilindro', 'Agente', 'N2 (recarga)', 'N3 (teste)', 'Situação N2'], rows: l.map(({ e, n }) => [e.codigo, Store.ger(e.ger).nome, e.area, e.local, e.fab, e.agente, Util.mes(e.n2), e.n3 || '', n ? rot[n.st] : 'Sem data']) };
  },
  reservaAbas() {
    return [{ nome: 'Reserva técnica', head: ['Agente', 'Estoque', 'Mínimo', 'Situação', 'Atualizado em'], rows: Store.S.reserva.map(r => [r.agente, r.quantidade, r.minimo, r.minimo && r.quantidade <= r.minimo ? 'Repor' : 'OK', Util.fmtDataHora(r.atualizado_em)]) },
      { nome: 'Movimentações', head: ['Data', 'Agente', 'Tipo', 'Qtd', 'Referência', 'Usuário'], rows: Store.S.movs.map(m => [Util.fmtDataHora(m.criado_em), m.agente, m.tipo, m.qtd, m.referencia || '', Store.usuario(m.usuario_id).nome]) }];
  },
  desviosAba(f) {
    return { nome: 'Comunicados de desvio', head: ['Nº', 'Gatilho', 'Origem', 'Acionado por', 'Meio', 'Acionamento', 'Chegada', 'Resposta (min)', 'Ponto', 'Gerência', 'Local', 'Situação encontrada', 'Substituição', 'Reserva', 'Cilindro retirado', 'Cilindro instalado', 'Ação', 'Pendências', 'Status', 'Encerrado em', 'Bombeiro', 'One Page enviado'],
      rows: Dados.desvios(f).map(d => { const e = Store.eq(d.ponto_id), ok = Store.S.envios.find(x => x.desvio_id === d.id && x.status === 'enviado'); return [d.numero || '(na fila)', GATILHOS[d.gatilho]?.nome, d.origem === 'producao' ? 'Produção' : 'Inspeção', d.origem === 'producao' ? `${ACIONADORES[d.acionador_papel] || ''}${d.acionador_nome ? ' — ' + d.acionador_nome : ''}` : '', MEIOS[d.meio]?.nome || '', Util.fmtDataHora(d.acionado_em), Util.fmtDataHora(d.chegada_em), tempoResp(d) ?? '', e?.codigo, e ? Store.ger(e.ger).nome : '', e?.local, d.descricao, d.substituir ? 'Sim' : 'Não', d.reserva === 'usada' ? 'Usada' : d.reserva === 'indisponivel' ? 'Indisponível' : '', d.cilindro_retirado || '', d.cilindro_instalado || '', d.acao, d.pendencias || '', d.status === 'pendente' ? 'Pendente' : 'Encerrado', d.encerrado_em ? Util.fmtDataHora(d.encerrado_em) : '', Store.usuario(d.bombeiro_id).nome, ok ? Util.fmtDataHora(ok.enviado_em) : 'Não']; }) };
  },
  rastreioAbas(f) {
    const okP = id => !f.ponto || id === f.ponto;
    const tr = Dados.trocas(f).filter(t => okP(t.ponto_id)), al = Store.S.alts.filter(a => okP(a.ponto_id) && Periodo.ok(a.criado_em, f) && Dados.eqOk(Store.eq(a.ponto_id), f));
    return [{ nome: 'Trocas de equipamento', head: ['Data', 'Ponto', 'Gerência', 'Motivo', 'Origem', 'Referência', 'Fonte', 'Retirado (cilindro)', 'Retirado (agente)', 'Retirado N2', 'Instalado (cilindro)', 'Instalado (agente)', 'Instalado N2', 'Instalado N3', 'Observação', 'Usuário'],
      rows: tr.map(t => { const e = Store.eq(t.ponto_id); return [Util.fmtDataHora(t.criado_em), e?.codigo, e ? Store.ger(e.ger).nome : '', t.motivo, t.origem, t.referencia || '', ORIGENS_TROCA[t.fonte] || '', t.ret_cilindro || '', t.ret_agente || '', Util.mes(t.ret_n2), t.ins_cilindro, t.ins_agente || '', Util.mes(t.ins_n2), t.ins_n3 || '', t.observacao || '', Store.usuario(t.usuario_id).nome]; }) },
    { nome: 'Alterações nos pontos', head: ['Data', 'Ponto', 'O que mudou', 'De', 'Para', 'Origem', 'Referência', 'Usuário'],
      rows: al.map(a => [Util.fmtDataHora(a.criado_em), Store.eq(a.ponto_id)?.codigo, CAMPOS_ALT[a.campo] || a.campo, valorAlt(a.campo, a.de), valorAlt(a.campo, a.para), ORIGEM_ALT[a.origem]?.[0] || a.origem, a.referencia || '', Store.usuario(a.usuario_id).nome]) }];
  },
  pontosAba() {
    return { nome: 'Pontos', head: ['Código', 'Tipo', 'Gerência', 'Sigla', 'Área', 'Local', 'Equipamento previsto', 'Capacidade', 'Nº do cilindro', 'Agente', 'N2', 'N3', 'Bombeiro responsável', 'ID da etiqueta QR', 'Conteúdo do QR', 'Etiqueta impressa em', 'Situação', 'Cadastrado em'],
      rows: Store.S.pontos.map(e => [e.codigo, Store.cat(e.cat).nome, Store.ger(e.ger).nome, Store.ger(e.ger).sigla, e.area, e.local, e.subtipo, e.cap, e.fab, e.agente, Util.mes(e.n2), e.n3 || '', e.resp ? Store.usuario(e.resp).nome : '', QR.fmt(e.qr), e.qr ? QR.url(e) : '', e.qrImpresso ? Util.fmtData(e.qrImpresso) : '', e.ativo ? 'Ativo' : 'Inativo', Util.fmtData(e.criado)]) };
  },
  /* ---------- documento consolidado ---------- */
  consolidado(f) {
    const S = Store.S, ins = Dados.insp(f), [c, nc] = Dados.cn(ins), cob = Dados.cobertura(f), dv = Dados.desvios(f), tr = Dados.trocas(f);
    const ncsAb = Regras.ncsAbertas(f.ger).filter(x => !f.cat || x.e.cat === f.cat);
    const filtros = Rel.filtrosTxt({ ...f, ponto: '' });
    const porGer = S.gers.map(g => { const l = ins.filter(i => Store.eq(i.eq).ger === g.id), cb = Dados.cobertura({ ...f, ger: g.id }), [a, b] = Dados.cn(l); return [g.nome, cb.total, cb.feitos, cb.pend, cb.pct + '%', l.length, b]; }).filter(r => r[1] && (!f.ger || r[0] === Store.ger(f.ger).nome));
    const porCat = Store.categorias().map(x => { const cb = Dados.cobertura({ ...f, cat: x.chave }), l = ins.filter(i => Store.eq(i.eq).cat === x.chave); return [x.plural, x.per, cb.total, cb.feitos, cb.pct + '%', l.length, Dados.cn(l)[1]]; }).filter(r => r[2] && (!f.cat || r[0] === Store.cat(f.cat).plural));
    const porBomb = [...Dados.agrupar(ins, i => i.ins)].map(([u, l]) => [Store.usuario(u).nome, l.length, Dados.cn(l)[0], Dados.cn(l)[1], new Set(l.map(i => i.dt.slice(0, 10))).size]).sort((a, b) => b[1] - a[1]);
    const n2 = Rel.n2Aba(f).rows.filter(r => r[8] === 'Vencida' || r[8] === 'Vence neste mês');
    const resp = dv.map(tempoResp).filter(x => x != null);
    const corpo = Rel.kp([['Cobertura do ciclo atual', cob.pct + '%', `${cob.feitos} de ${cob.total} pontos`], ['Inspeções no período', ins.length, `${c} conformes · ${nc} NC`], ['Taxa de NC', Util.pct(nc, ins.length) + '%', ''], ['NCs abertas', ncsAb.length, 'na data de emissão']]) + '<div style="height:8px"></div>' +
      Rel.kp([['Comunicados de desvio', dv.length, `${dv.filter(d => d.status === 'pendente').length} pendente(s)`], ['Tempo médio de resposta', (resp.length ? Math.round(resp.reduce((a, b) => a + b, 0) / resp.length) : 0) + ' min', 'acionamentos pela produção'], ['Trocas de equipamento', tr.length, 'no período'], ['N2 vencida', n2.filter(r => r[8] === 'Vencida').length, 'extintores ativos']]) +
      `<h2>Cobertura e conformidade por gerência</h2>${Rel.tab(['Gerência', 'Pontos', 'Inspecionados (ciclo)', 'Pendentes', 'Cobertura', 'Inspeções no período', 'NC no período'], porGer, [1, 2, 3, 4, 5, 6])}
      <h2>Por categoria</h2>${Rel.tab(['Categoria', 'Periodicidade', 'Pontos', 'Inspecionados (ciclo)', 'Cobertura', 'Inspeções no período', 'NC'], porCat, [2, 3, 4, 5, 6])}
      <h2>Produtividade da equipe</h2>${Rel.tab(['Bombeiro', 'Inspeções', 'Conformes', 'NC', 'Dias com inspeção'], porBomb, [1, 2, 3, 4])}
      <h2>Não conformidades abertas (${ncsAb.length})</h2>${Rel.tab(['Ponto', 'Gerência', 'Local', 'Desde', 'Dias', 'Não conformidade'], ncsAb.slice(0, 60).map(({ e, s, desde }) => [e.codigo, Store.ger(e.ger).sigla, e.local || e.area, Util.fmtData(desde), Util.diasEntre(desde, new Date()), Regras.textoNC(s.ultima)]), [4])}
      <h2>Comunicados de desvio no período (${dv.length})</h2>${Rel.tab(['Nº', 'Gatilho', 'Ponto', 'Data', 'Resposta', 'Substituição', 'Status'], dv.map(d => [d.numero || '(fila)', GATILHOS[d.gatilho]?.nome, Store.eq(d.ponto_id)?.codigo, Util.fmtDataHora(d.acionado_em), tempoResp(d) != null ? tempoResp(d) + ' min' : '—', d.substituir ? (d.cilindro_instalado ? 'Realizada' : 'Sem reserva') : 'Não', d.status === 'pendente' ? '<span class="tag wr">Pendente</span>' : '<span class="tag ok">Encerrado</span>']))}
      <h2>Trocas de equipamento no período (${tr.length})</h2>${Rel.tab(['Data', 'Ponto', 'Motivo', 'Retirado', 'Instalado', 'Origem'], tr.slice(0, 80).map(t => [Util.fmtData(t.criado_em), Store.eq(t.ponto_id)?.codigo, t.motivo, t.ret_cilindro || '—', t.ins_cilindro, t.origem === 'desvio' ? 'Desvio ' + (t.referencia || '') : t.origem]))}
      <h2>Extintores com N2 vencida ou vencendo no mês (${n2.length})</h2>${Rel.tab(['Ponto', 'Gerência', 'Local', 'Cilindro', 'Agente', 'N2', 'Situação'], n2.map(r => [r[0], r[1], r[3], r[4], r[5], r[6], r[8] === 'Vencida' ? '<span class="tag nc">Vencida</span>' : '<span class="tag wr">Vence no mês</span>']))}`;
    abrirDocumento('Relatório consolidado do período', CSS, Rel.pagina('Relatório consolidado do período', 'Inspeções de equipamentos de emergência — visão executiva', filtros, corpo),
      { excel: () => Rel.excel(`inspec_consolidado_${Util.hojeISO()}`, [Rel.formsAba(ins), Rel.ncsAba(f), Rel.desviosAba(f), ...Rel.rastreioAbas(f), Rel.n2Aba(f)]) });
  },
  ncsDoc(f) {
    const a = Rel.ncsAba(f);
    abrirDocumento('Não conformidades abertas', CSS, Rel.pagina('Não conformidades abertas', 'Lista priorizada pela idade da não conformidade', [f.ger ? Store.ger(f.ger).nome : 'Todas as gerências', `Emitido em ${Util.fmtData(new Date())}`], Rel.tab(a.head.slice(0, 9), a.rows.map(r => r.slice(0, 9)), [6])), { excel: () => Rel.excel('inspec_ncs_abertas_' + Util.hojeISO(), [a]) });
  }
};
A.Rel = Rel;

/* ---------------- catálogo de relatórios (tela, PDF e Excel) ---------------- */
const pick = (aba, idx) => ({ head: idx.map(i => aba.head[i]), rows: aba.rows.map(r => idx.map(i => r[i])) });
const st = v => v === 'Conforme' ? '<span class="tag ok">Conforme</span>' : v === 'Não conforme' ? '<span class="tag nc">Não conforme</span>' : v;
export const RELATORIOS = [
  { id: 'consolidado', icone: 'chart', titulo: 'Relatório consolidado do período', desc: 'KPIs, cobertura do ciclo, conformidade por gerência e categoria, produtividade, NCs, desvios, trocas e N2.', painel: false },
  { id: 'inspecoes', icone: 'clipboard', titulo: 'Inspeções do período', desc: 'Todas as inspeções com ponto, bombeiro, resultado e não conformidade. O Excel sai no formato completo do Forms.' },
  { id: 'ncs', icone: 'alert', titulo: 'Não conformidades abertas', desc: 'Lista priorizada por idade, com item NC, local, responsável e evidências.' },
  { id: 'desvios', icone: 'headset', titulo: 'Comunicados de desvio', desc: 'Gatilhos, origens, tempos de resposta, reserva técnica, substituições e envio do One Page.', paisagem: true },
  { id: 'rastreio', icone: 'history', titulo: 'Rastreabilidade dos pontos', desc: 'Trocas de equipamento (retirado → instalado) e alterações de cadastro, com quem e quando. Escolha um ponto para ver o dossiê completo dele.', ponto: true },
  { id: 'n2', icone: 'extintor', titulo: 'Validade N2 e reserva técnica', desc: 'Situação de recarga de cada extintor, estoque da reserva e movimentações.' },
  { id: 'pontos', icone: 'qr', titulo: 'Cadastro de pontos e etiquetas QR', desc: 'Todos os pontos com equipamento instalado, responsável e ID da etiqueta QR.', paisagem: true }
];
Object.assign(Rel, {
  /** seções resumidas (para a tela e o PDF) */
  secoes(id, f) {
    const S = Store.S;
    if (id === 'inspecoes') {
      const l = Dados.insp(f);
      return [{ titulo: `Inspeções (${l.length})`, head: ['Data', 'Ponto', 'Tipo', 'Gerência', 'Local', 'Bombeiro', 'Resultado', 'Não conformidade', 'Fotos'], num: [8],
        rows: l.map(i => { const e = Store.eq(i.eq); return [Util.fmtDataHora(i.dt), e.codigo, Store.cat(e.cat).nome, Store.ger(e.ger).sigla, e.local || e.area, Store.usuario(i.ins).nome, st(i.st === 'ok' ? 'Conforme' : 'Não conforme'), i.resumo || '', Store.fotosDe(i.id).length]; }) }];
    }
    if (id === 'ncs') { const a = Rel.ncsAba(f); return [{ titulo: `Não conformidades abertas (${a.rows.length})`, ...a, num: [6, 9] }]; }
    if (id === 'desvios') { const a = Rel.desviosAba(f); return [{ titulo: `Comunicados de desvio (${a.rows.length})`, ...pick(a, [0, 1, 2, 5, 7, 8, 11, 12, 18, 21]), num: [4] }]; }
    if (id === 'n2') { const a = Rel.n2Aba(f), [r, m] = Rel.reservaAbas(); return [{ titulo: `Extintores — validade da recarga (${a.rows.length})`, ...a }, { titulo: 'Reserva técnica — estoque', ...r, num: [1, 2] }, { titulo: 'Reserva técnica — movimentações', ...m, num: [3] }]; }
    if (id === 'pontos') { const a = Rel.pontosAba(); return [{ titulo: `Pontos (${a.rows.length})`, ...pick(a, [0, 1, 2, 4, 5, 8, 9, 10, 12, 13, 16]) }]; }
    if (id === 'rastreio') {
      const [t, al] = Rel.rastreioAbas(f), out = [];
      if (f.ponto) {
        const e = Store.eq(f.ponto), d = e.dados || {};
        out.push({ titulo: `Ponto ${e.codigo}`, head: ['Campo', 'Valor'], rows: [['Tipo', Store.cat(e.cat).nome], ['Gerência', Store.ger(e.ger).nome], ['Área / local', `${e.area}${e.local && e.local !== e.area ? ' · ' + e.local : ''}`], ['Equipamento previsto', e.subtipo || '—'],
          ...(e.cat === 'extintor' ? [['Cilindro instalado', e.fab || '—'], ['Agente', e.agente || '—'], ['N2 / N3', `${Util.mes(e.n2) || '—'} / ${e.n3 || '—'}`]] : []),
          ...(Array.isArray(d.mangueiras) ? d.mangueiras.map((m, i) => [`Mangueira ${i + 1}`, `teste ${Util.mes(m.ult)} · próximo ${Util.mes(m.prox)}`]) : []),
          ['Bombeiro responsável', e.resp ? Store.usuario(e.resp).nome : '—'], ['Etiqueta QR', `${e.qr ? e.qr.slice(0, 4) + '-' + e.qr.slice(4) : '—'}${e.qrImpresso ? ' · impressa em ' + Util.fmtData(e.qrImpresso) : ''}`], ['Situação', e.ativo ? 'Ativo' : 'Inativo'], ['Cadastrado em', Util.fmtData(e.criado)]] });
      }
      out.push({ titulo: `Trocas de equipamento (${t.rows.length})`, ...pick(t, f.ponto ? [0, 3, 4, 5, 7, 10, 12, 15] : [0, 1, 3, 4, 7, 10, 15]) });
      out.push({ titulo: `Alterações de cadastro (${al.rows.length})`, ...pick(al, f.ponto ? [0, 2, 3, 4, 5, 7] : [0, 1, 2, 3, 4, 5, 7]) });
      if (f.ponto) {
        const ins = Store.inspecoesDe(f.ponto).filter(i => Periodo.ok(i.dt, f)), dv = S.desvios.filter(d => d.ponto_id === f.ponto && Periodo.ok(d.acionado_em, f));
        out.push({ titulo: `Inspeções (${ins.length})`, head: ['Data', 'Bombeiro', 'Resultado', 'Não conformidade / observação', 'Fotos'], num: [4], rows: ins.map(i => [Util.fmtDataHora(i.dt), Store.usuario(i.ins).nome, i.anulada ? 'Anulada' : st(i.st === 'ok' ? 'Conforme' : 'Não conforme'), i.resumo || i.obs || '', Store.fotosDe(i.id).length]) });
        out.push({ titulo: `Comunicados de desvio (${dv.length})`, head: ['Nº', 'Gatilho', 'Data', 'Situação encontrada', 'Status'], rows: dv.map(d => [d.numero || '(fila)', GATILHOS[d.gatilho]?.nome, Util.fmtDataHora(d.acionado_em), d.descricao, d.status === 'pendente' ? 'Pendente' : 'Encerrado']) });
      }
      return out;
    }
    return [];
  },
  abas(id, f) {
    if (id === 'consolidado') return [Rel.formsAba(Dados.insp(f)), Rel.ncsAba(f), Rel.desviosAba(f), ...Rel.rastreioAbas(f), Rel.n2Aba(f)];
    if (id === 'inspecoes') return [Rel.formsAba(Dados.insp(f))];
    if (id === 'ncs') return [Rel.ncsAba(f)];
    if (id === 'desvios') return [Rel.desviosAba(f)];
    if (id === 'rastreio') {
      const ab = Rel.rastreioAbas(f);
      if (f.ponto) { const sec = Rel.secoes('rastreio', f), pl = t => sec.find(x => x.titulo.startsWith(t)); ab.unshift({ nome: 'Ponto', head: pl('Ponto').head, rows: pl('Ponto').rows }); const ins = pl('Inspeções'), dv = pl('Comunicados'); ab.push({ nome: 'Inspeções', head: ins.head, rows: ins.rows.map(r => r.map(c => String(c).replace(/<[^>]+>/g, ''))) }, { nome: 'Desvios', head: dv.head, rows: dv.rows }); }
      return ab;
    }
    if (id === 'n2') return [Rel.n2Aba(f), ...Rel.reservaAbas()];
    if (id === 'pontos') return [Rel.pontosAba()];
    return [];
  },
  filtrosTxt(f) { return [Periodo.rot(f), f.ger ? Store.ger(f.ger).nome : 'Todas as gerências', f.cat ? Store.cat(f.cat).plural : 'Todas as categorias', ...(f.bomb ? ['Bombeiro: ' + Store.usuario(f.bomb).nome] : []), ...(f.ponto ? ['Ponto ' + Store.eq(f.ponto)?.codigo] : [])]; },
  tabelasHTML(id, f, lim) { return Rel.secoes(id, f).map(x => `<h2>${esc(x.titulo)}</h2>${Rel.tab(x.head, lim ? x.rows.slice(0, lim) : x.rows, x.num || [])}${lim && x.rows.length > lim ? `<p class="hint" style="margin:6px 0 0">Mostrando ${lim} de ${x.rows.length} linhas — o PDF e o Excel trazem todas.</p>` : ''}`).join(''); },
  doc(id, f) {
    if (id === 'consolidado') return Rel.consolidado(f);
    const r = RELATORIOS.find(x => x.id === id), tit = id === 'rastreio' && f.ponto ? `Dossiê do ponto ${Store.eq(f.ponto)?.codigo}` : r.titulo;
    abrirDocumento(tit, r.paisagem || (id === 'rastreio' && !f.ponto) ? CSS_PAISAGEM : CSS, Rel.pagina(tit, r.desc, Rel.filtrosTxt(f), Rel.tabelasHTML(id, f)), { excel: () => Rel.xlsx(id, f) });
  },
  xlsx(id, f) { const pt = f.ponto ? '_' + Store.eq(f.ponto)?.codigo : ''; return Rel.excel(`inspec_${id}${pt}_${Util.hojeISO()}`, Rel.abas(id, f)); }
});
/* tabela da tela (estilo do app) */
const tabTela = (x, lim) => `<div class="sec-h" style="margin-top:14px"><h2 style="font-size:15px">${esc(x.titulo)}</h2></div><div class="card tbl-wrap"><table class="tbl"><thead><tr>${x.head.map((h, i) => `<th class="${(x.num || []).includes(i) ? 'num' : ''}">${esc(h)}</th>`).join('')}</tr></thead><tbody>${x.rows.slice(0, lim).map(r => `<tr>${r.map((c, i) => `<td class="${(x.num || []).includes(i) ? 'num' : ''}">${String(c ?? '').startsWith('<span class="tag') ? c.replace('tag ok', 'tag t-ok').replace('tag nc', 'tag t-nc') : esc(c ?? '')}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${x.head.length}">Sem registros.</td></tr>`}</tbody></table></div>${x.rows.length > lim ? `<p class="hint" style="margin:6px 2px 0">Mostrando ${lim} de ${x.rows.length} — use PDF ou Excel para ver tudo.</p>` : ''}`;
V.relTela = (id, f, lim = 150) => Rel.secoes(id, f).map(x => tabTela(x, lim)).join('');
export const seletorPonto = (idInput, f) => `<label class="field" style="margin:0"><span>Ponto</span><input class="input" list="dl-pontos" data-input="${idInput}" value="${esc(f.ponto ? Store.eq(f.ponto)?.codigo || '' : '')}" placeholder="Todos os pontos — digite o código" style="min-height:38px;font-size:14px"><datalist id="dl-pontos">${Store.S.pontos.map(p => `<option value="${esc(p.codigo)}">${esc(Store.cat(p.cat).nome)} · ${esc(p.local || p.area)}</option>`).join('')}</datalist></label>`;
export const pontoDoTexto = v => { const t = String(v || '').trim().toUpperCase(); return t ? (Store.S.pontos.find(p => p.codigo.toUpperCase() === t)?.id || null) : ''; };

A.RELATORIOS = RELATORIOS; A.seletorPonto = seletorPonto; A.pontoDoTexto = pontoDoTexto;

V.relatorios = () => {
  const f = A.filtrosGestao();   // mesmo estado de filtros do Painel de gestão
  return `<div class="p-head"><div><p class="hint" style="margin:0">Documentos prontos para auditoria e gestão — visualize na tela, imprima/salve em PDF ou baixe em Excel. Os filtros abaixo valem para todos e são os mesmos do Painel de gestão.</p></div></div>
  ${V.filtrosGestao(f)}
  <div class="rep-grid" style="margin-top:12px">${RELATORIOS.map(r => `<section class="card rep"><div class="rep-h"><span class="ic">${ico(r.icone)}</span><div><h3>${r.titulo}</h3><p class="hint">${r.desc}</p></div></div>${r.ponto ? `<div class="rep-o">${seletorPonto('rf-ponto', f)}</div>` : ''}<div class="chips"><button class="btn btn-pri btn-sm" data-action="rep-doc" data-t="${r.id}">${ico('printer')}Visualizar / PDF</button><button class="btn btn-sec btn-sm" data-action="rep-xlsx" data-t="${r.id}">${ico('download')}Excel</button></div></section>`).join('')}</div>
  <p class="hint" style="margin-top:12px">Os relatórios usam os dados carregados no aparelho (últimos meses). Toque em <b>Atualizar</b> no painel para trazer o que outros aparelhos enviaram.</p>`;
};
const filtroDo = t => { const f = A.filtrosGestao(); return t === 'rastreio' ? f : { ...f, ponto: '' }; };
Object.assign(A.Inputs, {
  'rf-ponto': el => { const id = pontoDoTexto(el.value); if (id !== null) A.filtrosGestao().ponto = id; }
});
Object.assign(A.Acoes, {
  'rep-doc': el => { const f = filtroDo(el.dataset.t); if (f.ponto === null) return UI.toast('Ponto não encontrado: confira o código.'); Rel.doc(el.dataset.t, f); },
  'rep-xlsx': async el => { const f = filtroDo(el.dataset.t); await UI.ocupado(el, () => Rel.xlsx(el.dataset.t, f)); }
});
