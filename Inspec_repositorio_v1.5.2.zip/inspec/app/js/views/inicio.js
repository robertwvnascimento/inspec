/* Inspec — Início do inspetor (pendências do ciclo) e lista por categoria */
import { A } from '../ns.js';
import { Store, Regras, Fila } from '../dados.js';
import { Comp } from '../ui.js';
import { ico, esc, Util, Ciclos } from '../util.js';

const V = A.V;
const pref = (k, v) => { try { if (v === undefined) return localStorage.getItem('inspec-' + k); localStorage.setItem('inspec-' + k, v); } catch (e) { return null; } };

/* "Meus pontos": extintores com bombeiro responsável; demais categorias são da equipe toda */
export const Escopo = {
  get ger() { return A.tmp.ger ?? (A.tmp.ger = pref('ger') || ''); },
  set ger(v) { A.tmp.ger = v; pref('ger', v); },
  temRota: () => Store.S.pontos.some(e => e.resp === Store.S.eu.id),
  meus: () => pref('meus') !== '0' && Escopo.temRota(),
  noMeu: e => !Escopo.meus() || !e.resp || e.resp === Store.S.eu.id,
  ativos(cat) { const g = Escopo.ger; return Store.S.pontos.filter(e => e.ativo && (!cat || e.cat === cat) && (!g || e.ger === g) && Escopo.noMeu(e)); },
  resumo(cat) {
    let pend = 0, nc = 0, perd = 0, venc = 0, feitos = 0; const lista = Escopo.ativos(cat);
    for (const e of lista) { const s = Regras.situacao(e); if (s.pendente) { pend++; if (s.perdido) perd++; if (s.vence) venc++; } else feitos++; if (s.ncAberta) nc++; }
    return { total: lista.length, pend, feitos, nc, perd, venc };
  },
  proximo(e) {
    const c = Store.S.pontos.filter(x => x.ativo && x.id !== e.id && x.cat === e.cat && x.ger === e.ger && Escopo.noMeu(x) && Regras.situacao(x).pendente);
    return c.find(x => x.area === e.area) || c[0] || null;
  }
};
A.Escopo = Escopo;

V.inicio = () => {
  const agora = new Date(), eu = Store.S.eu, cm = Ciclos.mensal(agora), cs = Ciclos.semanal(agora);
  const dRest = Ciclos.diasRestantesMes(agora), fimSem = new Date(Ciclos.inicioSemana(agora).getTime() + 6 * 864e5);
  const hora = agora.getHours(), saud = hora < 12 ? 'Bom dia' : hora < 18 ? 'Boa tarde' : 'Boa noite';
  if (!Store.S.pontos.length) return `<section class="hello"><h1>${saud}, ${esc(eu.nome.split(' ')[0])}</h1><p>${esc(Store.S.unidade.nome)}</p></section>` +
    Comp.vazio('box', 'Nenhum ponto cadastrado nesta unidade', Regras.pode('admin') ? '<a href="#/admin/importacao">Fazer a carga inicial dos pontos</a>' : 'Aguarde o administrador cadastrar os pontos.');
  const cards = Store.categorias().map(c => {
    const r = Escopo.resumo(c.chave); if (!r.total) return '';
    const p = Util.pct(r.feitos, r.total), done = r.pend === 0;
    return `<a class="cat ${done ? 'done' : ''}" href="#/lista/${c.chave}">
      <div class="h"><span class="ic">${ico(c.icone)}</span><span><b>${esc(c.plural)}</b><span>${c.per === 'mensal' ? 'Mensal' : 'Semanal'} · ${esc(Ciclos.rotulo(c.per === 'mensal' ? cm : cs))}</span></span></div>
      <div class="num"><strong>${done ? ico('check') : r.pend}</strong><span>${done ? 'Concluído' : (r.pend === 1 ? 'pendente' : 'pendentes')}</span></div>
      <div class="bar" role="progressbar" aria-label="Progresso de ${esc(c.plural)}" aria-valuenow="${p}" aria-valuemin="0" aria-valuemax="100"><i style="width:${p}%"></i></div>
      <div class="foot"><span class="hint">${r.feitos} de ${r.total} · ${p}%</span></div>
      <div class="foot">${r.venc && !done ? `<span class="tag t-warn">${ico('clock')}Vence em breve</span>` : ''}${r.perd ? `<span class="tag t-lost">${r.perd} ciclo perdido</span>` : ''}${r.nc ? `<span class="tag t-nc">${r.nc} NC aberta${r.nc > 1 ? 's' : ''}</span>` : ''}</div>
    </a>`;
  }).join('');
  const ncs = Regras.ncsAbertas(Escopo.ger), perdidos = Store.categorias().reduce((a, c) => a + Escopo.resumo(c.chave).perd, 0);
  const meus = Store.S.insp.filter(i => i.ins === eu.id && !i.anulada).slice(0, 5);
  const n2v = Escopo.ativos('extintor').filter(e => Regras.n2(e)?.st === 'vencida').length, fila = Fila.cache.length;
  const nMeus = Store.S.pontos.filter(e => e.ativo && e.resp === eu.id).length;
  return `
  <section class="hello"><h1>${saud}, ${esc(eu.nome.split(' ')[0])}</h1><p>${esc(Store.S.unidade.nome)} · ${Util.fmtData(agora)}</p></section>
  ${V.cartaoInstalar()}
  <div class="cycle-row">
    <div class="cycle ${dRest <= 4 ? 'warn' : ''}"><span class="ic">${ico('clock')}</span><span><b>Ciclo mensal · ${esc(Ciclos.rotulo(cm))}</b><span>${dRest === 0 ? 'Termina hoje' : `Termina em ${Util.plural(dRest, 'dia')}`}</span></span></div>
    <div class="cycle"><span class="ic">${ico('refresh')}</span><span><b>${esc(Ciclos.rotulo(cs))} · chuveiros</b><span>Até ${Util.fmtData(fimSem).slice(0, 5)} (domingo)</span></span></div>
  </div>
  ${Regras.pode('inspecionar') ? `<div class="quick3"><a class="big-search" href="#/nova">${ico('clipboard')}Nova inspeção<span>gerência → tipo → ponto</span></a><a class="big-search at" href="#/desvio/novo">${ico('headset')}Novo comunicado de desvio<span>extrativo · violação · em combate</span></a><a class="big-search sec" href="#/buscar" aria-label="Buscar ponto">${ico('search')}<span style="margin:0;opacity:1;font-weight:600;font-size:15px">Buscar</span></a></div>` : ''}
  ${Escopo.temRota() ? `<div class="meus" role="group" aria-label="Escopo"><button class="chip" data-action="meus" data-v="1" aria-pressed="${Escopo.meus()}">${ico('user')}Meus pontos (${nMeus})</button><button class="chip" data-action="meus" data-v="0" aria-pressed="${!Escopo.meus()}">${ico('users')}Toda a equipe</button></div>` : ''}
  <div class="sec-h"><h2>Pendências do ciclo</h2><div style="min-width:180px">${Comp.selectGerencia('f-ger-inicio', Escopo.ger)}</div></div>
  <div class="cat-grid">${cards}</div>
  <div class="sec-h"><h2>Atenção</h2></div>
  <div class="stack">
    ${ncs.length ? `<a class="alert-card a-red" href="#/ncs"><span class="ic">${ico('alert')}</span><span><b>Não conformidades abertas</b><span>Mais antiga há ${Util.plural(Util.diasEntre(ncs[0].desde, agora), 'dia')} · ${esc(ncs[0].e.codigo)}</span></span><span class="n">${ncs.length}</span></a>` : `<div class="alert-card a-ok"><span class="ic">${ico('check')}</span><span><b>Nenhuma não conformidade aberta</b><span>Tudo em ordem.</span></span></div>`}
    ${n2v ? `<a class="alert-card a-red" href="#/lista/extintor?aba=n2"><span class="ic">${ico('extintor')}</span><span><b>Extintores com recarga (N2) vencida</b><span>Pelo mês de recarga registrado no ponto</span></span><span class="n">${n2v}</span></a>` : ''}
    ${perdidos ? `<a class="alert-card a-amber" href="#/lista/extintor?aba=perdidos"><span class="ic">${ico('clock')}</span><span><b>Pontos com ciclo perdido</b><span>Não inspecionados no ciclo anterior e ainda pendentes</span></span><span class="n">${perdidos}</span></a>` : ''}
    ${fila ? `<a class="alert-card a-amber" href="#/menu"><span class="ic">${ico('send')}</span><span><b>Registros aguardando envio</b><span>Serão enviados quando a conexão voltar</span></span><span class="n">${fila}</span></a>` : ''}
  </div>
  ${meus.length ? `<div class="sec-h"><h2>Minhas últimas inspeções</h2><a class="hint" href="#/historico?meu=1">Ver todas</a></div>
  <div class="list">${meus.map(i => { const e = Store.eq(i.eq); if (!e) return ''; return `<a class="row" href="#/ponto/${e.id}"><span class="ic">${ico(Store.cat(e.cat).icone)}</span><span class="body"><span class="l1"><span class="code">${esc(e.codigo)}</span><span class="tag ${i.st === 'ok' ? 't-ok' : 't-nc'}">${i.st === 'ok' ? 'OK' : 'Não conforme'}</span>${i.sync === 'fila' ? '<span class="tag t-fila">Na fila</span>' : ''}</span><span class="l3">${Util.fmtCurta(i.dt)} · ${esc(e.local)}</span></span><span class="chev">${ico('chev')}</span></a>`; }).join('')}</div>` : ''}`;
};

/* convite para instalar (some por 30 dias ao dispensar) */
V.cartaoInstalar = () => {
  const P = A.PWA; if (!P || !P.podeInstalar()) return '';
  let disp = 0; try { disp = Number(localStorage.getItem('inspec-pwa-dispensado') || 0); } catch (e) { /* ignore */ }
  if (Date.now() - disp < 30 * 864e5) return '';
  return `<div class="install-card"><img src="/icons/icon-192.png" alt=""><div><b>Instale o Inspec no celular</b><span>Abre pelo ícone, em tela cheia e funciona sem internet.</span></div><button class="btn btn-sm" style="background:#fff;color:#0A2F57" data-action="pwa-instalar">${ico('download')}Instalar</button><button class="x" data-action="pwa-dispensar" aria-label="Agora não">${ico('x')}</button></div>`;
};

V.lista = (cat, q) => {
  const c = Store.cat(cat); if (!Store.S.cats.some(x => x.chave === cat)) return V.naoEncontrado();
  const aba = q.get('aba') || 'pendentes', ger = q.get('ger') ?? Escopo.ger, lim = Number(q.get('lim') || 150);
  const todos = Store.S.pontos.filter(e => e.ativo && e.cat === cat && (!ger || e.ger === ger) && Escopo.noMeu(e)).map(e => ({ e, s: Regras.situacao(e) }));
  const filtros = { pendentes: x => x.s.pendente, inspecionados: x => !x.s.pendente, perdidos: x => x.s.perdido, ncs: x => x.s.ncAberta, n2: x => Regras.n2(x.e)?.st === 'vencida', todos: () => true };
  const cont = k => todos.filter(filtros[k]).length;
  const gs = id => Store.ger(id).sigla;
  const lista = todos.filter(filtros[aba] || filtros.pendentes).sort((a, b) => gs(a.e.ger).localeCompare(gs(b.e.ger)) || a.e.area.localeCompare(b.e.area) || a.e.codigo.localeCompare(b.e.codigo, 'pt', { numeric: true }));
  let html = '', grp = '';
  for (const { e } of lista.slice(0, lim)) {
    const k = e.ger + '|' + e.area;
    if (k !== grp) { grp = k; const n = lista.filter(x => x.e.ger === e.ger && x.e.area === e.area).length; html += `<div class="group-h"><span>${esc(gs(e.ger))} › ${esc(e.area || '—')}</span><span>${n}</span></div>`; }
    html += Comp.linhaEq(e);
  }
  const base = `#/lista/${cat}?ger=${encodeURIComponent(ger)}`;
  const tab = (k, n) => `<a href="${base}&aba=${k}" role="tab" aria-selected="${aba === k}">${n} (${cont(k)})</a>`;
  return `
  <div class="tabs" role="tablist" aria-label="Filtro de situação">${tab('pendentes', 'Pendentes')}${tab('inspecionados', 'Inspecionados')}${tab('ncs', 'NC')}${tab('perdidos', 'Perdidos')}${cat === 'extintor' ? tab('n2', 'N2 vencida') : ''}${tab('todos', 'Todos')}</div>
  ${Escopo.meus() && cat === 'extintor' ? `<p class="hint" style="margin:8px 2px 0">Mostrando só os seus pontos. <button class="linkbtn" data-action="meus" data-v="0" style="padding:0">Ver toda a equipe</button></p>` : ''}
  <div class="toolbar">${Comp.selectGerencia('f-ger-lista', ger)}<a class="btn btn-navy" href="#/buscar?cat=${cat}">${ico('search')}Buscar em ${esc(c.plural.toLowerCase())}</a></div>
  ${lista.length ? `<div class="list">${html}${lista.length > lim ? `<a class="more" href="${base}&aba=${aba}&lim=${lim + 150}" style="text-align:center;text-decoration:none">Mostrar mais (${lista.length - lim} restantes)</a>` : ''}</div>`
    : Comp.vazio('check', aba === 'pendentes' ? 'Nenhuma pendência' : 'Nada por aqui', aba === 'pendentes' ? `Todos os ${esc(c.plural.toLowerCase())} deste filtro foram inspecionados no ciclo.` : 'Nenhum ponto nesta situação.')}`;
};

Object.assign(A.Acoes, { meus: el => { pref('meus', el.dataset.v); A.render(); } });
Object.assign(A.Inputs, {
  'f-ger-inicio': el => { Escopo.ger = el.value; A.render(); },
  'f-ger-lista': el => { const { param, q } = A.Router.parse(); location.hash = `#/lista/${param}?ger=${encodeURIComponent(el.value)}&aba=${q.get('aba') || 'pendentes'}`; }
});
