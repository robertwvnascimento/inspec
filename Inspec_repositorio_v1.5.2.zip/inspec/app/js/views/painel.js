/* Inspec — Painel de gestão (período por calendário, gerência, categoria e bombeiro) */
import { A } from '../ns.js';
import { Store, Regras } from '../dados.js';
import { Comp, Cal, UI } from '../ui.js';
import { tempoResp } from './desvios.js';
import { ico, esc, Util, Periodo, Charts, COR, GATILHOS, CK, INSPECIONA } from '../util.js';

const V = A.V;
export const Dados = {
  eqOk: (e, f) => e && (!f.ger || e.ger === f.ger) && (!f.cat || e.cat === f.cat),
  insp: (f = {}) => Store.S.insp.filter(i => !i.anulada && Periodo.ok(i.dt, f) && (!f.bomb || i.ins === f.bomb) && Dados.eqOk(Store.eq(i.eq), f)),
  desvios: (f = {}) => Store.S.desvios.filter(d => Periodo.ok(d.acionado_em, f) && (!f.bomb || d.bombeiro_id === f.bomb) && Dados.eqOk(Store.eq(d.ponto_id), f)),
  trocas: (f = {}) => Store.S.trocas.filter(t => Periodo.ok(t.criado_em, f) && Dados.eqOk(Store.eq(t.ponto_id), f)),
  cn: l => [l.filter(i => i.st === 'ok').length, l.filter(i => i.st === 'nc').length],
  agrupar(l, chave) { const m = new Map(); for (const x of l) { const k = chave(x); if (k == null) continue; if (!m.has(k)) m.set(k, []); m.get(k).push(x); } return m; },
  cobertura(f = {}) { const l = Store.S.pontos.filter(e => e.ativo && Dados.eqOk(e, f) && (!f.bomb || e.resp === f.bomb)); const p = l.filter(e => Regras.situacao(e).pendente).length; return { total: l.length, feitos: l.length - p, pend: p, pct: Util.pct(l.length - p, l.length) }; },
  itensNC(insps) {
    const m = new Map();
    for (const i of insps) { if (i.st !== 'nc' || !i.ck?.it) continue; const e = Store.eq(i.eq); const its = [...(CK[e.cat].pressurizado || []), ...CK[e.cat].itens];
      for (const [k, v] of Object.entries(i.ck.it)) if (v === 'NC') { const n = its.find(x => x.k === k)?.l || k; const chave = `${Store.cat(e.cat).nome} · ${n}`; m.set(chave, (m.get(chave) || 0) + 1); }
      if (i.ck.troca === 'Sim') m.set('Extintor · Troca necessária', (m.get('Extintor · Troca necessária') || 0) + 1); }
    return [...m.entries()].sort((a, b) => b[1] - a[1]);
  },
  inicioDados() { const l = Store.S.insp; return l.length ? l[l.length - 1].dt.slice(0, 10) : Periodo.hoje(); }
};
A.Dados = Dados;

/* filtros de gestão — um único estado e um único componente, usados pelo Painel e pelo menu Relatórios */
export const filtrosGestao = () => A.tmp.painel || (A.tmp.painel = { ...Periodo.mesAtual(), ger: '', cat: '', bomb: '', ponto: '' });
V.filtrosGestao = (f, extra = '') => {
  const sel = (rot, k, opts, todos) => `<label><span>${rot}</span><select class="select" data-input="pf" data-k="${k}"><option value="">${todos}</option>${opts.map(([v, n]) => `<option value="${v}" ${v === f[k] ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></label>`;
  return `<div class="fbar" style="margin-top:0">${Cal.botao('p-per', f, (de, ate) => { f.de = de; f.ate = ate; A.render(); })}
    ${sel('Gerência', 'ger', Store.S.gers.map(g => [g.id, g.nome]), 'Todas')}
    ${sel('Categoria', 'cat', Store.categorias().map(x => [x.chave, x.plural]), 'Todas')}
    ${sel('Bombeiro', 'bomb', Store.S.membros.filter(m => INSPECIONA.includes(m.papel)).map(m => [m.usuario_id, m.nome]), 'Todos')}
    ${extra}</div>`;
};
A.filtrosGestao = filtrosGestao;
V.painel = () => {
  const f = filtrosGestao();
  if (!Store.S.pontos.length) return Comp.vazio('box', 'Nenhum ponto cadastrado nesta unidade', Regras.pode('admin') ? '<a href="#/admin/importacao">Fazer a carga inicial dos pontos</a>' : 'Aguarde o administrador cadastrar os pontos.');
  const ins = Dados.insp(f), [c, nc] = Dados.cn(ins), cob = Dados.cobertura(f), dv = Dados.desvios(f), tr = Dados.trocas(f);
  const ncsAb = Regras.ncsAbertas(f.ger).filter(x => !f.cat || x.e.cat === f.cat);
  const resp = dv.map(tempoResp).filter(x => x != null), media = resp.length ? Math.round(resp.reduce((a, b) => a + b, 0) / resp.length) : 0;
  const n2 = { vencida: 0, mes: 0, proxima: 0, ok: 0 }; Store.S.pontos.filter(e => e.ativo && e.cat === 'extintor' && Dados.eqOk(e, f)).forEach(e => { const n = Regras.n2(e); if (n) n2[n.st]++; });
  const serie = Periodo.serie(f, ff => Dados.cn(Dados.insp(ff)), Dados.inicioDados());
  const porGer = Store.S.gers.map(g => ({ label: g.sigla + ' · ' + g.nome, ...Dados.cobertura({ ...f, ger: g.id }) })).filter(x => x.total && (!f.ger || x.label.startsWith(Store.ger(f.ger).sigla + ' ')));
  const porBomb = [...Dados.agrupar(ins, i => i.ins)].map(([u, l]) => ({ label: Store.usuario(u).nome, v: Dados.cn(l) })).sort((a, b) => (b.v[0] + b.v[1]) - (a.v[0] + a.v[1]));
  const itens = Dados.itensNC(ins).slice(0, 8);
  return `${V.cartaoInstalar ? V.cartaoInstalar() : ''}
  ${V.filtrosGestao(f, `<button class="btn btn-sec btn-sm" data-action="atualizar" title="Buscar dados novos no servidor">${ico('refresh')}Atualizar</button>`)}
  <div class="kpis kpis-4" style="margin-top:12px">
    ${Comp.kpi('Cobertura do ciclo atual', cob.pct + '%', `${cob.feitos} de ${cob.total} pontos`, cob.pct >= 98 ? COR.c : cob.pct >= 85 ? COR.amber : COR.nc)}
    ${Comp.kpi('Inspeções no período', ins.length, esc(Periodo.rot(f)))}
    ${Comp.kpi('Taxa de não conformidade', Util.pct(nc, ins.length) + '%', `${nc} NC no período`)}
    ${Comp.kpi('NCs abertas agora', ncsAb.length, ncsAb.length ? `mais antiga há ${Util.plural(Util.diasEntre(ncsAb[0].desde, new Date()), 'dia')}` : 'nenhuma', ncsAb.length ? COR.nc : '')}
    ${Comp.kpi('Comunicados de desvio', dv.length, `${dv.filter(d => d.status === 'pendente').length} pendente(s) de reposição`)}
    ${Comp.kpi('Tempo médio de resposta', media + '<span style="font-size:14px"> min</span>', 'acionamentos pela produção')}
    ${Comp.kpi('Trocas de equipamento', tr.length, 'nos pontos, no período')}
    ${Comp.kpi('Extintores com N2 vencida', n2.vencida, `${n2.mes} vencem neste mês`, n2.vencida ? COR.nc : '')}
  </div>
  <div class="pgrid">
    <section class="card chart" style="grid-column:1/-1"><h3>Inspeções no período</h3><p class="sub">Por ${serie.por} · conforme × não conforme</p>${Charts.vbars(serie.rows)}</section>
    <section class="card chart"><h3>Cobertura do ciclo atual por gerência</h3><p class="sub">Pontos inspecionados × pendentes no ciclo vigente</p>${Charts.hbars(porGer.map(x => ({ label: x.label, v: [x.feitos, x.pend] })), { cores: [COR.c, COR.cinza], nomes: ['Inspecionados', 'Pendentes'], rot: 170 })}</section>
    <section class="card chart"><h3>Inspeções por bombeiro</h3><p class="sub">No período filtrado</p>${Charts.hbars(porBomb, { rot: 150 })}</section>
    <section class="card chart"><h3>Itens não conformes mais frequentes</h3><p class="sub">Quantidade de NC por item do checklist</p>${Charts.hbars(itens.map(([l, n]) => ({ label: l, v: [n] })), { cores: [COR.nc], nomes: ['NC'], legenda: false, rot: 190 })}</section>
    <section class="card chart"><h3>Validade da recarga (N2)</h3><p class="sub">Extintores ativos, situação atual</p>${Charts.donut([{ label: 'Vencida', v: n2.vencida, cor: COR.nc }, { label: 'Vence neste mês', v: n2.mes, cor: COR.amber }, { label: 'Próximos 75 dias', v: n2.proxima, cor: '#C99A2E' }, { label: 'Em dia', v: n2.ok, cor: COR.c }])}</section>
    <section class="card chart"><h3>Comunicados de desvio por gatilho</h3><p class="sub">No período filtrado</p>${Charts.donut(Object.entries(GATILHOS).map(([k, g]) => ({ label: g.nome, v: dv.filter(d => d.gatilho === k).length, cor: g.cor })))}</section>
  </div>
  ${ncsAb.length ? `<div class="sec-h"><h2>Não conformidades mais antigas</h2><a class="hint" href="#/ncs">Ver todas</a></div>
  <div class="list">${ncsAb.slice(0, 5).map(({ e, s, desde }) => `<a class="row" href="#/ponto/${e.id}"><span class="ic" style="background:var(--red-bg);color:var(--red)">${ico(Store.cat(e.cat).icone)}</span><span class="body"><span class="l1"><span class="code">${esc(e.codigo)}</span><span class="tag t-nc">há ${Util.plural(Util.diasEntre(desde, new Date()), 'dia')}</span></span><span class="l2">${esc(Regras.textoNC(s.ultima))}</span><span class="l3">${esc(Store.ger(e.ger).sigla)} › ${esc(e.local || e.area)}</span></span></a>`).join('')}</div>` : ''}
  ${V.painelRelatorios(f)}
  <div class="chips" style="margin-top:14px"><a class="btn btn-sec" href="#/pendencias">${ico('clipboard')}Pendências por categoria</a><a class="btn btn-sec" href="#/relatorios">${ico('file')}Relatórios</a><a class="btn btn-sec" href="#/desvios">${ico('flame')}Comunicados de desvio</a></div>
  <p class="hint" style="margin-top:12px">Dados carregados em ${Util.fmtDataHora(Store.S.cargaEm)} · histórico dos últimos ${Math.round((Date.now() - new Date(Dados.inicioDados())) / 864e5)} dias no aparelho.</p>`;
};
/* relatórios do menu Relatórios, vistos aqui na tela com os mesmos filtros (o consolidado é este painel) */
V.painelRelatorios = f => {
  const lista = (A.RELATORIOS || []).filter(r => r.painel !== false), ab = A.tmp.painelRel || 'inspecoes', r = lista.find(x => x.id === ab) || lista[0];
  if (!r) return '';
  return `<div class="sec-h" style="margin-top:22px"><h2>Relatórios</h2><span class="hint">mesmos filtros do painel · sem abrir outra janela</span></div>
  <section class="card pad">
    <div class="tabs" role="tablist" style="margin-bottom:10px">${lista.map(x => `<a href="#/painel" role="tab" data-action="painel-rel" data-t="${x.id}" aria-selected="${x.id === r.id}">${esc(x.titulo.replace(' do período', '').replace('Cadastro de pontos e etiquetas QR', 'Pontos e QR'))}</a>`).join('')}</div>
    <div class="chips" style="align-items:flex-end;gap:10px"><p class="hint" style="margin:0;flex:1;min-width:220px">${esc(r.desc)}</p>${r.ponto ? `<div style="min-width:240px">${A.seletorPonto('pr-ponto', f)}</div>` : ''}<button class="btn btn-sec btn-sm" data-action="painel-rel-doc">${ico('printer')}Visualizar / PDF</button><button class="btn btn-sec btn-sm" data-action="painel-rel-xlsx">${ico('download')}Excel</button></div>
    <div id="painel-rel-corpo">${V.relTela(r.id, { ...f, ponto: r.ponto ? f.ponto : '' })}</div>
  </section>`;
};
Object.assign(A.Inputs, {
  pf: el => { A.tmp.painel[el.dataset.k] = el.value; A.render(); },
  'pr-ponto': el => { const id = A.pontoDoTexto(el.value); if (id === null) return; A.tmp.painel.ponto = id; document.getElementById('painel-rel-corpo').innerHTML = V.relTela('rastreio', A.tmp.painel); }
});
Object.assign(A.Acoes, {
  'painel-rel': (el, ev) => { ev.preventDefault(); A.tmp.painelRel = el.dataset.t; const y = scrollY; A.render(); scrollTo(0, y); },
  'painel-rel-doc': () => { const t = A.tmp.painelRel || 'inspecoes', f = A.tmp.painel; A.Rel.doc(t, { ...f, ponto: t === 'rastreio' ? f.ponto : '' }); },
  'painel-rel-xlsx': async el => { const t = A.tmp.painelRel || 'inspecoes', f = A.tmp.painel; await UI.ocupado(el, () => A.Rel.xlsx(t, { ...f, ponto: t === 'rastreio' ? f.ponto : '' })); }
});
