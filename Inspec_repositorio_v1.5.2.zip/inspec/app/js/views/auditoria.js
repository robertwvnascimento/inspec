/* Inspec — Histórico do sistema (auditoria completa): acessos, alterações, inspeções,
   desvios, usuários, configurações e exportações. Lido direto do servidor; só administradores. */
import { A } from '../ns.js';
import { Store, Regras } from '../dados.js';
import { sb, todos, msgErro, evento } from '../db.js';
import { UI, Comp, Cal } from '../ui.js';
import { valorAlt } from './ponto.js';
import { Rel } from './relatorios.js';
import { ico, esc, Util, Periodo, CAMPOS_ALT, PAPEIS } from '../util.js';

const V = A.V;

/* ---------- vocabulário ---------- */
const ACOES = {
  'acesso.login': ['Entrou no sistema', 'acesso'], 'acesso.logout': ['Saiu do sistema', 'acesso'], 'acesso.sessao': ['Abriu o app (sessão salva)', 'acesso'], 'acesso.inatividade': ['Desconectado por inatividade', 'acesso'],
  'acesso.falha_login': ['Tentativa de login com senha errada', 'alerta'], 'acesso.senha_alterada': ['Alterou a senha', 'acesso'], 'acesso.senha_definida': ['Definiu a senha no 1º acesso', 'acesso'],
  'app.exportacao': ['Exportou planilha Excel', 'export'], 'app.relatorio': ['Abriu relatório para impressão', 'export'], 'app.impressao': ['Imprimiu / salvou PDF', 'export'],
  'app.etiquetas': ['Abriu etiquetas QR', 'export'], 'app.onepage': ['Baixou One Page (PDF)', 'export'], 'app.backup': ['Gerou backup completo', 'export'], 'app.foto': ['Baixou foto da galeria', 'export'],
  'pontos.insert': ['Ponto cadastrado', 'cad'], 'pontos.update': ['Ponto alterado', 'cad'], 'pontos.delete': ['Ponto excluído', 'alerta'],
  'qr_historico.insert': ['Etiqueta QR substituída', 'cad'], 'gerencias.insert': ['Gerência criada', 'cad'], 'gerencias.update': ['Gerência alterada', 'cad'],
  'inspecoes.insert': ['Inspeção registrada', 'insp'], 'inspecoes.update': ['Inspeção alterada', 'alerta'], 'fotos.insert': ['Foto de evidência enviada', 'insp'], 'fotos.delete': ['Foto excluída', 'alerta'],
  'desvios.insert': ['Comunicado de desvio registrado', 'desv'], 'desvios.update': ['Comunicado de desvio atualizado', 'desv'], 'envios_email.insert': ['One Page enviado por e-mail', 'desv'],
  'trocas.insert': ['Troca de equipamento no ponto', 'troca'], 'reserva_movimentos.insert': ['Movimento na reserva técnica', 'troca'], 'reserva_estoque.insert': ['Agente incluído na reserva', 'troca'], 'reserva_estoque.update': ['Estoque da reserva alterado', 'troca'],
  'membros.insert': ['Usuário adicionado à organização', 'usu'], 'membros.update': ['Usuário alterado (perfil/acesso)', 'usu'], 'membros.delete': ['Usuário removido', 'alerta'],
  'membro_unidades.insert': ['Acesso a unidade concedido', 'usu'], 'membro_unidades.delete': ['Acesso a unidade removido', 'usu'],
  'organizacoes.insert': ['Organização criada', 'cfg'], 'organizacoes.update': ['Configuração da organização alterada', 'cfg'], 'unidades.insert': ['Unidade criada', 'cfg'], 'unidades.update': ['Unidade alterada', 'cfg'],
  'categorias.insert': ['Categoria criada', 'cfg'], 'categorias.update': ['Categoria alterada', 'cfg'],
  'agentes.insert': ['Agente extintor cadastrado', 'cfg'], 'agentes.update': ['Agente extintor renomeado', 'cfg'], 'agentes.delete': ['Agente extintor excluído', 'cfg'],
  'destinatarios.insert': ['Destinatário do One Page incluído', 'cfg'], 'destinatarios.update': ['Destinatário alterado', 'cfg'], 'destinatarios.delete': ['Destinatário excluído', 'cfg'],
  organizacao_criada: ['Organização criada', 'cfg'], usuario_criado: ['Criou login de usuário', 'usu'], usuario_excluido: ['Excluiu login de usuário', 'alerta'],
  importacao: ['Importação de pontos', 'cad'], inspecao_anulada: ['Anulou inspeção', 'alerta'], troca_registrada: ['Registrou troca (resumo)', 'troca']
};
const COR = { acesso: 't-info', alerta: 't-nc', export: 't-pend', cad: 't-warn', insp: 't-ok', desv: 't-nc', troca: 't-warn', usu: 't-info', cfg: 't-lost' };
const CATS = {
  acessos: ['Acessos (login, logout, senhas)', ['acesso.*']],
  falhas: ['Tentativas de login com erro', ['acesso.falha_login']],
  pontos: ['Pontos, gerências e etiquetas', ['pontos.*', 'qr_historico.*', 'gerencias.*', 'importacao']],
  inspecoes: ['Inspeções e fotos', ['inspecoes.*', 'fotos.*', 'inspecao_anulada']],
  desvios: ['Comunicados de desvio e e-mails', ['desvios.*', 'envios_email.*']],
  trocas: ['Trocas e reserva técnica', ['trocas.*', 'reserva_*', 'troca_registrada']],
  usuarios: ['Usuários e permissões', ['membros.*', 'membro_unidades.*', 'usuario_*']],
  config: ['Configurações', ['agentes.*', 'organizacoes.*', 'unidades.*', 'categorias.*', 'destinatarios.*', 'organizacao_criada']],
  export: ['Exportações, relatórios e backups', ['app.*']]
};
const nomeAcao = a => (ACOES[a] || [a.replace(/[._]/g, ' '), 'cfg'])[0];
const OCULTOS = new Set(['id', 'org_id', 'unidade_id', 'criado_em', 'atualizado_em', 'recebida_em', 'qr_gerado_em', 'usuario_id', 'criado_por', 'enviado_por', 'inspetor_id', 'bombeiro_id', 'dados', 'membro_id', 'ponto_id', 'registro_id', 'desvio_id', 'categoria_id', 'periodicidade', 'rotulo', 'inspecao_origem_id', 'sinc_tardia', 'anulada_por', 'anulada_em']);
const quem = id => id ? Store.usuario(id).nome : 'Sistema';
const fmtV = (k, v) => {
  if (v == null || v === '') return '—';
  if (typeof v === 'boolean') return k === 'ativo' ? (v ? 'Ativo' : 'Inativo') : v ? 'Sim' : 'Não';
  if (['gerencia_id', 'bombeiro_id', 'unidade_id', 'qr_id', 'n2'].includes(k)) return valorAlt(k, String(v));
  if (k === 'papel') return PAPEIS[v] || v;
  if (typeof v === 'object') return JSON.stringify(v).slice(0, 120);
  if (/^\d{4}-\d{2}-\d{2}T/.test(String(v))) return Util.fmtDataHora(v);
  return String(v).slice(0, 160);
};
const SUB = { anel: 'Cor do anel', base: 'Base', qtd: 'Materiais do abrigo', kit_vencimento: 'Vencimento do kit', pressurizado: 'Pressurizado', th_ultimo: 'Último teste hidrostático', th_proximo: 'Próximo teste hidrostático', responsavel: 'Responsável (planilha)', origem: 'Origem' };
const LBL = { qtd: 'Quantidade', quantidade: 'Quantidade', minimo: 'Mínimo', tipo: 'Tipo', referencia: 'Referência', motivo: 'Motivo', origem: 'Origem', fonte: 'Fonte', observacao: 'Observação',
  ins_cilindro: 'Cilindro instalado', ret_cilindro: 'Cilindro retirado', ins_agente: 'Agente instalado', ret_agente: 'Agente retirado', ins_n2: 'N2 instalado', ret_n2: 'N2 retirado', ins_n3: 'N3 instalado', ret_n3: 'N3 retirado',
  dispositivo: 'Dispositivo', email: 'E-mail', abas: 'Abas', status: 'Situação', nome: 'Nome', papel: 'Perfil', trocar_senha: 'Troca de senha pendente', numero: 'Número', gatilho: 'Gatilho', descricao: 'Descrição',
  observacoes: 'Observação', resumo_nc: 'Não conformidade', ciclo_referencia: 'Ciclo', anulada: 'Anulada', motivo_anulacao: 'Motivo da anulação', path: 'Arquivo', bytes: 'Tamanho (bytes)', registros: 'Registros',
  destinatarios: 'Destinatários', erro: 'Erro', sigla: 'Sigla', config: 'Configuração', qr_impresso_em: 'Etiqueta impressa em', requer_conferencia: 'Requer conferência', motivo_inativacao: 'Motivo da inativação', inativado_em: 'Inativado em' };
const rotCampo = k => CAMPOS_ALT[k] || LBL[k] || k.replace(/_/g, ' ');
function detalheHTML(x) {
  const d = x.detalhe || {};
  if (/\.update$/.test(x.acao) && Object.values(d).every(v => Array.isArray(v) && v.length === 2))
    return Object.entries(d).filter(([k]) => !['atualizado_em'].includes(k)).flatMap(([k, [de, para]]) => {
      if (k === 'dados' && de && para && typeof de === 'object' && typeof para === 'object') {
        const ks = [...new Set([...Object.keys(de), ...Object.keys(para)])].filter(c => JSON.stringify(de[c]) !== JSON.stringify(para[c]));
        return ks.map(c => [SUB[c] || c, de[c], para[c]]);
      }
      return [[k, de, para]];
    }).map(([k, de, para]) => `<div><b>${esc(rotCampo(k))}:</b> <span class="de">${esc(fmtV(k, de))}</span> <span class="arr">→</span> <span class="para">${esc(fmtV(k, para))}</span></div>`).join('');
  const itens = Object.entries(d).filter(([k, v]) => !OCULTOS.has(k) && v !== null && v !== '' && !(typeof v === 'object' && !Object.keys(v).length));
  return itens.slice(0, 10).map(([k, v]) => `<span class="aud-kv"><b>${esc(rotCampo(k))}:</b> ${esc(fmtV(k, v))}</span>`).join(' ');
}
const padroes = cat => (CATS[cat]?.[1] || []);
function aplicarFiltros(q, f) {
  q = q.eq('org_id', Store.S.org.id);
  if (f.de) q = q.gte('criado_em', new Date(f.de + 'T00:00:00').toISOString());
  if (f.ate) q = q.lte('criado_em', new Date(f.ate + 'T23:59:59.999').toISOString());
  if (f.usu) q = q.eq('usuario_id', f.usu);
  if (f.cat) q = q.or(padroes(f.cat).map(p => `acao.like.${p}`).join(','));
  const t = f.q.replace(/[,()*%]/g, ' ').trim();
  if (t) q = q.or(`rotulo.ilike.*${t}*,acao.ilike.*${t}*,registro.ilike.*${t}*`);
  return q;
}

/* ---------- tela ---------- */
V.admAud = () => {
  const f = A.tmp.audf || (A.tmp.audf = { ...Periodo.mesAtual(), usu: '', cat: '', q: '', lim: 200 });
  const st = A.tmp.audSt;
  if (!st || st.chave !== JSON.stringify(f)) { carregar(); }
  const k = st?.kpi;
  return `<p class="hint" style="margin:0 0 10px">Tudo o que acontece no Inspec fica registrado aqui: acessos, tentativas de senha errada, cadastros e alterações (com o valor anterior e o novo), inspeções, fotos, comunicados de desvio, trocas, reserva, usuários, configurações, exportações e backups. Os registros são gravados pelo próprio banco e <b>não podem ser editados nem apagados</b>.</p>
  <div class="fbar" style="margin-top:0">${Cal.botao('audg-per', f, (de, ate) => { f.de = de; f.ate = ate; f.lim = 200; A.render(); })}
    <label><span>Usuário</span><select class="select" data-input="audg" data-k="usu"><option value="">Todos</option>${Store.S.membros.map(m => `<option value="${m.usuario_id}" ${f.usu === m.usuario_id ? 'selected' : ''}>${esc(m.nome)}</option>`).join('')}</select></label>
    <label><span>Tipo de evento</span><select class="select" data-input="audg" data-k="cat"><option value="">Todos</option>${Object.entries(CATS).map(([c, [n]]) => `<option value="${c}" ${f.cat === c ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
    <label><span>Texto</span><input class="input" style="min-height:38px;font-size:14px" type="search" data-input="audg-q" value="${esc(f.q)}" placeholder="ponto, nº CD, nome, e-mail…"></label>
    <button class="btn btn-sec btn-sm" data-action="audg-recarregar">${ico('refresh')}Atualizar</button>
  </div>
  <div class="kpis kpis-4" style="margin-top:12px">
    ${Comp.kpi('Eventos no período', k ? k.total : '…', esc(Periodo.rot(f)))}
    ${Comp.kpi('Acessos (logins + sessões)', k ? k.acessos : '…', k ? `${k.usuarios} usuário(s) diferentes` : '')}
    ${Comp.kpi('Senha errada', k ? k.falhas : '…', 'tentativas no período', k?.falhas ? 'var(--red)' : '')}
    ${Comp.kpi('Exportações e backups', k ? k.export : '…', 'planilhas, relatórios, PDFs')}
  </div>
  <div class="sec-h"><h2>Último acesso de cada usuário</h2></div>
  <section class="card tbl-wrap">${st?.ult ? `<table class="tbl"><thead><tr><th>Usuário</th><th>Perfil</th><th>Último login</th><th>Última atividade registrada</th><th>Situação</th></tr></thead><tbody>${Store.S.membros.map(m => { const u = st.ult[m.usuario_id] || {}; return `<tr><td><b>${esc(m.nome)}</b></td><td>${PAPEIS[m.papel]}</td><td>${u.login ? Util.fmtDataHora(u.login) : '<span class="hint">nunca entrou</span>'}</td><td>${u.ativ ? `${Util.fmtDataHora(u.ativ.criado_em)} <span class="hint">· ${esc(nomeAcao(u.ativ.acao))}</span>` : '<span class="hint">—</span>'}</td><td>${!m.ativo ? '<span class="tag t-off">Bloqueado</span>' : m.trocar_senha ? '<span class="tag t-warn">Aguardando 1º acesso</span>' : '<span class="tag t-ok">Ativo</span>'}</td></tr>`; }).join('')}</tbody></table>` : '<p class="hint" style="padding:12px;margin:0"><span class="spin"></span>Carregando…</p>'}</section>
  <div class="chips" style="margin:14px 0 8px"><span class="res-count" style="margin:0">${st?.lista ? `${Util.plural(st.count ?? st.lista.length, 'evento')}${(st.count ?? 0) > st.lista.length ? ` · mostrando os ${st.lista.length} mais recentes` : ''}` : 'Carregando…'}</span><button class="btn btn-sec btn-sm" data-action="audg-xlsx" style="margin-left:auto">${ico('download')}Exportar Excel</button></div>
  <section class="card">${st?.erro ? `<div class="notice n-red" style="margin:12px">${ico('alert')}<div>${esc(st.erro)}</div></div>` : !st?.lista ? '<p class="hint" style="padding:14px;margin:0"><span class="spin"></span>Buscando no servidor…</p>' : st.lista.length ? `<div class="tbl-wrap"><table class="tbl aud-tbl"><thead><tr><th>Data e hora</th><th>Usuário</th><th>Evento</th><th>Sobre</th><th>Detalhes</th></tr></thead><tbody>${st.lista.map(x => { const [n, c] = ACOES[x.acao] || [nomeAcao(x.acao), 'cfg']; return `<tr><td class="nw">${Util.fmtData(x.criado_em)}<br><span class="hint">${new Date(x.criado_em).toLocaleTimeString('pt-BR')}</span></td><td>${esc(quem(x.usuario_id))}</td><td><span class="tag ${COR[c]}">${esc(n)}</span></td><td>${x.tabela === 'pontos' && x.registro && Store.eq(x.registro) ? `<a href="#/ponto/${x.registro}"><b>${esc(x.rotulo || '')}</b></a>` : `<b>${esc(x.rotulo || '')}</b>`}</td><td class="aud-det">${detalheHTML(x)}</td></tr>`; }).join('')}</tbody></table></div>${(st.count ?? 0) > st.lista.length ? `<button class="more" data-action="audg-mais" style="width:100%">Carregar mais ${Math.min(200, st.count - st.lista.length)}</button>` : ''}` : Comp.vazio('history', 'Nenhum evento', 'Ajuste o período ou os filtros.')}</section>`;
};

async function carregar() {
  const f = A.tmp.audf, chave = JSON.stringify(f);
  A.tmp.audSt = { ...(A.tmp.audSt || {}), chave, lista: null, erro: null };
  if (!navigator.onLine) { A.tmp.audSt.erro = 'O histórico do sistema é consultado no servidor: conecte-se à internet.'; return; }
  try {
    const [pg, ac, ex, tot, ult, ativ] = await Promise.all([
      aplicarFiltros(sb.from('logs').select('id, criado_em, usuario_id, acao, tabela, registro, rotulo, detalhe', { count: 'exact' }), f).order('criado_em', { ascending: false }).range(0, f.lim - 1),
      aplicarFiltros(sb.from('logs').select('acao, usuario_id'), { ...f, cat: 'acessos', q: '' }).limit(10000),
      aplicarFiltros(sb.from('logs').select('id', { count: 'exact', head: true }), { ...f, cat: 'export', q: '' }),
      aplicarFiltros(sb.from('logs').select('id', { count: 'exact', head: true }), { ...f, cat: '', usu: '', q: '' }),
      sb.rpc('membros_acesso', { p_org: Store.S.org.id }),
      sb.from('logs').select('usuario_id, acao, criado_em').eq('org_id', Store.S.org.id).not('usuario_id', 'is', null).order('criado_em', { ascending: false }).limit(3000)
    ]);
    for (const r of [pg, ac, ex, tot]) if (r.error) throw r.error;
    if (A.tmp.audSt.chave !== chave) return;
    const acs = ac.data || [], mapa = {};
    for (const r of ult.data || []) mapa[r.usuario_id] = { login: r.ultimo_login };
    for (const r of ativ.data || []) { const m = mapa[r.usuario_id] || (mapa[r.usuario_id] = {}); if (!m.ativ) m.ativ = r; if (!m.login && r.acao === 'acesso.login') m.login = r.criado_em; }
    Object.assign(A.tmp.audSt, { lista: pg.data, count: pg.count, ult: mapa,
      kpi: { total: tot.count ?? 0, acessos: acs.filter(x => ['acesso.login', 'acesso.sessao'].includes(x.acao)).length, usuarios: new Set(acs.filter(x => x.acao !== 'acesso.falha_login').map(x => x.usuario_id)).size, falhas: acs.filter(x => x.acao === 'acesso.falha_login').length, export: ex.count ?? 0 } });
  } catch (e) { A.tmp.audSt.erro = msgErro(e); }
  if (location.hash.startsWith('#/admin/auditoria')) A.render();
}

let tQ;
Object.assign(A.Inputs, {
  audg: el => { A.tmp.audf[el.dataset.k] = el.value; A.tmp.audf.lim = 200; A.render(); },
  'audg-q': el => { A.tmp.audf.q = el.value; clearTimeout(tQ); tQ = setTimeout(() => { const pos = el.selectionStart; A.tmp.audf.lim = 200; A.render(); const n = document.querySelector('[data-input="audg-q"]'); if (n) { n.focus(); n.setSelectionRange(pos, pos); } }, 400); }
});
Object.assign(A.Acoes, {
  'audg-recarregar': () => { A.tmp.audSt = null; A.render(); },
  'audg-mais': () => { A.tmp.audf.lim += 200; A.render(); },
  'audg-xlsx': async el => {
    if (!navigator.onLine) return UI.toast('Conecte-se para exportar o histórico.');
    await UI.ocupado(el, async () => {
      try {
        const l = await todos(() => aplicarFiltros(sb.from('logs').select('criado_em, usuario_id, acao, tabela, registro, rotulo, detalhe'), A.tmp.audf).order('criado_em', { ascending: false }));
        const txt = x => { const d = document.createElement('div'); d.innerHTML = detalheHTML(x); return d.textContent.replace(/\s+/g, ' ').trim(); };
        await Rel.excel(`inspec_historico_sistema_${Util.hojeISO()}`, [{ nome: 'Histórico do sistema', head: ['Data e hora', 'Usuário', 'Evento', 'Código do evento', 'Sobre', 'Detalhes', 'Dispositivo'], rows: l.map(x => [Util.fmtDataHora(x.criado_em) + ':' + String(new Date(x.criado_em).getSeconds()).padStart(2, '0'), quem(x.usuario_id), nomeAcao(x.acao), x.acao, x.rotulo || '', txt(x), x.detalhe?.dispositivo || '']) }]);
      } catch (e) { UI.toast(msgErro(e)); }
    });
  }
});

/* ---------- Registros de acesso com IP (Marco Civil, art. 15) — somente Owner e Admin ---------- */
const EV_ACESSO = { 'acesso.login': 'Login', 'acesso.sessao': 'Abriu o app (sessão salva)', 'acesso.logout': 'Saiu', 'acesso.inatividade': 'Desconectado por inatividade', 'acesso.falha_login': 'Senha errada', 'acesso.senha_alterada': 'Alterou a senha', 'acesso.senha_definida': 'Definiu a senha (1º acesso)' };
const navCurto = ua => {
  if (!ua) return '—';
  const so = /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iOS' : /Windows/.test(ua) ? 'Windows' : /Mac OS/.test(ua) ? 'macOS' : /Linux/.test(ua) ? 'Linux' : '';
  const nav = /Edg\//.test(ua) ? 'Edge' : /OPR\//.test(ua) ? 'Opera' : /Chrome\//.test(ua) ? 'Chrome' : /Firefox\//.test(ua) ? 'Firefox' : /Safari\//.test(ua) ? 'Safari' : 'Navegador';
  return so ? `${nav} · ${so}` : nav;
};
function filtrarAcessos(q, f) {
  q = q.eq('org_id', Store.S.org.id);
  if (f.de) q = q.gte('criado_em', new Date(f.de + 'T00:00:00').toISOString());
  if (f.ate) q = q.lte('criado_em', new Date(f.ate + 'T23:59:59.999').toISOString());
  if (f.usu) q = q.eq('usuario_id', f.usu);
  if (f.ev) q = q.eq('evento', f.ev);
  const t = f.q.replace(/[,()*%]/g, ' ').trim();
  if (t) q = q.or(`ip.ilike.*${t}*,email.ilike.*${t}*`);
  return q;
}
async function carregarAcessos() {
  const f = A.tmp.acsf, chave = JSON.stringify(f);
  A.tmp.acsSt = { chave, lista: null, erro: null };
  if (!navigator.onLine) { A.tmp.acsSt.erro = 'Os registros de acesso são consultados no servidor: conecte-se à internet.'; return; }
  try {
    const r = await filtrarAcessos(sb.from('acessos').select('id, criado_em, usuario_id, email, evento, ip, ip_cadeia, navegador', { count: 'exact' }), f).order('criado_em', { ascending: false }).range(0, f.lim - 1);
    if (r.error) throw r.error;
    if (A.tmp.acsSt.chave !== chave) return;
    Object.assign(A.tmp.acsSt, { lista: r.data, count: r.count });
  } catch (e) { A.tmp.acsSt.erro = msgErro(e); }
  if (location.hash.startsWith('#/admin/acessos')) A.render();
}
V.admAcessos = () => {
  const f = A.tmp.acsf || (A.tmp.acsf = { ...Periodo.mesAtual(), usu: '', ev: '', q: '', lim: 200 });
  const st = A.tmp.acsSt;
  if (!st || st.chave !== JSON.stringify(f)) carregarAcessos();
  const l = st?.lista || [];
  return `<div class="notice n-info" style="margin:0 0 12px">${ico('shield')}<div><b>Registros de acesso à aplicação</b> — data, hora, endereço IP e navegador de cada entrada, saída e tentativa de senha errada, gravados pelo servidor. Guarda recomendada de no mínimo 6 meses (Marco Civil da Internet, art. 15), sob sigilo: <b>somente Owner e Admin</b> veem esta tela. Os registros não podem ser editados nem apagados, nem mesmo ao zerar o sistema.</div></div>
  <div class="fbar" style="margin-top:0">${Cal.botao('acs-per', f, (de, ate) => { f.de = de; f.ate = ate; f.lim = 200; A.render(); })}
    <label><span>Usuário</span><select class="select" data-input="acs" data-k="usu"><option value="">Todos</option>${Store.S.membros.map(m => `<option value="${m.usuario_id}" ${f.usu === m.usuario_id ? 'selected' : ''}>${esc(m.nome)}</option>`).join('')}</select></label>
    <label><span>Evento</span><select class="select" data-input="acs" data-k="ev"><option value="">Todos</option>${Object.entries(EV_ACESSO).map(([k, n]) => `<option value="${k}" ${f.ev === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
    <label><span>IP ou e-mail</span><input class="input" style="min-height:38px;font-size:14px" type="search" data-input="acs-q" value="${esc(f.q)}" placeholder="ex.: 177.12"></label>
    <button class="btn btn-sec btn-sm" data-action="acs-recarregar">${ico('refresh')}Atualizar</button>
  </div>
  <div class="kpis kpis-4" style="margin-top:12px">
    ${Comp.kpi('Registros no período', st?.lista ? (st.count ?? l.length) : '…', esc(Periodo.rot(f)))}
    ${Comp.kpi('IPs diferentes', st?.lista ? new Set(l.map(x => x.ip).filter(Boolean)).size : '…', 'nos registros exibidos')}
    ${Comp.kpi('Usuários', st?.lista ? new Set(l.map(x => x.usuario_id).filter(Boolean)).size : '…', 'nos registros exibidos')}
    ${Comp.kpi('Senha errada', st?.lista ? l.filter(x => x.evento === 'acesso.falha_login').length : '…', 'nos registros exibidos', l.some(x => x.evento === 'acesso.falha_login') ? 'var(--red)' : '')}
  </div>
  <div class="chips" style="margin:14px 0 8px"><span class="res-count" style="margin:0">${st?.lista ? `${Util.plural(st.count ?? l.length, 'registro')}${(st.count ?? 0) > l.length ? ` · mostrando os ${l.length} mais recentes` : ''}` : 'Carregando…'}</span><button class="btn btn-sec btn-sm" style="margin-left:auto" data-action="acs-xlsx">${ico('download')}Excel</button></div>
  <section class="card">${st?.erro ? `<div class="notice n-red" style="margin:12px">${ico('alert')}<div>${esc(st.erro)}</div></div>` : !st?.lista ? '<p class="hint" style="padding:14px;margin:0"><span class="spin"></span>Buscando no servidor…</p>' : l.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Data e hora</th><th>Usuário</th><th>Evento</th><th>Endereço IP</th><th>Navegador</th></tr></thead><tbody>${l.map(x => `<tr><td style="white-space:nowrap">${Util.fmtDataHora(x.criado_em)}</td><td><b>${esc(x.usuario_id ? Store.usuario(x.usuario_id).nome : '—')}</b><br><span class="hint">${esc(x.email || '')}</span></td><td>${x.evento === 'acesso.falha_login' ? `<span class="tag t-nc">${EV_ACESSO[x.evento]}</span>` : esc(EV_ACESSO[x.evento] || x.evento)}</td><td><code>${esc(x.ip || '—')}</code>${x.ip_cadeia && x.ip_cadeia !== x.ip ? `<br><span class="hint" title="Cadeia X-Forwarded-For">${esc(x.ip_cadeia)}</span>` : ''}</td><td title="${esc(x.navegador || '')}">${esc(navCurto(x.navegador))}</td></tr>`).join('')}</tbody></table></div>${(st.count ?? 0) > l.length ? `<div style="padding:10px;text-align:center"><button class="btn btn-sec btn-sm" data-action="acs-mais">Mostrar mais</button></div>` : ''}` : '<p class="hint" style="padding:14px;margin:0">Nenhum registro no período.</p>'}</section>`;
};
let tQa;
Object.assign(A.Inputs, {
  acs: el => { A.tmp.acsf[el.dataset.k] = el.value; A.tmp.acsf.lim = 200; A.render(); },
  'acs-q': el => { A.tmp.acsf.q = el.value; clearTimeout(tQa); tQa = setTimeout(() => { const pos = el.selectionStart; A.tmp.acsf.lim = 200; A.render(); const n = document.querySelector('[data-input="acs-q"]'); if (n) { n.focus(); n.setSelectionRange(pos, pos); } }, 400); }
});
Object.assign(A.Acoes, {
  'acs-recarregar': () => { A.tmp.acsSt = null; A.render(); },
  'acs-mais': () => { A.tmp.acsf.lim += 200; A.render(); },
  'acs-xlsx': async el => {
    if (!navigator.onLine) return UI.toast('Conecte-se para exportar os registros.');
    await UI.ocupado(el, async () => {
      try {
        const l = await todos(() => filtrarAcessos(sb.from('acessos').select('criado_em, usuario_id, email, evento, ip, ip_cadeia, navegador'), A.tmp.acsf).order('criado_em', { ascending: false }));
        await Rel.excel(`inspec_registros_acesso_${Util.hojeISO()}`, [{ nome: 'Registros de acesso', head: ['Data e hora (UTC-3)', 'Usuário', 'E-mail', 'Evento', 'Endereço IP', 'Cadeia X-Forwarded-For', 'Navegador (user agent)'],
          rows: l.map(x => [Util.fmtDataHora(x.criado_em) + ':' + String(new Date(x.criado_em).getSeconds()).padStart(2, '0'), x.usuario_id ? Store.usuario(x.usuario_id).nome : '', x.email || '', EV_ACESSO[x.evento] || x.evento, x.ip || '', x.ip_cadeia || '', x.navegador || ''])}]);
        evento('app.exportacao', { rotulo: 'Registros de acesso (IP)', registros: l.length });
      } catch (e) { UI.toast(msgErro(e)); }
    });
  }
});
