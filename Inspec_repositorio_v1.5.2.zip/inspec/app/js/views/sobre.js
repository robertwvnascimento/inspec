/* Inspec — Sobre o sistema: versões, atualização, diagnóstico e histórico */
import { A } from '../ns.js';
import { Store, Fila } from '../dados.js';
import { sb } from '../db.js';
import { UI } from '../ui.js';
import { PWA } from '../pwa.js';
import { VERSOES, VERSAO } from '../versoes.js';
import { CONFIG } from '../../config.js';
import { ico, esc, Util, LOGO, fmtDia } from '../util.js';

const V = A.V;
const linha = (t, sub, v, id = '') => `<div class="sb-l"><span><b>${t}</b>${sub ? `<small>${sub}</small>` : ''}</span><span class="sb-v" ${id ? `id="${id}"` : ''}>${v}</span></div>`;
const tag = (txt, cls = 't-info') => `<span class="tag ${cls}">${esc(txt)}</span>`;

V.sobre = () => {
  const S = Store.S, ref = (CONFIG.SUPABASE_URL.match(/^https?:\/\/([^.]+)\./) || [])[1] || CONFIG.SUPABASE_URL;
  const leitor = 'BarcodeDetector' in window ? ['Nativo do aparelho (BarcodeDetector)', 'Nativo'] : ['Biblioteca jsQR (iPhone/Safari e navegadores sem leitor nativo)', 'jsQR'];
  const inst = PWA.instalado(), fila = Fila.cache.length, erros = Fila.comErro().length;
  return `
  <a class="btn btn-sec btn-sm" href="#/menu" style="margin:2px 0 12px">${ico('back')}Voltar ao menu</a>
  <section class="card pad sb-head"><img src="${LOGO}" alt="Inspec"><p class="hint" style="margin:6px 0 0">Gestão inteligente de inspeções de equipamentos de emergência</p></section>

  <div class="sec-h"><h2>Versão</h2></div>
  <section class="card sb">
    ${linha('Versão do app', 'O código que está rodando agora', tag('v' + VERSAO, 't-ok'))}
    ${linha('Publicado em', '', esc(fmtDia(VERSOES[0].data)))}
    ${linha('Versão offline', 'Cache do aplicativo instalado no aparelho', '<span class="hint">verificando…</span>', 'sb-off')}
    <div class="sb-l" style="flex-wrap:wrap;gap:10px"><span id="sb-upd" class="hint" style="flex:1;min-width:200px">${PWA.novaPronta ? 'Uma versão nova já foi baixada.' : 'Confere no servidor se há uma versão mais nova.'}</span>
      ${PWA.novaPronta ? `<button class="btn btn-pri btn-sm" data-action="pwa-recarregar">${ico('refresh')}Recarregar agora</button>` : `<button class="btn btn-sec btn-sm" data-action="sb-atualizar">${ico('refresh')}Procurar atualização</button>`}</div>
  </section>

  <div class="sec-h"><h2>Instalação</h2></div>
  <section class="card sb">
    ${linha('Modo', '', inst ? 'Aberto como aplicativo' : 'Aberto no navegador')}
    ${linha('Instalado', '', inst ? tag('Instalado', 't-ok') : tag('Não instalado', 't-pend'))}
    ${inst ? '' : `<div class="sb-l" style="flex-wrap:wrap;gap:10px"><span class="hint" style="flex:1;min-width:200px">Instale para abrir pelo ícone na tela inicial, em tela cheia e sem internet.</span><button class="btn btn-pri btn-sm" data-action="pwa-instalar">${ico('download')}Instalar o Inspec</button></div>`}
  </section>

  <div class="sec-h"><h2>Diagnóstico</h2></div>
  <section class="card sb">
    ${linha('Leitor de QR Code', leitor[0], tag(leitor[1]))}
    ${linha('Câmera', '', 'mediaDevices' in navigator ? 'Disponível' : 'Indisponível neste navegador')}
    ${linha('Conexão', '', navigator.onLine ? tag('Online', 't-ok') : tag('Offline', 't-nc'))}
    ${linha('Fila de envio', 'Registros ainda não enviados ao servidor', fila ? `${fila}${erros ? ` · <b style="color:var(--red)">${erros} com erro</b>` : ''}` : 'Vazia')}
    ${linha('Dados no aparelho', 'Última carga do servidor', esc(Util.fmtDataHora(S.cargaEm)))}
    ${linha('Armazenamento usado', 'Cache do app, dados e fotos na fila', '<span class="hint">…</span>', 'sb-esp')}
    ${linha('Projeto', 'Banco de dados (Supabase)', `<code>${esc(ref)}</code>`)}
    ${linha('Versão do banco', 'Script inspec-completo.sql aplicado', '<span class="hint">…</span>', 'sb-db')}
    ${linha('Organização / unidade', '', `${esc(S.org.nome)} · ${esc(S.unidade.nome)}`)}
    ${linha('Usuário', '', `${esc(S.eu.nome)} · ${esc(S.eu.email)}`)}
  </section>

  <div class="sec-h"><h2>Histórico de versões</h2></div>
  <section class="card pad"><ol class="sb-hist">${VERSOES.map(x => `<li><div><b>v${esc(x.v)}</b><span class="hint">${esc(fmtDia(x.data))}</span></div><ul>${x.itens.map(i => `<li>${esc(i)}</li>`).join('')}</ul></li>`).join('')}</ol></section>
  <div class="sec-h"><h2>Autoria e licenças</h2></div>
  <section class="card pad">
    <p style="margin:0 0 6px"><b>Inspec</b> © ${new Date().getFullYear()} Robert William V. Nascimento · <a href="https://rwnitsolutions.com.br" target="_blank" rel="noopener">rwnitsolutions.com.br</a>. Todos os direitos reservados.</p>
    <p class="hint" style="margin:0 0 8px">Componentes de terceiros, todos com licença que permite uso comercial: supabase-js (MIT), jsQR (Apache-2.0), qrcode-generator (MIT), jsPDF (MIT), SheetJS Community Edition (Apache-2.0) e fontes Poppins e Inter (SIL OFL 1.1). “QR Code” é marca registrada da DENSO WAVE INCORPORATED.</p>
    <a class="btn btn-sec btn-sm" href="/vendor/LICENCAS.txt" target="_blank" rel="noopener">${ico('file')}Licenças de terceiros</a>
  </section>
  <div class="notice n-info" style="margin-top:12px">${ico('info')}<div>Se a <b>Versão offline</b> estiver diferente da <b>Versão do app</b>, feche e abra o Inspec novamente (ou toque em <b>Procurar atualização</b>) para concluir a atualização.</div></div>`;
};

async function preencher(rota) {
  if (rota !== 'sobre') return;
  const off = await PWA.versaoOffline(), el = document.getElementById('sb-off');
  if (el) el.innerHTML = off ? `<span class="tag ${off === VERSAO ? 't-ok' : 't-warn'}">v${esc(off)}</span>${off !== VERSAO ? ' <small class="hint">diferente — reabra o app</small>' : ''}` : '<span class="hint">não instalado (abra pelo navegador uma vez com internet)</span>';
  try { const e = await navigator.storage?.estimate?.(); const x = document.getElementById('sb-esp'); if (x && e) x.textContent = `${(e.usage / 1048576).toFixed(1)} MB`; } catch (e) { /* ignore */ }
  const d = document.getElementById('sb-db');
  if (d) { if (!navigator.onLine) d.textContent = 'indisponível offline'; else { const { data } = await sb.from('versao_banco').select('versao, aplicado_em').maybeSingle(); d.innerHTML = data ? `v${esc(data.versao)} <small class="hint">${Util.fmtData(data.aplicado_em)}</small>` : '—'; } }
}
(A.depoisRender || (A.depoisRender = [])).push(preencher);

Object.assign(A.Acoes, {
  'sb-atualizar': async el => {
    const m = document.getElementById('sb-upd');
    await UI.ocupado(el, async () => {
      const r = await PWA.procurar();
      if (r === 'nova') { A.render(); UI.toast('Versão nova baixada. Toque em “Recarregar agora”.'); }
      else if (m) m.textContent = { atual: `Você já está na versão mais recente (v${VERSAO}).`, offline: 'Sem conexão: conecte-se para procurar atualização.', 'sem-sw': 'O modo offline ainda não foi instalado neste navegador.' }[r];
    });
  }
});
