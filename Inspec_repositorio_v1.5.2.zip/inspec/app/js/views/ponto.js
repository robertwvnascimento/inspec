/* Inspec — Ficha do ponto: equipamento instalado, trocas, alterações, QR, inspeções */
import { A } from '../ns.js';
import { Store, Regras, Fila, Fotos } from '../dados.js';
import { sb, rpc, msgErro } from '../db.js';
import { UI, Comp } from '../ui.js';
import { QR } from '../qr.js';
import { ico, esc, Util, Ciclos, CK, itensDe, MOTIVOS_TROCA, ORIGENS_TROCA, ORIGEM_ALT, CAMPOS_ALT, INSPECIONA } from '../util.js';

const V = A.V;

/* ---------- fotos assinadas: preenchidas depois do render ---------- */
export const thumbsFotos = (registro) => {
  const fs = Store.fotosDe(registro); if (!fs.length) return '';
  return `<div class="thumbs" style="margin-top:6px">${fs.map(f => `<button class="thumb" style="padding:0" data-action="ver-foto" data-path="${esc(f.path)}" aria-label="Ampliar foto"><img data-foto="${esc(f.path)}" alt="Evidência"></button>`).join('')}</div>`;
};
async function preencherFotos() {
  const imgs = [...document.querySelectorAll('img[data-foto]:not([src])')]; if (!imgs.length) return;
  const paths = [...new Set(imgs.map(i => i.dataset.foto))];
  const lista = paths.map(p => Store.S.fotos.find(f => f.path === p) || { path: p });
  const urls = await Fotos.urlsDe(lista);
  imgs.forEach(i => { const u = urls[i.dataset.foto]; if (u) i.src = u; else i.alt = 'Foto indisponível offline'; });
}
(A.depoisRender || (A.depoisRender = [])).push(() => preencherFotos());
A.preencherFotos = preencherFotos;

/* ---------- valores legíveis das alterações ---------- */
export function valorAlt(campo, v) {
  if (v == null || v === '') return '';
  if (campo === 'gerencia_id') return Store.ger(v).nome;
  if (campo === 'bombeiro_id') return Store.usuario(v).nome;
  if (campo === 'unidade_id') return Store.S.unidades.find(u => u.id === v)?.nome || v;
  if (campo === 'ativo') return v === 'true' || v === true ? 'Ativo' : 'Inativo';
  if (campo === 'qr_id') return QR.fmt(v);
  if (campo === 'n2') return Util.mes(v);
  return v;
}
export const linhasAlt = (ev, comPonto = false) => `<div class="tbl-wrap"><table class="tbl alt-tbl"><thead><tr><th>Data</th>${comPonto ? '<th>Ponto</th>' : ''}<th>O que mudou</th><th>Alteração (de → para)</th><th>Origem</th><th>Quem</th></tr></thead><tbody>
  ${ev.map(a => { const o = ORIGEM_ALT[a.origem] || [a.origem, 't-pend'], e = comPonto && Store.eq(a.ponto_id), de = valorAlt(a.campo, a.de), para = valorAlt(a.campo, a.para);
    return `<tr><td class="nw">${Util.fmtData(a.criado_em)}<br><span class="hint">${Util.fmtDataHora(a.criado_em).slice(11)}</span></td>${comPonto ? `<td>${e ? `<a href="#/ponto/${e.id}"><b>${esc(e.codigo)}</b></a><br><span class="hint">${esc(Store.ger(e.ger).sigla)}</span>` : '—'}</td>` : ''}<td><b>${esc(CAMPOS_ALT[a.campo] || a.campo)}</b></td><td class="dp">${de ? `<span class="de">${esc(de)}</span> <span class="arr">→</span> ` : ''}<span class="para">${esc(para || '—')}</span></td><td><span class="tag ${o[1]}">${esc(o[0])}</span>${a.referencia ? `<br><span class="hint">${esc(a.referencia.length > 20 ? 'inspeção' : a.referencia)}</span>` : ''}</td><td>${esc(Store.usuario(a.usuario_id).nome)}</td></tr>`; }).join('')}</tbody></table></div>`;

V.ponto = (id) => {
  const e = Store.eq(id); if (!e) return V.naoEncontrado();
  const s = Regras.situacao(e), g = Store.ger(e.ger), c = Store.cat(e.cat), ins = Store.inspecoesDe(id), d = e.dados || {};
  const campos = [['Tipo de ponto', c.nome], ['Equipamento previsto', e.subtipo], ['Gerência', g.nome], ['Área', e.area], ['Local', e.local], ['Bombeiro responsável', e.resp ? Store.usuario(e.resp).nome : (d.responsavel ? `${d.responsavel} (não vinculado)` : 'Equipe (sem responsável fixo)')], ['Periodicidade', c.per === 'mensal' ? 'Mensal' : 'Semanal']];
  if (d.origem?.numero) campos.push(['Nº na planilha', d.origem.numero]);
  if (!e.ativo) campos.push(['Inativado em', `${Util.fmtData(e.inativadoEm)} — ${e.motivoInativacao || ''}`]);
  const comp = [];
  if (d.origem?.observacao) comp.push(['Observação da planilha', d.origem.observacao]);
  if (e.conferir) comp.push(['Requer conferência', 'Sim']);
  if (d.origem?.aba) comp.push(['Origem', `${d.origem.aba} · linha ${d.origem.linha}`]);
  comp.push(['Cadastrado em', Util.fmtData(e.criado)]);
  const altas = Store.S.alts.filter(a => a.ponto_id === id), lim = A.tmp.altLim === id ? 999 : 8;
  return `
  <section class="card eq-head">
    <div class="top-line"><span class="code">${esc(e.codigo)}</span><span class="tag t-info">${ico(c.icone)}${esc(c.nome)}</span>${Comp.tagSituacao(e, s)}${Comp.tagN2(e)}</div>
    <div class="desc">${esc(e.subtipo)}${e.cap ? ' · ' + esc(e.cap) : ''}</div>
    <div class="chips">
      ${Regras.pode('inspecionar') && e.ativo ? `<a class="btn btn-pri btn-sm" href="#/inspecao/${e.id}">${ico('check')}Registrar inspeção</a><a class="btn btn-sec btn-sm" href="#/desvio/novo?eq=${e.id}">${ico('headset')}Comunicado de desvio</a>` : ''}
      ${Regras.pode('admin') ? `<button class="btn btn-sec btn-sm" data-action="pt-editar" data-id="${e.id}">${ico('edit')}Editar</button>
      ${e.ativo ? `<button class="btn btn-danger btn-sm" data-action="pt-inativar" data-id="${e.id}">Inativar</button>` : `<button class="btn btn-sec btn-sm" data-action="pt-reativar" data-id="${e.id}">Reativar</button>`}` : ''}
    </div>
  </section>
  <div class="grid-2" style="margin-top:12px">
    <section class="card pad"><h2 style="font-size:15px;margin-bottom:10px">Cadastro do ponto</h2><dl class="kv">${campos.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v || '—')}</dd>`).join('')}</dl></section>
    <section class="card pad"><h2 style="font-size:15px;margin-bottom:10px">Dados complementares</h2><dl class="kv">${comp.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('')}</dl></section>
  </div>
  ${V.instalado(e)}
  ${V.trocasPonto(e)}
  <div class="sec-h"><h2>Histórico de alterações</h2><span class="hint">${Util.plural(altas.length, 'registro')} · quem, quando, o quê</span></div>
  <section class="card">${altas.length ? linhasAlt(altas.slice(0, lim)) : '<p class="hint" style="padding:14px;margin:0">Nenhuma alteração registrada no período carregado.</p>'}${altas.length > lim ? `<button class="more" data-action="alt-mais" data-id="${e.id}" style="width:100%">Ver todas as ${altas.length} alterações</button>` : ''}</section>
  ${e.qr ? V.qrFicha(e) : ''}
  <div class="sec-h"><h2>Histórico de inspeções</h2><span class="hint">${Util.plural(ins.length, 'registro')}</span></div>
  <section class="card pad">${ins.length ? `<ol class="tl">${ins.map(i => V.itemTimeline(i)).join('')}</ol>` : '<p class="hint" style="margin:0">Nenhuma inspeção registrada.</p>'}</section>`;
};

V.instalado = e => {
  const d = e.dados || {}, n2 = Regras.n2(e), tr = Store.trocasDe(e.id), qtd = d.qtd;
  const linhas = e.cat === 'extintor' ? [['Nº do cilindro', e.fab || '—'], ['Agente extintor', e.agente || '—'], ['N2 (recarga)', n2 ? n2.rot + (n2.st === 'vencida' ? ' — vencida' : '') : '—'], ['N3 (teste hidrostático)', e.n3 || '—'], ['Anel / base', `${d.anel || '—'} · ${d.base || '—'}`]]
    : e.cat === 'hidrante' ? [['Materiais do abrigo', qtd ? `${qtd.mangueiras ?? 0} mangueiras · ${qtd.storz ?? 0} Storz · ${qtd.agulheta ?? 0} agulheta · ${qtd.regulavel ?? 0} regulável` : '—'], ...(Array.isArray(d.mangueiras) && d.mangueiras.length ? d.mangueiras.map((m, i) => [`Mangueira ${i + 1} — teste hidrostático`, `último ${Util.mes(m.ult) || '—'} · próximo ${Util.mes(m.prox) || '—'}${m.prox && m.prox < Ciclos.mensal(new Date()) ? ' (vencido)' : ''}`]) : [['Teste hidrostático das mangueiras', 'ainda não informado']])]
    : e.cat === 'maca' ? [['Vencimento do kit', d.kit_vencimento ? Util.fmtData(d.kit_vencimento + 'T12:00') : '—']] : e.cat === 'chuveiro' ? [['Pressurizado', d.pressurizado ? 'Sim' : 'Não']] : [['Equipamento previsto', e.subtipo || '—']];
  return `<section class="card pad inst-card" style="margin-top:12px"><div class="inst-h"><div><h2 style="font-size:15px;margin:0">Equipamento instalado no ponto</h2><p class="hint" style="margin:2px 0 0">${tr.length ? `Instalado em ${Util.fmtData(tr[0].criado_em)} · ${Util.plural(tr.length, 'troca registrada', 'trocas registradas')} neste ponto` : 'Desde o cadastro do ponto · nenhuma troca registrada'}</p></div>
    ${Regras.pode('inspecionar') && e.ativo ? `<button class="btn btn-pri btn-sm" data-action="troca-abrir" data-id="${e.id}">${ico('swap')}Registrar troca</button>` : ''}</div>
    <dl class="kv" style="margin-top:10px">${linhas.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('')}</dl></section>`;
};
V.trocasPonto = e => {
  const tr = Store.trocasDe(e.id); if (!tr.length) return '';
  const rotOrig = t => t.origem === 'desvio' ? 'Comunicado de desvio ' + (t.referencia || '') : t.origem === 'inspecao' ? 'Identificada na inspeção' : t.origem === 'regularizacao' ? 'Regularização ' + (t.referencia || '') : 'Troca registrada';
  return `<div class="sec-h"><h2>Trocas de equipamento</h2><span class="hint">${Util.plural(tr.length, 'troca')}</span></div>
  <section class="card pad"><ol class="tl">${tr.map(t => `<li><span class="dot ${t.origem === 'desvio' ? 'nc' : 'ok'}"></span><div>
    <div><b>${esc(t.motivo || 'Troca')}</b> · <span class="meta">${Util.fmtDataHora(t.criado_em)} · ${esc(Store.usuario(t.usuario_id).nome)}</span> <span class="tag ${t.origem === 'desvio' ? 't-nc' : t.origem === 'inspecao' ? 't-ok' : 't-warn'}">${esc(rotOrig(t))}</span></div>
    <div class="troca-g"><span><small>Retirado</small><b>${t.ret_cilindro ? 'cilindro ' + esc(t.ret_cilindro) : '—'}</b><em>${esc([t.ret_agente, t.ret_n2 ? 'N2 ' + Util.mes(t.ret_n2) : ''].filter(Boolean).join(' · '))}</em></span><span class="seta">${ico('chev')}</span><span><small>Instalado</small><b>${e.cat === 'extintor' ? 'cilindro ' : ''}${esc(t.ins_cilindro)}</b><em>${esc([t.ins_agente, t.ins_n2 ? 'N2 ' + Util.mes(t.ins_n2) : '', t.fonte ? ORIGENS_TROCA[t.fonte] : ''].filter(Boolean).join(' · '))}</em></span></div>
    ${t.observacao ? `<div class="obs">${esc(t.observacao)}</div>` : ''}</div></li>`).join('')}</ol></section>`;
};
V.qrFicha = e => `<div class="sec-h"><h2>Etiqueta QR</h2><span class="hint">ID ${QR.fmt(e.qr)}</span></div>
  <section class="card pad qr-card"><div class="etq-prev">${QR.etiqueta(e)}</div>
  <p class="hint" style="margin:0 0 10px">Gerada em ${Util.fmtData(e.qrEm)} · ${e.qrImpresso ? `impressa em ${Util.fmtData(e.qrImpresso)}` : '<b style="color:var(--red)">ainda não impressa</b>'}. O QR abre este ponto pela câmera do celular ou pelo leitor do Inspec.</p>
  <div class="chips">${Regras.pode('admin') ? `<button class="btn btn-sec btn-sm" data-action="qr-imp-um" data-id="${e.id}">${ico('printer')}Imprimir placa QR</button><button class="btn btn-sec btn-sm" data-action="qr-regerar" data-id="${e.id}">${ico('refresh')}Gerar novo QR (etiqueta danificada)</button>` : ''}</div></section>`;

V.detalheCk = (i, e) => {
  const ck = i.ck; if (!ck || !ck.it) return '';
  const its = itensDe(e.cat, ck.press ?? e.dados?.pressurizado);
  const linhas = its.map(it => { const v = ck.it[it.k] || '—'; return `<tr><td>${esc(it.l)}</td><td><span class="tag ${v === 'NC' ? 't-nc' : v === 'C' ? 't-ok' : 't-pend'}">${v}</span></td><td>${esc((ck.desc && ck.desc[it.k]) || '')}</td></tr>`; });
  if (e.cat === 'extintor') { linhas.push(`<tr><td>Cilindro / agente</td><td colspan="2">${esc(ck.cab?.fab || '—')} · ${esc(ck.cab?.agente || '—')} · N2 ${esc(Util.mes(ck.cab?.n2) || '—')} · N3 ${esc(ck.cab?.n3 || '—')}</td></tr>`); if (ck.op) linhas.push(`<tr><td>Cor do anel / base</td><td colspan="2">${esc(ck.op.anel || '—')} · ${esc(ck.op.base || '—')}</td></tr>`); linhas.push(`<tr><td>Troca do extintor</td><td colspan="2">${esc(ck.troca || 'Não')}${ck.motivo ? ' — ' + esc(ck.motivo) : ''}</td></tr>`); }
  if (e.cat === 'hidrante' && ck.qtd) linhas.push(`<tr><td>Materiais</td><td colspan="2">${ck.qtd.mangueiras ?? 0} mangueiras · ${ck.qtd.storz ?? 0} Storz · ${ck.qtd.agulheta ?? 0} agulheta · ${ck.qtd.regulavel ?? 0} regulável</td></tr>`);
  if (e.cat === 'hidrante' && ck.mang?.length) linhas.push(`<tr><td>Testes hidrostáticos</td><td colspan="2">${ck.mang.map((m, i) => `M${i + 1}: ${Util.mes(m.ult)} → ${Util.mes(m.prox)}`).join(' · ')}</td></tr>`);
  return `<details class="ck-det"><summary>Ver checklist</summary><table class="tbl"><tbody>${linhas.join('')}</tbody></table></details>`;
};
V.itemTimeline = i => {
  const e = Store.eq(i.eq);
  return `<li class="${i.anulada ? 'anulada' : ''}"><span class="dot ${i.anulada ? 'an' : i.st}"></span><div>
  <div><b class="st">${i.st === 'ok' ? 'Conforme' : 'Não conforme'}</b> · <span class="meta">ciclo ${esc(Ciclos.rotulo(i.ciclo))}</span> ${i.sync === 'fila' ? '<span class="tag t-fila">Na fila</span>' : ''} ${i.anulada ? '<span class="tag t-pend">Anulada</span>' : ''}${i.origem === 'desvio' ? '<span class="tag t-info">Comunicado de desvio</span>' : ''}${i.tardia ? '<span class="tag t-warn" title="Enviada mais de 72 h depois">Sincronização tardia</span>' : ''}</div>
  <div class="meta">${Util.fmtDataHora(i.dt)} · ${esc(Store.usuario(i.ins).nome)}</div>
  ${i.st === 'nc' ? `<div class="obs" style="color:var(--red)"><b>${esc(Regras.textoNC(i))}</b></div>` : ''}${i.obs && i.obs !== i.resumo ? `<div class="obs">${esc(i.obs)}</div>` : ''}
  ${e ? V.detalheCk(i, e) : ''}${thumbsFotos(i.id)}
  ${i.anulada ? `<div class="meta">Anulada por ${esc(Store.usuario(i.anuladaPor).nome)} em ${Util.fmtData(i.anuladaEm)}: ${esc(i.motivo)}</div>` : (Regras.pode('anular') && i.sync !== 'fila' ? `<button class="linkbtn" data-action="anular" data-id="${i.id}" style="font-size:13px">Anular registro</button>` : '')}
</div></li>`;
};

/* ---------- diálogos ---------- */
V.dlgTroca = e => {
  const ext = e.cat === 'extintor', ags = Store.agentes(e.agente);
  UI.dialogo({ titulo: `Registrar troca — ${esc(e.codigo)}`, corpo: `
    <div class="notice n-info" style="margin:0 0 12px">${ico('info')}<div>O ponto continua o mesmo (código, local e QR). Muda o <b>equipamento instalado</b>: o retirado e o novo ficam no histórico do ponto.</div></div>
    <p class="hint" style="margin:0 0 6px">Retirado: <b>${ext ? 'cilindro ' + esc(e.fab || '—') + ' · ' + esc(e.agente || '') + (e.n2 ? ' · N2 ' + Util.mes(e.n2) : '') : esc(e.subtipo)}</b></p>
    <div class="grid-2" style="gap:0 12px">
      <label class="field"><span>Motivo da troca</span><select class="select" id="tr-mot">${MOTIVOS_TROCA.map(m => `<option>${m}</option>`).join('')}</select></label>
      <label class="field"><span>Origem do novo equipamento</span><select class="select" id="tr-fonte">${Object.entries(ORIGENS_TROCA).map(([k, n]) => `<option value="${k}">${n}</option>`).join('')}</select></label>
      ${ext ? `<label class="field"><span>Nº do cilindro instalado</span><input class="input" id="tr-fab" maxlength="20" placeholder="Ex.: 55123"></label>
      <label class="field"><span>Agente extintor</span><select class="select" id="tr-ag">${ags.map(a => `<option ${a === e.agente ? 'selected' : ''}>${esc(a)}</option>`).join('')}</select></label>
      <label class="field"><span>N2 do instalado (mês)</span><input class="input" type="month" id="tr-n2" value="${Ciclos.mensal(new Date())}"></label>
      <label class="field"><span>N3 do instalado (ano)</span><input class="input" id="tr-n3" inputmode="numeric" maxlength="4" value="${esc(e.n3 || '')}"></label>` : `<label class="field"><span>Equipamento instalado (identificação)</span><input class="input" id="tr-fab" maxlength="40" placeholder="Ex.: nº de série ou descrição"></label>`}
    </div>
    <label class="field"><span>Observação (opcional)</span><input class="input" id="tr-obs" maxlength="200"></label>
    <p class="hint" style="margin:0">Com origem “Reserva técnica”, 1 unidade do agente é baixada do estoque automaticamente.</p>
    <div class="err" id="tr-err" role="alert"></div>`,
    rodape: `<button class="btn btn-sec" data-action="fechar-dlg">Cancelar</button><button class="btn btn-pri" data-action="troca-ok" data-id="${e.id}">${ico('check')}Registrar troca</button>` });
};
V.dlgPonto = (e) => {
  const S = Store.S, novo = !e, c = e ? e.cat : (A.tmp.novoCat || 'extintor');
  const insp = S.membros.filter(m => m.ativo && INSPECIONA.includes(m.papel));
  UI.dialogo({ titulo: novo ? 'Novo ponto' : `Editar ponto ${esc(e.codigo)}`, largo: true, corpo: `
    ${novo ? `<div class="notice n-info" style="margin:0 0 12px">${ico('qr')}<div>Ao salvar, o banco gera automaticamente um <b>QR Code único</b> para o ponto. Imprima a etiqueta e cole no local.</div></div>` : ''}
    <div class="grid-2" style="gap:0 12px">
      <label class="field"><span>Tipo de ponto</span><select class="select" id="pt-cat" ${novo ? '' : 'disabled'}>${Store.categorias().map(x => `<option value="${x.chave}" ${x.chave === c ? 'selected' : ''}>${esc(x.nome)}</option>`).join('')}</select></label>
      <label class="field"><span>Código</span><input class="input" id="pt-cod" maxlength="20" value="${esc(e?.codigo || '')}" placeholder="Ex.: ACI-150, HID-134" style="text-transform:uppercase"></label>
      <label class="field"><span>Gerência</span><select class="select" id="pt-ger">${S.gers.map(g => `<option value="${g.id}" ${g.id === e?.ger ? 'selected' : ''}>${esc(g.nome)}</option>`).join('')}</select></label>
      <label class="field"><span>Área</span><input class="input" id="pt-area" maxlength="120" value="${esc(e?.area || '')}" list="dl-areas"><datalist id="dl-areas">${[...new Set(S.pontos.map(p => p.area).filter(Boolean))].sort().map(a => `<option value="${esc(a)}">`).join('')}</datalist></label>
      <label class="field"><span>Local / referência</span><input class="input" id="pt-local" maxlength="160" value="${esc(e?.local || '')}"></label>
      <label class="field"><span>Equipamento previsto</span><input class="input" id="pt-sub" maxlength="80" value="${esc(e?.subtipo || '')}" placeholder="Ex.: CO2 6 kg, Hidrante, Chuveiro fixo"></label>
      <label class="field"><span>Capacidade</span><input class="input" id="pt-cap" maxlength="30" value="${esc(e?.cap || '')}"></label>
      <label class="field"><span>Bombeiro responsável</span><select class="select" id="pt-resp"><option value="">Equipe (sem responsável fixo)</option>${insp.map(m => `<option value="${m.usuario_id}" ${m.usuario_id === e?.resp ? 'selected' : ''}>${esc(m.nome)}</option>`).join('')}</select></label>
    </div>
    ${novo ? `<div id="pt-ext" ${c === 'extintor' ? '' : 'hidden'}><h3 style="font-size:14px;margin:6px 0 8px">Extintor instalado</h3><div class="grid-2" style="gap:0 12px">
      <label class="field"><span>Nº do cilindro</span><input class="input" id="pt-fab" maxlength="20"></label>
      <label class="field"><span>Agente extintor</span><select class="select" id="pt-ag"><option value="">—</option>${Store.agentes().map(a => `<option>${esc(a)}</option>`).join('')}</select></label>
      <label class="field"><span>N2 (mês da recarga)</span><input class="input" type="month" id="pt-n2"></label>
      <label class="field"><span>N3 (ano do teste)</span><input class="input" id="pt-n3" inputmode="numeric" maxlength="4"></label></div></div>`
      : `<p class="hint" style="margin:4px 0 0">O equipamento instalado (cilindro, agente, N2/N3) muda por <b>Registrar troca</b> ou pela conferência na inspeção, para manter a rastreabilidade.</p>
      <label class="checkline"><input type="checkbox" id="pt-conf" ${e.conferir ? 'checked' : ''}> Requer conferência na próxima inspeção</label>`}
    <div class="err" id="pt-err" role="alert"></div>`,
    rodape: `<button class="btn btn-sec" data-action="fechar-dlg">Cancelar</button><button class="btn btn-pri" data-action="pt-salvar" data-id="${e?.id || ''}">${ico('check')}${novo ? 'Cadastrar ponto' : 'Salvar alterações'}</button>`,
    aoAbrir: d => { const s = d.querySelector('#pt-cat'); if (novo) s.addEventListener('change', () => { d.querySelector('#pt-ext').hidden = s.value !== 'extintor'; }); } });
};

async function exigirOnline() { if (!navigator.onLine) { UI.toast('Esta ação precisa de conexão com a internet.'); return false; } return true; }

Object.assign(A.Acoes, {
  'alt-mais': el => { A.tmp.altLim = el.dataset.id; A.render(); },
  'troca-abrir': el => V.dlgTroca(Store.eq(el.dataset.id)),
  'troca-ok': async el => {
    const e = Store.eq(el.dataset.id), err = document.getElementById('tr-err'), g = id => document.getElementById(id);
    const fab = g('tr-fab').value.trim(), n3 = g('tr-n3')?.value.trim();
    if (!fab) { err.textContent = 'Informe o equipamento instalado.'; return; }
    if (n3 && !/^\d{4}$/.test(n3)) { err.textContent = 'N3: ano com 4 dígitos.'; return; }
    const p = { id: Util.uuid(), ponto_id: e.id, motivo: g('tr-mot').value, fonte: g('tr-fonte').value, cilindro: fab, agente: g('tr-ag')?.value || null, n2: g('tr-n2')?.value || null, n3: n3 || null, observacao: g('tr-obs').value.trim() || null };
    if (p.fonte === 'reserva' && navigator.onLine) {
      const est = Store.S.reserva.find(r => r.agente === (p.agente || e.agente));
      if (!est || est.quantidade < 1) { err.textContent = `Sem estoque de ${p.agente || e.agente || 'agente'} na reserva técnica. Escolha outra origem ou registre a entrada na reserva.`; return; }
    }
    await Fila.incluir('troca', p, p.id);
    // reflexo local imediato
    Store.S.trocas.unshift({ id: p.id, ponto_id: e.id, origem: 'manual', motivo: p.motivo, fonte: p.fonte, ret_cilindro: e.fab, ret_agente: e.agente, ret_n2: e.n2, ret_n3: e.n3, ins_cilindro: fab, ins_agente: p.agente || e.agente, ins_n2: p.n2 || e.n2, ins_n3: p.n3 || e.n3, observacao: p.observacao, usuario_id: Store.S.eu.id, criado_em: new Date().toISOString() });
    e.fab = fab; if (p.agente) e.agente = p.agente; if (p.n2) e.n2 = p.n2; if (p.n3) e.n3 = Number(p.n3);
    Store.reindexar(); Store.salvarCache(); UI.fechar(); A.render();
    UI.toast(navigator.onLine ? 'Troca registrada.' : 'Troca salva no aparelho; será enviada com a conexão.');
    A.Sync.ciclo();
  },
  anular: async el => {
    if (!await exigirOnline()) return;
    const motivo = await UI.confirmar({ titulo: 'Anular inspeção', texto: 'O registro continua no histórico, marcado como anulado, e deixa de contar para o ciclo. Informe o motivo:', ok: 'Anular', perigo: true, campo: { rotulo: 'Motivo', min: 5 } });
    if (!motivo) return;
    try { await rpc('anular_inspecao', { p_id: el.dataset.id, p_motivo: motivo }); const i = Store.S.insp.find(x => x.id === el.dataset.id); Object.assign(i, { anulada: true, anuladaPor: Store.S.eu.id, anuladaEm: new Date().toISOString(), motivo }); Store.reindexar(); Store.salvarCache(); A.render(); UI.toast('Inspeção anulada.'); }
    catch (e) { UI.toast(msgErro(e)); }
  },
  'ver-foto': async el => {
    const f = Store.S.fotos.find(x => x.path === el.dataset.path); const u = (await Fotos.urlsDe([f]))[f.path];
    if (!u) return UI.toast('Foto indisponível sem conexão.');
    UI.dialogo({ titulo: 'Evidência fotográfica', largo: true, corpo: `<img src="${u}" alt="Evidência" style="width:100%;border-radius:10px">` });
  },
  'pt-editar': el => V.dlgPonto(Store.eq(el.dataset.id)),
  'pt-salvar': async el => {
    if (!await exigirOnline()) return;
    const id = el.dataset.id, e = id && Store.eq(id), g = x => document.getElementById(x), err = g('pt-err'), S = Store.S;
    const codigo = g('pt-cod').value.trim().toUpperCase();
    if (codigo.length < 2) { err.textContent = 'Informe o código do ponto.'; return; }
    if (S.pontos.some(p => p.codigo.toUpperCase() === codigo && p.id !== id)) { err.textContent = `Já existe um ponto com o código ${codigo}.`; return; }
    if (!g('pt-ger').value) { err.textContent = 'Cadastre uma gerência antes (Administração → Gerências).'; return; }
    const row = { codigo, gerencia_id: g('pt-ger').value, area: g('pt-area').value.trim(), local: g('pt-local').value.trim(), subtipo: g('pt-sub').value.trim(), capacidade: g('pt-cap').value.trim(), bombeiro_id: g('pt-resp').value || null };
    await UI.ocupado(el, async () => {
      try {
        if (e) {
          row.requer_conferencia = g('pt-conf').checked;
          const { error } = await sb.from('pontos').update(row).eq('id', e.id); if (error) throw error;
          UI.fechar(); UI.toast('Ponto atualizado. A mudança ficou no histórico de alterações.');
        } else {
          const cat = Store.cat(g('pt-cat').value), n3 = g('pt-n3')?.value.trim();
          Object.assign(row, { org_id: S.org.id, unidade_id: S.unidade.id, categoria_id: cat.id, numero_cilindro: g('pt-fab')?.value.trim() || null, agente: g('pt-ag')?.value || null, n2: g('pt-n2')?.value || null, n3: n3 ? Number(n3) : null, dados: { origem: { aba: 'Cadastro manual' } } });
          const { data, error } = await sb.from('pontos').insert(row).select('id, qr_id').single(); if (error) throw error;
          UI.fechar(); await A.Sync.recarregar(true); location.hash = `#/ponto/${data.id}`;
          UI.toast(`Ponto ${codigo} cadastrado · QR ${QR.fmt(data.qr_id)} gerado.`, 5000); return;
        }
        await A.Sync.recarregar(true);
      } catch (x) { err.textContent = msgErro(x); }
    });
  },
  'pt-inativar': async el => {
    if (!await exigirOnline()) return;
    const e = Store.eq(el.dataset.id);
    const motivo = await UI.confirmar({ titulo: `Inativar ${esc(e.codigo)}`, texto: 'O ponto sai das pendências e das listas, mas todo o histórico é preservado. Informe o motivo:', ok: 'Inativar', perigo: true, campo: { rotulo: 'Motivo', min: 5 } });
    if (!motivo) return;
    const { error } = await sb.from('pontos').update({ ativo: false, inativado_em: new Date().toISOString(), motivo_inativacao: motivo }).eq('id', e.id);
    if (error) return UI.toast(msgErro(error));
    await A.Sync.recarregar(true); UI.toast('Ponto inativado.');
  },
  'pt-reativar': async el => {
    if (!await exigirOnline()) return;
    const { error } = await sb.from('pontos').update({ ativo: true, inativado_em: null, motivo_inativacao: null }).eq('id', el.dataset.id);
    if (error) return UI.toast(msgErro(error));
    await A.Sync.recarregar(true); UI.toast('Ponto reativado.');
  },
  'qr-imp-um': async el => {
    const e = Store.eq(el.dataset.id);
    QR.imprimir([e], { modelo: 'meiaA4', aoImprimir: () => A.marcarImpressas([e.id]) });
  },
  'qr-regerar': async el => {
    if (!await exigirOnline()) return;
    const e = Store.eq(el.dataset.id);
    const motivo = await UI.confirmar({ titulo: 'Gerar novo QR', texto: `A etiqueta atual (${QR.fmt(e.qr)}) será invalidada: quem lê-la verá o aviso “etiqueta substituída”. Informe o motivo:`, ok: 'Gerar novo QR', perigo: true, campo: { rotulo: 'Motivo', min: 3, valor: 'Etiqueta danificada' } });
    if (!motivo) return;
    try { const novo = await rpc('regerar_qr', { p_ponto: e.id, p_motivo: motivo }); await A.Sync.recarregar(true); UI.toast(`Novo QR ${QR.fmt(novo)} gerado. Imprima e substitua a etiqueta.`, 5000); }
    catch (x) { UI.toast(msgErro(x)); }
  }
});
A.marcarImpressas = async (ids) => {
  try { await rpc('marcar_etiquetas_impressas', { p_ids: ids }); const agora = new Date().toISOString(); ids.forEach(id => { const p = Store.eq(id); if (p) p.qrImpresso = agora; }); Store.salvarCache(); }
  catch (e) { console.warn(e); }
};
