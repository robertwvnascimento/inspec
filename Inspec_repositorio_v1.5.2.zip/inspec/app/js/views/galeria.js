/* Inspec — Galeria de fotos (somente administradores): todas as evidências da unidade,
   agrupadas por ponto, por dia ou por tipo, com filtros e visualização ampliada. */
import { A } from '../ns.js';
import { Store, Regras, Fotos } from '../dados.js';
import { sb, todos, msgErro, evento } from '../db.js';
import { UI, Comp, Busca, Cal } from '../ui.js';
import { ico, esc, Util, Periodo, GATILHOS, INSPECIONA } from '../util.js';

const V = A.V;
const G = { itens: null, carregando: false, erro: null, chave: null };

/* monta a lista de fotos com o contexto (ponto, inspeção ou desvio) */
async function carregar(forcar) {
  if (G.carregando || (G.itens && !forcar)) return;
  G.carregando = true; G.erro = null;
  try {
    const S = Store.S;
    let fotos = S.fotos.filter(f => !f._fila).map(f => ({ ...f })), insp = new Map(S.insp.map(i => [i.id, i])), dsv = new Map(S.desvios.map(d => [d.id, d]));
    if (navigator.onLine) {
      fotos = await todos(() => sb.from('fotos').select('id, registro_id, tipo, path, bytes, criado_em, criado_por').eq('unidade_id', S.unidade.id).order('criado_em', { ascending: false }));
      // registros mais antigos que o período guardado no aparelho
      const faltaI = [...new Set(fotos.filter(f => f.tipo === 'inspecao' && !insp.has(f.registro_id)).map(f => f.registro_id))];
      for (let i = 0; i < faltaI.length; i += 100) {
        const { data } = await sb.from('inspecoes').select('id, ponto_id, data_inspecao, status, resumo_nc, observacoes, inspetor_id, anulada').in('id', faltaI.slice(i, i + 100));
        (data || []).forEach(r => insp.set(r.id, { id: r.id, eq: r.ponto_id, dt: r.data_inspecao, st: r.status === 'ok' ? 'ok' : 'nc', resumo: r.resumo_nc || '', obs: r.observacoes || '', ins: r.inspetor_id, anulada: r.anulada }));
      }
    }
    S.fotos.filter(f => f._fila).forEach(f => fotos.unshift({ ...f, criado_em: new Date().toISOString() }));
    G.itens = fotos.map(f => {
      const i = f.tipo === 'inspecao' ? insp.get(f.registro_id) : null, d = f.tipo === 'desvio' ? dsv.get(f.registro_id) : null;
      const e = Store.eq(i?.eq || d?.ponto_id);
      return { f, i, d, e, dt: i?.dt || d?.acionado_em || f.criado_em, autor: i?.ins || d?.bombeiro_id || f.criado_por,
        txt: Util.norm([e?.codigo, e?.local, e?.area, e ? Store.ger(e.ger).nome : '', i?.resumo, i?.obs, d?.numero, d?.descricao].join(' ')) };
    }).sort((a, b) => String(b.dt).localeCompare(String(a.dt)));
  } catch (e) { G.erro = msgErro(e); }
  G.carregando = false;
  if (location.hash.startsWith('#/galeria')) A.render();
}

const filtrar = () => {
  const f = A.tmp.gal, termos = Busca.termos(f.q);
  return (G.itens || []).filter(x => Periodo.ok(x.dt, f) && (!f.ger || x.e?.ger === f.ger) && (!f.cat || x.e?.cat === f.cat) && (!f.tipo || (f.tipo === 'nc' ? x.i?.st === 'nc' : f.tipo === 'ok' ? x.i?.st === 'ok' : x.f.tipo === f.tipo)) && (!f.usu || x.autor === f.usu) && termos.every(t => x.txt.includes(t)));
};
const rotTipo = x => x.d ? `<span class="tag" style="background:${GATILHOS[x.d.gatilho]?.cor}1A;color:${GATILHOS[x.d.gatilho]?.cor}">${esc(x.d.numero || 'Desvio')}</span>` : x.i ? (x.i.anulada ? '<span class="tag t-pend">Anulada</span>' : x.i.st === 'nc' ? '<span class="tag t-nc">NC</span>' : '<span class="tag t-ok">Conforme</span>') : '<span class="tag t-pend">Foto</span>';
const chaveGrupo = { ponto: x => x.e ? x.e.codigo : '(ponto não encontrado)', dia: x => String(x.dt).slice(0, 10), tipo: x => x.d ? 'Comunicados de desvio' : x.i?.st === 'nc' ? 'Inspeções não conformes' : 'Inspeções conformes' };

V.galeria = () => {
  if (!Regras.pode('verAdmin')) return Comp.vazio('shield', 'Acesso restrito', 'A galeria de fotos é exclusiva dos administradores.');
  const f = A.tmp.gal || (A.tmp.gal = { de: '', ate: '', ger: '', cat: '', tipo: '', usu: '', q: '', agrupar: 'ponto', lim: 60 });
  if (!G.itens && !G.carregando) carregar();
  const l = G.itens ? filtrar() : [], vis = l.slice(0, f.lim), tot = (G.itens || []).reduce((a, x) => a + (x.f.bytes || 0), 0);
  const grupos = []; const idx = new Map();
  for (const x of vis) { const k = chaveGrupo[f.agrupar](x); if (!idx.has(k)) { idx.set(k, grupos.length); grupos.push({ k, itens: [] }); } grupos[idx.get(k)].itens.push(x); }
  if (f.agrupar === 'ponto') grupos.sort((a, b) => a.k.localeCompare(b.k, 'pt', { numeric: true }));
  A.tmp.galVis = vis;
  const sel = (rot, k, ops) => `<label><span>${rot}</span><select class="select" data-input="galf" data-k="${k}">${ops.map(([v, n]) => `<option value="${v}" ${f[k] === v ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></label>`;
  const contGrupo = k => l.filter(x => chaveGrupo[f.agrupar](x) === k).length;
  return `<div class="p-head"><p class="hint" style="margin:0;max-width:720px">Todas as evidências fotográficas da unidade ${esc(Store.S.unidade.nome)}, de inspeções e comunicados de desvio. Toque numa foto para ampliar, navegar e baixar.</p><button class="btn btn-sec btn-sm" data-action="gal-recarregar">${ico('refresh')}Atualizar</button></div>
  <div class="fbar gal-fbar">${Cal.botao('gal-per', f, (de, ate) => { f.de = de; f.ate = ate; f.lim = 60; A.render(); })}
    ${sel('Origem', 'tipo', [['', 'Todas'], ['nc', 'Inspeções não conformes'], ['ok', 'Inspeções conformes'], ['desvio', 'Comunicados de desvio']])}
    ${sel('Gerência', 'ger', [['', 'Todas'], ...Store.S.gers.map(g => [g.id, g.nome])])}
    ${sel('Tipo de ponto', 'cat', [['', 'Todos'], ...Store.categorias().map(c => [c.chave, c.plural])])}
    ${sel('Autor', 'usu', [['', 'Todos'], ...Store.S.membros.filter(m => INSPECIONA.includes(m.papel)).map(m => [m.usuario_id, m.nome])])}
    ${sel('Agrupar por', 'agrupar', [['ponto', 'Ponto'], ['dia', 'Dia'], ['tipo', 'Origem']])}
    <label><span>Texto</span><input class="input" style="min-height:38px;font-size:14px" type="search" data-input="galf-q" value="${esc(f.q)}" placeholder="ponto, local, NC, nº CD…"></label>
  </div>
  <div class="kpis kpis-4" style="margin-top:12px">${Comp.kpi('Fotos no filtro', G.itens ? l.length : '…')}${Comp.kpi('Pontos com foto', G.itens ? new Set(l.map(x => x.e?.id).filter(Boolean)).size : '…')}${Comp.kpi('De não conformidades', G.itens ? l.filter(x => x.i?.st === 'nc').length : '…')}${Comp.kpi('Armazenamento total', G.itens ? (tot / 1048576).toFixed(1) + ' MB' : '…', 'todas as fotos da unidade · limite 1 GB')}</div>
  ${G.erro ? `<div class="notice n-red" style="margin-top:12px">${ico('alert')}<div>${esc(G.erro)}</div></div>` : ''}
  ${!G.itens ? '<p class="hint" style="margin-top:16px"><span class="spin"></span>Carregando as fotos…</p>' : !l.length ? Comp.vazio('camera', 'Nenhuma foto', 'Ajuste os filtros. As fotos entram aqui conforme as inspeções e os desvios são registrados.') :
    grupos.map(g => `<div class="gal-grupo"><div class="gal-gh"><b>${f.agrupar === 'dia' ? esc(Util.fmtData(g.k + 'T12:00')) : esc(g.k)}</b>${f.agrupar === 'ponto' && g.itens[0].e ? `<span class="hint">${esc(Store.cat(g.itens[0].e.cat).nome)} · ${esc(Store.ger(g.itens[0].e.ger).sigla)} › ${esc(g.itens[0].e.local || g.itens[0].e.area)}</span><a class="hint" href="#/ponto/${g.itens[0].e.id}">Ficha do ponto</a>` : ''}<span class="hint" style="margin-left:auto">${Util.plural(contGrupo(g.k), 'foto')}</span></div>
      <div class="gal-grid">${g.itens.map(x => `<button class="gal-it" data-action="gal-abrir" data-i="${vis.indexOf(x)}"><img data-foto="${esc(x.f.path)}" alt="Foto ${esc(x.e?.codigo || '')}" loading="lazy"><span class="gal-cap"><span>${f.agrupar === 'ponto' ? '' : `<b>${esc(x.e?.codigo || '—')}</b> `}${Util.fmtCurta(x.dt)}</span>${rotTipo(x)}</span></button>`).join('')}</div></div>`).join('') +
    (l.length > f.lim ? `<button class="more" data-action="gal-mais" style="width:100%;margin-top:12px">Mostrar mais ${Math.min(60, l.length - f.lim)} de ${l.length - f.lim} restantes</button>` : '')}`;
};

/* ---------- visualização ampliada ---------- */
async function abrir(n) {
  const vis = A.tmp.galVis, x = vis[n]; if (!x) return;
  A.tmp.galAtual = n;
  const url = (await Fotos.urlsDe([x.f]))[x.f.path];
  const e = x.e, info = [
    ['Ponto', e ? `${e.codigo} · ${Store.cat(e.cat).nome}` : '—'], ['Local', e ? `${Store.ger(e.ger).nome} › ${e.area}${e.local && e.local !== e.area ? ' · ' + e.local : ''}` : '—'],
    ['Data', Util.fmtDataHora(x.dt)], ['Autor', Store.usuario(x.autor).nome],
    ...(x.i ? [['Inspeção', x.i.anulada ? 'Anulada' : x.i.st === 'nc' ? 'Não conforme' : 'Conforme'], ...(x.i.resumo ? [['Não conformidade', x.i.resumo]] : []), ...(x.i.obs ? [['Observação', x.i.obs]] : [])] : []),
    ...(x.d ? [['Comunicado', `${x.d.numero || '(na fila)'} · ${GATILHOS[x.d.gatilho]?.nome || ''}`], ['Situação', x.d.descricao]] : [])];
  UI.dialogo({ titulo: `${esc(e?.codigo || 'Foto')} · ${n + 1} de ${vis.length}`, largo: true, corpo: `
    <div class="gal-view">${url ? `<img src="${url}" alt="Evidência">` : '<p class="hint">Foto indisponível sem conexão.</p>'}
      <button class="gal-nav p" data-action="gal-nav" data-d="-1" aria-label="Foto anterior" ${n ? '' : 'disabled'}>${ico('back')}</button><button class="gal-nav n" data-action="gal-nav" data-d="1" aria-label="Próxima foto" ${n < vis.length - 1 ? '' : 'disabled'}>${ico('chev')}</button></div>
    <dl class="kv" style="margin-top:12px">${info.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('')}</dl>`,
    rodape: `${e ? `<a class="btn btn-sec" href="#/ponto/${e.id}">${ico('file')}Ficha do ponto</a>` : ''}${x.d ? `<a class="btn btn-sec" href="#/desvio/${x.d.id}">${ico('flame')}Comunicado</a>` : ''}<button class="btn btn-pri" data-action="gal-baixar" ${url ? '' : 'disabled'}>${ico('download')}Baixar foto</button>` });
  [n - 1, n + 1].forEach(k => vis[k] && Fotos.urlsDe([vis[k].f]).then(u => { const im = new Image(); im.src = u[vis[k].f.path] || ''; }));   // pré-carrega as vizinhas
}

let tQ;
Object.assign(A.Inputs, {
  galf: el => { A.tmp.gal[el.dataset.k] = el.value; A.tmp.gal.lim = 60; A.render(); },
  'galf-q': el => { A.tmp.gal.q = el.value; clearTimeout(tQ); tQ = setTimeout(() => { const pos = el.selectionStart; A.tmp.gal.lim = 60; A.render(); const n = document.querySelector('[data-input="galf-q"]'); if (n) { n.focus(); n.setSelectionRange(pos, pos); } }, 300); }
});
Object.assign(A.Acoes, {
  'gal-recarregar': async el => { await UI.ocupado(el, () => carregar(true)); },
  'gal-mais': () => { A.tmp.gal.lim += 60; A.render(); },
  'gal-abrir': el => abrir(Number(el.dataset.i)),
  'gal-nav': el => abrir(A.tmp.galAtual + Number(el.dataset.d)),
  'gal-baixar': async el => {
    const x = A.tmp.galVis[A.tmp.galAtual];
    await UI.ocupado(el, async () => {
      try {
        const url = (await Fotos.urlsDe([x.f]))[x.f.path], blob = await (await fetch(url)).blob();
        const nome = `${x.e?.codigo || 'foto'}_${String(x.dt).slice(0, 10)}_${x.f.path.split('_').pop()}`;
        Util.baixar(nome, blob); evento('app.foto', { rotulo: nome });
      } catch (e) { UI.toast('Não foi possível baixar a foto.'); }
    });
  }
});
document.addEventListener('keydown', ev => {
  if (!document.querySelector('#dlg[open] .gal-view')) return;
  if (ev.key === 'ArrowRight') document.querySelector('.gal-nav.n:not(:disabled)')?.click();
  if (ev.key === 'ArrowLeft') document.querySelector('.gal-nav.p:not(:disabled)')?.click();
});
A.galeriaInvalidar = () => { G.itens = null; };
