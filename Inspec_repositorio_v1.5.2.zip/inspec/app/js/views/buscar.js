/* Inspec — Buscar ponto (QR + texto) e Nova inspeção (gerência → tipo → ponto) */
import { A } from '../ns.js';
import { Store, Regras } from '../dados.js';
import { Comp, Busca } from '../ui.js';
import { ico, esc, Util } from '../util.js';

const V = A.V;
const recentes = () => { try { return JSON.parse(localStorage.getItem('inspec-recentes') || '[]'); } catch (e) { return []; } };
const guardarRecente = q => { q = String(q || '').trim(); if (q.length < 2) return; try { localStorage.setItem('inspec-recentes', JSON.stringify([q, ...recentes().filter(x => x !== q)].slice(0, 8))); } catch (e) { /* ignore */ } };
A.guardarRecente = guardarRecente;

V.buscar = (q) => {
  const st = A.tmp.busca || (A.tmp.busca = { q: '', cats: [], ger: '', soPend: false });
  if (q.get('cat')) st.cats = [q.get('cat')];
  return `
  <button type="button" class="scan-cta" data-action="scan-abrir"><span class="ic">${ico('scan')}</span><span><b>Ler QR Code</b><span>Aponte a câmera para a etiqueta do ponto</span></span>${ico('chev')}</button>
  <div class="search-box">
    ${ico('search')}
    <label class="sr" for="busca">Buscar ponto</label>
    <input class="input" id="busca" type="search" data-input="busca" value="${esc(st.q)}" placeholder="Ou digite código, tipo, local ou nº do cilindro…" autocomplete="off" enterkeyhint="search">
    <button class="iconbtn clear" data-action="limpar-busca" aria-label="Limpar busca" ${st.q ? '' : 'hidden'}>${ico('x')}</button>
  </div>
  <div class="chips" style="margin-top:10px" role="group" aria-label="Filtrar por categoria">
    ${Store.categorias().map(c => `<button class="chip" data-action="busca-cat" data-cat="${c.chave}" aria-pressed="${st.cats.includes(c.chave)}">${ico(c.icone)}${esc(c.plural)}</button>`).join('')}
    <button class="chip" data-action="busca-pend" aria-pressed="${st.soPend}">${ico('clock')}Só pendentes</button>
  </div>
  <div class="toolbar" style="margin-bottom:0">${Comp.selectGerencia('f-ger-busca', st.ger)}</div>
  <div id="busca-res" aria-live="polite">${V.buscaResultados()}</div>`;
};
V.buscaResultados = () => {
  const st = A.tmp.busca;
  if (!st.q.trim() && !st.cats.length && !st.soPend) return V.buscaSugestoes();
  const { termos, res } = Busca.executar(st);
  if (!res.length) return Comp.vazio('search', 'Nenhum ponto encontrado', `Confira a grafia ou tente outro termo${st.soPend ? ' — o filtro “Só pendentes” está ligado' : ''}.`);
  const lim = 60;
  return `<div class="res-count">${Util.plural(res.length, 'resultado')}${res.length > lim ? ` · mostrando os ${lim} mais relevantes` : ''}</div>
  <div class="list">${res.slice(0, lim).map(r => Comp.linhaEq(r.e, { termos })).join('')}</div>`;
};
V.buscaSugestoes = () => {
  const eu = Store.S.eu, ultima = Store.S.insp.find(i => i.ins === eu.id && !i.anulada);
  let area = '';
  if (ultima) {
    const e0 = Store.eq(ultima.eq);
    const pend = e0 ? Store.S.pontos.filter(e => e.ativo && e.area === e0.area && e.ger === e0.ger && Regras.situacao(e).pendente).slice(0, 6) : [];
    if (pend.length) area = `<div class="card"><h3>Continue na área: ${esc(e0.area)}</h3><p class="hint" style="margin:-4px 0 8px">Pendentes perto da sua última inspeção (${esc(e0.codigo)}).</p><div class="list">${pend.map(e => Comp.linhaEq(e)).join('')}</div></div>`;
  }
  const rec = recentes().slice(0, 6);
  return `<div class="sugg" style="margin-top:14px">${area}
    ${rec.length ? `<div class="card"><h3>Buscas recentes</h3><div class="chips">${rec.map(r => `<button class="chip" data-action="busca-exemplo" data-q="${esc(r)}">${ico('history')}${esc(r)}</button>`).join('')}</div></div>` : ''}
    <div class="card"><h3>Como buscar</h3><p class="hint" style="margin:0">A busca ignora acentos e maiúsculas e combina palavras: “co2 tarugos” encontra os extintores de CO₂ no pátio de tarugos. Também acha pelo nº do cilindro, pelo ID da etiqueta e pelo nome do bombeiro. Funciona sem internet.</p></div>
  </div>`;
};

V.nova = (q) => {
  if (!Regras.pode('inspecionar')) return Comp.vazio('shield', 'Somente inspetores registram inspeções', 'Seu perfil é de consulta.');
  const E = A.Escopo, ger = q.get('ger') || '', cat = q.get('cat') || '', todos = q.get('todos') === '1', filtro = q.get('f') || '';
  const pend = (g, c) => Store.S.pontos.filter(e => e.ativo && (!g || e.ger === g) && (!c || e.cat === c) && E.noMeu(e) && Regras.situacao(e).pendente).length;
  const g = ger && Store.ger(ger);
  const steps = `<nav class="steps" aria-label="Etapas">
    <a class="step ${!ger ? 'on' : 'done'}" href="#/nova"><b>1</b>${ger ? esc(g.sigla) : 'Gerência'}</a>
    <a class="step ${ger && !cat ? 'on' : cat ? 'done' : ''}" href="${ger ? `#/nova?ger=${ger}` : '#/nova'}"><b>2</b>${cat ? esc(Store.cat(cat).plural) : 'Tipo'}</a>
    <span class="step ${cat ? 'on' : ''}"><b>3</b>Ponto</span><span class="step"><b>4</b>Checklist</span></nav>`;
  const rota = E.meus() ? `<p class="hint" style="margin:-4px 2px 12px">Extintores: mostrando os seus pontos · <button class="linkbtn" data-action="meus" data-v="0" style="padding:0">ver toda a equipe</button></p>` : '';
  const cta = `<button type="button" class="scan-cta" data-action="scan-abrir"><span class="ic">${ico('scan')}</span><span><b>Ler QR Code</b><span>No ponto? Leia a etiqueta e vá direto ao checklist</span></span>${ico('chev')}</button>`;
  if (!ger) {
    const gs = Store.S.gers.filter(x => Store.S.pontos.some(e => e.ativo && e.ger === x.id));
    if (!gs.length) return Comp.vazio('box', 'Nenhum ponto cadastrado', 'Peça ao administrador para fazer a carga inicial.');
    return steps + cta + rota + `<div class="pick-grid">${gs.map(x => { const n = pend(x.id, ''); return `<a class="pick" href="#/nova?ger=${x.id}"><b>${esc(x.nome)}</b><span class="n ${n ? '' : 'zero'}">${n || ico('check')}</span><span>${n ? (n === 1 ? 'pendente' : 'pendentes') : 'em dia'}</span></a>`; }).join('')}</div>`;
  }
  if (!cat) {
    return steps + rota + `<div class="pick-grid">${Store.categorias().map(c => { const tot = Store.S.pontos.filter(e => e.ativo && e.ger === ger && e.cat === c.chave).length; if (!tot) return ''; const n = pend(ger, c.chave); return `<a class="pick" href="#/nova?ger=${ger}&cat=${c.chave}"><span class="ic">${ico(c.icone)}</span><b>${esc(c.plural)}</b><span><b class="n ${n ? '' : 'zero'}" style="font-size:18px">${n}</b> pendentes de ${tot}</span></a>`; }).join('')}</div>`;
  }
  return steps + rota + `
  <div class="search-box" style="margin-bottom:10px">${ico('search')}<label class="sr" for="nova-f">Filtrar</label><input class="input" id="nova-f" type="search" data-input="nova-f" value="${esc(filtro)}" placeholder="Filtrar por nº, local, tipo…" autocomplete="off"></div>
  <div class="chips" style="margin-bottom:10px"><button class="chip" data-action="nova-todos" aria-pressed="${todos}">Mostrar também os já inspecionados</button></div>
  <div id="nova-list">${V.novaLista(ger, cat, todos, filtro)}</div>`;
};
V.novaLista = (ger, cat, todos, filtro) => {
  const termos = Busca.termos(filtro), E = A.Escopo;
  const lista = Store.S.pontos.filter(e => e.ativo && e.ger === ger && e.cat === cat && E.noMeu(e))
    .map(e => ({ e, s: Regras.situacao(e) })).filter(x => todos || x.s.pendente)
    .filter(x => !termos.length || termos.every(t => Util.norm(Regras.textoBusca(x.e)).includes(t)))
    .sort((a, b) => (b.s.pendente - a.s.pendente) || a.e.area.localeCompare(b.e.area) || a.e.codigo.localeCompare(b.e.codigo, 'pt', { numeric: true }));
  return lista.length ? `<div class="list">${lista.slice(0, 200).map(x => Comp.linhaEq(x.e, { termos, href: `#/inspecao/${x.e.id}?de=lista` })).join('')}</div>`
    : Comp.vazio('check', 'Nada pendente aqui', `Todos os pontos deste filtro foram inspecionados neste ciclo.`);
};

let tB;
Object.assign(A.Inputs, {
  busca: el => { A.tmp.busca.q = el.value; document.querySelector('[data-action="limpar-busca"]').hidden = !el.value; clearTimeout(tB); tB = setTimeout(() => { document.getElementById('busca-res').innerHTML = V.buscaResultados(); }, 120); },
  'f-ger-busca': el => { A.tmp.busca.ger = el.value; document.getElementById('busca-res').innerHTML = V.buscaResultados(); },
  'nova-f': el => { clearTimeout(tB); tB = setTimeout(() => { const { q } = A.Router.parse(); q.set('f', el.value); history.replaceState(null, '', `#/nova?${q}`); document.getElementById('nova-list').innerHTML = V.novaLista(q.get('ger'), q.get('cat'), q.get('todos') === '1', el.value); }, 150); }
});
Object.assign(A.Acoes, {
  'limpar-busca': () => { A.tmp.busca.q = ''; A.render(); document.getElementById('busca')?.focus(); },
  'busca-cat': el => { const st = A.tmp.busca, c = el.dataset.cat; st.cats = st.cats.includes(c) ? st.cats.filter(x => x !== c) : [...st.cats, c]; el.setAttribute('aria-pressed', st.cats.includes(c)); document.getElementById('busca-res').innerHTML = V.buscaResultados(); },
  'busca-pend': el => { const st = A.tmp.busca; st.soPend = !st.soPend; el.setAttribute('aria-pressed', st.soPend); document.getElementById('busca-res').innerHTML = V.buscaResultados(); },
  'busca-exemplo': el => { A.tmp.busca.q = el.dataset.q; A.render(); },
  'nova-todos': () => { const { q } = A.Router.parse(); q.get('todos') === '1' ? q.delete('todos') : q.set('todos', '1'); location.hash = `#/nova?${q}`; }
});
document.addEventListener('click', ev => { const a = ev.target.closest('#busca-res a.row'); if (a && A.tmp.busca?.q) guardarRecente(A.tmp.busca.q); });
