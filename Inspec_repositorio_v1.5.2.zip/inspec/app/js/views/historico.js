/* Inspec — Histórico de inspeções (período por calendário, filtros, exportação) */
import { A } from '../ns.js';
import { Store, Regras } from '../dados.js';
import { Comp, Busca, Cal } from '../ui.js';
import { ico, esc, Util, Periodo, INSPECIONA } from '../util.js';

const V = A.V;
V.historico = (q) => {
  const f = A.tmp.hist || (A.tmp.hist = { ...Periodo.mesAtual(), cat: '', ger: '', st: '', ins: '', q: '', lim: 40 });
  if (q.get('meu')) { f.ins = Store.S.eu.id; f.de = ''; f.ate = ''; }
  const lista = V.historicoFiltrado();
  return `
  <div class="card pad">
    <div class="toolbar" style="margin:0 0 8px">
      ${Cal.botao('h-per', f, (de, ate) => { f.de = de; f.ate = ate; f.lim = 40; A.render(); })}
      ${Comp.selectCategoria('h-cat', f.cat)}
      ${Comp.selectGerencia('h-ger', f.ger)}
    </div>
    <div class="toolbar" style="margin:0">
      <label class="sr" for="h-st">Resultado</label>
      <select class="select" id="h-st" data-input="h-st">${[['', 'Todos os resultados'], ['ok', 'Conforme'], ['nc', 'Não conforme'], ['anulada', 'Anuladas']].map(([v, n]) => `<option value="${v}" ${f.st === v ? 'selected' : ''}>${n}</option>`).join('')}</select>
      <label class="sr" for="h-ins">Inspetor</label>
      <select class="select" id="h-ins" data-input="h-ins"><option value="">Todos os inspetores</option>${Store.S.membros.filter(u => INSPECIONA.includes(u.papel)).map(u => `<option value="${u.usuario_id}" ${f.ins === u.usuario_id ? 'selected' : ''}>${esc(u.nome)}</option>`).join('')}</select>
      <label class="sr" for="h-q">Filtrar por código ou texto</label>
      <input class="input" id="h-q" type="search" data-input="h-q" value="${esc(f.q)}" placeholder="Código, local, observação…">
    </div>
  </div>
  <div class="sec-h"><h2 id="h-count">${Util.plural(lista.length, 'registro')} <span class="hint" style="font-family:var(--font);font-weight:500">· ${esc(Periodo.rot(f))}</span></h2><span class="chips"><button class="btn btn-sec btn-sm" data-action="hist-xlsx" title="Mesmas colunas das respostas do Forms">${ico('download')}Excel (formato Forms)</button></span></div>
  <div id="h-list">${V.historicoLista(lista)}</div>`;
};
V.historicoFiltrado = () => {
  const f = A.tmp.hist, termos = Busca.termos(f.q);
  return Store.S.insp.filter(i => {
    const e = Store.eq(i.eq); if (!e) return false;
    if (!Periodo.ok(i.dt, f)) return false;
    if (f.cat && e.cat !== f.cat) return false;
    if (f.ger && e.ger !== f.ger) return false;
    if (f.st === 'anulada' ? !i.anulada : (f.st && (i.st !== f.st || i.anulada))) return false;
    if (f.ins && i.ins !== f.ins) return false;
    if (termos.length) { const h = Util.norm(Regras.textoBusca(e) + ' ' + i.obs + ' ' + (i.resumo || '')); if (!termos.every(t => h.includes(t))) return false; }
    return true;
  });
};
V.historicoLista = (lista) => {
  const f = A.tmp.hist;
  if (!lista.length) return Comp.vazio('history', 'Nenhum registro', 'Ajuste o período ou os filtros.');
  return `<div class="list">${lista.slice(0, f.lim).map(i => { const e = Store.eq(i.eq); return `
    <a class="row" href="#/ponto/${e.id}" style="${i.anulada ? 'opacity:.6' : ''}">
      <span class="ic">${ico(Store.cat(e.cat).icone)}</span>
      <span class="body"><span class="l1"><span class="code">${esc(e.codigo)}</span>${i.anulada ? '<span class="tag t-pend">Anulada</span>' : `<span class="tag ${i.st === 'ok' ? 't-ok' : 't-nc'}">${i.st === 'ok' ? 'Conforme' : 'Não conforme'}</span>`}${i.sync === 'fila' ? '<span class="tag t-fila">Na fila</span>' : ''}${Store.fotosDe(i.id).length ? `<span class="tag t-pend">${ico('camera')}${Store.fotosDe(i.id).length}</span>` : ''}</span>
      <span class="l2">${Util.fmtDataHora(i.dt)} · ${esc(Store.usuario(i.ins).nome)}</span>
      <span class="l3">${esc(Store.ger(e.ger).sigla)} › ${esc(e.local || e.area)}${i.st === 'nc' ? ' · “' + esc(Regras.textoNC(i)) + '”' : ''}</span></span>
      <span class="chev">${ico('chev')}</span></a>`; }).join('')}
    ${lista.length > f.lim ? `<button class="more" data-action="hist-mais">Carregar mais (${lista.length - f.lim} restantes)</button>` : ''}</div>`;
};
const atualizar = () => { const l = V.historicoFiltrado(), f = A.tmp.hist; document.getElementById('h-list').innerHTML = V.historicoLista(l); document.getElementById('h-count').innerHTML = `${Util.plural(l.length, 'registro')} <span class="hint" style="font-family:var(--font);font-weight:500">· ${esc(Periodo.rot(f))}</span>`; };
let t;
for (const k of ['cat', 'ger', 'st', 'ins', 'q']) A.Inputs['h-' + k] = el => { A.tmp.hist[k] = el.value; A.tmp.hist.lim = 40; clearTimeout(t); t = setTimeout(atualizar, k === 'q' ? 150 : 0); };
Object.assign(A.Acoes, {
  'hist-mais': () => { A.tmp.hist.lim += 60; atualizar(); },
  'hist-xlsx': () => A.Rel.excelForms(V.historicoFiltrado().filter(i => !i.anulada), 'inspec_historico_' + Util.hojeISO())
});
