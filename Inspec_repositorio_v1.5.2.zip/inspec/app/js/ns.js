/* Inspec — espaço compartilhado entre os módulos (views e ações se registram aqui) */
export const A = {
  V: {},          // views: funções que devolvem HTML
  Acoes: {},      // ações: data-action="nome" → A.Acoes.nome(el, ev)
  Inputs: {},     // data-input="nome" → A.Inputs.nome(el, ev)
  Envios: {},     // <form id="x"> → A.Envios.x(ev)
  tmp: {}         // estado efêmero das telas (filtros, rascunhos)
};
