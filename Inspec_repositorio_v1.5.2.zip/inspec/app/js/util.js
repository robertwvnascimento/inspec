/* Inspec — utilidades, ícones, ciclos, checklists e gráficos (sem dependência de dados) */
export const ICON_PATHS = {
  home:'<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  search:'<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
  alert:'<path d="M12 3.5l9.5 16.5h-19z"/><path d="M12 10v4.5M12 17.5h.01"/>',
  history:'<path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1L3.5 8.5"/><path d="M3.5 3.5v5h5M12 7.5V12l3 2"/>',
  chart:'<path d="M4 20V11M10 20V5M16 20v-6M21 20H3"/>',
  admin:'<path d="M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1"/><circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="18" r="2"/>',
  menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',
  check:'<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  x:'<path d="M6 6l12 12M18 6L6 18"/>',
  camera:'<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
  back:'<path d="M15 5l-7 7 7 7"/>',
  chev:'<path d="M9 5l7 7-7 7"/>',
  extintor:'<path d="M9 8h6v12a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1z"/><path d="M11 8V5h2v3M13 5h3.5L19 7M9 11c-2.2.8-3.5 2.6-3.5 5"/>',
  hidrante:'<path d="M7 21h10M9 21V10h6v11M7 10h10M10 10V7a2 2 0 0 1 4 0v3M5 14h4M15 14h4"/>',
  maca:'<rect x="3" y="9" width="18" height="5" rx="1.5"/><path d="M6 14v4M18 14v4M7 9V7M17 9V7"/>',
  chuveiro:'<path d="M6 21V9a5 5 0 0 1 5-5h1a5 5 0 0 1 5 5"/><path d="M13 9h8M15 12.5v1M18 12.5v1M21 12.5v1M16.5 16v1M19.5 16v1"/>',
  user:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  wifioff:'<path d="M3 3l18 18M8.5 16.5a5 5 0 0 1 7 0M5 12.8a10 10 0 0 1 4.5-2.5M19 12.8a10 10 0 0 0-2.3-1.6M2 8.8A15 15 0 0 1 6 6.2M22 8.8A15 15 0 0 0 11 5"/><circle cx="12" cy="20" r="1"/>',
  wifi:'<path d="M8.5 16.5a5 5 0 0 1 7 0M5 12.8a10 10 0 0 1 14 0M2 8.8a15 15 0 0 1 20 0"/><circle cx="12" cy="20" r="1"/>',
  download:'<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
  upload:'<path d="M12 20V9M7 14l5-5 5 5M5 4h14"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  edit:'<path d="M4 20h4L19 9l-4-4L4 16z"/>',
  building:'<path d="M4 21V5l8-2v18M12 8h8v13M8 8v.01M8 12v.01M8 16v.01M16 12v.01M16 16v.01M2 21h20"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8v.01"/>',
  logout:'<path d="M15 4h4v16h-4M10 17l5-5-5-5M15 12H4"/>',
  refresh:'<path d="M20 11a8 8 0 0 0-14.5-4.5L4 8M4 4v4h4M4 13a8 8 0 0 0 14.5 4.5L20 16M20 20v-4h-4"/>',
  file:'<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M9 13h6M9 17h6"/>',
  users:'<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 7M18 14.5a6.5 6.5 0 0 1 3.5 5.5"/>',
  shield:'<path d="M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-4.5"/>',
  send:'<path d="M4 12l16-8-6 16-3-7z"/>',
  map:'<path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
  book:'<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 19V5M8 7h7"/>',
  clipboard:'<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V3h6v1M9 11h6M9 15h4M8.5 11h.01M8.5 15h.01"/>',
  flame:'<path d="M12 3c1 3.5 5 5.5 5 10a5 5 0 0 1-10 0c0-2.5 1.5-4 2.5-5 .5 2 1.5 3 2.5 3 0-3-1-5 0-8z"/>',
  headset:'<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><rect x="3" y="14" width="4" height="6" rx="1.5"/><rect x="17" y="14" width="4" height="6" rx="1.5"/><path d="M19 20c0 1-2 2-5 2"/>',
  mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
  box:'<path d="M3 7l9-4 9 4v10l-9 4-9-4z"/><path d="M3 7l9 4 9-4M12 11v10"/>',
  grid:'<rect x="3" y="3" width="8" height="8" rx="1.5"/><rect x="13" y="3" width="8" height="5" rx="1.5"/><rect x="13" y="10" width="8" height="11" rx="1.5"/><rect x="3" y="13" width="8" height="8" rx="1.5"/>',
  printer:'<path d="M6 9V3h12v6M6 18H4v-7h16v7h-2"/><rect x="6" y="14" width="12" height="7"/>',
  qr:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM20 14v1M14 20h1M17 17h4v4h-4z"/>',
  scan:'<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3M4 12h16"/>',
  bolt:'<path d="M13 3L5 13h6l-1 8 8-10h-6z"/>',
  calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  chevdown:'<path d="M6 9l6 6 6-6"/>',
  swap:'<path d="M7 7h13M16 3l4 4-4 4M17 17H4M8 13l-4 4 4 4"/>'
};

export const ico = (n, cls = '') => `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON_PATHS[n] || ''}</svg>`;
export const LOGO = '/img/logo.png';
export const SYM = '/img/simbolo.png';

export const Util = {
  esc: s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])),
  pad: (n, l = 2) => String(n).padStart(l, '0'),
  normChar: c => c.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase(),
  norm: s => String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase(),
  uuid: () => crypto.randomUUID(),
  fmtData: d => { if (!d) return '—'; d = new Date(d); return `${Util.pad(d.getDate())}/${Util.pad(d.getMonth() + 1)}/${d.getFullYear()}`; },
  fmtDataHora: d => { if (!d) return '—'; d = new Date(d); return `${Util.fmtData(d)} ${Util.pad(d.getHours())}:${Util.pad(d.getMinutes())}`; },
  fmtCurta: d => { d = new Date(d); return `${Util.pad(d.getDate())}/${Util.pad(d.getMonth() + 1)} ${Util.pad(d.getHours())}:${Util.pad(d.getMinutes())}`; },
  diasEntre: (a, b) => Math.floor((new Date(b) - new Date(a)) / 864e5),
  plural: (n, s, p) => `${n} ${n === 1 ? s : (p || s + 's')}`,
  pct: (a, b) => b ? Math.round(a * 100 / b) : 0,
  iniciais: nome => String(nome || '?').split(' ').filter(Boolean).slice(0, 2).map(p => p[0]).join('').toUpperCase(),
  mes: m => m && /^\d{4}-\d{2}$/.test(m) ? `${m.slice(5)}/${m.slice(0, 4)}` : (m || ''),
  destacar(texto, termos) {
    const t = String(texto ?? '');
    if (!termos.length) return Util.esc(t);
    const n = Array.from(t).map(Util.normChar).join('');
    const marks = new Array(t.length).fill(false);
    for (const q of termos) { let i = n.indexOf(q); while (q && i > -1) { for (let k = i; k < i + q.length; k++) marks[k] = true; i = n.indexOf(q, i + q.length); } }
    let out = '', on = false;
    Array.from(t).forEach((ch, i) => { if (marks[i] && !on) { out += '<mark>'; on = true; } if (!marks[i] && on) { out += '</mark>'; on = false; } out += Util.esc(ch); });
    return out + (on ? '</mark>' : '');
  },
  baixar(nome, conteudo, tipo = 'text/plain') {
    const blob = conteudo instanceof Blob ? conteudo : new Blob([conteudo], { type: tipo + ';charset=utf-8' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = nome;
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 800);
  },
  csv(linhas) { return '﻿' + linhas.map(l => l.map(v => { const s = String(v ?? ''); return /[";\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; }).join(';')).join('\n'); },
  hojeISO: () => new Date().toISOString().slice(0, 10)
};
export const esc = Util.esc;

export const MESES = ['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];
/* espelho de app.ciclo_de() no banco (fuso do aparelho = America/Sao_Paulo na operação) */
export const Ciclos = {
  mensal: d => `${d.getFullYear()}-${Util.pad(d.getMonth() + 1)}`,
  semanal(d) {
    const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    const dia = t.getUTCDay() || 7; t.setUTCDate(t.getUTCDate() + 4 - dia);
    const ano = t.getUTCFullYear();
    const sem = Math.ceil(((t - Date.UTC(ano, 0, 1)) / 864e5 + 1) / 7);
    return `${ano}-W${Util.pad(sem)}`;
  },
  de: (d, per) => per === 'semanal' ? Ciclos.semanal(d) : Ciclos.mensal(d),
  anteriorData: (d, per, n = 1) => per === 'semanal' ? new Date(d.getTime() - 7 * 864e5 * n) : new Date(d.getFullYear(), d.getMonth() - n, 15, 12),
  inicioSemana(d) { const x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); const dia = x.getDay() || 7; x.setDate(x.getDate() - dia + 1); return x; },
  rotulo(c) {
    if (!c || c === '-') return '—';
    if (c.includes('W')) return `Semana ${Number(c.split('W')[1])}/${c.slice(0, 4)}`;
    const [a, m] = c.split('-'); return `${MESES[Number(m) - 1]}/${a}`;
  },
  diasRestantesMes(d) { return new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate() - d.getDate(); },
  venceBreve(per, d) { return per === 'semanal' ? [5, 6, 0].includes(d.getDay()) : Ciclos.diasRestantesMes(d) <= 4; }
};

export const ICONE_CAT = { extintor: 'extintor', hidrante: 'hidrante', maca: 'maca', chuveiro: 'chuveiro' };
export const SINONIMOS = {
  extintor: 'extintor extintores', hidrante: 'hidrante hidrantes abrigo mangueira mangueiras storz esguicho',
  maca: 'maca macas prancha resgate primeiros socorros kit', chuveiro: 'chuveiro chuveiros lava-olhos lava olhos lavaolhos chuveiro de emergencia ducha'
};
export const GATILHOS = { extrativo: { nome: 'Extrativo', cor: '#2F6FD6', icone: 'upload', desc: 'Extintor retirado/ausente do ponto' }, violacao: { nome: 'Violação', cor: '#E8912D', icone: 'shield', desc: 'Lacre/trava violado ou equipamento adulterado' }, combate: { nome: 'Em combate', cor: '#C8342B', icone: 'flame', desc: 'Utilizado em princípio de incêndio' } };
export const ACIONADORES = { lider: 'Líder do turno', brigada: 'Membro da brigada', supervisor: 'Supervisor da área', gerente: 'Gerente da área' };
export const MEIOS = { email: { nome: 'E-mail', icone: 'mail' }, radio: { nome: 'Rádio', icone: 'headset' }, whatsapp: { nome: 'WhatsApp', icone: 'send' }, pessoalmente: { nome: 'Pessoalmente', icone: 'user' } };
export const MOTIVOS_TROCA = ['Validade da Carga N2','Validade do Cilindro (Teste Hidrostático) N3','Corrosão','Amassados','Lacre rompido','Manômetro danificado','Despressurizado','Uso em combate','Extintor ausente (extrativo)','Remanejamento entre pontos','Outro'];
export const ORIGENS_TROCA = { reserva: 'Reserva técnica', manutencao: 'Empresa de manutenção (recarga)', remanejamento: 'Outro ponto (remanejamento)', outro: 'Outro' };
export const ORIGEM_ALT = { cadastro: ['Cadastro', 't-info'], inspecao: ['Inspeção', 't-ok'], desvio: ['Comunicado de desvio', 't-nc'], troca: ['Troca de equipamento', 't-warn'], qr: ['Etiqueta QR', 't-pend'], situacao: ['Situação do ponto', 't-lost'], importacao: ['Importação', 't-pend'] };
export const CAMPOS_ALT = { codigo: 'Código', area: 'Área', local: 'Local', gerencia_id: 'Gerência', bombeiro_id: 'Bombeiro responsável', subtipo: 'Equipamento previsto', capacidade: 'Capacidade', numero_cilindro: 'Nº do cilindro', agente: 'Agente extintor', n2: 'N2 (recarga)', n3: 'N3 (teste hidrostático)', ativo: 'Situação', qr_id: 'Etiqueta QR', unidade_id: 'Unidade', ponto_cadastrado: 'Ponto cadastrado' };
export const PAPEIS = { owner: 'Owner', admin: 'Administrador', inspetor: 'Inspetor', inspetor_leitura: 'Inspetor (leitura)', admin_leitura: 'Admin (leitura)', consulta: 'Admin (leitura)' };
/** quem faz inspeções (aparece nas listas de bombeiros) */
export const INSPECIONA = ['owner', 'admin', 'inspetor'];
export const RESERVA_MIN_PADRAO = { 'CO₂ 6kg': 6, 'Pó Químico Seco BC 4kg': 4, 'Pó Químico BC 6kg': 4, 'Água': 2, 'Pó Químico Seco ABC 6kg': 2 };

/* ---------------- período (filtro por calendário) ---------------- */
export const diaDe = d => { const x = new Date(d); return `${x.getFullYear()}-${Util.pad(x.getMonth() + 1)}-${Util.pad(x.getDate())}`; };
export const fmtDia = d => d ? d.split('-').reverse().join('/') : '';
export const Periodo = {
  hoje: () => diaDe(new Date()),
  mesAtual() { const h = new Date(); return { de: diaDe(new Date(h.getFullYear(), h.getMonth(), 1)), ate: diaDe(h) }; },
  ok(iso, f) { const d = diaDe(iso); return (!f.de || d >= f.de) && (!f.ate || d <= f.ate); },
  rot(f = {}) {
    if (!f.de && !f.ate) return 'Todo o período carregado';
    if (f.de === f.ate) return `Dia ${fmtDia(f.de)}`;
    return `${fmtDia(f.de) || 'início'} a ${fmtDia(f.ate) || 'hoje'}`;
  },
  presets() {
    const h = new Date(), d = n => diaDe(new Date(h.getFullYear(), h.getMonth(), h.getDate() - n));
    return [['Hoje', d(0), d(0)], ['Ontem', d(1), d(1)], ['Últimos 7 dias', d(6), d(0)], ['Últimos 30 dias', d(29), d(0)],
      ['Este mês', diaDe(new Date(h.getFullYear(), h.getMonth(), 1)), d(0)], ['Mês passado', diaDe(new Date(h.getFullYear(), h.getMonth() - 1, 1)), diaDe(new Date(h.getFullYear(), h.getMonth(), 0))],
      ['Últimos 90 dias', d(89), d(0)], ['Todo o período', '', '']];
  },
  dias(f, inicio) { const de = f.de || inicio || Periodo.hoje(), ate = f.ate || Periodo.hoje(), out = []; let x = new Date(de + 'T12:00'); const fim = new Date(ate + 'T12:00'); while (x <= fim && out.length < 800) { out.push(diaDe(x)); x = new Date(x.getTime() + 864e5); } return out; },
  serie(f, fn, inicio) {
    const ds = Periodo.dias(f, inicio);
    if (ds.length <= 45) return { por: 'dia', rows: ds.map(d => ({ label: ds.length > 20 ? d.slice(8) : `${d.slice(8)}/${d.slice(5, 7)}`, v: fn({ ...f, de: d, ate: d }) })) };
    const ms = [...new Set(ds.map(d => d.slice(0, 7)))];
    return { por: 'mês', rows: ms.map(m => ({ label: Ciclos.rotulo(m).slice(0, 3) + '/' + m.slice(2, 4), v: fn({ ...f, de: f.de && f.de > m + '-01' ? f.de : m + '-01', ate: f.ate && f.ate < m + '-31' ? f.ate : m + '-31' }) })) };
  }
};

/* ---------------- checklists (espelham o Forms da Brigada) ---------------- */
export const AGENTES = ['Pó Químico Seco BC 4kg','Pó Químico BC 6kg','Pó Químico BC 8kg','Pó Químico BC 9kg','Pó Químico Seco ABC 6kg','Pó Químico BC Carreta 20kg','Pó Químico BC Carreta 25kg','CO₂ 4kg','CO₂ 6kg','CO₂ Carreta 25kg','Água','Espuma'];
export const CK = {
  extintor: {
    secao: 'Extintor',
    cab: [ { k:'fab', l:'Nº do cilindro', t:'text' }, { k:'agente', l:'Agente extintor', t:'select', op: AGENTES }, { k:'n2', l:'Inspeção N2 (recarga)', t:'month' }, { k:'n3', l:'Inspeção N3 (teste hidrostático)', t:'year' } ],
    itens: [
      { k:'manometro', l:'Manômetro', na:true, sug:['Ponteiro fora da faixa verde','Visor quebrado','Manômetro danificado'] },
      { k:'mangueira', l:'Mangueira', na:true, sug:['Ressecada/rachada','Mangueira solta','Ausente'] },
      { k:'difusor', l:'Difusor', na:true, sug:['Obstruído','Quebrado','Ausente'] },
      { k:'lacre', l:'Lacre', na:true, sug:['Lacre rompido','Lacre ausente','Pino de segurança ausente'] },
      { k:'sinalizacao', l:'Sinalização', na:true, sug:['Placa ausente','Placa desbotada','Demarcação de piso apagada','Acesso obstruído'] }
    ],
    opcoes: [ { k:'anel', l:'Cor do anel', op:['Amarelo','Verde','Branco','Azul','Preto','Laranja','Púrpura'] }, { k:'base', l:'Base', op:['Coluna','Tripé','Carreta','Suporte (parede)'] } ],
    troca: { l:'Troca do extintor?', motivos:['Validade da Carga N2','Validade do Cilindro (Teste Hidrostático) N3','Corrosão','Amassados','Lacre rompido','Manômetro danificado','Despressurizado'] }
  },
  hidrante: {
    secao: 'Hidrante',
    itens: [
      { k:'integridade', l:'Integridade do hidrante', sug:['Vazamento no registro','Registro emperrado','Corrosão'] },
      { k:'abrigo', l:'Integridade do abrigo', sug:['Porta danificada','Vidro quebrado','Abrigo sem fechamento'] },
      { k:'acesso', l:'Acesso', sug:['Acesso obstruído por material','Acesso obstruído por veículo'] },
      { k:'sinalVert', l:'Sinalização vertical', sug:['Placa ausente','Placa desbotada'] },
      { k:'sinalHoriz', l:'Sinalização horizontal', sug:['Demarcação de piso apagada','Sem demarcação'] },
      { k:'lacre', l:'Lacre', sug:['Lacre rompido','Lacre ausente'] }
    ],
    qtd: [ { k:'mangueiras', l:'Mangueiras' }, { k:'storz', l:'Chaves Storz' }, { k:'agulheta', l:'Esguicho agulheta' }, { k:'regulavel', l:'Esguicho regulável' } ]
  },
  maca: {
    secao: 'Maca',
    cab: [ { k:'kitVenc', l:'Vencimento do kit de emergência', t:'date' } ],
    itens: [
      { k:'lacre', l:'Lacre / suporte', sug:['Lacre rompido','Suporte danificado','Tirantes incompletos'] },
      { k:'acesso', l:'Acesso', sug:['Acesso obstruído'] },
      { k:'sinalizacao', l:'Sinalização', sug:['Placa ausente','Placa desbotada'] }
    ]
  },
  chuveiro: {
    secao: 'Chuveiro e lava-olhos',
    pressurizado: [
      { k:'pIntegridade', l:'Integridade do equipamento pressurizado', sug:['Cilindro danificado','Sem pressão'] },
      { k:'pAcesso', l:'Acesso do equipamento pressurizado', sug:['Acesso obstruído'] },
      { k:'pSinal', l:'Sinalização do equipamento pressurizado', sug:['Placa ausente'] }
    ],
    itens: [
      { k:'acesso', l:'Acesso', sug:['Acesso obstruído'] },
      { k:'integridade', l:'Integridade do equipamento', sug:['Acionador quebrado','Tampas do lava-olhos ausentes','Vazamento'] },
      { k:'pressao', l:'Pressão da água', na:true, sug:['Baixa vazão','Sem água'] },
      { k:'agua', l:'Água limpa', sug:['Água com ferrugem','Água suja'] },
      { k:'temperatura', l:'Temperatura da água (16 °C a 38 °C)', na:true, sug:['Água muito quente','Água muito fria'] },
      { k:'sinalizacao', l:'Sinalização', sug:['Placa ausente','Placa desbotada'] }
    ]
  }
};

export const itensDe = (cat, press) => cat === 'chuveiro' && press ? [...CK.chuveiro.pressurizado, ...CK.chuveiro.itens] : CK[cat].itens;

/* ---------------- gráficos SVG/HTML leves ---------------- */
export const COR = { c:'#1E9E6A', nc:'#D14343', navy:'#0A2F57', teal:'#00A87E', cinza:'#CBD5DF', amber:'#D9912B', azul:'#2F6FD6' };
export const Charts = {
  legenda: itens => `<div style="display:flex;flex-wrap:wrap;gap:6px 14px;margin-top:10px;font-size:12px;color:#44576A">${itens.map(([n, c]) => `<span style="display:inline-flex;align-items:center;gap:6px"><i style="width:10px;height:10px;border-radius:3px;background:${c};display:inline-block"></i>${esc(n)}</span>`).join('')}</div>`,
  vazio: (t = 'Sem dados para os filtros escolhidos.') => `<p style="color:#6B7C8D;font-size:13px;margin:8px 0">${t}</p>`,
  /* barras horizontais (empilhadas quando houver mais de um valor) */
  hbars(rows, { cores = [COR.c, COR.nc], nomes = ['Conforme', 'Não conforme'], rot = 150, max, legenda = true, sufixo = '' } = {}) {
    if (!rows.length) return Charts.vazio();
    const m = max || Math.max(1, ...rows.map(r => r.v.reduce((a, b) => a + b, 0)));
    return `<div style="display:grid;gap:7px">${rows.map(r => { const tot = r.v.reduce((a, b) => a + b, 0); const tip = `<b>${esc(r.label)}</b>${r.v.map((x, i) => `${nomes[i] || ''}: ${x}${sufixo}`).join('<br>')}`;
      return `<div data-tip="${esc(tip)}" style="display:grid;grid-template-columns:${rot}px 1fr 48px;align-items:center;gap:8px;font-size:12.5px"><span style="color:#44576A;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${esc(r.label)}">${esc(r.label)}</span><span style="display:flex;height:13px;background:#EDF1F5;border-radius:3px;overflow:hidden">${r.v.map((x, i) => x ? `<span style="width:${x * 100 / m}%;background:${cores[i]};${i ? 'border-left:2px solid #fff;' : ''}"></span>` : '').join('')}</span><span style="text-align:right;font-weight:700;color:#16222E;font-variant-numeric:tabular-nums">${tot}${sufixo}</span></div>`; }).join('')}</div>${legenda && rows[0].v.length > 1 ? Charts.legenda(nomes.map((n, i) => [n, cores[i]])) : ''}`;
  },
  /* colunas verticais empilhadas */
  vbars(rows, { cores = [COR.c, COR.nc], nomes = ['Conforme', 'Não conforme'], altura = 150, legenda = true, destaque = -1 } = {}) {
    if (!rows.length) return Charts.vazio();
    const m = Math.max(1, ...rows.map(r => r.v.reduce((a, b) => a + b, 0))), n = rows.length, gap = n > 20 ? 2 : n > 12 ? 4 : 6, passo = Math.ceil(n / 12), num = n <= 16;
    return `<div style="display:flex;align-items:flex-end;gap:${gap}px;height:${altura + 18}px;border-bottom:1px solid #DCE4EC;padding:0 2px">${rows.map((r, k) => { const tot = r.v.reduce((a, b) => a + b, 0); const tip = `<b>${esc(r.label)}</b>${r.v.map((x, i) => `${nomes[i] || ''}: ${x}`).join('<br>')}`;
      return `<div data-tip="${esc(tip)}" style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%;min-width:0"><span style="font-size:${num ? 11 : 9}px;font-weight:700;color:#16222E;margin-bottom:3px;white-space:nowrap">${num || tot === m ? tot || '' : ''}</span><span style="width:100%;max-width:44px;display:flex;flex-direction:column-reverse;border-radius:4px 4px 0 0;overflow:hidden;${k === destaque ? 'outline:2px solid #0A2F57;outline-offset:1px;' : ''}">${r.v.map((x, i) => x ? `<span style="height:${x * altura / m}px;background:${cores[i]};${i ? 'border-bottom:2px solid #fff;' : ''}"></span>` : '').join('')}</span></div>`; }).join('')}</div>
      <div style="display:flex;gap:${gap}px;padding:5px 2px 0">${rows.map((r, k) => `<span style="flex:1;min-width:0;text-align:center;font-size:10.5px;color:#6B7C8D;white-space:nowrap;overflow:visible">${k % passo === 0 ? esc(r.label) : ''}</span>`).join('')}</div>${legenda && rows[0].v.length > 1 ? Charts.legenda(nomes.map((n, i) => [n, cores[i]])) : ''}`;
  },
  /* rosca com total no centro */
  donut(parts, { centro, sub = '', tam = 150 } = {}) {
    const tot = parts.reduce((a, p) => a + p.v, 0);
    if (!tot) return Charts.vazio();
    const r = 52, C = 2 * Math.PI * r; let off = 0;
    const arcos = parts.filter(p => p.v).map(p => { const len = p.v / tot * C; const s = `<circle r="${r}" cx="70" cy="70" fill="none" stroke="${p.cor}" stroke-width="20" stroke-dasharray="${Math.max(0, len - 2)} ${C}" stroke-dashoffset="${-off}" transform="rotate(-90 70 70)"><title>${esc(p.label)}: ${p.v}</title></circle>`; off += len; return s; }).join('');
    return `<div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap"><svg viewBox="0 0 140 140" width="${tam}" height="${tam}" role="img" aria-label="${esc(parts.map(p => p.label + ' ' + p.v).join(', '))}">${arcos}<text x="70" y="68" text-anchor="middle" font-family="Poppins,Arial" font-size="24" font-weight="700" fill="#0B2440">${centro ?? tot}</text><text x="70" y="86" text-anchor="middle" font-family="Arial" font-size="10" fill="#6B7C8D">${esc(sub)}</text></svg>
      <div style="display:grid;gap:6px;font-size:12.5px">${parts.map(p => `<span data-tip="<b>${esc(p.label)}</b>${p.v} (${Util.pct(p.v, tot)}%)" style="display:flex;align-items:center;gap:8px"><i style="width:10px;height:10px;border-radius:3px;background:${p.cor};display:inline-block"></i><span style="color:#44576A">${esc(p.label)}</span><b style="margin-left:auto;padding-left:10px">${p.v}</b><span style="color:#6B7C8D;width:38px;text-align:right">${Util.pct(p.v, tot)}%</span></span>`).join('')}</div></div>`;
  },
  /* velocímetro de conformidade (0–100%) */
  gauge(pct, { rotulo = '', meta = 98, tam = 200 } = {}) {
    const p = Math.max(0, Math.min(100, pct)), a = Math.PI * (1 - p / 100), x = 100 + 80 * Math.cos(a), y = 100 - 80 * Math.sin(a);
    const cor = p >= meta ? COR.c : p >= 85 ? COR.amber : COR.nc;
    const am = Math.PI * (1 - meta / 100), mx = 100 + 80 * Math.cos(am), my = 100 - 80 * Math.sin(am);
    return `<svg viewBox="0 0 200 118" width="${tam}" style="max-width:100%" role="img" aria-label="${esc(rotulo)} ${p}%"><path d="M20 100 A80 80 0 0 1 180 100" fill="none" stroke="#E6ECF2" stroke-width="18" stroke-linecap="round"/>${p > 0 ? `<path d="M20 100 A80 80 0 0 1 ${x.toFixed(1)} ${y.toFixed(1)}" fill="none" stroke="${cor}" stroke-width="18" stroke-linecap="round"/>` : ''}<line x1="${(100 + 68 * Math.cos(am)).toFixed(1)}" y1="${(100 - 68 * Math.sin(am)).toFixed(1)}" x2="${(100 + 92 * Math.cos(am)).toFixed(1)}" y2="${(100 - 92 * Math.sin(am)).toFixed(1)}" stroke="#44576A" stroke-width="2" stroke-dasharray="3 2"/><text x="100" y="92" text-anchor="middle" font-family="Poppins,Arial" font-size="30" font-weight="700" fill="#0B2440">${String(p).replace('.', ',')}%</text><text x="100" y="112" text-anchor="middle" font-family="Arial" font-size="10" fill="#6B7C8D">${esc(rotulo)} · meta ${meta}%</text></svg>`;
  },
  /* matriz itens NC × equipamento (como no BI) */
  heat(linhas, colunas, val) {
    if (!linhas.length) return Charts.vazio('Nenhum item não conforme no período.');
    const max = Math.max(1, ...linhas.flatMap(l => colunas.map(c => val(l, c))));
    return `<div style="overflow-x:auto"><table style="border-collapse:separate;border-spacing:3px;font-size:11.5px;width:100%"><thead><tr><th></th>${colunas.map(c => `<th style="font-weight:600;color:#44576A;padding:2px 4px;text-align:center;writing-mode:vertical-rl;transform:rotate(180deg);height:128px;white-space:nowrap;font-size:11px">${esc(c)}</th>`).join('')}</tr></thead><tbody>${linhas.map(l => `<tr><td style="font-weight:700;color:#0B2440;white-space:nowrap;padding-right:6px">${esc(l)}</td>${colunas.map(c => { const v = val(l, c); return `<td data-tip="<b>${esc(l)}</b>${esc(c)}: ${v} NC" style="background:${v ? `rgba(209,67,67,${.25 + .75 * v / max})` : '#F1F4F7'};color:${v ? '#fff' : '#9AA8B5'};text-align:center;border-radius:4px;height:24px;min-width:26px;font-weight:700">${v || ''}</td>`; }).join('')}</tr>`).join('')}</tbody></table></div>`;
  },
  barra: (p, cor = COR.teal) => `<span style="display:block;height:8px;background:#E6ECF2;border-radius:999px;overflow:hidden"><i style="display:block;height:100%;width:${Math.max(0, Math.min(100, p))}%;background:${cor};border-radius:999px"></i></span>`
};

