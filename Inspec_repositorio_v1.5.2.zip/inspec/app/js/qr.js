/* Inspec — QR Code: etiquetas (geração e impressão) e leitor pela câmera */
import { A } from './ns.js';
import { Store, Regras } from './dados.js';
import { rpc } from './db.js';
import { UI, Comp } from './ui.js';
import { ico, esc, Util, SYM } from './util.js';
import { CONFIG } from '../config.js';
import { abrirDocumento } from './janela.js';

export const QR = {
  url: e => CONFIG.DOMINIO_QR + e.qr,
  fmt: t => t ? t.slice(0, 4) + '-' + t.slice(4) : '',
  matriz(txt) { const q = window.qrcode(0, 'M'); q.addData(txt, /^[0-9A-Z $%*+\-./:]*$/.test(txt) ? 'Alphanumeric' : 'Byte'); q.make(); return q; },
  svg(txt, { margem = 2, px } = {}) {
    const q = QR.matriz(txt), n = q.getModuleCount(), t = n + margem * 2; let d = '';
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (q.isDark(r, c)) d += `M${c + margem} ${r + margem}h1v1h-1z`;
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${t} ${t}" ${px ? `width="${px}" height="${px}"` : ''} shape-rendering="crispEdges" role="img" aria-label="QR Code"><rect width="${t}" height="${t}" fill="#fff"/><path d="${d}" fill="#000"/></svg>`;
  },
  /** extrai o ID do texto lido: URL do Inspec, ID puro (ABCD-EFGH) ou código do ponto */
  extrair(txt) {
    const up = String(txt || '').trim().toUpperCase();
    const m = up.match(/\/Q\/([0-9A-Z]{4}-?[0-9A-Z]{4})\b/) || up.match(/^(?:INSPEC:)?([0-9A-Z]{4}-?[0-9A-Z]{4})$/);
    return { id: m ? m[1].replace('-', '') : null, bruto: up, url: /^https?:/i.test(up) };
  },
  async resolver(txt) {
    const { id, bruto, url } = QR.extrair(txt);
    if (id) {
      const e = Store.S.pontos.find(x => x.qr === id); if (e) return { e };
      if (navigator.onLine) {
        try { const r = await rpc('resolver_qr', { p_qr: id }); const x = r?.[0]; if (x) { const e2 = Store.eq(x.ponto_id); if (e2) return { e: e2, antigo: x.substituida ? { ate: x.invalidado_em, motivo: x.motivo } : null }; return { erro: 'Este ponto pertence a outra unidade. Troque a unidade no Menu.' }; } }
        catch (er) { console.warn(er); }
      } else return { erro: 'Etiqueta não encontrada nos dados do aparelho. Conecte-se para conferir se é uma etiqueta antiga.' };
    }
    const porCod = Store.S.pontos.find(x => x.codigo.toUpperCase() === bruto);
    if (porCod) return { e: porCod, porCodigo: true };
    return { erro: url ? 'Este QR Code não é de uma etiqueta do Inspec.' : 'QR Code não reconhecido: não corresponde a nenhum ponto cadastrado.' };
  },
  etiqueta(e) {
    const g = Store.ger(e.ger), c = Store.cat(e.cat);
    return `<div class="etq"><div class="q">${QR.svg(QR.url(e), { margem: 1 })}</div><div class="t"><span class="m"><img src="${location.origin}${SYM}" alt="">INSPEC</span><span class="c">${esc(e.codigo)}</span><span class="s">${esc(c.nome)}${e.subtipo ? ' · ' + esc(e.subtipo) : ''}</span><span class="l">${esc(g.sigla)} › ${esc(e.local || e.area)}</span><span class="id">ID ${QR.fmt(e.qr)}</span></div></div>`;
  },
  placa(e) {
    const g = Store.ger(e.ger), c = Store.cat(e.cat);
    return `<div class="pl"><div class="pl-q">${QR.svg(QR.url(e), { margem: 2 })}<span class="pl-id">ID ${QR.fmt(e.qr)}</span></div>
      <div class="pl-t"><img class="pl-logo" src="${location.origin}/img/logo_placa.png" alt="Inspec">
      <div class="pl-tipo">${esc(c.nome)}</div><div class="pl-c">${esc(e.codigo)}</div>
      <div class="pl-g"><span>Gerência</span>${esc(g.nome)}</div>
      <div class="pl-i">Aponte a câmera do celular para o QR Code para abrir este ponto no Inspec.<br>Sem leitura? Digite o ID <b>${QR.fmt(e.qr)}</b> no leitor do app.</div></div></div>`;
  },
  CSS_PLACA: `.pl{width:210mm;height:148.5mm;padding:12mm 12mm 12mm 12mm;display:grid;grid-template-columns:112mm 1fr;gap:9mm;align-items:center;color:#0A2F57;font-family:Inter,Arial,sans-serif;background:#fff;position:relative;overflow:hidden}
.pl::before{content:'';position:absolute;inset:5mm;border:1.2mm solid #0A2F57;border-radius:5mm;pointer-events:none}
.pl-q{display:flex;flex-direction:column;align-items:center;gap:2mm}.pl-q svg{width:108mm;height:108mm;display:block}
.pl-id{font-size:11pt;font-weight:700;letter-spacing:.12em;color:#44576A}
.pl-t{display:flex;flex-direction:column;gap:3.2mm;min-width:0;padding-right:2mm}
.pl-logo{width:62mm;height:auto;display:block;margin-bottom:2mm}
.pl-tipo{font-size:13pt;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#C0362C;margin-top:2mm}
.pl-c{font-family:Poppins,Inter,Arial,sans-serif;font-weight:700;font-size:40pt;line-height:1;letter-spacing:-.01em;word-break:break-all}
.pl-g{font-size:15pt;font-weight:700;color:#16222E;line-height:1.2}.pl-g span{display:block;font-size:8.5pt;font-weight:600;text-transform:uppercase;letter-spacing:.08em;color:#6B7C8D;margin-bottom:.8mm}
.pl-i{font-size:9pt;line-height:1.4;color:#44576A;border-top:.3mm solid #DCE4EC;padding-top:3mm;margin-top:2mm}.pl-i b{color:#0A2F57;letter-spacing:.05em}`,
  MODELOS: {
    meiaA4: { nome: 'Placa meia folha A4 — 2 por folha (210 × 148 mm)', placa: true },
    a4263: { nome: 'Pimaco A4263 / 6180 — 21 por folha (63,5 × 38,1 mm)', col: 3, lin: 7, w: 63.5, h: 38.1, mx: 7.2, my: 15.15, gx: 2.5, gy: 0 },
    a4260: { nome: 'Pimaco A4260 — 24 por folha (63,5 × 33,9 mm)', col: 3, lin: 8, w: 63.5, h: 33.9, mx: 7.2, my: 12.9, gx: 2.5, gy: 0 },
    avulsa: { nome: 'Impressora de etiquetas — 1 por etiqueta (63,5 × 38,1 mm)', col: 1, lin: 1, w: 63.5, h: 38.1, avulsa: true }
  },
  CSS_ETQ: `.etq{width:63.5mm;height:38.1mm;background:#fff;display:grid;grid-template-columns:30mm 1fr;align-items:center;gap:2mm;padding:2.5mm;box-sizing:border-box;color:#0A2F57;font-family:Inter,Arial,sans-serif;overflow:hidden}
.etq .q svg{width:100%;height:auto;display:block}.etq .t{min-width:0;display:flex;flex-direction:column;gap:.8mm}
.etq .m{display:flex;align-items:center;gap:1.2mm;font-size:6.5pt;font-weight:700;color:#00A87E}.etq .m img{width:3.6mm;height:3.6mm}
.etq .c{font-family:Poppins,Inter,Arial,sans-serif;font-weight:700;font-size:13pt;line-height:1}.etq .s{font-size:6.3pt;font-weight:600;color:#16222E;line-height:1.2}
.etq .l{font-size:5.8pt;color:#44576A;line-height:1.2;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}.etq .id{font-size:5.5pt;color:#6B7C8D;letter-spacing:.05em}`,
  imprimir(lista, { modelo = 'meiaA4', pular = 0, aoImprimir } = {}) {
    if (QR.MODELOS[modelo]?.placa) return QR.imprimirPlacas(lista, { pular, aoImprimir });
    const M = QR.MODELOS[modelo], porFolha = M.col * M.lin, cels = [...Array(M.avulsa ? 0 : pular).fill(null), ...lista], folhas = [];
    for (let i = 0; i < cels.length; i += porFolha) folhas.push(cels.slice(i, i + porFolha));
    const css = `*{box-sizing:border-box}body{margin:0;background:#E9EEF3;font-family:Inter,Arial,sans-serif;-webkit-print-color-adjust:exact;print-color-adjust:exact}
      .fl{width:210mm;height:297mm;margin:14px auto;background:#fff;box-shadow:0 4px 20px rgba(0,0,0,.12);padding:${M.my || 0}mm ${M.mx || 0}mm;display:grid;grid-template-columns:repeat(${M.col},${M.w}mm);grid-auto-rows:${M.h}mm;column-gap:${M.gx || 0}mm;row-gap:${M.gy || 0}mm;align-content:start;page-break-after:always}
      .fl.av{width:${M.w}mm;height:${M.h}mm;padding:0;display:block}${QR.CSS_ETQ}.etq{height:${M.h}mm}.vz{border:1px dashed #E1E7EE}
      @page{size:${M.avulsa ? `${M.w}mm ${M.h}mm` : 'A4'};margin:0}@media print{body{background:#fff}.fl{margin:0;box-shadow:none}.vz{border:0}}`;
    const corpo = M.avulsa ? lista.map(e => `<div class="fl av">${QR.etiqueta(e)}</div>`).join('') : folhas.map(f => `<div class="fl">${f.map(e => e ? QR.etiqueta(e) : '<div class="vz"></div>').join('')}</div>`).join('');
    return abrirDocumento(`Etiquetas QR · ${Util.plural(lista.length, 'etiqueta')} — ${M.nome}`, css, corpo, { aoImprimir });
  },
  /** placas de meia folha A4: 2 por folha A4 em pé, com linha de corte no meio */
  imprimirPlacas(lista, { pular = 0, aoImprimir } = {}) {
    const cels = [...Array(Math.min(1, pular)).fill(null), ...lista], folhas = [];
    for (let i = 0; i < cels.length; i += 2) folhas.push(cels.slice(i, i + 2));
    const css = `*{box-sizing:border-box}body{margin:0;background:#E9EEF3;-webkit-print-color-adjust:exact;print-color-adjust:exact}
      .fl{width:210mm;height:297mm;margin:14px auto;background:#fff;box-shadow:0 4px 20px rgba(0,0,0,.12);display:flex;flex-direction:column;page-break-after:always;break-after:page;overflow:hidden}
      .corte{height:0;border-top:.3mm dashed #9AA8B5;position:relative}.corte span{position:absolute;right:8mm;top:-2.2mm;background:#fff;padding:0 2mm;font:7pt Inter,Arial,sans-serif;color:#9AA8B5}
      .vz{width:210mm;height:148.5mm}${QR.CSS_PLACA}
      @page{size:A4 portrait;margin:0}@media print{body{background:#fff}.fl{margin:0;box-shadow:none}}`;
    const corpo = folhas.map(f => `<div class="fl">${f[0] ? QR.placa(f[0]) : '<div class="vz"></div>'}<div class="corte"><span>✂ corte aqui</span></div>${f[1] ? QR.placa(f[1]) : '<div class="vz"></div>'}</div>`).join('');
    return abrirDocumento(`Placas QR · ${Util.plural(lista.length, 'placa')} em ${Util.plural(folhas.length, 'folha')} A4 (2 por folha)`, css, corpo, { aoImprimir });
  }
};

/* ---------------- leitor (BarcodeDetector nativo ou jsQR) ---------------- */
export const Scan = {
  st: null,
  abrir({ modo = 'geral' } = {}) {
    Scan.st = { modo, stream: null, raf: 0, ult: 0, pausa: 0, det: null };
    const el = document.getElementById('scan'); el.classList.add('on'); document.body.style.overflow = 'hidden';
    Scan.render(); Scan.camera();
  },
  render(msg = '', tipo = '') {
    const st = Scan.st, el = document.getElementById('scan');
    el.innerHTML = `<div class="scan-top"><button class="iconbtn" data-action="scan-fechar" aria-label="Fechar leitor">${ico('x')}</button><b>${st.modo === 'desvio' ? 'Ler QR do ponto do desvio' : 'Ler QR Code do ponto'}</b>${st.torch ? `<button class="iconbtn" data-action="scan-torch" aria-label="Lanterna">${ico('bolt')}</button>` : ''}</div>
      <div class="scan-view">${st.semCamera ? `<div class="scan-sem">${ico('camera')}<p><b style="color:#fff">${esc(st.semCamera)}</b></p><p>Você pode ler o QR a partir de uma foto ou digitar o identificador impresso na etiqueta (ex.: ABCD-2345).</p></div>` : `<video id="scan-v" playsinline muted></video><div class="scan-mask"><div class="scan-frame"><span class="scan-line"></span></div></div>`}
      <p class="scan-msg ${tipo}" id="scan-msg" role="status">${msg || (st.semCamera ? '' : 'Aponte a câmera para a etiqueta QR do ponto')}</p></div>
      <div class="scan-bot"><button class="btn btn-sm" data-action="scan-foto">${ico('upload')}Ler de uma foto</button><button class="btn btn-sm" data-action="scan-digitar">${ico('edit')}Digitar ID ou código</button></div>`;
    if (st.stream) { const v = document.getElementById('scan-v'); v.srcObject = st.stream; v.play().catch(() => {}); }
  },
  async camera() {
    const st = Scan.st;
    if (!navigator.mediaDevices?.getUserMedia) { st.semCamera = 'Câmera indisponível neste navegador.'; return Scan.render(); }
    try {
      st.stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 } }, audio: false });
      if (!Scan.st) return st.stream.getTracks().forEach(t => t.stop());
      const tr = st.stream.getVideoTracks()[0]; st.torch = !!(tr.getCapabilities && tr.getCapabilities().torch);
      if ('BarcodeDetector' in window) { try { const f = await window.BarcodeDetector.getSupportedFormats(); if (f.includes('qr_code')) st.det = new window.BarcodeDetector({ formats: ['qr_code'] }); } catch (e) { /* usa jsQR */ } }
      Scan.render(); Scan.loop();
    } catch (err) {
      st.semCamera = err && err.name === 'NotAllowedError' ? 'Permissão da câmera negada. Libere o acesso à câmera nas configurações do navegador.' : 'Nenhuma câmera encontrada neste dispositivo.';
      Scan.render();
    }
  },
  loop() {
    const st = Scan.st; if (!st || !st.stream) return;
    st.raf = requestAnimationFrame(Scan.loop);
    const v = document.getElementById('scan-v'), agora = performance.now();
    if (!v || v.readyState < 2 || agora - st.ult < 140 || agora < st.pausa || st.ocupado) return;
    st.ult = agora;
    if (st.det) { st.ocupado = true; st.det.detect(v).then(r => { st.ocupado = false; if (r[0]) Scan.lido(r[0].rawValue); }).catch(() => { st.ocupado = false; st.det = null; }); return; }
    const txt = Scan.decodificar(v, v.videoWidth, v.videoHeight); if (txt) Scan.lido(txt);
  },
  decodificar(src, w, h, tentar = false) {
    const k = Math.min(1, 800 / Math.max(w, h)), cw = Math.round(w * k), ch = Math.round(h * k);
    const c = Scan._c || (Scan._c = document.createElement('canvas')); c.width = cw; c.height = ch;
    const ctx = c.getContext('2d', { willReadFrequently: true }); ctx.drawImage(src, 0, 0, cw, ch);
    const r = window.jsQR(ctx.getImageData(0, 0, cw, ch).data, cw, ch, { inversionAttempts: tentar ? 'attemptBoth' : 'dontInvert' });
    return r ? r.data : null;
  },
  async lido(txt) {
    const st = Scan.st; if (!st || st.resolvendo) return;
    st.resolvendo = true; const r = await QR.resolver(txt); st.resolvendo = false;
    if (!Scan.st) return;
    if (r.erro) { st.pausa = performance.now() + 1800; const m = document.getElementById('scan-msg'); if (m) { m.className = 'scan-msg err'; m.textContent = r.erro; } else UI.toast(r.erro); navigator.vibrate?.(200); return; }
    navigator.vibrate?.(60); const modo = st.modo; Scan.fechar(); Scan.acao(r, modo);
  },
  fechar() {
    const st = Scan.st; if (!st) return;
    cancelAnimationFrame(st.raf); st.stream?.getTracks().forEach(t => t.stop());
    Scan.st = null; const el = document.getElementById('scan'); el.classList.remove('on'); el.innerHTML = ''; document.body.style.overflow = '';
  },
  async foto(file) {
    if (!file) return;
    const img = new Image(), url = URL.createObjectURL(file);
    img.onload = () => {
      const txt = Scan.decodificar(img, img.naturalWidth, img.naturalHeight, true); URL.revokeObjectURL(url);
      document.getElementById('scan-foto').value = '';
      if (txt) { if (!Scan.st) Scan.st = { modo: 'geral', avulso: true }; Scan.lido(txt); }
      else { const m = document.getElementById('scan-msg'); if (m) { m.className = 'scan-msg err'; m.textContent = 'Não encontramos um QR Code nesta foto. Tente mais perto e com boa iluminação.'; } else UI.toast('Nenhum QR Code encontrado na foto.'); }
    };
    img.src = url;
  },
  /** QR lido pela câmera comum do celular: https://dominio/Q/ID → #/q/ID */
  async deepLink(id) {
    if (A.Router.modo !== 'app') { try { sessionStorage.setItem('inspec-qr', id || ''); } catch (e) { /* ignore */ } return; }
    history.replaceState(null, '', '#/buscar'); A.Router.render();
    const r = await QR.resolver('/Q/' + (id || ''));
    if (r.erro) UI.toast(r.erro, 5000); else Scan.acao(r);
  },
  acao({ e, antigo, porCodigo }, modo = 'geral') {
    if (modo === 'desvio' && A.tmp.desvio) { A.tmp.desvio.eq = e.id; A.tmp.desvio.localOk = false; A.tmp.desvio.reserva = null; if (location.hash.startsWith('#/desvio/novo')) A.render(); else location.hash = '#/desvio/novo'; UI.toast(`${e.codigo} identificado pelo QR Code.`); return; }
    const s = Regras.situacao(e), g = Store.ger(e.ger), podeI = Regras.pode('inspecionar') && e.ativo;
    UI.dialogo({ titulo: `Ponto ${esc(e.codigo)} identificado`, corpo: `
      ${antigo ? `<div class="notice n-amber" style="margin-bottom:12px">${ico('alert')}<div><b>Etiqueta substituída.</b> Esta etiqueta foi invalidada em ${Util.fmtData(antigo.ate)} (${esc(antigo.motivo)}). Retire-a e cole a etiqueta atual — avise a coordenação se ela ainda não foi reimpressa.</div></div>` : ''}
      ${!e.ativo ? `<div class="notice n-amber" style="margin-bottom:12px">${ico('alert')}<div><b>Ponto inativo</b> desde ${Util.fmtData(e.inativadoEm)} — ${esc(e.motivoInativacao || '')}.</div></div>` : ''}
      ${porCodigo ? '<p class="hint" style="margin-top:0">Identificado pelo código do ponto.</p>' : ''}
      <div class="list">${Comp.linhaEq(e, { href: `#/ponto/${e.id}` })}</div>
      <p class="hint" style="margin:10px 2px 0">${esc(Store.cat(e.cat).nome)} · ${esc(g.nome)} · ${s.pendente ? '<b style="color:#8A5A00">pendente no ciclo atual</b>' : 'já inspecionado no ciclo atual'}</p>`,
      rodape: `<button class="btn btn-sec" data-action="scan-abrir">${ico('scan')}Ler outro</button>${podeI ? `<a class="btn btn-sec" href="#/desvio/novo?eq=${e.id}">${ico('headset')}Desvio</a>` : ''}<a class="btn ${podeI ? 'btn-sec' : 'btn-pri'}" href="#/ponto/${e.id}">${ico('file')}Ficha</a>${podeI ? `<a class="btn btn-pri" href="#/inspecao/${e.id}?de=qr">${ico('check')}Inspecionar</a>` : ''}` });
  }
};

Object.assign(A.Acoes, {
  'scan-abrir': el => { UI.fechar(); Scan.abrir({ modo: el.dataset.modo || 'geral' }); },
  'scan-fechar': () => Scan.fechar(),
  'scan-foto': () => document.getElementById('scan-foto').click(),
  'scan-torch': async () => { const st = Scan.st, tr = st?.stream?.getVideoTracks()[0]; if (!tr) return; st.luz = !st.luz; try { await tr.applyConstraints({ advanced: [{ torch: st.luz }] }); } catch (e) { UI.toast('Lanterna indisponível.'); } },
  'scan-digitar': () => {
    const v = prompt('Digite o ID impresso na etiqueta (ex.: ABCD-2345) ou o código do ponto (ex.: ACI-020):');
    if (v) Scan.lido(v);
  }
});
/* estilos da placa também na página (prévia nos diálogos) */
{ const st = document.createElement('style'); st.textContent = QR.CSS_PLACA; document.head.appendChild(st); }
