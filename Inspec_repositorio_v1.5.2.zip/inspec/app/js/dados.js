/* =====================================================================
   Inspec — dados: modelo em memória, cache local (IndexedDB) e fila offline
   - Store.S guarda o retrato da unidade atual (pontos, inspeções, trocas…)
   - O retrato é salvo no aparelho: o app abre e funciona sem internet
   - Toda escrita de campo (inspeção, foto, troca, desvio) entra na FILA e
     é enviada na ordem; cada item é idempotente (UUID gerado no aparelho)
   ===================================================================== */
import { sb, todos, rpc, ehRede, msgErro } from './db.js';
import { CONFIG } from '../config.js';
import { Util, Ciclos, ICONE_CAT, SINONIMOS, CK } from './util.js';

/* ---------------- IndexedDB mínimo ---------------- */
const IDB = {
  db: null,
  abrir() {
    if (this.db) return Promise.resolve(this.db);
    return new Promise((ok, er) => {
      const r = indexedDB.open('inspec', 1);
      r.onupgradeneeded = () => { const d = r.result; d.createObjectStore('kv'); d.createObjectStore('fila', { keyPath: 'id' }); };
      r.onsuccess = () => { this.db = r.result; ok(this.db); };
      r.onerror = () => er(r.error);
    });
  },
  async tx(store, modo, fn) {
    const d = await this.abrir();
    return new Promise((ok, er) => {
      const t = d.transaction(store, modo), s = t.objectStore(store); let res;
      const r = fn(s); if (r) r.onsuccess = () => { res = r.result; };
      t.oncomplete = () => ok(res); t.onerror = () => er(t.error); t.onabort = () => er(t.error);
    });
  },
  get: (k) => IDB.tx('kv', 'readonly', s => s.get(k)),
  set: (k, v) => IDB.tx('kv', 'readwrite', s => s.put(v, k)),
  del: (k) => IDB.tx('kv', 'readwrite', s => s.delete(k)),
  filaTodos: () => IDB.tx('fila', 'readonly', s => s.getAll()),
  filaPut: (it) => IDB.tx('fila', 'readwrite', s => s.put(it)),
  filaDel: (id) => IDB.tx('fila', 'readwrite', s => s.delete(id)),
  limpar: () => Promise.all([IDB.tx('kv', 'readwrite', s => s.clear()), IDB.tx('fila', 'readwrite', s => s.clear())])
};
export { IDB };

/* ---------------- conversão banco → modelo do app ---------------- */
const mapPonto = (p, catChave) => ({
  id: p.id, codigo: p.codigo, cat: catChave[p.categoria_id] || 'extintor', catId: p.categoria_id, ger: p.gerencia_id,
  unidade: p.unidade_id, area: p.area || '', local: p.local || '', subtipo: p.subtipo || '', cap: p.capacidade || '',
  resp: p.bombeiro_id, qr: p.qr_id, qrEm: p.qr_gerado_em, qrImpresso: p.qr_impresso_em,
  fab: p.numero_cilindro || '', agente: p.agente || '', n2: p.n2 || '', n3: p.n3 || '', conferir: p.requer_conferencia,
  dados: p.dados || {}, ativo: p.ativo, inativadoEm: p.inativado_em, motivoInativacao: p.motivo_inativacao,
  criado: p.criado_em, atualizado: p.atualizado_em
});
const mapInsp = i => ({
  id: i.id, eq: i.ponto_id, dt: i.data_inspecao, ciclo: i.ciclo_referencia, per: i.periodicidade,
  st: i.status === 'ok' ? 'ok' : 'nc', ck: i.checklist && Object.keys(i.checklist).length ? i.checklist : null,
  resumo: i.resumo_nc || '', obs: i.observacoes || '', ins: i.inspetor_id, origem: i.origem, recebida: i.recebida_em,
  tardia: i.sinc_tardia, anulada: i.anulada, anuladaPor: i.anulada_por, anuladaEm: i.anulada_em, motivo: i.motivo_anulacao, sync: 'enviado'
});

/* ---------------- Store ---------------- */
export const Store = {
  S: null,            // retrato atual
  idx: null,          // índices
  sessao: null,       // { user }
  online: navigator.onLine,
  carregando: false,
  ultimaCarga: null,

  vazio() {
    return { eu: null, org: null, unidade: null, unidades: [], membros: [], usuarios: [], cats: [], gers: [], pontos: [], insp: [],
      fotos: [], trocas: [], alts: [], desvios: [], reserva: [], movs: [], dests: [], envios: [], cargaEm: null, versao: 1 };
  },

  /** categorias criadas pelo administrador ganham checklist próprio (as 4 padrão seguem o Forms) */
  registrarChecklists() {
    for (const c of this.S.cats) {
      if (['extintor', 'hidrante', 'maca', 'chuveiro'].includes(c.chave)) continue;
      const its = (c.checklist?.itens || []).map((i, n) => ({ k: i.k || 'i' + n, l: i.l, na: !!i.na, sug: [] }));
      CK[c.chave] = { secao: c.nome, itens: its.length ? its : [{ k: 'geral', l: 'Condição geral', sug: [] }] };
    }
  },
  reindexar() {
    if (this.S?.cats) this.registrarChecklists();
    const S = this.S, idx = { ponto: new Map(), ger: new Map(), usu: new Map(), cat: new Map(), catId: new Map(), porPonto: new Map(), fotos: new Map(), trocas: new Map(), desvio: new Map() };
    S.pontos.forEach(p => idx.ponto.set(p.id, p));
    S.gers.forEach(g => idx.ger.set(g.id, g));
    S.cats.forEach(c => { idx.cat.set(c.chave, c); idx.catId.set(c.id, c); });
    S.usuarios.forEach(u => idx.usu.set(u.id, { nome: u.nome || u.email || '—', email: u.email }));
    S.membros.forEach(m => idx.usu.set(m.usuario_id, { nome: m.nome, email: idx.usu.get(m.usuario_id)?.email || '', papel: m.papel }));
    S.insp.sort((a, b) => b.dt.localeCompare(a.dt));
    for (const i of S.insp) { if (!idx.porPonto.has(i.eq)) idx.porPonto.set(i.eq, []); idx.porPonto.get(i.eq).push(i); }
    for (const f of S.fotos) { if (!idx.fotos.has(f.registro_id)) idx.fotos.set(f.registro_id, []); idx.fotos.get(f.registro_id).push(f); }
    S.trocas.sort((a, b) => b.criado_em.localeCompare(a.criado_em));
    for (const t of S.trocas) { if (!idx.trocas.has(t.ponto_id)) idx.trocas.set(t.ponto_id, []); idx.trocas.get(t.ponto_id).push(t); }
    S.desvios.forEach(d => idx.desvio.set(d.id, d));
    S.desvios.sort((a, b) => b.acionado_em.localeCompare(a.acionado_em));
    S.alts.sort((a, b) => b.criado_em.localeCompare(a.criado_em));
    this.idx = idx;
  },
  eq: id => Store.idx.ponto.get(id),
  ger: id => Store.idx.ger.get(id) || { nome: '—', sigla: '—' },
  cat: chave => Store.idx.cat.get(chave) || { nome: chave, plural: chave, per: 'mensal', icone: 'extintor' },
  usuario: id => (id && Store.idx.usu.get(id)) || { nome: id ? '(usuário removido)' : '—' },
  inspecoesDe: id => Store.idx.porPonto.get(id) || [],
  fotosDe: id => Store.idx.fotos.get(id) || [],
  trocasDe: id => Store.idx.trocas.get(id) || [],
  /** agentes extintores cadastrados pelo administrador (+ o valor atual, se não estiver na lista) */
  agentes(atual) { const l = (this.S.agentes || []).map(a => a.nome); if (atual && !l.includes(atual)) l.push(atual); return l.sort((a, b) => a.localeCompare(b, 'pt')); },
  categorias(todas) { return this.S.cats.filter(c => todas || c.ativo !== false).sort((a, b) => a.ordem - b.ordem || a.nome.localeCompare(b.nome)); },

  /* ---------- cache local ---------- */
  async lerCache(uid) {
    try { const c = await IDB.get('retrato'); if (c && c.eu && c.eu.id === uid) { this.S = c; this.reindexar(); return true; } } catch (e) { console.warn(e); }
    return false;
  },
  salvarCache() { if (this.S?.eu) IDB.set('retrato', this.S).catch(e => console.warn('cache', e)); },

  /* ---------- perfil e organização ---------- */
  async perfil(user) {
    const { data: mems, error } = await sb.from('membros').select('id, org_id, usuario_id, nome, papel, ativo, trocar_senha').eq('usuario_id', user.id).eq('ativo', true);
    if (error) throw error;
    if (!mems.length) return null;
    const m = mems[0];
    return { id: user.id, email: user.email, nome: m.nome, papel: m.papel, membroId: m.id, org: m.org_id, trocar: m.trocar_senha };
  },

  /* ---------- carga completa da unidade ---------- */
  async carregar(eu, unidadeId) {
    if (this.carregando) return this._p;
    this.carregando = true;
    this._p = (async () => {
      const desde = new Date(Date.now() - CONFIG.DIAS_CARGA * 864e5).toISOString();
      const org = eu.org;
      const [{ data: orgRow, error: e1 }, unidades] = await Promise.all([
        sb.from('organizacoes').select('id, nome, fuso, config').eq('id', org).single(),
        todos(() => sb.from('unidades').select('id, nome').eq('org_id', org).order('nome'))
      ]);
      if (e1) throw e1;
      if (!unidades.length) throw new Error('Seu usuário não tem acesso a nenhuma unidade. Fale com o administrador.');
      const unidade = unidades.find(u => u.id === unidadeId) || unidades.find(u => u.id === this.S?.unidade?.id) || unidades[0];
      const U = unidade.id;
      const [membros, usuarios, cats, gers, pontos, insp, fotos, trocas, alts, desvios, reserva, movs, dests, envios, mu, agentes] = await Promise.all([
        todos(() => sb.from('membros').select('id, usuario_id, nome, papel, ativo, trocar_senha, criado_em').eq('org_id', org).order('nome')),
        todos(() => sb.from('usuarios').select('id, email, nome')),
        todos(() => sb.from('categorias').select('id, chave, nome, nome_plural, prefixo, periodicidade, ordem, ativo, icone, checklist').eq('org_id', org).order('ordem')),
        todos(() => sb.from('gerencias').select('id, nome, sigla, unidade_id').eq('unidade_id', U).order('nome')),
        todos(() => sb.from('pontos').select('*').eq('unidade_id', U).order('codigo')),
        todos(() => sb.from('inspecoes').select('id, ponto_id, data_inspecao, recebida_em, periodicidade, ciclo_referencia, status, observacoes, checklist, resumo_nc, origem, inspetor_id, sinc_tardia, anulada, anulada_por, anulada_em, motivo_anulacao').eq('unidade_id', U).gte('data_inspecao', desde).order('data_inspecao', { ascending: false })),
        todos(() => sb.from('fotos').select('id, registro_id, tipo, path, bytes, criado_em').eq('unidade_id', U).gte('criado_em', desde)),
        todos(() => sb.from('trocas').select('*').eq('unidade_id', U).order('criado_em', { ascending: false })),
        todos(() => sb.from('alteracoes').select('*').eq('unidade_id', U).gte('criado_em', desde).order('criado_em', { ascending: false })),
        todos(() => sb.from('desvios').select('*').eq('unidade_id', U).order('acionado_em', { ascending: false })),
        todos(() => sb.from('reserva_estoque').select('agente, quantidade, minimo, atualizado_em').eq('unidade_id', U).order('agente')),
        todos(() => sb.from('reserva_movimentos').select('*').eq('unidade_id', U).gte('criado_em', desde).order('criado_em', { ascending: false })),
        todos(() => sb.from('destinatarios').select('*').eq('org_id', org).order('papel')),
        todos(() => sb.from('envios_email').select('id, desvio_id, destinatarios, status, erro, enviado_em').eq('org_id', org).order('enviado_em', { ascending: false })),
        todos(() => sb.from('membro_unidades').select('membro_id, unidade_id')),
        todos(() => sb.from('agentes').select('id, nome').eq('org_id', org).order('nome'))
      ]);
      const catChave = Object.fromEntries(cats.map(c => [c.id, c.chave]));
      const S = this.vazio();
      Object.assign(S, {
        eu, org: { id: orgRow.id, nome: orgRow.nome, fuso: orgRow.fuso, config: { regra_foto: 'nc', max_fotos: 3, ...(orgRow.config || {}) } },
        unidade, unidades, usuarios,
        membros: membros.map(m => ({ ...m, unidades: mu.filter(x => x.membro_id === m.id).map(x => x.unidade_id) })),
        cats: cats.map(c => ({ id: c.id, chave: c.chave, nome: c.nome, plural: c.nome_plural, prefixo: c.prefixo, per: c.periodicidade, ordem: c.ordem, ativo: c.ativo, icone: c.icone || ICONE_CAT[c.chave] || 'clipboard', checklist: c.checklist || {} })),
        gers, agentes, pontos: pontos.map(p => mapPonto(p, catChave)), insp: insp.map(mapInsp), fotos, trocas, alts, desvios, reserva, movs, dests, envios,
        cargaEm: new Date().toISOString()
      });
      // mantém o que ainda está na fila (não chegou ao servidor)
      const fila = await Fila.itens();
      for (const it of fila) Fila.aplicarLocal(S, it);
      this.S = S; this.reindexar(); this.salvarCache(); this.ultimaCarga = Date.now();
      return S;
    })();
    try { return await this._p; } finally { this.carregando = false; }
  },

  /* ---------- inserções locais (otimistas) ---------- */
  addInsp(reg) { this.S.insp.push(reg); this.reindexar(); this.salvarCache(); }
};

/* =====================================================================
   FILA — envio em ordem, idempotente, com fotos em Blob
   tipos: inspecao | conferir | foto | troca | desvio
   ===================================================================== */
export const Fila = {
  enviando: false,
  ouvintes: new Set(),
  cache: [],
  async itens() { try { this.cache = (await IDB.filaTodos()).sort((a, b) => a.ord - b.ord); } catch (e) { this.cache = []; } return this.cache; },
  pendentes() { return this.cache.filter(i => !i.erro); },
  comErro() { return this.cache.filter(i => i.erro); },
  avisar() { this.ouvintes.forEach(f => { try { f(); } catch (e) { console.warn(e); } }); },

  async incluir(tipo, dados, grupo, extra = {}) {
    const it = { id: Util.uuid(), ord: Date.now() + Math.random(), tipo, dados, grupo, uid: Store.sessao?.user?.id || null, criado: new Date().toISOString(), tentativas: 0, erro: null, ...extra };
    await IDB.filaPut(it); await this.itens(); this.avisar();
    return it;
  },

  /* reaplica no retrato o que está na fila (depois de recarregar do servidor) */
  aplicarLocal(S, it) {
    const d = it.dados;
    if (it.tipo === 'inspecao' && !S.insp.some(i => i.id === d.id)) S.insp.push({ ...it.local, sync: 'fila' });
    if (it.tipo === 'desvio' && !S.desvios.some(x => x.id === d.id)) S.desvios.push({ ...it.local, _fila: true });
    if (it.tipo === 'foto' && !S.fotos.some(f => f.path === d.path)) S.fotos.push({ id: it.id, registro_id: d.registro_id, tipo: d.tipo, path: d.path, _blob: it.blob, _fila: true });
  },

  async processar() {
    if (this.enviando || !navigator.onLine || !Store.sessao) return { enviados: 0 };
    this.enviando = true; this.avisar();
    let enviados = 0, falhou = new Set(), parouRede = false;
    try {
      const eu = Store.sessao?.user?.id;
      for (const it of await this.itens()) {
        if (it.uid && eu && it.uid !== eu) continue;   // registro de outro usuário deste aparelho: só ele envia
        if (it.erro) { falhou.add(it.grupo); continue; }
        if (falhou.has(it.grupo)) continue;
        try {
          await this.enviar(it);
          await IDB.filaDel(it.id); enviados++;
          this.marcarEnviado(it);
        } catch (e) {
          if (ehRede(e)) { parouRede = true; break; }
          it.tentativas++; it.erro = msgErro(e); it.erroEm = new Date().toISOString();
          await IDB.filaPut(it); falhou.add(it.grupo);
          console.warn('fila', it.tipo, e);
        }
      }
    } finally {
      this.enviando = false; await this.itens(); this.avisar();
    }
    return { enviados, parouRede, erros: this.comErro().length };
  },

  async enviar(it) {
    const d = it.dados;
    switch (it.tipo) {
      case 'inspecao': {
        const { error } = await sb.from('inspecoes').upsert(d, { onConflict: 'id', ignoreDuplicates: true });
        if (error) throw error; return;
      }
      case 'conferir': await rpc('conferir_ponto', { p: d }); return;
      case 'troca': await rpc('registrar_troca', { p: d }); return;
      case 'desvio': { const num = await rpc('registrar_desvio', { p: d }); it._numero = num; return; }
      case 'foto': {
        const blob = it.blob;
        const up = await sb.storage.from('fotos').upload(d.path, blob, { contentType: 'image/jpeg', upsert: false });
        if (up.error && !/exist|duplicate|409/i.test(up.error.message + (up.error.statusCode || ''))) throw up.error;
        const { error } = await sb.from('fotos').upsert({ org_id: d.org_id, unidade_id: d.unidade_id, registro_id: d.registro_id, tipo: d.tipo, path: d.path, bytes: blob.size }, { onConflict: 'path', ignoreDuplicates: true });
        if (error) throw error; return;
      }
    }
  },

  marcarEnviado(it) {
    const S = Store.S; if (!S) return;
    if (it.tipo === 'inspecao') { const r = S.insp.find(i => i.id === it.dados.id); if (r) r.sync = 'enviado'; }
    if (it.tipo === 'desvio') { const r = S.desvios.find(x => x.id === it.dados.id); if (r) { r.numero = it._numero; delete r._fila; } }
    if (it.tipo === 'foto') { const r = S.fotos.find(f => f.path === it.dados.path); if (r) delete r._fila; }
  },

  async descartar(id) {
    const it = this.cache.find(x => x.id === id); if (!it) return;
    const doGrupo = this.cache.filter(x => x.grupo === it.grupo);
    for (const x of doGrupo) await IDB.filaDel(x.id);
    const S = Store.S;
    if (S) { S.insp = S.insp.filter(i => !(i.id === it.grupo && i.sync === 'fila')); S.desvios = S.desvios.filter(x => !(x.id === it.grupo && x._fila)); S.fotos = S.fotos.filter(f => !(f.registro_id === it.grupo && f._fila)); Store.reindexar(); Store.salvarCache(); }
    await this.itens(); this.avisar();
  },
  async tentarDeNovo() { for (const it of this.comErro()) { it.erro = null; await IDB.filaPut(it); } await this.itens(); return this.processar(); }
};

/* ---------------- fotos: compressão e URLs assinadas ---------------- */
export const Fotos = {
  urls: new Map(),   // path → { url, ate }
  /** JPEG ~1280px, qualidade 0.7 (≈120–200 KB) — limite do bucket é 1 MB */
  async comprimir(file, max = 1280, q = 0.7) {
    const bmp = await new Promise((ok, er) => { const i = new Image(); i.onload = () => ok(i); i.onerror = er; i.src = URL.createObjectURL(file); });
    try {
      const k = Math.min(1, max / Math.max(bmp.naturalWidth, bmp.naturalHeight));
      const cv = document.createElement('canvas'); cv.width = Math.round(bmp.naturalWidth * k); cv.height = Math.round(bmp.naturalHeight * k);
      cv.getContext('2d').drawImage(bmp, 0, 0, cv.width, cv.height);
      let blob = await new Promise(ok => cv.toBlob(ok, 'image/jpeg', q));
      if (blob.size > 900 * 1024) blob = await new Promise(ok => cv.toBlob(ok, 'image/jpeg', 0.5));
      return blob;
    } finally { URL.revokeObjectURL(bmp.src); }
  },
  async urlsDe(lista) {
    const agora = Date.now(), faltam = [], out = {};
    for (const f of lista) {
      if (f._blob) { out[f.path] = f._url || (f._url = URL.createObjectURL(f._blob)); continue; }
      const c = this.urls.get(f.path);
      if (c && c.ate > agora) out[f.path] = c.url; else faltam.push(f.path);
    }
    if (faltam.length && navigator.onLine) {
      const { data, error } = await sb.storage.from('fotos').createSignedUrls(faltam, 600);   // 10 minutos
      if (!error) for (const r of data) if (r.signedUrl) { this.urls.set(r.path, { url: r.signedUrl, ate: agora + 540e3 }); out[r.path] = r.signedUrl; }
    }
    return out;
  }
};

/* ---------------- regras de negócio derivadas do retrato ---------------- */
export const Regras = {
  situacao(e) {
    const per = Store.cat(e.cat).per, agora = new Date();
    const validas = Store.inspecoesDe(e.id).filter(i => !i.anulada);
    const atual = Ciclos.de(agora, per), anterior = Ciclos.de(Ciclos.anteriorData(agora, per), per);
    const noCiclo = validas.filter(i => (i.ciclo && i.ciclo !== '-' ? i.ciclo : Ciclos.de(new Date(i.dt), per)) === atual);
    const ultima = validas[0] || null;
    const pendente = e.ativo && noCiclo.length === 0;
    const criadoAntes = new Date(e.criado) < Ciclos.anteriorData(agora, per);
    const perdido = pendente && criadoAntes && !validas.some(i => i.ciclo === anterior);
    const ncAberta = e.ativo && ultima && ultima.st === 'nc';
    return { per, atual, noCiclo, ultima, pendente, perdido, ncAberta, vence: pendente && Ciclos.venceBreve(per, agora), statusCiclo: noCiclo[0]?.st || null };
  },
  pode(acao) {
    const p = Store.S?.eu?.papel;
    const mapa = { inspecionar: ['owner', 'admin', 'inspetor'], admin: ['owner', 'admin'], verAdmin: ['owner', 'admin', 'admin_leitura'], gestor: ['owner', 'admin', 'admin_leitura'], anular: ['owner', 'admin'], owner: ['owner'], leitura: ['inspetor_leitura', 'admin_leitura'] };
    return (mapa[acao] || []).includes(p);
  },
  n2(e) {
    const v = e.n2; if (!v || !/^\d{4}-\d{2}$/.test(v)) return null;
    const hoje = Ciclos.mensal(new Date()), [a, m] = v.split('-').map(Number), lim = new Date(a, m + 1, 1);
    const rot = `${Util.pad(m)}/${a}`;
    if (v < hoje) return { st: 'vencida', rot }; if (v === hoje) return { st: 'mes', rot };
    return lim - new Date() < 75 * 864e5 ? { st: 'proxima', rot } : { st: 'ok', rot };
  },
  textoNC: i => i ? (i.resumo || i.obs || 'Não conforme') : '',
  inicioNC(e) {
    const v = Store.inspecoesDe(e.id).filter(i => !i.anulada); let d = v[0]?.dt;
    for (const i of v) { if (i.st === 'nc') d = i.dt; else break; }
    return d;
  },
  ncsAbertas(gerFiltro) {
    return Store.S.pontos.filter(e => e.ativo && (!gerFiltro || e.ger === gerFiltro))
      .map(e => ({ e, s: Regras.situacao(e) })).filter(x => x.s.ncAberta)
      .map(x => ({ ...x, desde: Regras.inicioNC(x.e) })).sort((a, b) => a.desde.localeCompare(b.desde));
  },
  textoBusca(e) {
    const g = Store.ger(e.ger), c = Store.cat(e.cat);
    return [e.codigo, c.nome, c.plural, SINONIMOS[e.cat] || e.cat, e.subtipo, e.agente, e.cap, g.nome, g.sigla, e.area, e.local, e.resp ? Store.usuario(e.resp).nome : '', e.dados?.responsavel || '',
      e.fab ? 'cilindro ' + e.fab : '', e.dados?.origem?.numero ? 'nº ' + e.dados.origem.numero : '', e.qr ? e.qr + ' ' + e.qr.slice(0, 4) + '-' + e.qr.slice(4) : ''].join(' · ');
  }
};
