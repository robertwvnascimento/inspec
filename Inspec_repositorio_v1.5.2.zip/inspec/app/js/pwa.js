/* Inspec — instalação do PWA e atualização do Service Worker */
import { A } from './ns.js';
import { UI } from './ui.js';

export const PWA = {
  prompt: null, reg: null, novaPronta: false,
  instalado: () => matchMedia('(display-mode: standalone)').matches || navigator.standalone === true,
  ios: () => /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1),
  podeInstalar() { return !PWA.instalado() && (!!PWA.prompt || PWA.ios()); },
  async instalar() {
    if (PWA.instalado()) return UI.toast('O Inspec já está instalado neste aparelho.');
    if (PWA.prompt) {
      PWA.prompt.prompt();
      const r = await PWA.prompt.userChoice; PWA.prompt = null;
      if (r.outcome === 'accepted') UI.toast('Inspec instalado. Abra pelo ícone na tela inicial.');
      A.render?.(); return;
    }
    if (PWA.ios()) return UI.dialogo({ titulo: 'Instalar no iPhone / iPad', corpo: `<ol style="padding-left:20px;line-height:1.7;margin:0"><li>Abra o Inspec no <b>Safari</b>.</li><li>Toque em <b>Compartilhar</b> (quadrado com seta para cima).</li><li>Escolha <b>Adicionar à Tela de Início</b> e confirme em <b>Adicionar</b>.</li><li>Abra pelo novo ícone: o app ocupa a tela inteira e funciona sem internet.</li></ol>` });
    UI.dialogo({ titulo: 'Instalar o Inspec', corpo: `<p style="margin-top:0">Este navegador não ofereceu a instalação automática. Use o menu do navegador (⋮) → <b>Instalar app</b> ou <b>Adicionar à tela inicial</b>.</p><p class="hint">No computador, o Chrome e o Edge mostram também um ícone de instalação na barra de endereço.</p>` });
  },
  /** versão do cache offline instalado (nome do cache do Service Worker) */
  async versaoOffline() {
    try { const ks = (await caches.keys()).filter(k => /^inspec-v/.test(k)).sort(); return ks.length ? ks[ks.length - 1].replace('inspec-v', '') : null; } catch (e) { return null; }
  },
  /** procura versão nova no servidor; devolve 'nova' | 'atual' | 'sem-sw' | 'offline' */
  async procurar() {
    if (!navigator.onLine) return 'offline';
    const reg = PWA.reg || await navigator.serviceWorker?.getRegistration();
    if (!reg) return 'sem-sw';
    await reg.update();
    const nw = reg.installing || reg.waiting;
    if (!nw) return PWA.novaPronta ? 'nova' : 'atual';
    if (nw.state !== 'activated') await new Promise(ok => { const f = () => { if (nw.state === 'activated' || nw.state === 'redundant') { nw.removeEventListener('statechange', f); ok(); } }; nw.addEventListener('statechange', f); setTimeout(ok, 15000); });
    PWA.novaPronta = true; return 'nova';
  }
};
A.PWA = PWA;

window.addEventListener('beforeinstallprompt', ev => { ev.preventDefault(); PWA.prompt = ev; if (A.Router?.modo === 'app') { if (!/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName || '')) A.render(); } else if (A.Router?.modo === 'login' && !document.getElementById('lg-email')?.value) A.Router.tela(A.V.login()); });
window.addEventListener('appinstalled', () => { PWA.prompt = null; UI.toast('Inspec instalado no aparelho.'); });

if ('serviceWorker' in navigator && (location.protocol === 'https:' || ['localhost', '127.0.0.1'].includes(location.hostname))) {
  const tinhaControle = !!navigator.serviceWorker.controller;
  navigator.serviceWorker.register('/sw.js').then(reg => {
    PWA.reg = reg;
    reg.addEventListener('updatefound', () => {
      const nw = reg.installing;
      nw?.addEventListener('statechange', () => { if (nw.state === 'activated' && tinhaControle) PWA.novaPronta = true; });
    });
  }).catch(e => console.warn('SW', e));
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (!tinhaControle) return;                     // primeira instalação: nada a avisar
    PWA.novaPronta = true;
    const t = document.getElementById('toast');
    t.innerHTML = 'Nova versão do Inspec instalada. <button class="linkbtn" data-action="pwa-recarregar" style="color:#7FE0C2;padding:0 0 0 6px;font-weight:700">Recarregar agora</button>';
    t.classList.add('on'); setTimeout(() => t.classList.remove('on'), 15000);
  });
}
Object.assign(A.Acoes, {
  'pwa-instalar': () => PWA.instalar(),
  'pwa-recarregar': () => location.reload(),
  'pwa-dispensar': () => { try { localStorage.setItem('inspec-pwa-dispensado', String(Date.now())); } catch (e) { /* ignore */ } A.render(); }
});
