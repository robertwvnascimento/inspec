/* Inspec — versões do app. A primeira linha é a versão em execução.
   Ao publicar: acrescente uma linha no topo e use o MESMO número em sw.js (VERSAO = 'inspec-vX.Y.Z'). */
export const VERSOES = [
  { v: '1.5.2', data: '2026-10-02', itens: [
    'Menu reorganizado: "Histórico" passou a se chamar "Inspeções" e fica logo abaixo de "Nova inspeção", seguido de "Não conformidades".',
    '"Comunicado de desvio" passou a se chamar "Novo comunicado de desvio".'
  ] },
  { v: '1.5.1', data: '2026-10-02', itens: [
    'Segurança: Inspetor, Inspetor (leitura) e Admin (leitura) são desconectados após 5 minutos sem uso, com aviso 30 segundos antes. Registros ainda não enviados ficam guardados e sobem quando o mesmo usuário entrar de novo.',
    'Novo "Registros de acesso (IP)" na Administração, visível só para Owner e Admin: data, hora, IP e navegador de cada login, saída e senha errada, gravados pelo servidor (Marco Civil da Internet).',
    'Menu Relatórios com os mesmos filtros do Painel de gestão (período, gerência, categoria e bombeiro) — os filtros escolhidos num valem no outro.',
    'Relatórios com muitas colunas (pontos e etiquetas QR, desvios, rastreabilidade geral) saem em A4 paisagem, sem cortar dados.',
    'Administração no computador: as abas quebram linha e todas ficam visíveis.',
    'Bibliotecas atualizadas (SheetJS 0.20.3 e jsPDF 4.2.1), corrigindo vulnerabilidades conhecidas; avisos de licença de terceiros incluídos (Sobre o sistema → Licenças de terceiros).'
  ] },
  { v: '1.5.0', data: '2026-10-01', itens: [
    'Novos perfis: Owner, Admin, Inspetor, Inspetor (leitura) e Admin (leitura). Perfis de leitura veem tudo do perfil correspondente, sem poder alterar nada. O antigo "Consulta" virou Admin (leitura).',
    'Owner pode zerar o sistema (Administração → Configurações) para recomeçar depois dos testes; backup completo em JSON passou a ser exclusivo do Owner.',
    'Categorias de ponto gerenciáveis: criar, editar (nome, periodicidade, ícone, itens do checklist) e excluir/inativar.',
    'Todos os relatórios com Visualizar/PDF e Excel; rastreabilidade por ponto (dossiê completo do ponto) ou de todos.',
    'Painel de gestão mostra os relatórios na própria tela, em abas, com os mesmos filtros.',
    'One Page: visualização na tela com as fotos anexadas, e PDF com as imagens em tamanho legível.',
    'Corrigido: no celular, o teclado fechava sozinho ao digitar na busca.'
  ] },
  { v: '1.4.1', data: '2026-10-01', itens: [
    'Hidrante: teste hidrostático por mangueira, só com mês/ano. Para cada mangueira do abrigo, o último e o próximo teste são obrigatórios (4 mangueiras = 8 datas).',
    'Aviso de teste vencido por mangueira; datas aparecem na ficha do ponto, no checklist e nas planilhas.'
  ] },
  { v: '1.4.0', data: '2026-10-01', itens: [
    'Placa QR com o logo oficial do Inspec e só o essencial: tipo, código do ponto, gerência, ID do QR Code e instrução de uso.',
    'Agentes extintores gerenciados pelo administrador (Administração → Agentes extintores): cadastrar, renomear e excluir. A opção "Outra" foi retirada — se faltar um agente, o bombeiro pede ao administrador.',
    'Comunicado de desvio: novo meio de comunicação "Pessoalmente"; os meios não são mais numerados.'
  ] },
  { v: '1.3.1', data: '2026-10-01', itens: [
    'Placas de QR Code em meia folha A4 (210 × 148 mm), 2 por folha com linha de corte: QR grande, código do ponto em destaque, tipo, local e instrução de leitura.',
    'A placa é o modelo padrão em Etiquetas QR e no botão "Imprimir placa QR" da ficha do ponto; os modelos Pimaco continuam disponíveis.'
  ] },
  { v: '1.3.0', data: '2026-10-01', itens: [
    'Nova "Galeria de fotos" (somente administradores): todas as evidências da unidade num só lugar, agrupadas por ponto, por dia ou por origem.',
    'Filtros por período, origem (NC, conforme, desvio), gerência, tipo de ponto, autor e texto.',
    'Foto ampliada com navegação (setas do teclado), dados da inspeção ou do desvio, atalho para a ficha e botão para baixar.'
  ] },
  { v: '1.2.0', data: '2026-10-01', itens: [
    'Novo "Histórico do sistema" na Administração: tudo o que acontece fica registrado — acessos, saídas, senhas, tentativas de senha errada, cadastros e alterações (valor anterior → novo), inspeções, fotos, desvios, trocas, reserva, usuários, configurações, exportações e backups.',
    'Filtros por período, usuário, tipo de evento e texto; exportação em Excel.',
    'Último login e última atividade de cada usuário.',
    'Os registros são gravados pelo banco e não podem ser editados nem apagados (banco v1.1).'
  ] },
  { v: '1.1.0', data: '2026-10-01', itens: [
    'Nova tela "Sobre o sistema": versão do app, versão offline, procurar atualização, diagnóstico e histórico de versões.',
    'Botão "Instalar o Inspec" no Menu e no Início (Android/Chrome/Edge) e instruções para iPhone/iPad.',
    'Aviso quando uma nova versão é instalada, com botão para recarregar.'
  ] },
  { v: '1.0.0', data: '2026-10-01', itens: [
    'Primeira versão de produção ligada ao Supabase: login fechado, troca de senha no 1º acesso e recuperação por e-mail.',
    'Pontos com QR único, leitor pela câmera/foto/ID e etiquetas para impressão.',
    'Inspeções com checklist, conferência do equipamento instalado e fotos em bucket privado.',
    'Uso sem internet com fila de envio automática.',
    'Trocas de equipamento, histórico de alterações, reserva técnica e comunicado de desvio com One Page.',
    'Painel de gestão, relatórios (PDF/Excel), administração, backup e auditoria.'
  ] }
];
export const VERSAO = VERSOES[0].v;
