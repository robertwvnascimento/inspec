/* Inspec — acesso ao Supabase (cliente único, paginação, tradução de erros) */
import { CONFIG } from '../config.js';

export const configurado = () => !/SEU-PROJETO|COLE_AQUI/.test(CONFIG.SUPABASE_URL + CONFIG.SUPABASE_KEY);

export const sb = window.supabase.createClient(CONFIG.SUPABASE_URL, CONFIG.SUPABASE_KEY, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true, storageKey: 'inspec-auth' }
});

/** Lê todas as linhas de uma consulta, em páginas de 1000 (limite do PostgREST). */
export async function todos(montar, pagina = 1000) {
  const out = [];
  for (let de = 0; ; de += pagina) {
    const { data, error } = await montar().range(de, de + pagina - 1);
    if (error) throw error;
    out.push(...data);
    if (data.length < pagina) return out;
  }
}

export async function rpc(nome, args) {
  const { data, error } = await sb.rpc(nome, args);
  if (error) throw error;
  return data;
}

/** Chama uma Edge Function com o JWT do usuário. */
export async function funcao(nome, corpo) {
  const { data, error } = await sb.functions.invoke(nome, { body: corpo });
  if (error) {
    let msg = error.message;
    try { const j = await error.context?.json?.(); if (j?.erro) msg = j.erro; } catch (e) { /* corpo não-JSON */ }
    const er = new Error(msg); er.funcao = true; throw er;
  }
  if (data?.erro) throw new Error(data.erro);
  return data;
}

/** Falha de rede (vale tentar de novo depois) × erro do servidor (não adianta repetir). */
export function ehRede(e) {
  if (!navigator.onLine) return true;
  if (!e || e.funcao) return false;
  if (e.code && /^[0-9A-Z]{5}$/.test(e.code)) return false;                // erro SQL/PostgREST
  if (typeof e.status === 'number' && e.status >= 400 && e.status < 500) return false;
  return /fetch|network|load failed|timeout|ECONN|Failed to|NetworkError|aborted/i.test(String(e.message || e));
}

export function msgErro(e) {
  const m = String(e?.message || e || 'Erro desconhecido');
  if (ehRede(e)) return 'Sem conexão com o servidor. Tente novamente quando a internet voltar.';
  if (/Invalid login credentials/i.test(m)) return 'E-mail ou senha incorretos.';
  if (/Email not confirmed/i.test(m)) return 'E-mail ainda não confirmado. Fale com o administrador.';
  if (/JWT expired|invalid JWT|Auth session missing/i.test(m)) return 'Sua sessão expirou. Entre novamente.';
  if (e?.code === '42501' || /row-level security|permission denied/i.test(m)) return 'Sem permissão para esta ação. ' + (/Somente|Sem permissão/.test(m) ? m : '');
  if (e?.code === '23505') return 'Já existe um registro com este valor (código ou e-mail repetido).';
  return m.replace(/^.*?ERROR:\s*/i, '');
}

/** resumo do aparelho para a auditoria (sem dados pessoais) */
export function dispositivo() {
  const u = navigator.userAgent;
  const so = /iPhone|iPad|iPod/.test(u) ? 'iPhone/iPad' : /Android/.test(u) ? 'Android' : /Windows/.test(u) ? 'Windows' : /Mac OS/.test(u) ? 'Mac' : /Linux/.test(u) ? 'Linux' : 'Outro';
  const nav = /Edg\//.test(u) ? 'Edge' : /OPR\//.test(u) ? 'Opera' : /Firefox\//.test(u) ? 'Firefox' : /Chrome\//.test(u) ? 'Chrome' : /Safari\//.test(u) ? 'Safari' : 'Navegador';
  const app = matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
  return `${so} · ${nav}${app ? ' · app instalado' : ''}`;
}
/** registra um evento na auditoria (login, exportação…). Nunca atrapalha o uso: falhas são ignoradas. */
export function evento(acao, detalhe = {}) {
  if (!navigator.onLine) return Promise.resolve();
  return sb.rpc('registrar_evento', { p_acao: acao, p_detalhe: { ...detalhe, dispositivo: dispositivo() } }).then(() => {}, () => {});
}
