/* =====================================================================
   Inspec — configuração do ambiente (ÚNICO arquivo a editar no deploy)
   Preencha com os dados de Supabase → Project Settings → API Keys.
   A Publishable key é pública por design (a segurança está na RLS).
   NUNCA coloque aqui a Secret key / service_role.
   ===================================================================== */
export const CONFIG = {
  SUPABASE_URL: 'https://valqiddnxrtlyxzmshft.supabase.co',
  SUPABASE_KEY: 'sb_publishable_LyKFp3iEqN2Fi7BdpwOE2w_UpX_gTxV',
  DOMINIO_QR: 'HTTPS://INSPEC.RWNITSOLUTIONS.COM.BR/Q/',   // conteúdo gravado nas etiquetas
  DIAS_CARGA: 400                                         // histórico mantido no aparelho (dias)
};
