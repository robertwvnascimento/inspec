/* Inspec — Service Worker: o app abre e funciona sem internet.
   Suba VERSAO a cada publicação para os aparelhos baixarem a versão nova.
   Requisições ao Supabase (outro domínio) NUNCA passam pelo cache. */
const VERSAO = 'inspec-v1.5.2';
const ARQUIVOS = [
  '/', '/index.html', '/config.js', '/manifest.webmanifest', '/favicon.ico',
  '/css/app.css', '/css/prod.css',
  '/img/logo.png', '/img/logo_placa.png', '/img/simbolo.png',
  '/icons/icon-192.png', '/icons/icon-512.png', '/icons/icon-maskable-512.png', '/icons/apple-touch-icon.png', '/icons/favicon-32.png',
  '/vendor/supabase.umd.js', '/vendor/qrcode-generator.min.js', '/vendor/jsqr.min.js', '/vendor/jspdf.umd.min.js', '/vendor/xlsx.mini.min.js', '/vendor/LICENCAS.txt',
  '/js/qr-path.js', '/js/ns.js', '/js/versoes.js', '/js/pwa.js', '/js/views/sobre.js', '/js/util.js', '/js/db.js', '/js/dados.js', '/js/ui.js', '/js/qr.js', '/js/janela.js', '/js/core.js',
  '/js/views/inicio.js', '/js/views/buscar.js', '/js/views/inspecao.js', '/js/views/ponto.js', '/js/views/ncs.js', '/js/views/desvios.js',
  '/js/views/historico.js', '/js/views/painel.js', '/js/views/relatorios.js', '/js/views/admin.js', '/js/views/menu.js', '/js/views/auditoria.js', '/js/views/galeria.js'
];

self.addEventListener('install', ev => {
  ev.waitUntil(caches.open(VERSAO).then(c => c.addAll(ARQUIVOS.map(u => new Request(u, { cache: 'reload' })))).then(() => self.skipWaiting()));
});
self.addEventListener('activate', ev => {
  ev.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k.startsWith('inspec-') && k !== VERSAO).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', ev => {
  const req = ev.request, url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== location.origin) return;            // Supabase, fontes: rede direta
  const estatico = ARQUIVOS.includes(url.pathname) || /^\/(js|css|img|icons|vendor)\//.test(url.pathname);
  if (req.mode === 'navigate') {                                                   // qualquer página (inclusive /Q/<ID>) → app
    ev.respondWith(fetch(req).catch(() => caches.match('/index.html')));
    return;
  }
  if (!estatico) return;                                                           // API, /data/ e o resto: sempre da rede
  ev.respondWith(caches.match(req, { ignoreSearch: true }).then(r => r || fetch(req).then(resp => {
    if (resp.ok && resp.type === 'basic') { const cp = resp.clone(); caches.open(VERSAO).then(c => c.put(req, cp)); }
    return resp;
  })));
});
